// Builds src/lib/openings/data/book.json — Coachlet's built-in opening book.
//
//   node tools/build-book.mjs
//
// Inputs : tools/book-seed.txt            (curated move shares / results for the main lines)
//          src/lib/openings/data/openings.json (3,865 named openings, lichess-org/chess-openings, CC0)
// Output : a position -> moves table in the same shape a Lichess-style explorer shows:
//          per move: games, white wins, draws, black wins.
//
// The figures are APPROXIMATE (modelled on typical master/strong-player proportions), not live data.
// Seeded positions use the curated shares; every other catalogue position gets shares from how much
// named theory runs through each move, and results inherited from the parent move with a small
// deterministic spread. Transpositions are merged by position (EPD), like a real explorer.
import { Chess } from 'chess.js'
import { readFileSync, writeFileSync } from 'node:fs'

const ROOT_TOTAL = 5_000_000
const CATALOGUE_FLOOR = 5 // every named-opening move keeps at least this many games (or the parent's total if smaller)
const UNSEEDED_COVERAGE = 0.93 // share of an unseeded position's games that go to catalogue moves
const SEEDED_LEFTOVER_CAP = 0.55 // part of a seeded position's unlisted share that may go to catalogue moves
const MAX_MOVES = 20

const epdOf = (fen) => fen.split(' ').slice(0, 4).join(' ')
const START = new Chess().fen()
const START_EPD = epdOf(START)

// ---- deterministic hash for result spread
function h32(s) {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) }
  return h >>> 0
}

// ---- legal move step with cache
const stepCache = new Map()
function step(fen, san) {
  const key = fen + '|' + san
  if (stepCache.has(key)) return stepCache.get(key)
  let out = null
  try {
    const c = new Chess(fen)
    const m = c.move(san)
    out = { san: m.san, uci: m.from + m.to + (m.promotion ?? ''), fen: c.fen() }
  } catch { /* illegal */ }
  stepCache.set(key, out)
  return out
}

// ---- 1. catalogue graph: epd -> Map(san -> {uci, childEpd, childFen, weight})
const rows = JSON.parse(readFileSync('src/lib/openings/data/openings.json', 'utf8'))
const nodes = new Map() // epd -> { fen, edges: Map<san, edge> }
const node = (fen) => {
  const e = epdOf(fen)
  if (!nodes.has(e)) nodes.set(e, { fen, edges: new Map() })
  return nodes.get(e)
}
node(START)
let badRows = 0
for (const [, , moves] of rows) {
  let fen = START
  for (const san of moves.split(' ').filter(Boolean)) {
    const s = step(fen, san)
    if (!s) { badRows++; break }
    const n = node(fen)
    let edge = n.edges.get(s.san)
    if (!edge) { edge = { san: s.san, uci: s.uci, childFen: s.fen, weight: 0, curated: null }; n.edges.set(s.san, edge) }
    edge.weight++
    fen = s.fen
    node(fen)
  }
}
if (badRows) console.warn(`warning: ${badRows} catalogue rows had an illegal move`)

// ---- 2. seed
const seeds = new Map() // epd -> [{san, share, res|null}]
let seedErrors = 0
for (const raw of readFileSync('tools/book-seed.txt', 'utf8').split('\n')) {
  const line = raw.trim()
  if (!line || line.startsWith('#')) continue
  const [pathPart, movePart] = line.split(' > ')
  if (movePart === undefined) { console.error('seed: bad line', line); seedErrors++; continue }
  let fen = START
  let ok = true
  if (pathPart.trim() !== '-') {
    for (const san of pathPart.trim().split(/\s+/)) {
      const s = step(fen, san)
      if (!s) { console.error(`seed: illegal "${san}" in path "${pathPart}"`); seedErrors++; ok = false; break }
      fen = s.fen
    }
  }
  if (!ok) continue
  const list = []
  for (const part of movePart.split('|')) {
    const tok = part.trim().split(/\s+/)
    const [name, shareTxt, resTxt] = tok
    if (!name || !/^[KQRBNOa-h][A-Za-z0-9+#=-]*$/.test(name)) continue // placeholder entries are ignored
    const share = Number(shareTxt)
    if (!(share > 0)) continue
    const s = step(fen, name)
    if (!s) { console.error(`seed: illegal move "${name}" after "${pathPart}"`); seedErrors++; continue }
    let res = null
    if (resTxt && /^\d+\/\d+\/\d+$/.test(resTxt)) {
      const [w, d, b] = resTxt.split('/').map(Number)
      if (Math.abs(w + d + b - 100) > 1) { console.error(`seed: results of ${name} after "${pathPart}" do not sum to 100`); seedErrors++ } else res = { w, d, b: 100 - w - d }
    }
    list.push({ san: s.san, uci: s.uci, childFen: s.fen, share, res })
  }
  const total = list.reduce((a, m) => a + m.share, 0)
  if (total > 100.5) { console.error(`seed: shares after "${pathPart}" sum to ${total}`); seedErrors++ }
  const e = epdOf(fen)
  if (seeds.has(e)) { console.error(`seed: duplicate position "${pathPart}"`); seedErrors++ }
  seeds.set(e, list)
  node(fen)
  for (const m of list) node(m.childFen)
}
if (seedErrors) { console.error(`${seedErrors} seed error(s)`); process.exit(1) }

// ---- 3. propagate game counts level by level (transpositions merge by position)
const pos = new Map() // epd -> { fen, level, total, w, d, b, moves: [] }
pos.set(START_EPD, { fen: START, level: 0, total: ROOT_TOTAL, w: 0, d: 0, b: 0, moves: [] })
let frontier = [START_EPD]
let level = 0
const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x))

while (frontier.length) {
  const next = new Set()
  for (const epd of frontier) {
    const p = pos.get(epd)
    const n = nodes.get(epd)
    const seed = seeds.get(epd) ?? []
    const seedSan = new Set(seed.map((m) => m.san))
    const catEdges = n ? [...n.edges.values()].filter((e) => !seedSan.has(e.san)) : []
    const seedSum = seed.reduce((a, m) => a + m.share, 0)

    // candidate edges with a share (percent of p.total)
    const cand = seed.map((m) => ({ san: m.san, uci: m.uci, childFen: m.childFen, share: m.share, res: m.res, floor: 0 }))
    const wsum = catEdges.reduce((a, e) => a + Math.pow(e.weight, 0.85), 0)
    if (catEdges.length && wsum > 0) {
      const pool = seed.length ? Math.max(0, 100 - seedSum) * SEEDED_LEFTOVER_CAP : UNSEEDED_COVERAGE * 100
      for (const e of catEdges) {
        cand.push({ san: e.san, uci: e.uci, childFen: e.childFen, share: (pool * Math.pow(e.weight, 0.85)) / wsum, res: null, floor: Math.min(CATALOGUE_FLOOR, p.total) })
      }
    }

    // position results used for inheritance (root is seeded fully, so its value is unused)
    const pt = p.w + p.d + p.b || 1
    const base = p.level === 0 ? { w: 39, d: 34, b: 27 } : { w: (p.w / pt) * 100, d: (p.d / pt) * 100, b: (p.b / pt) * 100 }

    const moves = []
    for (const c of cand) {
      let count = Math.max(Math.round((p.total * c.share) / 100), c.floor)
      if (count < 1) continue
      const childEpd = epdOf(c.childFen)
      const existing = pos.get(childEpd)
      if (existing && existing.level !== level + 1) continue // would create a cycle / out-of-order transposition
      let res = c.res
      if (!res) {
        const h = h32(epd + '|' + c.san)
        const dw = (h % 9) - 4
        const dd = ((h >>> 8) % 9) - 4
        const w = clamp(Math.round(base.w + dw), 8, 80)
        const d = clamp(Math.round(base.d + dd), 8, 80)
        res = { w, d, b: clamp(100 - w - d, 4, 80) }
        const s = res.w + res.d + res.b
        res.w = Math.round((res.w / s) * 100); res.d = Math.round((res.d / s) * 100); res.b = 100 - res.w - res.d
      }
      const w = Math.round((count * res.w) / 100)
      const d = Math.round((count * res.d) / 100)
      const b = count - w - d
      moves.push({ san: c.san, uci: c.uci, total: count, w, d, b, childFen: c.childFen })
    }
    moves.sort((a, b) => b.total - a.total || a.san.localeCompare(b.san))
    const kept = moves.slice(0, MAX_MOVES)
    p.moves = kept
    for (const m of kept) {
      const childEpd = epdOf(m.childFen)
      let ch = pos.get(childEpd)
      if (!ch) { ch = { fen: m.childFen, level: level + 1, total: 0, w: 0, d: 0, b: 0, moves: [] }; pos.set(childEpd, ch) }
      ch.total += m.total; ch.w += m.w; ch.d += m.d; ch.b += m.b
      next.add(childEpd)
    }
  }
  frontier = [...next]
  level++
}

// root results = sum of its moves
{
  const r = pos.get(START_EPD)
  r.w = r.moves.reduce((a, m) => a + m.w, 0)
  r.d = r.moves.reduce((a, m) => a + m.d, 0)
  r.b = r.moves.reduce((a, m) => a + m.b, 0)
  r.total = r.w + r.d + r.b
}

// ---- 4. write compact JSON: epd -> [total, w, d, b, [[san, uci, total, w, d, b], ...]]
const out = { v: 1, positions: {} }
for (const [epd, p] of pos) {
  out.positions[epd] = [p.total, p.w, p.d, p.b, p.moves.map((m) => [m.san, m.uci, m.total, m.w, m.d, m.b])]
}
writeFileSync('src/lib/openings/data/book.json', JSON.stringify(out))

// ---- 5. coverage report
let covered = 0
let missing = 0
for (const [, , moves, epd] of rows) {
  if (pos.has(epd)) covered++
  else missing++
}
const seedHits = [...seeds.keys()].filter((e) => pos.has(e)).length
console.log(`positions: ${pos.size}, max ply: ${level - 1}, seeded positions: ${seeds.size} (reached: ${seedHits})`)
console.log(`catalogue openings reachable in the book: ${covered}/${rows.length} (missing ${missing})`)
const rs = pos.get(START_EPD)
console.log('root:', rs.total, `W ${((rs.w / rs.total) * 100).toFixed(1)} D ${((rs.d / rs.total) * 100).toFixed(1)} B ${((rs.b / rs.total) * 100).toFixed(1)}`)
console.log(rs.moves.map((m) => `${m.san}:${m.total}`).join(' '))
