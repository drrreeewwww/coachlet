'use client'

import { ChevronLeft, ChevronRight, FlipVertical2, Pause, Play, RotateCcw } from 'lucide-react'

export type PlayMode = 'most-played' | 'engine' | 'selected'

export const MODE_LABEL: Record<PlayMode, { title: string; hint: string }> = {
  'most-played': { title: 'Most-played line', hint: 'Follows the opening book\'s most-played move for both sides.' },
  engine: { title: 'Engine best line', hint: 'Stockfish chooses the move for both sides (engine-generated, not from the book).' },
  selected: { title: 'Selected variation', hint: 'Replays the exact branch you built on the board.' },
}

interface Props {
  running: boolean
  atStart: boolean
  atEnd: boolean
  mode: PlayMode
  onMode: (m: PlayMode) => void
  speedMs: 1000 | 1500 | 2000
  onSpeed: (n: 1000 | 1500 | 2000) => void
  onPlay: () => void
  onPause: () => void
  onPrev: () => void
  onNext: () => void
  onRestart: () => void
  onFlip: () => void
  message: string | null
}

const b = 'inline-flex h-11 min-w-11 items-center justify-center rounded-md border border-[#3a3834] bg-[#262522] px-2.5 text-stone-100 transition hover:bg-[#33312d] disabled:cursor-not-allowed disabled:opacity-40'

export default function PlaybackBar(p: Props) {
  return (
    <div className="mt-2 space-y-2 rounded-lg border border-[#3a3834] bg-[#262522] p-2" role="group" aria-label="Playback controls">
      <div className="flex flex-wrap items-center justify-center gap-1.5">
        <button type="button" className={b} onClick={p.onRestart} disabled={p.atStart && !p.running} aria-label="Restart from the first move" title="Restart"><RotateCcw className="h-4 w-4" aria-hidden /></button>
        <button type="button" className={b} onClick={p.onPrev} disabled={p.atStart} aria-label="Previous move" title="Previous (←)"><ChevronLeft className="h-5 w-5" aria-hidden /></button>
        {p.running ? (
          <button type="button" className={`${b} gap-1.5 !bg-[#81b64c] px-4 font-bold !text-[#1c1b19]`} onClick={p.onPause} aria-label="Pause playback"><Pause className="h-4 w-4" aria-hidden /> Pause</button>
        ) : (
          <button type="button" className={`${b} gap-1.5 !bg-[#81b64c] px-4 font-bold !text-[#1c1b19]`} onClick={p.onPlay} aria-label="Play line"><Play className="h-4 w-4" aria-hidden /> Play</button>
        )}
        <button type="button" className={b} onClick={p.onNext} disabled={p.atEnd} aria-label="Next move" title="Next (→)"><ChevronRight className="h-5 w-5" aria-hidden /></button>
        <button type="button" className={b} onClick={p.onFlip} aria-label="Flip board" title="Flip board (F)"><FlipVertical2 className="h-4 w-4" aria-hidden /></button>
        <label className="flex items-center gap-1.5 text-[11px] text-stone-300">
          <span className="sr-only sm:not-sr-only">Speed</span>
          <select value={p.speedMs} onChange={(e) => p.onSpeed(Number(e.target.value) as 1000 | 1500 | 2000)} className="h-11 rounded-md border border-[#3a3834] bg-[#1e1d1b] px-2 text-xs text-stone-100" aria-label="Playback speed, seconds per move">
            <option value={1000}>1 s / move</option>
            <option value={1500}>1.5 s / move</option>
            <option value={2000}>2 s / move</option>
          </select>
        </label>
      </div>
      <div className="grid grid-cols-3 gap-1" role="radiogroup" aria-label="Playback mode">
        {(Object.keys(MODE_LABEL) as PlayMode[]).map((m) => (
          <button key={m} type="button" role="radio" aria-checked={p.mode === m} title={MODE_LABEL[m].hint} onClick={() => p.onMode(m)}
            className={`min-h-11 rounded-md px-1.5 py-1 text-[11px] font-bold leading-tight ${p.mode === m ? 'bg-[#81b64c]/20 text-[#a3d160] ring-1 ring-[#81b64c]' : 'bg-[#1e1d1b] text-stone-300 hover:bg-[#33312d]'}`}>
            {MODE_LABEL[m].title}
          </button>
        ))}
      </div>
      <p className="px-1 text-[11px] text-stone-400" role="status" aria-live="polite">{p.message ?? MODE_LABEL[p.mode].hint}</p>
    </div>
  )
}
