'use client'

import { useMemo, useState } from 'react'
import { BookOpen, Loader2 } from 'lucide-react'
import type { Analysis } from '@/lib/stockfish/engine'
import { formatScore } from '@/lib/evaluation/classify'
import { formatGames, moveShare, rankMoves, resultSplit, type BookMove, type BookPosition, type SortKey } from '@/lib/openings/book'

/** State of the opening book for the current position. */
export interface BookView {
  phase: 'loading' | 'ready' | 'error'
  position: BookPosition | null
  error?: string
}

interface DbProps {
  state: BookView
  onPlay: (m: BookMove) => void
  /** UCI of the move that is next in the current line (highlighted in the table). */
  selectedUci: string | null
  /** Name of the opening the board is currently in, if any. */
  openingLabel?: string | null
  onRetry?: () => void
}

const VISIBLE = 12
const pct = (n: number) => (n >= 10 ? n.toFixed(0) : n.toFixed(1))

/** White / draw / black result bar, Lichess style: segments sized by result, label shown when there is room. */
function ResultBar({ r, label }: { r: { white: number; draws: number; black: number }; label: string }) {
  return (
    <div className="flex h-6 overflow-hidden rounded text-[10px] font-bold leading-6" role="img" aria-label={label}>
      <div className="bg-stone-100 text-center text-stone-900" style={{ width: `${r.white}%` }}>{r.white >= 12 ? `${pct(r.white)}%` : ''}</div>
      <div className="bg-stone-500 text-center text-white" style={{ width: `${r.draws}%` }}>{r.draws >= 12 ? `${pct(r.draws)}%` : ''}</div>
      <div className="bg-stone-900 text-center text-stone-100 ring-1 ring-inset ring-stone-600" style={{ width: `${r.black}%` }}>{r.black >= 12 ? `${pct(r.black)}%` : ''}</div>
    </div>
  )
}

const SORTS: Array<{ key: SortKey; label: string; title: string }> = [
  { key: 'games', label: 'Games', title: 'Sort by number of games (most played first)' },
  { key: 'white', label: 'White', title: 'Sort by White win rate' },
  { key: 'draws', label: 'Draw', title: 'Sort by draw rate' },
  { key: 'black', label: 'Black', title: 'Sort by Black win rate' },
]

export function DatabasePanel(p: DbProps) {
  const [sort, setSort] = useState<SortKey>('games')
  const [showAll, setShowAll] = useState(false)
  const pos = p.state.position
  const ranked = useMemo(() => (pos ? rankMoves(pos, sort) : []), [pos, sort])
  const rows = showAll ? ranked : ranked.slice(0, VISIBLE)
  const hidden = ranked.length - rows.length

  return (
    <section className="rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg" aria-label="Opening book statistics">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="flex items-center gap-1.5 text-sm font-extrabold text-white">
          <BookOpen className="h-4 w-4 text-[#81b64c]" aria-hidden /> Most played <span className="font-normal text-stone-400">· Opening book</span>
        </h2>
        <div className="flex overflow-hidden rounded-md border border-[#3a3834]" role="radiogroup" aria-label="Sort moves by">
          {SORTS.map((s) => (
            <button key={s.key} type="button" role="radio" aria-checked={sort === s.key} title={s.title} onClick={() => setSort(s.key)}
              className={`min-h-9 px-2.5 text-[11px] font-bold ${sort === s.key ? 'bg-[#81b64c] text-[#1c1b19]' : 'bg-[#1e1d1b] text-stone-300 hover:bg-[#33312d]'}`}>
              {s.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-2 min-h-[2.5rem]" aria-live="polite">
        {p.state.phase === 'loading' && <p className="flex items-center gap-2 text-xs text-stone-400"><Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Loading the opening book…</p>}
        {p.state.phase === 'error' && (
          <p className="text-xs text-red-300">
            {p.state.error ?? 'The opening book could not be loaded.'}{' '}
            {p.onRetry && <button type="button" onClick={p.onRetry} className="font-semibold text-[#a3d160] underline-offset-2 hover:underline">Try again</button>}
          </p>
        )}
        {p.state.phase === 'ready' && pos && (
          <p className="text-[11px] text-stone-400">
            {p.openingLabel ? <b className="font-semibold text-stone-200">{p.openingLabel}</b> : <b className="font-semibold text-stone-200">Current position</b>}
            {' · '}≈ {formatGames(pos.total)} games
          </p>
        )}
      </div>

      {p.state.phase === 'ready' && pos && ranked.length > 0 && (
        <div className="mt-1 overflow-x-auto">
          <table className="w-full min-w-[320px] text-xs">
            <caption className="sr-only">Moves played in this position, with games and results</caption>
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wide text-stone-500">
                <th className="py-1 pr-2 font-semibold">Move</th>
                <th className="py-1 pr-2 font-semibold">Games</th>
                <th className="py-1 font-semibold">White / draw / Black</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((m) => {
                const share = moveShare(m, pos)
                const rs = resultSplit(m)
                return (
                  <tr key={m.uci} className={`border-t border-[#33312d] ${p.selectedUci === m.uci ? 'bg-[#81b64c]/10' : 'hover:bg-[#2c2a27]'}`}>
                    <td className="py-0.5 pr-2">
                      <button type="button" onClick={() => p.onPlay(m)} className="min-h-10 rounded px-2 font-mono text-sm font-bold text-white hover:bg-[#3b3935]" aria-label={`Play ${m.san}, ${pct(share)} percent of games`}>{m.san}</button>
                    </td>
                    <td className="py-1 pr-2">
                      <div className="font-semibold text-stone-100">{pct(share)}%</div>
                      <div className="text-[10px] text-stone-500">{formatGames(m.total)}</div>
                    </td>
                    <td className="min-w-[120px] py-1">
                      <ResultBar r={rs} label={`White ${pct(rs.white)}%, draws ${pct(rs.draws)}%, Black ${pct(rs.black)}%`} />
                    </td>
                  </tr>
                )
              })}
            </tbody>
            <tfoot>
              <tr className="border-t border-[#4a4843]">
                <td className="py-1.5 pr-2 pl-2 font-mono text-sm font-bold text-stone-300" title="All games in this position">Σ</td>
                <td className="py-1.5 pr-2">
                  <div className="font-semibold text-stone-100">{formatGames(pos.total)}</div>
                  <div className="text-[10px] text-stone-500">games</div>
                </td>
                <td className="min-w-[120px] py-1.5">
                  {(() => {
                    const rs = resultSplit(pos)
                    return <ResultBar r={rs} label={`Overall: White ${pct(rs.white)}%, draws ${pct(rs.draws)}%, Black ${pct(rs.black)}%`} />
                  })()}
                </td>
              </tr>
            </tfoot>
          </table>
          {(hidden > 0 || showAll) && ranked.length > VISIBLE && (
            <button type="button" onClick={() => setShowAll((v) => !v)} className="mt-1 min-h-9 w-full rounded-md border border-[#3a3834] text-[11px] font-semibold text-stone-300 hover:bg-[#33312d]">
              {showAll ? 'Show fewer moves' : `Show ${hidden} more move${hidden === 1 ? '' : 's'}`}
            </button>
          )}
        </div>
      )}
      {p.state.phase === 'ready' && !pos && (
        <p className="mt-1 text-xs leading-relaxed text-stone-300">This position is outside the opening book, so there are no statistics for it. Use the engine below, go back a move, or pick another opening from the library.</p>
      )}
      {p.state.phase === 'ready' && pos && ranked.length === 0 && (
        <p className="mt-1 text-xs leading-relaxed text-stone-300">The book ends here: no continuations are recorded for this position. The board and engine still work.</p>
      )}

      <p className="mt-2 text-[10px] leading-snug text-stone-500">
        Built-in reference book — approximate game counts and results modelled on typical master and strong-player databases, not live data. Popularity ≠ strength: compare with the engine below.
      </p>
    </section>
  )
}

export interface EngineView {
  status: 'starting' | 'ready' | 'fallback'
  busy: boolean
  analysis: Analysis | null
  paused: boolean
}

export function EnginePanel({ e, onPlay }: { e: EngineView; onPlay: (uci: string) => void }) {
  return (
    <section className="rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg" aria-label="Engine analysis">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-extrabold text-white">Best by engine <span className="font-normal text-stone-400">· Stockfish 19</span></h2>
        {e.busy && <Loader2 className="h-4 w-4 animate-spin text-[#81b64c]" aria-label="Analysing" />}
      </div>
      <div aria-live="polite" className="mt-1.5">
        {e.status === 'fallback' && <p className="text-xs text-red-300">Stockfish could not start in this browser, so no engine analysis is available. The database and board still work.</p>}
        {e.status === 'starting' && <p className="text-xs text-stone-400">Starting Stockfish…</p>}
        {e.status === 'ready' && e.paused && !e.analysis && <p className="text-xs text-stone-400">Analysis resumes when playback stops.</p>}
        {e.status === 'ready' && !e.analysis && !e.paused && <p className="text-xs text-stone-400">Analysing…</p>}
        {e.analysis && e.analysis.variations.length === 0 && <p className="text-xs text-stone-400">No legal moves in this position.</p>}
        {e.analysis && e.analysis.variations.length > 0 && (
          <ul className="space-y-1">
            {e.analysis.variations.map((v, i) => (
              <li key={v.firstMove.uci}>
                <button type="button" onClick={() => onPlay(v.firstMove.uci)} className="flex min-h-11 w-full items-center gap-2 rounded-md px-2 py-1 text-left hover:bg-[#302e2b]" aria-label={`Play engine move ${v.firstMove.san}, evaluation ${formatScore(v.score)}`}>
                  <span className={`w-14 shrink-0 rounded px-1.5 py-0.5 text-center font-mono text-[11px] font-bold ${i === 0 ? 'bg-[#81b64c] text-[#1c1b19]' : 'bg-[#33312d] text-stone-200'}`}>{formatScore(v.score)}</span>
                  <span className="font-mono text-sm font-bold text-white">{v.firstMove.san}</span>
                  <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-stone-500">{v.sanMoves.slice(1, 6).join(' ')}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
        {e.analysis && e.analysis.depth > 0 && <p className="mt-1 text-[10px] text-stone-500">Depth {e.analysis.depth}, evaluation from White&apos;s point of view. Engine output, not database statistics.</p>}
      </div>
    </section>
  )
}
