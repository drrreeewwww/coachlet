import { readFileSync } from 'node:fs'
import { Chess } from 'chess.js'
import { describe, expect, it } from 'vitest'
import { buildBook, formatCount, formatGames, lookupBook, moveShare, rankMoves, resultSplit, topMove } from '@/lib/openings/book'
import { buildCatalogue, epdOf } from '@/lib/openings/catalogue'
import { START_FEN } from '@/lib/openings/lineState'

const book = buildBook(JSON.parse(readFileSync('src/lib/openings/data/book.json', 'utf8')))
const rows = JSON.parse(readFileSync('src/lib/openings/data/openings.json', 'utf8')) as Array<[string, string, string, string]>

describe('opening book data', () => {
  it('has the start position with the popular first moves in order', () => {
    const p = lookupBook(book, START_FEN)!
    const r = rankMoves(p)
    expect(r.slice(0, 4).map((m) => m.san)).toEqual(['e4', 'd4', 'Nf3', 'c4'])
    expect(p.total).toBeGreaterThan(1_000_000)
  })
  it('every move is legal, results add up, and counts never exceed the position', () => {
    let checked = 0
    for (const [epd, row] of Object.entries(book.positions)) {
      const [total, w, d, b, moves] = row
      expect(w + d + b).toBe(total)
      // reconstruct a FEN-ish position from the EPD for legality checks
      const c = new Chess(`${epd} 0 1`)
      for (const [san, uci, t, mw, md, mb] of moves) {
        expect(mw + md + mb).toBe(t)
        expect(t).toBeGreaterThan(0)
        const m = new Chess(c.fen()).move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci.slice(4, 5) || undefined })
        expect(m.san).toBe(san)
        checked++
      }
      if (checked > 4000) break // keep the test quick; the build script validates every move
    }
    expect(checked).toBeGreaterThan(1000)
  })
  it('covers every named opening in the catalogue (the line can be followed move by move)', () => {
    const cat = buildCatalogue(rows)
    for (const e of cat.entries) expect(book.positions[e.epd], e.name).toBeTruthy()
  })
  it('follows a sensible most-played line, and knows the Ruy Lopez main line', () => {
    const line = new Chess()
    const played: string[] = []
    for (let i = 0; i < 16; i++) {
      const top = topMove(book, line.fen())
      if (!top) break
      expect(line.move(top.san).san).toBe(top.san) // always legal
      played.push(top.san)
    }
    expect(played.length).toBeGreaterThanOrEqual(12)
    expect(played.slice(0, 3)).toEqual(['e4', 'c5', 'Nf3'])
    const c = new Chess()
    for (const san of ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5']) {
      expect(topMove(book, c.fen())).toBeTruthy()
      c.move(san)
    }
    expect(lookupBook(book, c.fen())!.moves[0].san).toBe('a6')
    // Same position reached by a different move order shares one entry.
    const a = new Chess(); for (const s of ['d4', 'Nf6', 'c4', 'e6']) a.move(s)
    const b = new Chess(); for (const s of ['c4', 'e6', 'd4', 'Nf6']) b.move(s)
    expect(epdOf(a.fen())).toBe(epdOf(b.fen()))
    expect(lookupBook(book, b.fen())).toBeTruthy()
  })
  it('returns null outside the book', () => {
    const c = new Chess()
    for (const s of ['a4', 'a5', 'h4', 'h5', 'Ra3', 'Ra6', 'Rb3', 'Rb6']) c.move(s)
    expect(lookupBook(book, c.fen())).toBeNull()
    expect(topMove(book, c.fen())).toBeNull()
  })
})

describe('book helpers', () => {
  const pos = { total: 100, moves: [
    { uci: 'a', san: 'a', white: 1, draws: 1, black: 8, total: 10 },
    { uci: 'b', san: 'b', white: 40, draws: 20, black: 10, total: 70 },
    { uci: 'c', san: 'c', white: 10, draws: 10, black: 0, total: 20 },
  ] }
  it('ranks by games or by result', () => {
    expect(rankMoves(pos).map((m) => m.san)).toEqual(['b', 'c', 'a'])
    expect(rankMoves(pos, 'black').map((m) => m.san)).toEqual(['a', 'b', 'c'])
    expect(rankMoves(pos, 'draws').map((m) => m.san)[0]).toBe('c')
    expect(rankMoves(pos, 'white').map((m) => m.san)[0]).toBe('b')
  })
  it('computes shares and result splits', () => {
    expect(moveShare(pos.moves[1], pos)).toBe(70)
    const r = resultSplit(pos.moves[1])
    expect(Math.round(r.white + r.draws + r.black)).toBe(100)
    expect(resultSplit({ white: 0, draws: 0, black: 0, total: 0 })).toEqual({ white: 0, draws: 0, black: 0 })
  })
  it('formats counts', () => {
    expect(formatCount(999)).toBe('999')
    expect(formatCount(1500)).toBe('1.5k')
    expect(formatCount(2_250_000)).toBe('2.3M')
    expect(formatGames(1234567)).toBe('1,234,567')
  })
})
