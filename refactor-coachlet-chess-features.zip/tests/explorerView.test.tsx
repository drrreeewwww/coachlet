// @vitest-environment jsdom
import { afterEach, describe, expect, it } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import OpeningExplorerView from '@/views/OpeningExplorerView'

afterEach(() => cleanup())

const history = () => within(screen.getByRole('group', { name: 'Move history' }))

describe('Opening Explorer — Most played (built-in book) end to end', () => {
  it('shows the book table, plays a move from it, and follows the most-played line', async () => {
    render(<OpeningExplorerView />)

    // Start position: Lichess-style table with the popular first moves, no token / network involved.
    await screen.findByRole('table', {}, { timeout: 10_000 })
    const first = screen.getAllByRole('row').slice(1, 5).map((r) => r.textContent ?? '')
    expect(first[0]).toContain('e4')
    expect(first[1]).toContain('d4')
    expect(screen.queryByText(/token/i)).toBeNull()
    expect(screen.queryByText(/lichess api/i)).toBeNull()

    // Clicking a move row plays it on the board and the table updates for Black.
    fireEvent.click(screen.getByRole('button', { name: /Play e4/ }))
    await waitFor(() => expect(history().getByText('1. e4')).toBeTruthy())
    await waitFor(() => expect(screen.getAllByRole('row')[1].textContent).toContain('c5'))

    // Sorting by White's win rate re-orders the rows.
    fireEvent.click(screen.getByRole('radio', { name: 'Draw' }))
    expect(screen.getAllByRole('row').length).toBeGreaterThan(3)
    fireEvent.click(screen.getByRole('radio', { name: 'Games' }))

    // Most-played playback: the first ply is immediate, and it follows the book's top move.
    fireEvent.click(screen.getByRole('radio', { name: 'Most-played line' }))
    fireEvent.click(screen.getByLabelText('Play line'))
    await waitFor(() => expect(history().getByText('1… c5')).toBeTruthy(), { timeout: 4000 })
    fireEvent.click(screen.getByLabelText('Pause playback'))
  }, 30_000)

  it('the Stockfish panel is still there and there is no Lichess/token UI', async () => {
    render(<OpeningExplorerView />)
    await screen.findByRole('table', {}, { timeout: 10_000 })
    expect(screen.getByText(/Best by engine/)).toBeTruthy()
    expect(screen.getByRole('radio', { name: 'Engine best line' })).toBeTruthy()
    expect(screen.queryByText(/masters/i)).toBeNull()
  })
})
