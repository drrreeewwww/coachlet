'use client'
import { useState } from 'react'
import Avatar from './Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { CLASS_META, type MoveClass } from '@/lib/evaluation/classify'
import { bandFor } from '@/lib/stockfish/elo'
import type { CoachId } from '@/types'

export interface Reaction { text: string; cls: MoveClass; cpLoss: number; san: string }
export interface ChatMsg { from: 'you' | 'coach'; text: string }
interface Props {
  coachId: CoachId; elos: Record<CoachId, number>; onCoach: (id: CoachId) => void; onElo: (id: CoachId, elo: number) => void
  reaction: Reaction | null; voiceOn: boolean; onVoice: (on: boolean) => void; speed: number; onSpeed: (n: number) => void
  onPreview: (id: CoachId) => void; onReplay: () => void; onStop: () => void; chat: ChatMsg[]; onAsk: (q: string) => void
}

export default function CoachPanel(p: Props) {
  const [q, setQ] = useState('')
  const coach = COACHES.find((c) => c.id === p.coachId)!, r = p.reaction
  const small = 'rounded-md border border-line px-3 py-1.5 text-sm hover:bg-line'
  const submit = (e: React.FormEvent) => { e.preventDefault(); const t = q.trim(); if (t) { p.onAsk(t); setQ('') } }
  return (
    <section className="space-y-4">
      <div className="rounded-xl border border-line bg-panel p-4">
        <div className="flex items-center gap-3">
          <Avatar id={coach.id} accent={coach.accent} size={48} />
          <div><h2 className="font-display text-lg leading-tight">{coach.name}</h2><p className="text-xs text-stone-400">{coach.style}</p></div>
        </div>
        {r && (
          <p className="mt-3 flex flex-wrap items-center gap-2 text-sm" title={CLASS_META[r.cls].note}>
            <span className="rounded px-2 py-0.5 font-bold text-ink" style={{ background: CLASS_META[r.cls].color }}>{CLASS_META[r.cls].icon} {CLASS_META[r.cls].label}</span>
            <span className="text-stone-300">{r.san}</span>{r.cpLoss > 0 && <span className="text-stone-500">−{r.cpLoss} cp</span>}
          </p>
        )}
        <p className="mt-3 italic text-stone-300" aria-live="polite">“{r ? r.text : coach.greeting}”</p>
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-stone-400">
          <label className="flex items-center gap-2"><input type="checkbox" checked={p.voiceOn} onChange={(e) => p.onVoice(e.target.checked)} className="accent-[#d1a64a]" /> Voice</label>
          <label className="flex items-center gap-2">Speed {p.speed.toFixed(1)}×
            <input type="range" min={0.6} max={1.6} step={0.1} value={p.speed} onChange={(e) => p.onSpeed(Number(e.target.value))} className="w-24 accent-[#d1a64a]" /></label>
          <button className={small} onClick={p.onReplay}>Replay</button>
          <button className={small} onClick={p.onStop}>Stop</button>
        </div>
        <ul className="mt-3 max-h-48 space-y-1 overflow-y-auto text-sm" aria-live="polite">
          {p.chat.slice(-8).map((m, i) => (
            <li key={i} className={m.from === 'you' ? 'text-right text-stone-400' : 'text-stone-200'}>{m.from === 'you' ? '' : `${coach.name}: `}{m.text}</li>
          ))}
        </ul>
        <form onSubmit={submit} className="mt-3 flex gap-2">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask about the best move, eval, or what to train" aria-label="Ask your coach"
            className="min-w-0 flex-1 rounded-md border border-line bg-ink px-3 py-1.5 text-sm placeholder:text-stone-600" />
          <button type="submit" className="rounded-md bg-gold px-3 py-1.5 text-sm font-semibold text-ink">Ask</button>
        </form>
      </div>
      <div className="grid gap-3 md:grid-cols-3 lg:grid-cols-1">
        {COACHES.map((c) => {
          const sel = c.id === p.coachId
          return (
            <div key={c.id} className={`rounded-xl border p-4 ${sel ? 'border-gold bg-panel' : 'border-line'}`}>
              <div className="flex items-center gap-3">
                <Avatar id={c.id} accent={c.accent} />
                <div><h3 className="font-display text-lg leading-tight">{c.name}</h3><p className="text-xs text-stone-400">{c.style}</p></div>
              </div>
              <p className="mt-3 text-sm text-stone-300">{c.philosophy}</p>
              <ul className="mt-2 flex flex-wrap gap-1.5">
                {c.strengths.map((s) => <li key={s} className="rounded-full border border-line px-2 py-0.5 text-xs text-stone-400">{s}</li>)}
              </ul>
              <label htmlFor={`elo-${c.id}`} className="mt-3 block text-xs text-stone-400">Strength <b className="text-gold">{p.elos[c.id]} Elo</b>, {bandFor(p.elos[c.id])}</label>
              <input id={`elo-${c.id}`} type="range" min={300} max={3200} step={50} value={p.elos[c.id]} onChange={(e) => p.onElo(c.id, Number(e.target.value))} className="w-full accent-[#d1a64a]" />
              <div className="mt-3 flex gap-2 text-sm">
                <button className={small} onClick={() => p.onPreview(c.id)}>Preview voice</button>
                <button onClick={() => p.onCoach(c.id)} aria-pressed={sel}
                  className={`rounded-md px-3 py-1.5 font-semibold ${sel ? 'bg-gold text-ink' : 'border border-gold text-gold hover:bg-gold/10'}`}>{sel ? 'Selected' : 'Select coach'}</button>
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}
