import type { CoachId } from '@/types'

// Original illustrated avatars, drawn from scratch for this project.
export default function Avatar({ id, accent, size = 56 }: { id: CoachId; accent: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" role="img" aria-label={`${id} avatar`} className="shrink-0 rounded-full">
      <rect width="64" height="64" fill={accent} />
      <path d="M6 64c2-14 14-19 26-19s24 5 26 19z" fill="#13201b" />
      <circle cx="32" cy="29" r="13" fill="#f1d3b3" />
      {id === 'vale' && <>
        <path d="M18 27c0-11 7-15 14-15s14 4 14 15c-4-5-9-6-14-6s-10 1-14 6z" fill="#6b4a2f" />
        <rect x="22" y="27" width="8" height="5" rx="2" fill="none" stroke="#13201b" strokeWidth="1.5" />
        <rect x="34" y="27" width="8" height="5" rx="2" fill="none" stroke="#13201b" strokeWidth="1.5" />
        <path d="M28 38q4 1.5 8 0" stroke="#7a4a3a" strokeWidth="1.6" fill="none" strokeLinecap="round" />
      </>}
      {id === 'flash' && <>
        <path d="M17 28l2-15 7 7 6-10 6 10 7-7 2 15c-4-5-9-6-15-6s-11 1-15 6z" fill="#1d1d1d" />
        <circle cx="26" cy="29" r="1.8" fill="#13201b" /><circle cx="38" cy="29" r="1.8" fill="#13201b" />
        <path d="M25 35q7 6 14 0" stroke="#7a2a2a" strokeWidth="2" fill="none" strokeLinecap="round" />
        <path d="M17 30c0-14 6-19 15-19s15 5 15 19" stroke="#e8e8e8" strokeWidth="2" fill="none" /><rect x="43" y="30" width="4" height="7" rx="2" fill="#e8e8e8" />
      </>}
      {id === 'gambit' && <>
        <circle cx="22" cy="20" r="6" fill="#2b2118" /><circle cx="32" cy="16" r="7" fill="#2b2118" /><circle cx="42" cy="20" r="6" fill="#2b2118" />
        <path d="M23 25q3-3 6 0M35 25q3-3 6 0" stroke="#2b2118" strokeWidth="1.6" fill="none" strokeLinecap="round" />
        <circle cx="26" cy="29" r="1.8" fill="#13201b" /><circle cx="38" cy="29" r="1.8" fill="#13201b" />
        <path d="M25 34q7 8 14 0z" fill="#7a2a2a" />
      </>}
    </svg>
  )
}
