'use client'
import { Chess, type Square } from 'chess.js'
import { useMemo, useState } from 'react'
import { DEFAULTS, THEMES, type Settings } from '@/lib/settings'

const FILES = 'abcdefgh'
const SOLID: Record<string, string> = { p: '♟', n: '♞', b: '♝', r: '♜', q: '♛', k: '♚' }
const HOLLOW: Record<string, string> = { p: '♙', n: '♘', b: '♗', r: '♖', q: '♕', k: '♔' }
const nameAt = (i: number) => (FILES[i % 8] + (8 - Math.floor(i / 8))) as Square

interface Props {
  fen: string; flipped: boolean; lastMove: { from: string; to: string } | null; disabled: boolean; marks?: string[]
  look?: Partial<Pick<Settings, 'theme' | 'pieces' | 'coords'>>; onMove: (from: string, to: string, promotion?: string) => void
}

export default function Chessboard({ fen, flipped, lastMove, disabled, marks, look, onMove }: Props) {
  const [sel, setSel] = useState<Square | null>(null)
  const [promo, setPromo] = useState<{ from: Square; to: Square } | null>(null)
  const { theme, pieces, coords } = { theme: DEFAULTS.theme, pieces: DEFAULTS.pieces, coords: DEFAULTS.coords, ...look }
  const T = THEMES[theme] ?? THEMES.walnut
  const chess = useMemo(() => new Chess(fen), [fen])
  const board = chess.board().flat()
  const targets = useMemo(() => new Set(sel ? chess.moves({ square: sel, verbose: true }).map((m) => m.to) : []), [sel, chess])
  const checked = chess.inCheck() ? board.find((p) => p && p.type === 'k' && p.color === chess.turn())?.square : undefined

  const go = (from: Square, to: Square) => {
    setSel(null)
    if (chess.moves({ square: from, verbose: true }).some((m) => m.to === to && m.promotion)) setPromo({ from, to })
    else onMove(from, to)
  }
  const click = (sq: Square) => {
    if (disabled) return
    if (sel && targets.has(sq)) { go(sel, sq); return }
    const p = chess.get(sq)
    setSel(p && p.color === chess.turn() ? sq : null)
  }

  return (
    <div className="relative grid w-full max-w-[640px] grid-cols-8 overflow-hidden rounded-md border border-line shadow-2xl">
      {Array.from({ length: 64 }, (_, d) => {
        const i = flipped ? 63 - d : d
        const sq = nameAt(i), p = board[i]
        const dark = (i % 8 + Math.floor(i / 8)) % 2 === 1, label = dark ? T.light : T.dark
        const canDrag = !disabled && !!p && p.color === chess.turn()
        const white = p?.color === 'w'
        return (
          <div key={sq} onClick={() => click(sq)} onDragOver={(e) => e.preventDefault()}
            onDrop={() => { if (sel && targets.has(sq)) go(sel, sq); else setSel(null) }}
            style={{ background: dark ? T.dark : T.light }} className="relative flex aspect-square items-center justify-center">
            {lastMove && (sq === lastMove.from || sq === lastMove.to) && <span className="absolute inset-0 bg-yellow-300/45" />}
            {marks?.includes(sq) && <span className="absolute inset-0 ring-4 ring-inset ring-red-600/80" />}
            {sq === sel && <span className="absolute inset-0 bg-sky-400/50" />}
            {sq === checked && <span className="absolute inset-0 bg-[radial-gradient(circle,rgba(220,38,38,.9),transparent_70%)]" />}
            {coords && d % 8 === 0 && <span className="absolute left-0.5 top-0 text-[10px] font-semibold leading-tight" style={{ color: label }}>{8 - Math.floor(i / 8)}</span>}
            {coords && d >= 56 && <span className="absolute bottom-0 right-0.5 text-[10px] font-semibold leading-tight" style={{ color: label }}>{FILES[i % 8]}</span>}
            {targets.has(sq) && (p
              ? <span className="absolute inset-1 rounded-full border-4 border-black/30" />
              : <span className="absolute h-1/4 w-1/4 rounded-full bg-black/30" />)}
            {p && (
              <span draggable={canDrag} onDragStart={() => canDrag && setSel(sq)}
                className={`relative select-none leading-none ${canDrag ? 'cursor-grab' : ''}`}>
                {pieces === 'letters' ? (
                  <span className={`grid h-[min(9vw,3.2rem)] w-[min(9vw,3.2rem)] place-items-center rounded-full border-2 text-[length:min(5vw,1.7rem)] font-bold ${white ? 'border-stone-800 bg-stone-50 text-stone-900' : 'border-stone-200 bg-stone-900 text-stone-50'}`}>
                    {p.type === 'p' ? 'P' : p.type.toUpperCase()}
                  </span>
                ) : (
                  <span className={`text-[length:min(8vw,3.6rem)] ${pieces === 'outline' ? 'text-stone-900' : white ? 'text-white [text-shadow:0_0_2px_#000,0_1px_1px_#000]' : 'text-stone-900'}`}>
                    {(pieces === 'outline' && white ? HOLLOW : SOLID)[p.type]}
                  </span>
                )}
              </span>
            )}
          </div>
        )
      })}
      {promo && (
        <div className="absolute inset-0 z-10 grid place-items-center bg-black/60" role="dialog" aria-label="Choose promotion piece">
          <div className="flex gap-2 rounded-lg bg-panel p-3">
            {(['q', 'r', 'b', 'n'] as const).map((p) => (
              <button key={p} aria-label={`Promote to ${p}`} onClick={() => { onMove(promo.from, promo.to, p); setPromo(null) }}
                className="rounded p-1 text-5xl text-white hover:bg-line">{SOLID[p]}</button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
