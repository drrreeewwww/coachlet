import { toCp, winPct, formatScore, type Score } from '@/lib/evaluation/classify'

export default function EvalBar({ score, flipped }: { score: Score; flipped: boolean }) {
  const white = winPct(toCp(score)), label = formatScore(score)
  const whiteEnd = flipped ? 'top-1' : 'bottom-1', blackEnd = flipped ? 'bottom-1' : 'top-1'
  return (
    <div role="img" aria-label={`Evaluation ${label}`} className="relative w-8 shrink-0 self-stretch overflow-hidden rounded-md border border-line bg-stone-900">
      <div className={`absolute inset-x-0 ${flipped ? 'top-0' : 'bottom-0'} bg-stone-100 transition-[height] duration-500`} style={{ height: `${white}%` }} />
      <span className={`absolute inset-x-0 text-center text-[10px] font-semibold ${white >= 50 ? `${whiteEnd} text-stone-900` : `${blackEnd} text-stone-100`}`}>{label}</span>
    </div>
  )
}
