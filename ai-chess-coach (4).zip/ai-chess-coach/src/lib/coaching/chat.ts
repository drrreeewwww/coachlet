import { CLASS_META, formatScore, toCp, type Score } from '@/lib/evaluation/classify'
import { train } from './profile'
import type { MoveRecord } from '@/lib/review/record'
import type { CoachId } from '@/types'

/** Everything a reply may use comes from real engine data passed in here. Nothing is invented. */
export interface Ctx { coach: CoachId; elo: number; bestSan?: string; score?: Score; recs: MoveRecord[]; over: boolean }

const W: Record<CoachId, Record<'best' | 'eval' | 'last' | 'none' | 'help', string>> = {
  vale: { best: 'If you want it: {san}. It improves the position without commitment.', eval: 'The engine says {ev}, so {who}. Small edges are enough if you are patient.',
    last: 'Your last move, {san}, was {cls}. {note}', none: 'There is nothing to discuss yet.',
    help: 'Ask me for the best move, the evaluation, why your last move was rated as it was, or what to train.' },
  flash: { best: '{san}! Check it: checks, captures, threats.', eval: 'Engine says {ev}, so {who}. Keep the pressure on!',
    last: '{san} was {cls}. {note}', none: 'Make a move first, then we can break it down!', help: 'Try: best move, eval, last move, or what should I train.' },
  gambit: { best: 'Okay, you asked nicely: {san}! Can you see why it works?', eval: 'The engine shows {ev}, so {who}. Does that match your gut feeling?',
    last: 'Your move {san} was {cls}. {note} What would you play instead?', none: 'We haven’t played a move yet, friend!',
    help: 'You can ask me for the best move, the evaluation, about your last move, or what to practise. Go on, ask!' },
}

export function answer(q: string, c: Ctx): string {
  const t = q.toLowerCase(), w = W[c.coach]
  const mine = c.recs.filter((m) => m.color === 'w'), last = mine[mine.length - 1]
  if (/best|hint|suggest|what (do|should) i play/.test(t)) return c.bestSan && !c.over ? w.best.replace('{san}', c.bestSan) : 'The game is over, so there is no move to suggest.'
  if (/eval|better|winning|advantage|score/.test(t)) {
    if (!c.score) return w.none
    const cp = toCp(c.score), who = Math.abs(cp) < 30 ? 'it is level' : cp > 0 ? 'White is better' : 'Black is better'
    return w.eval.replace('{ev}', formatScore(c.score)).replace('{who}', who)
  }
  if (/last|why|mistake|blunder|wrong|rated/.test(t)) {
    if (!last) return w.none
    const note = last.uci === last.best ? 'It was the engine’s top choice.' : `The engine preferred ${last.bestSan}.`
    return w.last.replace('{san}', last.san).replace('{cls}', CLASS_META[last.cls].label.toLowerCase()).replace('{note}', note)
  }
  if (/train|practi|improv|weak|learn|study/.test(t)) return train(c.coach, c.elo, c.recs)
  return w.help
}
