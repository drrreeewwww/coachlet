import type { MoveRecord } from '@/lib/review/record'
import type { CoachId } from '@/types'

export type Phase = 'opening' | 'middlegame' | 'endgame'
const PIECES: Record<string, string> = { N: 'knight', B: 'bishop', R: 'rook', Q: 'queen', K: 'king', O: 'king' }
const tier = (elo: number) => (elo < 1100 ? 0 : elo < 1900 ? 1 : 2)

/** Elo-adapted thinking prompts: simpler for beginners, more technical for strong players. */
const TIP: Record<CoachId, string[]> = {
  vale: ['Before you move, ask which of your pieces is undefended.', 'Compare your worst-placed piece with the one you just moved.', 'Does the structure still support your plan after this move?'],
  flash: ['Scan checks, captures and threats before every move.', 'Calculate the opponent’s forcing replies first.', 'Was there a forcing line you stopped calculating too early?'],
  gambit: ['Quick question: what could your opponent capture after that move?', 'Ask yourself: what was the last move threatening?', 'What did your candidate list look like? Was the engine’s move on it?'],
}
export const tipFor = (coach: CoachId, elo: number) => TIP[coach][tier(elo)]

export const phaseOf = (fen: string, ply: number): Phase =>
  (fen.split(' ')[0].match(/[qrbnQRBN]/g) ?? []).length <= 6 ? 'endgame' : ply < 20 ? 'opening' : 'middlegame'

/** Recurring weaknesses in the player's (White's) real mistakes and blunders. "Recurring" means two or more. */
export function weaknesses(recs: MoveRecord[]) {
  const bad = recs.map((m, i) => ({ m, i })).filter(({ m }) => m.color === 'w' && (m.cls === 'mistake' || m.cls === 'blunder'))
  const tally = (keys: string[]) => {
    const c = new Map<string, number>(); keys.forEach((k) => c.set(k, (c.get(k) ?? 0) + 1))
    const top = [...c].sort((a, b) => b[1] - a[1])[0]
    return top && top[1] >= 2 ? top : undefined
  }
  return {
    mistakes: bad.length,
    phase: tally(bad.map(({ m, i }) => phaseOf(m.fenBefore, i))) as [Phase, number] | undefined,
    piece: tally(bad.map(({ m }) => PIECES[m.san[0]] ?? 'pawn')),
  }
}

const OPEN: Record<CoachId, string> = { vale: 'Here is my honest read.', flash: 'Okay, here’s the plan!', gambit: 'Great question! Here’s what I’d practise.' }
const ADVICE: Record<Phase, string> = {
  opening: 'opening principles: develop your pieces, castle early and fight for the centre.',
  middlegame: 'tactics: before every move, scan checks, captures and threats, yours and theirs.',
  endgame: 'endgames: activate your king and count pawn races step by step.',
}
export function train(coach: CoachId, elo: number, recs: MoveRecord[]): string {
  if (recs.filter((m) => m.color === 'w').length < 3) return `${OPEN[coach]} Play a few more moves so I have real mistakes to learn from.`
  const w = weaknesses(recs)
  if (!w.mistakes) return `${OPEN[coach]} No mistakes or blunders so far. Keep doing exactly this.`
  const parts = [`${OPEN[coach]} You have made ${w.mistakes} serious error${w.mistakes > 1 ? 's' : ''} this game.`]
  parts.push(w.phase ? `Most come in the ${w.phase[0]}, so work on ${ADVICE[w.phase[0]]}` : `Work on ${ADVICE.middlegame}`)
  if (w.piece) parts.push(`Your ${w.piece[0]} moves keep costing you, so check it is safe before you move it.`)
  parts.push(tipFor(coach, elo))
  return parts.join(' ')
}
