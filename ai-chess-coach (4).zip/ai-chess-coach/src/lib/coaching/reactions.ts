import type { CoachId } from '@/types'
import type { MoveClass } from '@/lib/evaluation/classify'

// Deterministic lines per coach and classification. {best} is replaced with the engine’s preferred move.
const LINES: Record<CoachId, Record<MoveClass, string[]>> = {
  vale: {
    best: ['Precisely. That is the move I would have played.', 'Quietly the best. Well found.'],
    excellent: ['Very nearly the best. I will allow it.', 'Sound, and a touch more accurate than most.'],
    good: ['Reasonable. Not much to complain about.', 'It does the job, though {best} asked more of the position.'],
    inaccuracy: ['A slight drift. {best} kept the structure tighter.', 'Not wrong, but {best} was the more patient choice.'],
    mistake: ['That concedes something real. {best} was the move.', 'Hm. The plan frays a little here. {best} held it together.'],
    blunder: ['That, I am afraid, is a serious error. {best} was necessary.', 'Well. That changes the evaluation considerably. {best} was the only sensible path.'],
  },
  flash: {
    best: ['Boom! Best move, straight from the engine’s mouth!', 'Yes! That’s the one. Fast and clean.'],
    excellent: ['Nice! Basically the best. Keep that tempo up!', 'Strong. The pressure stays on.'],
    good: ['Fine, fine, but {best} hit harder.', 'Playable. {best} was sharper, though.'],
    inaccuracy: ['Ooh, you let me off a little. {best} was more forcing.', 'Slow! {best} kept the initiative.'],
    mistake: ['Ouch, that’s a mistake! {best} was the shot.', 'You’re handing me chances. {best} was needed!'],
    blunder: ['Blunder! Huge swing. {best} was the only move!', 'No, no, no! That loses ground fast. {best} was right there!'],
  },
  gambit: {
    best: ['Ladies and gentlemen, that is the best move on the board!', 'Chef’s kiss. The engine would applaud.'],
    excellent: ['Ooh, lovely. Nearly perfect, and I’m practically in tears.', 'Excellent! Take a bow. A small bow.'],
    good: ['Perfectly decent! Though {best} would have had more flair.', 'A solid choice. {best} was a touch spicier.'],
    inaccuracy: ['Tiny slip! Even the greats do it. {best} was the neater idea.', 'Hmm, not quite. {best} was the one with the plot.'],
    mistake: ['Oh dear, a plot twist, and not the good kind. {best} was the move.', 'That one stings! Remember {best} for next time.'],
    blunder: ['Gasp! The audience is on its feet. {best} was the only way out!', 'Dramatic! Tragic, even. {best} was begging to be played.'],
  },
}
export const reactionFor = (coach: CoachId, cls: MoveClass, n: number, best: string) => {
  const lines = LINES[coach][cls]
  return lines[n % lines.length].replace('{best}', best)
}
