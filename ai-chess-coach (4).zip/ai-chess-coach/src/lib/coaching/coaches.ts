import type { Coach } from '@/types'
// Original fictional characters. Their teaching styles are inspired by general, public approaches to chess coaching;
// they are not the real people, use no real voices or recordings, and are not endorsed by anyone.
export const COACHES: Coach[] = [
  { id: 'vale', name: 'Coach Vale', style: 'Calm, precise, quietly confident', accent: '#5aa9c9',
    tagline: 'Long-term plans, active pieces, quiet confidence.',
    philosophy: 'Improve every piece before you attack. Patience and precision turn small edges into wins.',
    strengths: ['Positional play', 'Endgame technique', 'Converting small edges'],
    greeting: 'Let’s see what you do with the centre. Take your time. I certainly will.',
    preview: 'I’m Coach Vale. Let’s improve your worst-placed piece first, and the rest will follow.' },
  { id: 'flash', name: 'Coach Flash', style: 'Fast, tactical, competitive', accent: '#e5533d',
    tagline: 'Calculation, forcing moves, and the shot nobody sees.',
    philosophy: 'Checks, captures, threats. Learn to spot patterns fast and calculate forcing lines cleanly.',
    strengths: ['Tactics and calculation', 'Forcing moves', 'Defensive resources'],
    greeting: 'Clock’s ticking, let’s go! Checks, captures, threats. Find the shot.',
    preview: 'Coach Flash here! Checks, captures, threats. Let’s find the shot!' },
  { id: 'gambit', name: 'Coach Gambit', style: 'Friendly, funny, very clear', accent: '#b07be0',
    tagline: 'Big ideas explained so they stick, with some theatre.',
    philosophy: 'Clear, friendly lessons built on memorable ideas. We find out why mistakes happen, then fix them.',
    strengths: ['Opening principles', 'Common tactics', 'Spotting blunders'],
    greeting: 'Welcome, friends! Today’s lesson: the fork. Yes, like the cutlery.',
    preview: 'Hey friends, Coach Gambit! Ready to learn something and have a laugh?' },
]
