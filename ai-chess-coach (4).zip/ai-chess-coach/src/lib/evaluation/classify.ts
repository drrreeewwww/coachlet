// Pure evaluation maths: no imports, so it can be unit-tested without a browser or engine.
export interface Score { cp?: number; mate?: number } // always from White's point of view
export type MoveClass = 'best' | 'excellent' | 'good' | 'inaccuracy' | 'mistake' | 'blunder'

const clamp = (n: number) => Math.max(-1000, Math.min(1000, n))
export const toCp = (s: Score) => (s.mate !== undefined ? (s.mate > 0 ? 1 : -1) * (10000 - Math.abs(s.mate) * 10) : s.cp ?? 0)
/** Win probability (0-100) for the side that is ahead in `cp`, using the Lichess logistic curve. */
export const winPct = (cp: number) => 50 + 50 * (2 / (1 + Math.exp(-0.00368208 * clamp(cp))) - 1)
export const formatScore = (s: Score) =>
  s.mate !== undefined ? `${s.mate > 0 ? '+' : '-'}M${Math.abs(s.mate)}`
  : Math.abs(s.cp ?? 0) >= 9000 ? ((s.cp ?? 0) > 0 ? '1-0' : '0-1')
  : `${(s.cp ?? 0) >= 0 ? '+' : ''}${((s.cp ?? 0) / 100).toFixed(1)}`

export const CLASS_META: Record<MoveClass, { label: string; icon: string; color: string; note: string }> = {
  best: { label: 'Best', icon: '★', color: '#26c281', note: 'The engine’s top choice.' },
  excellent: { label: 'Excellent', icon: '✓', color: '#6ab04c', note: 'Almost as strong as the best move.' },
  good: { label: 'Good', icon: '✓', color: '#8aa4b8', note: 'A fine move that gives up very little.' },
  inaccuracy: { label: 'Inaccuracy', icon: '?!', color: '#f2c230', note: 'A better move was available.' },
  mistake: { label: 'Mistake', icon: '?', color: '#e8892b', note: 'This gave away a real advantage.' },
  blunder: { label: 'Blunder', icon: '??', color: '#d0342c', note: 'This changed the result of the position.' },
}

/** Compares evaluation before and after a move (both White-POV centipawns) from the mover's side. */
export function classify(before: number, after: number, mover: 'w' | 'b', playedBest: boolean) {
  const sign = mover === 'w' ? 1 : -1
  const winLoss = Math.max(0, winPct(sign * before) - winPct(sign * after))
  const cpLoss = Math.max(0, Math.round(clamp(sign * before) - clamp(sign * after)))
  const cls: MoveClass = playedBest || winLoss < 0.5 ? 'best' : winLoss <= 2 ? 'excellent' : winLoss <= 5 ? 'good'
    : winLoss <= 10 ? 'inaccuracy' : winLoss <= 20 ? 'mistake' : 'blunder'
  return { cls, cpLoss, winLoss }
}

/** Per-move accuracy (0-100) from win-probability lost, using the Lichess formula. */
export const accuracyOf = (winLoss: number) => Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * winLoss) - 3.1669))
