import type { CoachId } from '@/types'
import type { MoveClass } from '@/lib/evaluation/classify'

/** One analysed half-move. `before`/`after` are White-POV centipawns from the engine; nothing here is invented. */
export interface MoveRecord {
  color: 'w' | 'b'; san: string; uci: string; fenBefore: string; fenAfter: string
  before: number; after: number; cls: MoveClass; cpLoss: number; winLoss: number; best: string; bestSan: string; pv: string[]
}
export interface SavedGame { coach: CoachId; elo: number; result: string; moves: MoveRecord[] }
const KEY = 'chess-coach:last-game'
export const saveGame = (g: SavedGame) => { try { if (g.moves.length) localStorage.setItem(KEY, JSON.stringify(g)) } catch { /* storage unavailable */ } }
export const loadGame = (): SavedGame | null => { try { const s = localStorage.getItem(KEY); return s ? JSON.parse(s) : null } catch { return null } }
