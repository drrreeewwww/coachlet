import { Chess } from 'chess.js'
import { formatScore, type Score } from '@/lib/evaluation/classify'

const NAME: Record<string, string> = { p: 'pawn', n: 'knight', b: 'bishop', r: 'rook', q: 'queen', k: 'king' }

/** Progressive hints built from the engine's best move in this exact position. Level 4 reveals it. */
export function hintFor(fen: string, best: string, score: Score, level: 1 | 2 | 3 | 4) {
  const c = new Chess(fen), from = best.slice(0, 2), to = best.slice(2, 4)
  const m = c.move({ from, to, promotion: best[4] })
  const piece = NAME[m.piece]
  const theme = c.isCheckmate() ? 'mate' : c.inCheck() ? 'check' : m.isCapture() ? 'capture' : m.isPromotion() ? 'promotion'
    : m.isKingsideCastle() || m.isQueensideCastle() ? 'castle' : (score.mate ?? 0) > 0 ? 'mate' : 'improve'
  const general: Record<string, string> = {
    mate: 'Look for a forcing sequence. There is a mating attack on the board.', check: 'Look for a forcing move. A check may be strong here.',
    capture: 'Something is loose. Look for a capture.', promotion: 'A pawn is close to promoting. Look at it.',
    castle: 'Think about king safety.', improve: 'Nothing is forced. Improve your worst-placed piece.' }
  const action: Record<string, string> = { mate: 'It sets up or delivers mate', check: 'It gives check', capture: 'It captures something',
    promotion: 'It promotes', castle: 'It castles', improve: 'It improves the position quietly' }
  if (level === 1) return { text: general[theme], marks: [] as string[] }
  if (level === 2) return { text: `Look at your ${piece} on ${from}.`, marks: [from] }
  if (level === 3) return { text: `That ${piece} wants to go to the ${to[0]}-file. ${action[theme]}.`, marks: [from] }
  return { text: `Best move: ${m.san} (${formatScore(score)}). ${action[theme]}.`, marks: [from, to] }
}
