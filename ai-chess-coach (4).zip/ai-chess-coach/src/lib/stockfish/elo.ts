export const BANDS = [
  { max: 700, label: 'Beginner' }, { max: 1100, label: 'Casual' }, { max: 1500, label: 'Developing' },
  { max: 1900, label: 'Intermediate' }, { max: 2300, label: 'Advanced' }, { max: 2700, label: 'Expert' },
  { max: 3200, label: 'Master-level challenge' },
]
export const bandFor = (elo: number) => BANDS.find((b) => elo <= b.max)!.label

export interface Strength { limit: boolean; uciElo: number; skill: number; movetime: number; blunder: number; multiPv: number }
const t = (x: number, a: number, b: number) => Math.min(1, Math.max(0, (x - a) / (b - a)))

// Stockfish's UCI_Elo only goes down to 1320, so below that we combine Skill Level 0-5, very short
// searches, and a chance of playing one of the other top-4 candidate moves instead of the best one.
export function strengthFor(elo: number): Strength {
  if (elo >= 3000) return { limit: false, uciElo: 3190, skill: 20, movetime: 1200, blunder: 0, multiPv: 1 }
  if (elo >= 1320) return { limit: true, uciElo: elo, skill: 20, movetime: 200 + Math.round(t(elo, 1320, 3000) * 800), blunder: 0, multiPv: 1 }
  const k = t(elo, 300, 1320)
  return { limit: false, uciElo: 1320, skill: Math.round(k * 5), movetime: 50, blunder: 0.6 - 0.45 * k, multiPv: 4 }
}
