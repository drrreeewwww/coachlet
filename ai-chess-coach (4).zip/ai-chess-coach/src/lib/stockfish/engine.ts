import type { Strength } from './elo'
import type { Score } from '@/lib/evaluation/classify'

export interface Analysis { score: Score; best: string; pv: string[] }
const FULL: Strength = { limit: false, uciElo: 3190, skill: 20, movetime: 300, blunder: 0, multiPv: 1 }

// UCI wrapper around Stockfish in a Web Worker. Calls are queued so searches never overlap.
export class Engine {
  private w: Worker
  private listeners = new Set<(line: string) => void>()
  private ready: Promise<void>
  private chain: Promise<unknown> = Promise.resolve()

  constructor() {
    this.w = new Worker('/stockfish/stockfish.js#/stockfish/stockfish.wasm')
    this.w.onmessage = (e) => this.listeners.forEach((f) => f(String(e.data)))
    this.ready = this.until('uciok', () => this.send('uci')).then(() => this.until('readyok', () => this.send('isready')))
  }

  private send(cmd: string) { this.w.postMessage(cmd) }
  private enqueue<T>(fn: () => Promise<T>): Promise<T> { const p = this.chain.then(fn); this.chain = p.catch(() => undefined); return p }

  private until(token: string, start: () => void, collect?: (line: string) => void) {
    return new Promise<void>((resolve) => {
      const f = (line: string) => { collect?.(line); if (line.startsWith(token)) { this.listeners.delete(f); resolve() } }
      this.listeners.add(f)
      start()
    })
  }

  private async search(fen: string, s: Strength, onInfo: (line: string) => void): Promise<string> {
    await this.ready
    this.send(`setoption name UCI_LimitStrength value ${s.limit}`)
    this.send(`setoption name UCI_Elo value ${s.uciElo}`)
    this.send(`setoption name Skill Level value ${s.skill}`)
    this.send(`setoption name MultiPV value ${s.multiPv}`)
    this.send(`position fen ${fen}`)
    let best = ''
    await this.until('bestmove', () => this.send(`go movetime ${s.movetime}`), (l) => {
      if (l.startsWith('bestmove')) best = l.split(' ')[1]
      else onInfo(l)
    })
    return best
  }

  /** The opponent's move in UCI form (e.g. "e7e5"), weakened according to `s`. */
  bestMove(fen: string, s: Strength): Promise<string> {
    return this.enqueue(async () => {
      const candidates = new Map<number, string>()
      const best = await this.search(fen, s, (l) => {
        if (l.startsWith('info') && l.includes(' pv ')) candidates.set(Number(/multipv (\d+)/.exec(l)?.[1] ?? 1), l.split(' pv ')[1].split(' ')[0])
      })
      if (s.multiPv > 1 && candidates.size > 1 && Math.random() < s.blunder) {
        const others = [...candidates].filter(([k]) => k > 1).map(([, m]) => m)
        return others[Math.floor(Math.random() * others.length)]
      }
      return best
    })
  }

  /** Full-strength evaluation of a position, scored from White's point of view. */
  analyse(fen: string, movetime = 300): Promise<Analysis> {
    return this.enqueue(async () => {
      const side = fen.split(' ')[1] === 'w' ? 1 : -1
      let score: Score = { cp: 0 }, pv: string[] = []
      const best = await this.search(fen, { ...FULL, movetime }, (l) => {
        const m = /score (cp|mate) (-?\d+)/.exec(l)
        if (m && l.includes(' pv ')) { const v = side * Number(m[2]); score = m[1] === 'cp' ? { cp: v } : { mate: v }; pv = l.split(' pv ')[1].trim().split(' ') }
      })
      return { score, best, pv }
    })
  }

  destroy() { this.w.terminate() }
}
