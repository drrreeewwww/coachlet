export type CoachId = 'vale' | 'flash' | 'gambit'
export interface Coach {
  id: CoachId; name: string; style: string; tagline: string; accent: string; greeting: string
  philosophy: string; strengths: string[]; preview: string
}
