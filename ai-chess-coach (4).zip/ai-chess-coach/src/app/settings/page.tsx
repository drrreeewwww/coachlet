'use client'
import type { ReactNode } from 'react'
import Chessboard from '@/components/Chessboard/Chessboard'
import { PIECE_STYLES, THEMES, type PieceStyle, type ThemeId } from '@/lib/settings'
import { playSound } from '@/lib/sound/sounds'
import { useSettings } from '@/lib/useSettings'
import { speak } from '@/lib/voice/speak'

const PREVIEW = 'r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4'
const Section = ({ title, children }: { title: string; children: ReactNode }) => (
  <section className="rounded-xl border border-line bg-panel p-4"><h2 className="font-display text-lg">{title}</h2><div className="mt-1 divide-y divide-line">{children}</div></section>
)
const Row = ({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) => (
  <div className="flex items-center justify-between gap-4 py-3 text-sm"><span>{label}{hint && <span className="block text-xs text-stone-500">{hint}</span>}</span>{children}</div>
)
const Toggle = ({ label, hint, checked, onChange }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void }) => (
  <Row label={label} hint={hint}><input type="checkbox" aria-label={label} checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-5 w-5 accent-[#d1a64a]" /></Row>
)
const Slider = ({ label, value, min, max, step, show, onChange }: { label: string; value: number; min: number; max: number; step: number; show: string; onChange: (v: number) => void }) => (
  <Row label={`${label}: ${show}`}><input type="range" aria-label={label} min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="w-40 accent-[#d1a64a]" /></Row>
)

export default function SettingsPage() {
  const [s, set, reset] = useSettings()
  const btn = 'rounded-md border border-line px-3 py-1.5 text-sm hover:bg-line'
  return (
    <main className="mx-auto grid max-w-6xl gap-6 p-4 lg:grid-cols-[1fr_minmax(0,420px)]">
      <div className="space-y-4">
        <h1 className="font-display text-3xl">Settings</h1>
        <Section title="Board">
          <Row label="Board theme">
            <div className="flex flex-wrap justify-end gap-2">
              {(Object.keys(THEMES) as ThemeId[]).map((id) => (
                <button key={id} onClick={() => set({ theme: id })} aria-pressed={s.theme === id} title={THEMES[id].label}
                  className={`flex overflow-hidden rounded-md border-2 ${s.theme === id ? 'border-gold' : 'border-line'}`}>
                  <span className="h-8 w-6" style={{ background: THEMES[id].light }} /><span className="h-8 w-6" style={{ background: THEMES[id].dark }} /></button>
              ))}
            </div>
          </Row>
          <Row label="Piece style">
            <select value={s.pieces} onChange={(e) => set({ pieces: e.target.value as PieceStyle })} className="rounded-md border border-line bg-ink px-2 py-1">
              {(Object.keys(PIECE_STYLES) as PieceStyle[]).map((k) => <option key={k} value={k}>{PIECE_STYLES[k]}</option>)}
            </select>
          </Row>
          <Toggle label="Board coordinates" checked={s.coords} onChange={(coords) => set({ coords })} />
          <Toggle label="Evaluation bar" checked={s.evalBar} onChange={(evalBar) => set({ evalBar })} />
        </Section>
        <Section title="Sound effects">
          <Toggle label="Move sounds" checked={s.sound} onChange={(sound) => set({ sound })} />
          <Slider label="Volume" value={s.volume} min={0} max={1} step={0.1} show={`${Math.round(s.volume * 100)}%`} onChange={(volume) => set({ volume })} />
          <Row label="Try the sounds"><button className={btn} onClick={() => { playSound('move', s.volume); setTimeout(() => playSound('capture', s.volume), 350); setTimeout(() => playSound('check', s.volume), 700) }}>Play</button></Row>
        </Section>
        <Section title="Coach voice">
          <Toggle label="Spoken coaching" checked={s.voice} onChange={(voice) => set({ voice })} />
          <Slider label="Speech speed" value={s.speed} min={0.6} max={1.6} step={0.1} show={`${s.speed.toFixed(1)}×`} onChange={(speed) => set({ speed })} />
          <Toggle label="Coach reactions" hint="Comment on your moves after you play them" checked={s.reactions} onChange={(reactions) => set({ reactions })} />
          <Row label="Test the voice"><button className={btn} onClick={() => speak('This is how your coach will sound.', 'vale', s.speed)}>Speak</button></Row>
        </Section>
        <Section title="Training">
          <Toggle label="Hints" hint="Show the Hint button during games" checked={s.hints} onChange={(hints) => set({ hints })} />
          <Toggle label="Training mode" hint="Take back major blunders so you can retry" checked={s.training} onChange={(training) => set({ training })} />
          <Slider label="Blunder threshold" value={s.threshold} min={10} max={40} step={1} show={`${s.threshold}% win chance lost`} onChange={(threshold) => set({ threshold })} />
        </Section>
        <button className={btn} onClick={reset}>Reset to defaults</button>
        <p className="text-xs text-stone-500">Settings are saved in this browser.</p>
      </div>
      <div className="lg:sticky lg:top-4 lg:self-start">
        <p className="mb-2 text-sm text-stone-400">Preview</p>
        <Chessboard fen={PREVIEW} flipped={false} lastMove={{ from: 'g1', to: 'f3' }} disabled look={s} onMove={() => undefined} />
      </div>
    </main>
  )
}
