'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Chess } from 'chess.js'
import Chessboard from '@/components/Chessboard/Chessboard'
import EvalBar from '@/components/EvalBar/EvalBar'
import { COACHES } from '@/lib/coaching/coaches'
import { reactionFor } from '@/lib/coaching/reactions'
import { CLASS_META, accuracyOf, formatScore, type MoveClass } from '@/lib/evaluation/classify'
import { phaseOf, train } from '@/lib/coaching/profile'
import { loadGame, type MoveRecord, type SavedGame } from '@/lib/review/record'
import { speak, stopSpeaking } from '@/lib/voice/speak'

const START = new Chess().fen()
const FINAL = {
  vale: ['A disciplined game. Keep building positions like this.', 'Several decisions drifted. Study the marked moments slowly.'],
  flash: ['Sharp! That was proper chess. Go again!', 'Too many loose moves. Study the red ones, then rematch!'],
  gambit: ['Bravo! A performance worthy of a standing ovation!', 'A tragedy in several acts. Luckily, we have a replay button!'],
}
const important = (m: MoveRecord) => m.cls === 'inaccuracy' || m.cls === 'mistake' || m.cls === 'blunder' || m.san.endsWith('#')
const sq = (u: string) => ({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] })
const pvSan = (fen: string, pv: string[]) => {
  const c = new Chess(fen), out: string[] = []
  for (const u of pv.slice(0, 6)) { try { out.push(c.move(sq(u)).san) } catch { break } }
  return out.join(' ')
}

export default function ReviewPage() {
  const [game, setGame] = useState<SavedGame | null | undefined>(undefined)
  const [idx, setIdx] = useState(-1)
  const [keyOnly, setKeyOnly] = useState(false)
  const [alt, setAlt] = useState(false)
  const [auto, setAuto] = useState(false)
  const len = game?.moves.length ?? 0
  const go = (i: number) => { setIdx(Math.max(-1, Math.min(len - 1, i))); setAlt(false) }

  useEffect(() => { setGame(loadGame()); return stopSpeaking }, [])
  useEffect(() => {
    const f = (e: KeyboardEvent) => { if (e.key === 'ArrowRight') go(idx + 1); if (e.key === 'ArrowLeft') go(idx - 1) }
    window.addEventListener('keydown', f); return () => window.removeEventListener('keydown', f)
  })
  useEffect(() => { if (!auto) return; const t = setInterval(() => setIdx((i) => Math.min(len - 1, i + 1)), 1200); return () => clearInterval(t) }, [auto, len])
  useEffect(() => { if (auto && idx >= len - 1) setAuto(false) }, [auto, idx, len])

  if (game === undefined) return null
  if (game === null) return (
    <main className="mx-auto max-w-xl p-8 text-center">
      <h1 className="font-display text-3xl">No game to review yet</h1>
      <p className="mt-3 text-stone-400">Play a game first. Every move is analysed and saved in this browser for review.</p>
      <Link href="/game" className="mt-6 inline-block rounded-lg bg-gold px-5 py-2.5 font-semibold text-ink">Play a game</Link>
    </main>
  )

  const mv = game.moves, cur = idx >= 0 ? mv[idx] : null
  const coach = COACHES.find((c) => c.id === game.coach)!
  let fen = cur ? cur.fenAfter : START, last = cur ? sq(cur.uci) : null, score = { cp: cur ? cur.after : 30 }
  if (cur && alt) { try { const c = new Chess(cur.fenBefore), m = c.move(sq(cur.best)); fen = c.fen(); last = { from: m.from, to: m.to, promotion: m.promotion }; score = { cp: cur.before } } catch { /* keep played position */ } }
  const mine = mv.filter((m) => m.color === 'w')
  const acc = mine.length ? mine.reduce((s, m) => s + accuracyOf(m.winLoss), 0) / mine.length : 0
  const avg = mine.length ? mine.reduce((s, m) => s + m.cpLoss, 0) / mine.length : 0
  const explain = cur ? (cur.color === 'w' ? reactionFor(game.coach, cur.cls, idx, cur.bestSan) : `The engine’s reply was ${CLASS_META[cur.cls].label.toLowerCase()}. ${CLASS_META[cur.cls].note}`) : ''
  const final = FINAL[game.coach][acc >= 75 ? 0 : 1]
  const btn = 'rounded-md border border-line px-3 py-1.5 hover:bg-panel disabled:opacity-40'

  return (
    <main className="mx-auto grid max-w-6xl gap-6 p-4 lg:grid-cols-[minmax(0,680px)_1fr]">
      <div>
        <h1 className="mb-2 font-display text-xl">Game review with {coach.name} <span className="text-stone-500">({game.result})</span></h1>
        <div className="flex gap-2">
          <EvalBar score={score} flipped={false} />
          <Chessboard fen={fen} flipped={false} lastMove={last} disabled onMove={() => undefined} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2 text-sm">
          <button className={btn} onClick={() => go(-1)} aria-label="Start">⏮</button>
          <button className={btn} onClick={() => go(idx - 1)} aria-label="Previous move">◀</button>
          <button className={btn} onClick={() => setAuto(!auto)}>{auto ? 'Pause' : 'Play'}</button>
          <button className={btn} onClick={() => go(idx + 1)} aria-label="Next move">▶</button>
          <button className={btn} onClick={() => go(len - 1)} aria-label="End">⏭</button>
        </div>
        {cur && (
          <section className="mt-4 rounded-xl border border-line bg-panel p-4 text-sm">
            <p className="flex flex-wrap items-center gap-2">
              <span className="rounded px-2 py-0.5 font-bold text-ink" style={{ background: CLASS_META[cur.cls].color }}>{CLASS_META[cur.cls].icon} {CLASS_META[cur.cls].label}</span>
              <b>{cur.san}</b>
              <span className="text-stone-400">{formatScore({ cp: cur.before })} → {formatScore({ cp: cur.after })}{cur.cpLoss > 0 && `, lost ${cur.cpLoss} cp`}</span>
            </p>
            <p className="mt-2 italic text-stone-300">“{explain}”</p>
            {cur.uci !== cur.best && (
              <p className="mt-2 text-stone-300">Best was <b>{cur.bestSan}</b>. Engine line: {pvSan(cur.fenBefore, cur.pv)}</p>
            )}
            <div className="mt-3 flex gap-2">
              {cur.uci !== cur.best && <button className={btn} onClick={() => setAlt(!alt)}>{alt ? 'Show played move' : 'Show best move'}</button>}
              <button className={btn} onClick={() => speak(explain, game.coach)}>Hear {coach.name}</button>
            </div>
          </section>
        )}
      </div>
      <div className="space-y-4">
        <section className="rounded-xl border border-line bg-panel p-4">
          <h2 className="font-display text-lg">Your game</h2>
          <p className="mt-1 text-sm text-stone-300">Accuracy <b className="text-gold">{acc.toFixed(1)}%</b>, average loss {avg.toFixed(0)} cp over {mine.length} moves, against {game.elo} Elo.</p>
          <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm">
            {(Object.keys(CLASS_META) as MoveClass[]).map((k) => (
              <li key={k}><span style={{ color: CLASS_META[k].color }} className="font-bold">{CLASS_META[k].icon}</span> {CLASS_META[k].label} {mine.filter((m) => m.cls === k).length}</li>
            ))}
          </ul>
          <ul className="mt-3 space-y-1 text-sm text-stone-300">
            {(['opening', 'middlegame', 'endgame'] as const).map((ph) => {
              const xs = mv.filter((m, i) => m.color === 'w' && phaseOf(m.fenBefore, i) === ph)
              if (!xs.length) return null
              return <li key={ph}><span className="capitalize">{ph}</span>: {(xs.reduce((s, m) => s + accuracyOf(m.winLoss), 0) / xs.length).toFixed(1)}% accuracy, {(xs.reduce((s, m) => s + m.cpLoss, 0) / xs.length).toFixed(0)} cp average loss, {xs.length} moves</li>
            })}
          </ul>
          <p className="mt-3 italic text-stone-300">“{final}”</p>
          <p className="mt-2 text-sm text-stone-300"><b>Training:</b> {train(game.coach, game.elo, mv)}</p>
        </section>
        <section className="rounded-xl border border-line p-4">
          <div className="mb-3 flex gap-2 text-sm">
            <button className={`${btn} ${!keyOnly ? 'border-gold' : ''}`} onClick={() => setKeyOnly(false)}>All moves</button>
            <button className={`${btn} ${keyOnly ? 'border-gold' : ''}`} onClick={() => setKeyOnly(true)}>Important moments</button>
          </div>
          <ol className="flex flex-wrap gap-1">
            {mv.map((m, i) => ({ m, i })).filter(({ m }) => !keyOnly || important(m)).map(({ m, i }) => (
              <li key={i}>
                <button onClick={() => go(i)} className={`flex items-center gap-1 rounded px-2 py-1 text-sm ${i === idx ? 'bg-gold text-ink' : 'hover:bg-panel'}`}>
                  {m.color === 'w' && <span className="text-stone-500">{Math.floor(i / 2) + 1}.</span>}{m.san}
                  <span style={{ color: CLASS_META[m.cls].color }} className="font-bold">{CLASS_META[m.cls].icon}</span>
                </button>
              </li>
            ))}
          </ol>
          {keyOnly && !mv.some(important) && <p className="text-sm text-stone-500">No important moments. A clean game.</p>}
        </section>
      </div>
    </main>
  )
}
