import { NextResponse } from 'next/server'
import { COACHES } from '@/lib/coaching/coaches'

// Turns real Stockfish facts into a natural, in-character explanation. The key stays on the server.
// Without ANTHROPIC_API_KEY this returns 501 and the browser falls back to the built-in coach wording.
export async function POST(req: Request) {
  const key = process.env.ANTHROPIC_API_KEY
  if (!key) return NextResponse.json({ error: 'not_configured' }, { status: 501 })
  const body = await req.json().catch(() => null)
  const coach = COACHES.find((c) => c.id === body?.coachId)
  const question = String(body?.question ?? '').slice(0, 300)
  if (!coach || !question) return NextResponse.json({ error: 'bad_request' }, { status: 400 })
  const system = `You are ${coach.name}, an original fictional chess coach (${coach.style}). Philosophy: ${coach.philosophy} ` +
    `The player is about ${Number(body.elo) || 1200} Elo: match your vocabulary to that level. Use ONLY the engine facts provided. ` +
    `Never invent moves, variations or evaluations. If the facts do not cover the question, say so briefly. ` +
    `Never reveal the best move if the facts say it is hidden. Reply in at most three short sentences, in character.`
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-5-5', max_tokens: 300, system,
      messages: [{ role: 'user', content: `Engine facts (Stockfish, trusted):\n${JSON.stringify(body.facts ?? {}).slice(0, 4000)}\n\nPlayer asks: ${question}` }] }),
  }).catch(() => null)
  if (!r?.ok) return NextResponse.json({ error: 'upstream' }, { status: 502 })
  const data = await r.json()
  const text = (data.content ?? []).map((b: { type: string; text?: string }) => (b.type === 'text' ? b.text : '')).join('').trim()
  return text ? NextResponse.json({ text }) : NextResponse.json({ error: 'empty' }, { status: 502 })
}
