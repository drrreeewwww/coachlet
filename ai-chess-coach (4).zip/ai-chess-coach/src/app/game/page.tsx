'use client'
import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { Chess, type Move as ChessMove } from 'chess.js'
import Chessboard from '@/components/Chessboard/Chessboard'
import CoachPanel, { type ChatMsg, type Reaction } from '@/components/CoachPanel/CoachPanel'
import EvalBar from '@/components/EvalBar/EvalBar'
import { answer } from '@/lib/coaching/chat'
import { COACHES } from '@/lib/coaching/coaches'
import { tipFor, weaknesses } from '@/lib/coaching/profile'
import { reactionFor } from '@/lib/coaching/reactions'
import { CLASS_META, classify, formatScore, toCp, type Score } from '@/lib/evaluation/classify'
import { hintFor } from '@/lib/hints/hints'
import { saveGame, type MoveRecord } from '@/lib/review/record'
import { Engine, type Analysis } from '@/lib/stockfish/engine'
import { strengthFor } from '@/lib/stockfish/elo'
import { playSound } from '@/lib/sound/sounds'
import { useSettings } from '@/lib/useSettings'
import { speak, stopSpeaking } from '@/lib/voice/speak'
import type { CoachId } from '@/types'

type Last = { from: string; to: string }
const START = new Chess().fen()
const uciMove = (u: string) => ({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] })
const sanOf = (fen: string, u: string) => { try { return new Chess(fen).move(uciMove(u)).san } catch { return u } }
const lastOf = (r: MoveRecord[]): Last | null => (r.length ? uciMove(r[r.length - 1].uci) : null)
const record = (m: ChessMove, prev: Analysis, after: Score): MoveRecord => {
  const uci = m.from + m.to + (m.promotion ?? ''), c = classify(toCp(prev.score), toCp(after), m.color, uci === prev.best)
  return { color: m.color, san: m.san, uci, fenBefore: m.before, fenAfter: m.after, before: toCp(prev.score), after: toCp(after),
    cls: c.cls, cpLoss: c.cpLoss, winLoss: c.winLoss, best: prev.best, bestSan: sanOf(m.before, prev.best), pv: prev.pv }
}

export default function GamePage() {
  const game = useRef(new Chess())
  const engine = useRef<Engine | null>(null)
  const cache = useRef(new Map<string, Analysis>())
  const recs = useRef<MoveRecord[]>([])
  const n = useRef(0)
  const [fen, setFen] = useState(START)
  const [last, setLast] = useState<Last | null>(null)
  const [coachId, setCoachId] = useState<CoachId>('vale')
  const [elos, setElos] = useState<Record<CoachId, number>>({ vale: 1200, flash: 1600, gambit: 800 })
  const [flipped, setFlipped] = useState(false)
  const [thinking, setThinking] = useState(false)
  const [resigned, setResigned] = useState(false)
  const [error, setError] = useState('')
  const [score, setScore] = useState<Score>({ cp: 30 })
  const [reaction, setReaction] = useState<Reaction | null>(null)
  const [st, setSt] = useSettings()
  const { voice: voiceOn, training, threshold: th, speed } = st
  const setVoiceOn = (v: boolean) => setSt({ voice: v }), setTraining = (v: boolean) => setSt({ training: v })
  const setTh = (v: number) => setSt({ threshold: v }), setSpeed = (v: number) => setSt({ speed: v })
  const [imp, setImp] = useState('')
  const [hint, setHint] = useState(0)
  const [note, setNote] = useState('')
  const [marks, setMarks] = useState<string[]>([])
  const [chat, setChat] = useState<ChatMsg[]>([])
  const spoken = useRef('')
  const say = (t: string) => { spoken.current = t; if (voiceOn) speak(t, coachId, speed) }

  useEffect(() => {
    let e: Engine | null = null
    try { e = new Engine(); engine.current = e } catch { setError('Stockfish could not start in this browser.') }
    e?.analyse(START).then((a) => { cache.current.set(START, a); setScore(a.score) }).catch(() => undefined)
    return () => { e?.destroy(); stopSpeaking() }
  }, [])

  const play = (from: string, to: string, promotion = 'q') => {
    try { const m = game.current.move({ from, to, promotion }); setFen(game.current.fen()); setLast(m)
      const gg = game.current
      playSound(gg.isGameOver() ? 'end' : m.san.includes('+') ? 'check' : m.captured ? 'capture' : 'move', st.sound ? st.volume : 0)
      return m } catch { return null }
  }
  const analyse = async (f: string) => {
    const hit = cache.current.get(f); if (hit) return hit
    const a = await engine.current!.analyse(f); cache.current.set(f, a); return a
  }
  const scoreOf = async (c: Chess): Promise<Score> =>
    c.isGameOver() ? { cp: c.isCheckmate() ? (c.turn() === 'w' ? -10000 : 10000) : 0 } : (await analyse(c.fen())).score
  const persist = (result?: string) => {
    const g = game.current
    saveGame({ coach: coachId, elo: elos[coachId], moves: recs.current,
      result: result ?? (g.isCheckmate() ? (g.turn() === 'w' ? '0-1' : '1-0') : g.isGameOver() ? '1/2-1/2' : '*') })
  }
  const reset = () => { setHint(0); setNote(''); setMarks([]) }

  const engineReply = async (g: Chess, eng: Engine) => {
    const mv = uciMove(await eng.bestMove(g.fen(), strengthFor(elos[coachId])))
    const r = play(mv.from, mv.to, mv.promotion)
    if (r) { const a2 = await scoreOf(g); recs.current.push(record(r, await analyse(r.before), a2)); setScore(a2) }
  }

  const onMove = async (from: string, to: string, promotion?: string) => {
    const g = game.current, eng = engine.current
    if (!eng) return
    const m = play(from, to, promotion)
    if (!m) return
    reset(); setThinking(true)
    try {
      const prev = await analyse(m.before)
      const after = await scoreOf(g)
      const rec = record(m, prev, after)
      const bad = rec.cls === 'mistake' || rec.cls === 'blunder'
      const text = reactionFor(coachId, rec.cls, n.current++, rec.bestSan) + (bad ? ' ' + tipFor(coachId, elos[coachId]) : '')
      if (st.reactions || bad) { setReaction({ text, cls: rec.cls, cpLoss: rec.cpLoss, san: m.san }); say(text) }
      if (training && rec.winLoss >= th) { // training mode: take back a major blunder and let the player retry
        g.undo(); setFen(g.fen()); setLast(lastOf(recs.current)); setScore(prev.score); setMarks([m.from, m.to])
        setNote('Blunder taken back. Try a different move, or ask for a hint.')
        return
      }
      recs.current.push(rec); setScore(after)
      if (bad) { const w = weaknesses(recs.current); if (w.phase || w.piece) setNote(`Pattern noticed: ${w.phase ? `${w.phase[1]} mistakes in the ${w.phase[0]}` : `${w.piece![1]} costly ${w.piece![0]} moves`}.`) }
      if (!g.isGameOver()) await engineReply(g, eng)
    } catch { setError('The engine stopped responding. Start a new game.') } finally { persist(); setThinking(false) }
  }

  const onHint = async () => {
    const g = game.current, lvl = Math.min(4, hint + 1) as 1 | 2 | 3 | 4
    try {
      const a = await analyse(g.fen()), h = hintFor(g.fen(), a.best, a.score, lvl)
      setHint(lvl); setNote(`Hint ${lvl} of 4: ${h.text}`); setMarks(h.marks)
      say(h.text)
    } catch { setNote('No hint available right now.') }
  }

  const undo = () => { // training mode only: take back the last full move (yours and the reply)
    const g = game.current
    for (let i = g.history().length % 2 === 0 ? 2 : 1; i > 0; i--) { g.undo(); recs.current.pop() }
    setFen(g.fen()); setLast(lastOf(recs.current)); setScore(cache.current.get(g.fen())?.score ?? { cp: 30 }); setReaction(null); reset(); persist()
  }
  const newGame = () => {
    game.current = new Chess(); recs.current = []; setFen(START); setLast(null); setResigned(false); setError(''); setReaction(null); setChat([]); spoken.current = ''; reset()
    setScore(cache.current.get(START)?.score ?? { cp: 30 }); stopSpeaking()
  }
  const importText = () => {
    const t = imp.trim(), eng = engine.current
    if (!t || thinking || !eng) return
    const c = new Chess()
    try { if (/^[rnbqkpRNBQKP1-8]+\/.*\s[wb]\s/.test(t)) c.load(t); else c.loadPgn(t) } catch { setNote('That is not a valid FEN or PGN.'); return }
    game.current = c; recs.current = []; setFen(c.fen()); setLast(null); setResigned(false); setError(''); setReaction(null); setChat([]); reset(); setImp('')
    setScore(cache.current.get(c.fen())?.score ?? { cp: 0 })
    analyse(c.fen()).then((a) => setScore(a.score)).catch(() => undefined)
    setNote(c.isGameOver() ? 'Loaded. This position is already finished.' : `Loaded. ${c.turn() === 'w' ? 'Your move.' : 'The coach moves first.'}`)
    if (c.turn() === 'b' && !c.isGameOver()) {
      setThinking(true)
      engineReply(c, eng).catch(() => setError('The engine stopped responding. Start a new game.')).finally(() => { persist(); setThinking(false) })
    }
  }
  const ask = async (q: string) => {
    setChat((c) => [...c, { from: 'you', text: q }])
    let a: Analysis | null = null
    try { if (engine.current && !game.current.isGameOver()) a = await analyse(game.current.fen()) } catch { /* answer without engine data */ }
    const ctx = { coach: coachId, elo: elos[coachId], bestSan: a ? sanOf(game.current.fen(), a.best) : undefined, score: a?.score ?? score, recs: recs.current, over: game.current.isGameOver() }
    let reply = ''
    try { // language-model explanation of real engine facts; falls back to the built-in wording if unavailable
      const mine = recs.current.filter((m) => m.color === 'w'), lastRec = mine[mine.length - 1]
      const facts = {
        sideToMove: game.current.turn() === 'w' ? 'White (the player)' : 'Black (the opponent)', evaluationWhitePOV: formatScore(ctx.score),
        bestMove: /best|hint|suggest|play/i.test(q) ? ctx.bestSan ?? 'none' : 'hidden: the player has not asked',
        lastPlayerMove: lastRec && { san: lastRec.san, rating: CLASS_META[lastRec.cls].label, centipawnLoss: lastRec.cpLoss, engineBest: lastRec.bestSan },
        seriousMistakes: mine.filter((m) => m.cls === 'mistake' || m.cls === 'blunder').slice(-5).map((m) => `${m.san} (${CLASS_META[m.cls].label}, best ${m.bestSan})`),
        recurringWeaknesses: weaknesses(recs.current),
      }
      const r = await fetch('/api/coach', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ coachId, elo: elos[coachId], question: q, facts }) })
      if (r.ok) reply = ((await r.json()).text as string) ?? ''
    } catch { /* fall back below */ }
    if (!reply) reply = answer(q, ctx)
    setChat((c) => [...c, { from: 'coach', text: reply }]); say(reply)
  }
  const copy = (text: string, label: string) =>
    navigator.clipboard?.writeText(text).then(() => setNote(`${label} copied.`), () => setNote('Copying is blocked in this browser.'))

  const g = game.current
  const coach = COACHES.find((c) => c.id === coachId)!
  const over = resigned || g.isGameOver()
  const myTurn = g.turn() === 'w' && !over && !thinking
  const status = resigned ? 'You resigned.'
    : g.isCheckmate() ? `Checkmate. ${g.turn() === 'w' ? 'Black' : 'White'} wins.`
    : g.isDraw() ? 'Draw.' : thinking ? `${coach.name} is thinking…` : g.inCheck() ? 'Check! Your move.' : 'Your move.'
  const hist = g.history()
  const rows = Array.from({ length: Math.ceil(hist.length / 2) }, (_, i) => `${i + 1}. ${hist[2 * i]} ${hist[2 * i + 1] ?? ''}`)
  const btn = 'rounded-md border border-line px-3 py-1.5 hover:bg-panel disabled:opacity-40'

  return (
    <main className="mx-auto grid max-w-6xl gap-6 p-4 lg:grid-cols-[minmax(0,680px)_1fr]">
      <div>
        <p className="mb-2 font-display text-xl" role="status">{error || status}</p>
        <div className="flex gap-2">
          {st.evalBar && <EvalBar score={score} flipped={flipped} />}
          <Chessboard fen={fen} flipped={flipped} lastMove={last} marks={marks} look={st} disabled={!myTurn} onMove={onMove} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2 text-sm">
          <button onClick={newGame} disabled={thinking} className={btn}>New game</button>
          {st.hints && <button onClick={onHint} disabled={!myTurn} className={btn}>Hint{hint ? ` (${hint}/4)` : ''}</button>}
          {training && <button onClick={undo} disabled={thinking || !hist.length} className={btn}>Undo</button>}
          <button onClick={() => setFlipped(!flipped)} className={btn}>Flip board</button>
          <button onClick={() => { setResigned(true); persist('0-1') }} disabled={thinking || over} className={btn}>Resign</button>
          <button onClick={() => copy(g.pgn(), 'PGN')} className={btn}>Copy PGN</button>
          <button onClick={() => copy(g.fen(), 'FEN')} className={btn}>Copy FEN</button>
          {recs.current.length > 0 && <Link href="/review" className={`${btn} border-gold text-gold`}>Review game</Link>}
        </div>
        {note && <p className="mt-3 rounded-md border border-gold/60 bg-panel p-3 text-sm" aria-live="polite">{note}</p>}
        <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-stone-300">
          <label className="flex items-center gap-2"><input type="checkbox" checked={training} onChange={(e) => setTraining(e.target.checked)} className="accent-[#d1a64a]" /> Training mode</label>
          {training && (
            <label className="flex items-center gap-2">Take back moves that lose {th}% or more
              <input type="range" min={10} max={40} value={th} onChange={(e) => setTh(Number(e.target.value))} className="accent-[#d1a64a]" /></label>
          )}
        </div>
        <details className="mt-3 rounded-md border border-line bg-panel p-3 text-sm">
          <summary className="cursor-pointer text-stone-300">Import PGN or FEN</summary>
          <textarea value={imp} onChange={(e) => setImp(e.target.value)} rows={3} aria-label="PGN or FEN" placeholder="Paste a PGN or a FEN position"
            className="mt-2 w-full rounded-md border border-line bg-ink p-2 text-xs" />
          <button onClick={importText} disabled={thinking || !imp.trim()} className={`${btn} mt-2`}>Load</button>
        </details>
        <ol className="mt-4 flex flex-wrap gap-x-4 gap-y-1 rounded-md border border-line bg-panel p-3 text-sm text-stone-300">
          {rows.length ? rows.map((r, i) => <li key={i}>{r}</li>) : <li className="text-stone-500">Moves will appear here.</li>}
        </ol>
      </div>
      <CoachPanel coachId={coachId} elos={elos} onCoach={(id) => { stopSpeaking(); setCoachId(id) }} onElo={(id, e) => setElos({ ...elos, [id]: e })}
        reaction={reaction} voiceOn={voiceOn} onVoice={(on) => { setVoiceOn(on); if (!on) stopSpeaking() }} speed={speed} onSpeed={setSpeed}
        onPreview={(id) => speak(COACHES.find((c) => c.id === id)!.preview, id, speed)} onReplay={() => spoken.current && speak(spoken.current, coachId, speed)}
        onStop={stopSpeaking} chat={chat} onAsk={ask} />
    </main>
  )
}
