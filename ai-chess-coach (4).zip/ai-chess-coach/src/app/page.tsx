import Link from 'next/link'
import Avatar from '@/components/CoachPanel/Avatar'
import { COACHES } from '@/lib/coaching/coaches'

export default function Home() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-16">
      <h1 className="max-w-2xl font-display text-5xl leading-tight sm:text-6xl">Play chess with a coach in your corner.</h1>
      <p className="mt-5 max-w-xl text-lg text-stone-400">Face Stockfish at any strength from 300 to 3200 Elo, and pick the coach whose voice suits how you like to learn.</p>
      <Link href="/game" className="mt-8 inline-block rounded-lg bg-gold px-6 py-3 font-semibold text-ink">Start playing</Link>
      <div className="mt-16 grid gap-4 sm:grid-cols-3">
        {COACHES.map((c) => (
          <div key={c.id} className="rounded-xl border border-line bg-panel p-5">
            <Avatar id={c.id} accent={c.accent} size={56} />
            <h2 className="mt-3 font-display text-xl">{c.name}</h2>
            <p className="text-sm text-stone-300">{c.style}</p>
            <p className="mt-2 text-sm text-stone-500">{c.tagline}</p>
          </div>
        ))}
      </div>
      <p className="mt-6 max-w-xl text-xs text-stone-500">The coaches are original fictional characters. Their voices are your browser’s built-in synthetic voices, and every evaluation comes from the Stockfish engine running in your browser.</p>
    </main>
  )
}
