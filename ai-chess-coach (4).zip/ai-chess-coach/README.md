# AI Chess Coach (Stage 1)
    npm install      # also copies the Stockfish WASM worker into public/stockfish/
    npm run dev      # http://localhost:3000
If the engine does not start, check that public/stockfish/stockfish.js and stockfish.wasm exist (see scripts/copy-stockfish.mjs).

## Optional: language-model coaching
Set `ANTHROPIC_API_KEY` (and optionally `ANTHROPIC_MODEL`) in `.env.local`. Chat answers then use the model to explain the real Stockfish facts;
without a key the built-in coach wording is used. The key is only ever read in `src/app/api/coach/route.ts` on the server.
