import type { Config } from 'tailwindcss'
export default {
  content: ['./src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { ink: '#13201b', panel: '#1b2c25', line: '#2c443a', gold: '#d1a64a', sq: { light: '#e8d8b9', dark: '#8a6a4a' } },
    fontFamily: { display: ['var(--font-display)', 'serif'], sans: ['var(--font-sans)', 'system-ui', 'sans-serif'] },
  } },
  plugins: [],
} satisfies Config
