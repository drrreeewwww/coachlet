// Copies the single-threaded Stockfish WASM build into /public so the browser can load it as a Web Worker.
import fs from 'node:fs'
import path from 'node:path'
const src = 'node_modules/stockfish/src', out = 'public/stockfish'
try {
  const files = fs.readdirSync(src).filter((f) => f.includes('single')).sort((a, b) => +b.includes('lite') - +a.includes('lite'))
  const js = files.find((f) => f.endsWith('.js')), wasm = files.find((f) => f.endsWith('.wasm'))
  fs.mkdirSync(out, { recursive: true })
  fs.copyFileSync(path.join(src, js), path.join(out, 'stockfish.js'))
  fs.copyFileSync(path.join(src, wasm), path.join(out, 'stockfish.wasm'))
  console.log('Stockfish copied:', js, wasm)
} catch (e) { console.warn('Stockfish copy skipped:', e.message) }
