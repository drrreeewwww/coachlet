import assert from 'node:assert/strict'
import { accuracyOf, classify, winPct, toCp, formatScore } from '../src/lib/evaluation/classify.ts'
assert.equal(Math.round(winPct(0)), 50)
assert.ok(winPct(300) > 70 && winPct(-300) < 30)
assert.equal(classify(50, 50, 'w', true).cls, 'best')
assert.equal(classify(50, 45, 'w', false).cls, 'best')       // ~5cp loss is noise, treated as best
assert.equal(classify(50, 20, 'w', false).cls, 'good')       // 30cp loss
assert.equal(classify(50, -250, 'w', false).cls, 'blunder')  // White drops 3 pawns
assert.equal(classify(-50, 250, 'b', false).cls, 'blunder')  // same from Black's side
assert.equal(classify(100, 100, 'b', false).cls, 'best')     // Black’s eval unchanged (gaining is not a loss)
assert.equal(classify(0, -150, 'w', false).cls, 'mistake')
assert.equal(classify(0, -60, 'w', false).cls, 'inaccuracy')
assert.equal(classify(0, 200, 'w', false).cpLoss, 0)
assert.equal(toCp({ mate: 3 }), 9970); assert.equal(toCp({ mate: -3 }), -9970)
assert.equal(formatScore({ cp: 40 }), '+0.4'); assert.equal(formatScore({ mate: -2 }), '-M2')
assert.ok(accuracyOf(0) > 99 && accuracyOf(30) < 30)
console.log('classify: all tests passed')
