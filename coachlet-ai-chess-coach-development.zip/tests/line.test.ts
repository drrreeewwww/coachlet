import { describe, expect, it } from 'vitest'
import { emptyLine, fenAt, goTo, lastMoveAt, lineFromSans, normaliseUci, sansOf, tryPlay, START_FEN, moveLabel } from '@/lib/openings/lineState'

describe('line state', () => {
  it('builds a legal line and rejects an illegal one', () => {
    const l = lineFromSans(['e4', 'e5', 'Nf3', 'Nc6'])!
    expect(l.plies).toHaveLength(4)
    expect(l.cursor).toBe(4)
    expect(sansOf(l)).toEqual(['e4', 'e5', 'Nf3', 'Nc6'])
    expect(lineFromSans(['e4', 'e4'])).toBeNull()
  })
  it('keeps FEN and last move in sync with the cursor', () => {
    const l = lineFromSans(['e4', 'c5'])!
    expect(fenAt(goTo(l, 0))).toBe(START_FEN)
    expect(fenAt(l)).toContain('rnbqkbnr/pp1ppppp/8/2p5/4P3/8/PPPP1PPP/RNBQKBNR w KQkq -')
    expect(lastMoveAt(l)).toEqual({ from: 'c7', to: 'c5' })
    expect(lastMoveAt(goTo(l, 0))).toBeNull()
  })
  it('re-playing the stored next move keeps the future; a different move branches', () => {
    const full = lineFromSans(['e4', 'e5', 'Nf3'])!
    const back = goTo(full, 1)
    const same = tryPlay(back, { san: 'e5' })!
    expect(same.plies).toHaveLength(3)
    expect(same.cursor).toBe(2)
    const branch = tryPlay(back, { san: 'c5' })!
    expect(sansOf(branch)).toEqual(['e4', 'c5'])
    expect(branch.cursor).toBe(2)
  })
  it('rejects illegal moves without changing state', () => {
    expect(tryPlay(emptyLine(), { from: 'e2', to: 'e5' })).toBeNull()
    expect(tryPlay(emptyLine(), { san: 'Ke2' })).toBeNull()
  })
  it('handles castling, en passant, promotion and mate', () => {
    const castle = lineFromSans(['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'O-O'])!
    expect(castle.plies[6].uci).toBe('e1g1')
    const ep = lineFromSans(['e4', 'a6', 'e5', 'd5', 'exd6'])!
    expect(ep.plies[4].san).toBe('exd6')
    expect(fenAt(ep).split(' ')[0]).not.toContain('d5')
    const promo = tryPlay({ plies: [], cursor: 0 }, { san: 'e4' })!
    expect(promo.cursor).toBe(1)
    const mate = lineFromSans(['f3', 'e5', 'g4', 'Qh4#'])!
    expect(mate.plies[3].san).toBe('Qh4#')
  })
  it('promotion via from/to', () => {
    const l = lineFromSans(['a4', 'b5', 'axb5', 'a6', 'bxa6', 'Bb7', 'a7', 'Bxg2'])!
    const p = tryPlay(l, { from: 'a7', to: 'b8', promotion: 'q' })!
    expect(p.plies[8].san).toBe('axb8=Q')
    expect(tryPlay(l, { from: 'a7', to: 'b8' })).toBeNull() // promotion piece required
  })
  it('normalises Lichess king-takes-rook castling UCI', () => {
    const l = lineFromSans(['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5'])!
    expect(normaliseUci('e1h1', fenAt(l))).toBe('e1g1')
    expect(tryPlay(l, { uci: 'e1h1' })!.plies[6].san).toBe('O-O')
    expect(normaliseUci('e2e4', START_FEN)).toBe('e2e4')
  })
  it('labels moves', () => {
    expect(moveLabel(0, 'e4')).toBe('1. e4')
    expect(moveLabel(1, 'e5')).toBe('1… e5')
    expect(moveLabel(4, 'Nf3')).toBe('3. Nf3')
  })
})
