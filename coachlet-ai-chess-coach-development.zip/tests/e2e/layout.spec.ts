import { expect, test } from '@playwright/test'
import fs from 'node:fs'

const VIEWPORTS = [
  ['iPhone SE', 375, 667], ['iPhone 14', 390, 844], ['iPhone Pro Max', 430, 932], ['iPhone landscape', 844, 390],
  ['iPad portrait', 768, 1024], ['iPad Air portrait', 820, 1180], ['iPad landscape', 1024, 768],
  ['Laptop', 1366, 768], ['Desktop', 1440, 900], ['Large desktop', 1920, 1080],
] as const

fs.mkdirSync('/tmp/shots', { recursive: true })

for (const [name, w, h] of VIEWPORTS) {
  for (const route of ['/play', '/openings', '/', '/settings', '/review']) {
    test(`${name} ${w}x${h} ${route}`, async ({ page }) => {
      const errors: string[] = []
      page.on('pageerror', (e) => errors.push(e.message))
      await page.setViewportSize({ width: w, height: h })
      await page.goto(route)
      await page.waitForTimeout(600)
      const shot = `/tmp/shots/${name.replace(/ /g, '_')}${route.replace(/\//g, '_') || '_home'}.png`
      await page.screenshot({ path: shot })

      // No horizontal overflow anywhere
      const overflow = await page.evaluate(() => {
        const m = document.querySelector('main')!
        return { doc: document.documentElement.scrollWidth - window.innerWidth, main: m.scrollWidth - m.clientWidth }
      })
      expect(overflow.doc, 'document horizontal overflow').toBeLessThanOrEqual(0)
      expect(overflow.main, 'main horizontal overflow').toBeLessThanOrEqual(0)

      if (route === '/play' || route === '/openings') {
        const board = page.locator('[data-square="e4"]').first()
        const box = await page.evaluate(() => {
          const sq = document.querySelector('[data-square="a8"]')!
          let el: HTMLElement | null = sq.parentElement // the 8x8 grid
          el = el!.parentElement // board root (aspect-square)
          const r = el!.getBoundingClientRect()
          return { x: r.x, y: r.y, w: r.width, h: r.height }
        })
        await expect(board).toBeVisible()
        expect(Math.abs(box.w - box.h), 'board is square').toBeLessThanOrEqual(1.5)
        expect(box.x, 'not clipped left').toBeGreaterThanOrEqual(0)
        expect(box.x + box.w, 'not clipped right').toBeLessThanOrEqual(w + 0.5)
        expect(box.w, 'board not tiny').toBeGreaterThanOrEqual(Math.min(260, w - 40))
        const mainBox = await page.evaluate(() => { const r = document.querySelector('main')!.getBoundingClientRect(); return { x: r.x, w: r.width, y: r.y, h: r.height } })
        expect(box.x).toBeGreaterThanOrEqual(mainBox.x - 0.5)
        expect(box.x + box.w).toBeLessThanOrEqual(mainBox.x + mainBox.w + 0.5)
        if (w >= 1024 && h >= 700) expect(box.y + box.h, 'board fits vertically on desktop').toBeLessThanOrEqual(h + 0.5)
        fs.appendFileSync('/tmp/shots/board-sizes.txt', `${name} ${w}x${h} ${route}: board ${Math.round(box.w)}px at x=${Math.round(box.x)} y=${Math.round(box.y)} (main x=${Math.round(mainBox.x)} w=${Math.round(mainBox.w)})\n`)
      }
      expect(errors, 'no uncaught page errors').toEqual([])
    })
  }
}
