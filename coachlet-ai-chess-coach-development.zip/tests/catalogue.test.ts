import { describe, expect, it } from 'vitest'
import { Chess } from 'chess.js'
import rows from '@/lib/openings/data/openings.json'
import { buildCatalogue, browseCategory, categoriesOf, epdOf, nameForLine, primaryCategory, searchOpenings, CATEGORIES } from '@/lib/openings/catalogue'
import { infoFor } from '@/lib/openings/familyInfo'
import { lineFromSans } from '@/lib/openings/lineState'
import { positionInsights } from '@/lib/openings/insights'

const cat = buildCatalogue(rows as unknown as Array<[string, string, string, string]>)

describe('opening catalogue', () => {
  it('contains thousands of openings with legal lines and consistent EPDs', () => {
    expect(cat.entries.length).toBeGreaterThan(3500)
    for (const e of [cat.entries[0], cat.entries[1500], cat.entries[3000], cat.entries[cat.entries.length - 1]]) {
      const l = lineFromSans(e.sans)!
      expect(l).not.toBeNull()
      expect(epdOf(l.plies[l.plies.length - 1].fen)).toBe(e.epd)
    }
  })
  it('searches by name and ECO code', () => {
    expect(searchOpenings(cat, 'najdorf')[0].name).toMatch(/Najdorf/)
    expect(searchOpenings(cat, 'B90')[0].eco).toBe('B90')
    expect(searchOpenings(cat, 'grunfeld').some((e) => e.family === 'Grünfeld Defense')).toBe(true)
    expect(searchOpenings(cat, 'zzzzzz')).toEqual([])
    expect(searchOpenings(cat, 'sicilian dragon').every((e) => /sicilian/i.test(e.name) && /dragon/i.test(e.name))).toBe(true)
  })
  it('names positions and finds the last named position after leaving book', () => {
    const l = lineFromSans(['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6', 'h3'])!
    const epds = ['rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq -', ...l.plies.map((p) => epdOf(p.fen))]
    const n = nameForLine(cat, epds, 9)!
    expect(n.entry.family).toBe('Ruy Lopez')
    expect(n.ply).toBeLessThanOrEqual(9)
  })
  it('categorises ECO ranges and gambits', () => {
    expect(primaryCategory('C60')).toBe('Open Games')
    expect(primaryCategory('C00')).toBe('Semi-Open Games')
    expect(primaryCategory('B20')).toBe('Semi-Open Games')
    expect(primaryCategory('D30')).toBe('Closed Games')
    expect(primaryCategory('E60')).toBe('Indian Defences')
    expect(primaryCategory('A10')).toBe('Flank Openings')
    const ev = cat.entries.find((e) => /Evans Gambit/.test(e.name))!
    expect(categoriesOf(ev)).toContain('Gambits')
    for (const c of CATEGORIES) expect(browseCategory(cat, c).length).toBeGreaterThan(5)
  })
  it('has curated notes for popular families and honest fallbacks otherwise', () => {
    expect(infoFor('Italian Game', 'Open Games').curated).toBe(true)
    const f = infoFor('Obscure Opening', 'Flank Openings')
    expect(f.curated).toBe(false)
    expect(f.info.summary).toMatch(/flank/i)
  })
})

describe('position insights are grounded in the board', () => {
  it('reports centre, development, hanging pieces and castling from the actual position', () => {
    const l = lineFromSans(['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6', 'Ng5', 'd5', 'exd5', 'Nxd5', 'Nxf7'])!
    const ins = positionInsights(l.plies[l.plies.length - 1].fen, 'Nxf7').join(' | ')
    expect(ins).toMatch(/Nxf7 is a capture/)
    expect(ins).toMatch(/Development: White has moved 2 of 4/)
    expect(ins).toMatch(/Black's king can no longer castle|king is on e8|attacked/)
    const start = positionInsights(new Chess().fen(), null).join(' ')
    expect(start).not.toMatch(/attacked/)
  })
  it('flags checkmate', () => {
    const l = lineFromSans(['f3', 'e5', 'g4', 'Qh4#'])!
    expect(positionInsights(l.plies[3].fen, 'Qh4#').join(' ')).toMatch(/checkmate/i)
  })
})
