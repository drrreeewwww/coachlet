import { beforeEach, describe, expect, it, vi } from 'vitest'
import { _resetExplorerState, explorerUrl, formatCount, getExplorer, moveShare, parseExplorer, positionKey, rankMoves, resultSplit } from '@/lib/openings/explorerApi'
import { START_FEN } from '@/lib/openings/lineState'

const sample = {
  white: 600, draws: 300, black: 100,
  moves: [
    { uci: 'd2d4', san: 'd4', averageRating: 2500, white: 100, draws: 60, black: 40 },
    { uci: 'e2e4', san: 'e4', averageRating: 2510, white: 400, draws: 200, black: 50 },
    { uci: 'g1f3', san: 'Nf3', white: 100, draws: 40, black: 10 },
    { uci: 'bad', san: 'x' },
  ],
  opening: { eco: 'A00', name: 'Start' },
}
const okRes = (body: unknown = sample) => ({ ok: true, status: 200, json: async () => body }) as Response
const status = (n: number) => ({ ok: false, status: n, json: async () => ({}) }) as Response

describe('explorer parsing & statistics', () => {
  it('parses the documented shape and drops malformed moves', () => {
    const p = parseExplorer(sample, 'masters', START_FEN)!
    expect(p.total).toBe(1000)
    expect(p.moves).toHaveLength(3)
    expect(p.moves[1].total).toBe(650)
    expect(p.opening).toEqual({ eco: 'A00', name: 'Start' })
    expect(parseExplorer({ nope: 1 }, 'masters', START_FEN)).toBeNull()
    expect(parseExplorer(null, 'lichess', START_FEN)).toBeNull()
  })
  it('ranks by games and computes shares and result splits from the data', () => {
    const p = parseExplorer(sample, 'masters', START_FEN)!
    const r = rankMoves(p)
    expect(r.map((m) => m.san)).toEqual(['e4', 'd4', 'Nf3'])
    expect(moveShare(r[0], p)).toBeCloseTo(65)
    expect(moveShare(r[1], p)).toBeCloseTo(20)
    const s = resultSplit(r[0])
    expect(s.white + s.draws + s.black).toBeCloseTo(100)
    expect(s.white).toBeCloseTo((400 / 650) * 100)
    expect(resultSplit({ white: 0, draws: 0, black: 0, total: 0 })).toEqual({ white: 0, draws: 0, black: 0 })
    expect(moveShare({ ...r[0], total: 5 }, { total: 0 })).toBe(0)
  })
  it('formats counts and builds stable keys / urls', () => {
    expect(formatCount(950)).toBe('950')
    expect(formatCount(1500)).toBe('1.5k')
    expect(formatCount(24_000)).toBe('24k')
    expect(formatCount(3_200_000)).toBe('3.2M')
    expect(positionKey('masters', 'a b c d 5 9')).toBe('masters|a b c d')
    expect(explorerUrl('lichess', START_FEN)).toContain('https://explorer.lichess.org/lichess?')
    expect(explorerUrl('masters', START_FEN)).toContain('/masters?')
  })
})

describe('explorer network behaviour', () => {
  beforeEach(() => _resetExplorerState())

  it('never calls the network without a token and says so', async () => {
    const f = vi.fn()
    expect(await getExplorer('masters', START_FEN, { fetchImpl: f as unknown as typeof fetch })).toEqual({ status: 'no-token' })
    expect(f).not.toHaveBeenCalled()
  })
  it('sends a Bearer token, then serves identical positions from cache', async () => {
    const f = vi.fn().mockResolvedValue(okRes())
    const a = await getExplorer('masters', START_FEN, { token: 'abc', fetchImpl: f as unknown as typeof fetch })
    const b = await getExplorer('masters', START_FEN + '', { token: 'abc', fetchImpl: f as unknown as typeof fetch })
    expect(a.status === 'ok' && !a.cached).toBe(true)
    expect(b.status === 'ok' && b.cached).toBe(true)
    expect(f).toHaveBeenCalledTimes(1)
    expect((f.mock.calls[0][1] as RequestInit).headers).toMatchObject({ Authorization: 'Bearer abc' })
  })
  it('cached positions work without a token (offline use)', async () => {
    const f = vi.fn().mockResolvedValue(okRes())
    await getExplorer('masters', START_FEN, { token: 'abc', fetchImpl: f as unknown as typeof fetch })
    const r = await getExplorer('masters', START_FEN, {})
    expect(r.status).toBe('ok')
  })
  it('reports 401 and does not cache it', async () => {
    const f = vi.fn().mockResolvedValue(status(401))
    expect((await getExplorer('lichess', START_FEN, { token: 'x', fetchImpl: f as unknown as typeof fetch })).status).toBe('unauthorized')
  })
  it('backs off for >= 60 s after a 429 and blocks further requests', async () => {
    let t = 1_000_000
    const f = vi.fn().mockResolvedValue(status(429))
    const opts = { token: 'x', fetchImpl: f as unknown as typeof fetch, now: () => t }
    const r = await getExplorer('lichess', START_FEN, opts)
    expect(r.status).toBe('rate-limited')
    if (r.status === 'rate-limited') expect(r.retryAt - t).toBeGreaterThanOrEqual(60_000)
    const r2 = await getExplorer('lichess', 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1', opts)
    expect(r2.status).toBe('rate-limited')
    expect(f).toHaveBeenCalledTimes(1)
    t += 61_000
    f.mockResolvedValue(okRes())
    const r3 = await getExplorer('lichess', 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1', opts)
    expect(r3.status).toBe('ok')
  })
  it('serialises requests (one at a time) and skips aborted ones', async () => {
    let active = 0
    let max = 0
    const f = vi.fn().mockImplementation(async () => {
      active++
      max = Math.max(max, active)
      await new Promise((r) => setTimeout(r, 20))
      active--
      return okRes()
    })
    const ctl = new AbortController()
    const fens = ['a', 'b', 'c'].map((x) => `${x}/8 w - - 0 1`)
    const ps = fens.map((fen, i) => getExplorer('masters', fen, { token: 't', fetchImpl: f as unknown as typeof fetch, signal: i === 2 ? ctl.signal : undefined }))
    ctl.abort()
    const res = await Promise.all(ps)
    expect(max).toBe(1)
    expect(res[2]).toEqual({ status: 'error', message: 'cancelled' })
    expect(f).toHaveBeenCalledTimes(2)
  })
  it('falls back to stale cache on network failure, otherwise reports offline', async () => {
    let t = 0
    const good = vi.fn().mockResolvedValue(okRes())
    await getExplorer('lichess', START_FEN, { token: 't', fetchImpl: good as unknown as typeof fetch, now: () => t })
    t += 2 * 86_400_000
    const bad = vi.fn().mockRejectedValue(new TypeError('network'))
    const r = await getExplorer('lichess', START_FEN, { token: 't', fetchImpl: bad as unknown as typeof fetch, now: () => t })
    expect(r.status === 'ok' && r.stale && r.cached).toBe(true)
    const r2 = await getExplorer('lichess', 'x/8 b - - 0 1', { token: 't', fetchImpl: bad as unknown as typeof fetch, now: () => t })
    expect(r2.status).toBe('offline')
  })
  it('rejects malformed payloads rather than inventing data', async () => {
    const f = vi.fn().mockResolvedValue(okRes({ hello: 'world' }))
    const r = await getExplorer('masters', 'm/8 w - - 0 1', { token: 't', fetchImpl: f as unknown as typeof fetch })
    expect(r.status).toBe('error')
  })
})
