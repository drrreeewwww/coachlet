import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { Autoplay } from '@/lib/openings/autoplay'

describe('Autoplay', () => {
  beforeEach(() => vi.useFakeTimers())
  afterEach(() => vi.useRealTimers())

  it('plays the first ply immediately then one ply per interval, and stops at the end', async () => {
    const times: number[] = []
    let n = 0
    const running: boolean[] = []
    const ap = new Autoplay({
      getIntervalMs: () => 1500,
      onRunning: (r) => running.push(r),
      step: async () => { times.push(Date.now()); return ++n >= 4 ? 'stop' : 'continue' },
    })
    const t0 = Date.now()
    ap.start()
    await vi.advanceTimersByTimeAsync(10_000)
    expect(times.map((t) => t - t0)).toEqual([0, 1500, 3000, 4500])
    expect(ap.isRunning).toBe(false)
    expect(running).toEqual([true, false])
  })
  it('uses a single timer: double start does nothing', async () => {
    const step = vi.fn(async () => 'continue' as const)
    const ap = new Autoplay({ getIntervalMs: () => 1000, onRunning: () => {}, step })
    ap.start(); ap.start(); ap.start()
    await vi.advanceTimersByTimeAsync(3500)
    expect(step).toHaveBeenCalledTimes(4)
    ap.stop()
  })
  it('pause keeps nothing scheduled; resume continues; stale step results are ignored', async () => {
    const applied: number[] = []
    let id = 0
    let release: (() => void) | null = null
    const ap = new Autoplay({
      getIntervalMs: () => 1000,
      onRunning: () => {},
      step: async (active) => {
        const my = ++id
        if (my === 2) await new Promise<void>((r) => { release = r }) // slow engine
        if (!active()) return 'stop'
        applied.push(my)
        return 'continue'
      },
    })
    ap.start()
    await vi.advanceTimersByTimeAsync(1000) // step 2 starts and hangs
    ap.stop()
    ;(release as (() => void) | null)?.() // late result after pause must NOT be applied
    await vi.advanceTimersByTimeAsync(5000)
    expect(applied).toEqual([1])
    ap.start()
    await vi.advanceTimersByTimeAsync(10)
    expect(applied).toEqual([1, 3])
    ap.stop()
    await vi.advanceTimersByTimeAsync(10_000)
    expect(applied).toEqual([1, 3])
  })
  it('stops when a step throws', async () => {
    const ap = new Autoplay({ getIntervalMs: () => 100, onRunning: () => {}, step: async () => { throw new Error('boom') } })
    ap.start()
    await vi.advanceTimersByTimeAsync(50)
    expect(ap.isRunning).toBe(false)
  })
  it('reads the interval live (speed change applies to the next ply)', async () => {
    let interval = 2000
    const times: number[] = []
    const ap = new Autoplay({ getIntervalMs: () => interval, onRunning: () => {}, step: async () => { times.push(Date.now()); return 'continue' } })
    const t0 = Date.now()
    ap.start()
    await vi.advanceTimersByTimeAsync(1) // first ply played, now waiting
    interval = 1000
    await vi.advanceTimersByTimeAsync(4000)
    expect(times.map((t) => t - t0)).toEqual([0, 2000, 3000, 4000])
    ap.stop()
  })
})
