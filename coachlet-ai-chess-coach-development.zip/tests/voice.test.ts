// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'

const kokoroState = { status: 'not-downloaded' as string }
const synth = vi.fn()
vi.mock('@/lib/voice/kokoro', async () => {
  const real = await vi.importActual<typeof import('@/lib/voice/kokoro')>('@/lib/voice/kokoro')
  return {
    ...real,
    getKokoroState: () => ({ ...kokoroState, progress: 0, receivedBytes: 0, totalBytes: 0 }),
    initKokoro: vi.fn(async () => undefined),
    synthesize: (...a: unknown[]) => synth(...a),
  }
})

class Utt {
  text: string
  rate = 1
  pitch = 1
  volume = 1
  lang = ''
  voice: unknown = null
  onstart: (() => void) | null = null
  onend: (() => void) | null = null
  onerror: ((e: unknown) => void) | null = null
  constructor(t: string) { this.text = t }
}
let spoken: Utt[] = []
const speechSynthesis = {
  speak: vi.fn((u: Utt) => { spoken.push(u) }),
  cancel: vi.fn(),
  pause: vi.fn(),
  resume: vi.fn(),
  getVoices: () => [],
}

class FakeSource {
  buffer: { duration: number } | null = null
  onended: (() => void) | null = null
  startedAt = -1
  stopped = false
  connect() {}
  disconnect() {}
  start(t: number) { this.startedAt = t }
  stop() { this.stopped = true }
}
let sources: FakeSource[] = []
const gain = { value: 1, setTargetAtTime: vi.fn() }
class FakeCtx {
  state = 'running'
  currentTime = 0
  destination = {}
  createGain() { return { gain, connect() {} } }
  createBuffer(_c: number, n: number, sr: number) { return { duration: n / sr, copyToChannel() {} } }
  createBufferSource() { const s = new FakeSource(); sources.push(s); return s }
  resume = vi.fn(async () => undefined)
  suspend = vi.fn(async () => undefined)
}

const flush = () => new Promise((r) => setTimeout(r, 0))

describe('speech controller', () => {
  let mod: typeof import('@/lib/voice/speak')
  beforeEach(async () => {
    vi.resetModules()
    spoken = []
    sources = []
    synth.mockReset()
    kokoroState.status = 'not-downloaded'
    ;(window as unknown as Record<string, unknown>).speechSynthesis = speechSynthesis
    ;(window as unknown as Record<string, unknown>).SpeechSynthesisUtterance = Utt
    ;(globalThis as unknown as Record<string, unknown>).SpeechSynthesisUtterance = Utt
    ;(globalThis as unknown as Record<string, unknown>).AudioContext = FakeCtx
    Object.values(speechSynthesis).forEach((f) => typeof f === 'function' && 'mockClear' in f && (f as ReturnType<typeof vi.fn>).mockClear())
    mod = await import('@/lib/voice/speak')
  })
  afterEach(() => mod.stopSpeaking())

  it('falls back to the browser voice (with an honest notice) when Kokoro is not downloaded', () => {
    mod.speak('Nf3 is a good move.', 'vale', { provider: 'kokoro', volume: 0.5, speed: 1.2 })
    const s = mod.getSpeechState()
    expect(s.provider).toBe('browser')
    expect(s.notice).toMatch(/not downloaded/i)
    expect(spoken[0].text).toBe('Knight to f3 is a good move.')
    expect(spoken[0].volume).toBeLessThanOrEqual(0.5)
    expect(spoken[0].rate).toBeGreaterThan(1) // user speed applied
  })

  it('tracks real playback: preparing -> speaking (onstart) -> idle (final onend)', () => {
    const seen: string[] = []
    mod.subscribeSpeechState((s) => seen.push(s.status))
    mod.speak('One sentence. Another sentence.', 'flash', { provider: 'browser-neural' })
    expect(mod.getSpeechState().status).toBe('preparing')
    spoken[0].onstart?.()
    expect(mod.getSpeechState().status).toBe('speaking')
    spoken[0].onend?.()
    vi.useFakeTimers()
    vi.advanceTimersByTime(1000)
    vi.useRealTimers()
    expect(spoken.length).toBeGreaterThan(0)
  })

  it('stop is immediate and stale callbacks cannot revive speech', () => {
    mod.speak('Hello there. How are you.', 'vale', { provider: 'browser-neural' })
    const first = spoken[0]
    mod.stopSpeaking()
    expect(mod.getSpeechState().status).toBe('idle')
    expect(mod.getSpeechState().isSpeaking).toBe(false)
    expect(speechSynthesis.cancel).toHaveBeenCalled()
    const count = spoken.length
    first.onend?.()
    expect(spoken.length).toBe(count)
    expect(mod.getSpeechState().status).toBe('idle')
  })

  it('a new speech replaces the old one (no overlap) and dedupe keys prevent duplicates', () => {
    mod.speak('First thing.', 'vale', { provider: 'browser-neural', dedupeKey: 'a' })
    mod.speak('First thing.', 'vale', { provider: 'browser-neural', dedupeKey: 'a' })
    expect(spoken.filter((u) => u.text === 'First thing.')).toHaveLength(1)
    mod.speak('Second thing.', 'vale', { provider: 'browser-neural' })
    expect(speechSynthesis.cancel).toHaveBeenCalledTimes(2) // deduped call skipped; every real speak() cancels what was playing first
    spoken[0].onend?.() // stale
    expect(mod.getSpeechState().text).toBe('Second thing.')
  })

  it('replay speaks the last request again; pause/resume use the provider', () => {
    expect(mod.replaySpeech()).toBe(false)
    mod.speak('Replay me.', 'gambit', { provider: 'browser-neural' })
    spoken[0].onstart?.()
    mod.pauseSpeaking()
    expect(speechSynthesis.pause).toHaveBeenCalled()
    expect(mod.getSpeechState().status).toBe('paused')
    mod.resumeSpeaking()
    expect(speechSynthesis.resume).toHaveBeenCalled()
    spoken.length = 0
    expect(mod.replaySpeech()).toBe(true)
    expect(spoken[0].text).toBe('Replay me.')
  })

  it('Kokoro path: applies speed in the model, volume through GainNode, state follows the last source ending', async () => {
    kokoroState.status = 'ready'
    synth.mockResolvedValue({ samples: new Float32Array(24000).fill(0.2), sampleRate: 24000 })
    mod.speak('First sentence here. Second sentence here.', 'vale', { provider: 'kokoro', volume: 0.4, speed: 1.2, voiceId: 'af_heart' })
    await flush(); await flush(); await flush()
    expect(synth).toHaveBeenCalledTimes(2)
    const [text, voice, speed] = synth.mock.calls[0]
    expect(text).toBe('First sentence here.')
    expect(voice).toBe('af_heart')
    expect(speed).toBeGreaterThan(1.0) // vale base 0.95 * emotion * user 1.2
    expect(gain.value).toBeCloseTo(0.4)
    expect(sources).toHaveLength(2)
    expect(sources[1].startedAt).toBeGreaterThan(sources[0].startedAt) // scheduled back to back
    expect(mod.getSpeechState().status).toBe('speaking')
    mod.setSpeechVolume(0.9)
    expect(gain.setTargetAtTime).toHaveBeenCalled()
    sources[0].onended?.()
    expect(mod.getSpeechState().status).toBe('speaking') // not the last source
    sources[1].onended?.()
    expect(mod.getSpeechState().status).toBe('idle')
  })

  it('Kokoro path: stop cancels scheduled audio and pending synthesis', async () => {
    kokoroState.status = 'ready'
    let release: (() => void) | null = null
    synth.mockImplementation(() => new Promise((r) => { release = () => r({ samples: new Float32Array(2400).fill(0.2), sampleRate: 24000 }) }))
    mod.speak('A sentence. Another sentence.', 'vale', { provider: 'kokoro' })
    await flush()
    mod.stopSpeaking()
    ;(release as (() => void) | null)?.()
    await flush(); await flush()
    expect(sources).toHaveLength(0) // late synthesis result is discarded
    expect(mod.getSpeechState().status).toBe('idle')
  })

  it('Kokoro failure falls back to the browser voice with a notice', async () => {
    kokoroState.status = 'ready'
    synth.mockRejectedValue(new Error('onnx exploded'))
    mod.speak('Fallback please.', 'flash', { provider: 'kokoro' })
    await flush(); await flush(); await flush()
    expect(mod.getSpeechState().provider).toBe('browser')
    expect(mod.getSpeechState().notice).toMatch(/onnx exploded/)
    expect(spoken[0].text).toBe('Fallback please.')
  })
})
