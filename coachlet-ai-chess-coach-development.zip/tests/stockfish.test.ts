import { describe, expect, it } from 'vitest'
import { spawn } from 'node:child_process'
import path from 'node:path'
import { Chess } from 'chess.js'

/** Runs the REAL Stockfish 19 WASM build shipped in /public/stockfish (same files the browser worker loads) under Node. */
function uci(commands: string[], until: RegExp, timeout = 40000): Promise<string> {
  return new Promise((resolve, reject) => {
    const js = path.resolve('node_modules/stockfish/bin/stockfish-19-lite-single.js')
    const p = spawn(process.execPath, [js], { stdio: ['pipe', 'pipe', 'inherit'] })
    let out = ''
    const t = setTimeout(() => { p.kill(); reject(new Error('timeout; output so far:\n' + out)) }, timeout)
    p.stdout.on('data', (d) => {
      out += d.toString()
      if (until.test(out)) { clearTimeout(t); p.kill(); resolve(out) }
    })
    for (const c of commands) p.stdin.write(c + '\n')
  })
}

describe('Stockfish 19 (WASM)', () => {
  it('identifies itself and returns a legal best move with MultiPV candidates', async () => {
    const fen = 'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3'
    const out = await uci(['uci', 'setoption name MultiPV value 3', `position fen ${fen}`, 'go depth 8'], /bestmove \S+/)
    expect(out).toMatch(/id name Stockfish 19/)
    const best = /bestmove (\S+)/.exec(out)![1]
    const c = new Chess(fen)
    const legal = c.moves({ verbose: true }).map((m) => m.from + m.to + (m.promotion ?? ''))
    expect(legal).toContain(best)
    const firsts = new Set([...out.matchAll(/multipv (\d) .* pv (\S+)/g)].map((m) => m[2]))
    expect(firsts.size).toBeGreaterThanOrEqual(2)
    for (const mv of firsts) expect(legal).toContain(mv)
  })
  it('finds mate in one', async () => {
    const out = await uci(['position fen 6k1/5ppp/8/8/8/8/5PPP/R5K1 w - - 0 1', 'go depth 6'], /bestmove \S+/)
    expect(/bestmove (\S+)/.exec(out)![1]).toBe('a1a8')
    expect(out).toMatch(/score mate 1/)
  })
})
