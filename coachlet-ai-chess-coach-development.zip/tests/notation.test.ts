import { describe, expect, it } from 'vitest'
import { preprocessChessTextForSpeech as P } from '@/lib/voice/chessNotationPreprocessor'
import { writeForSpeech, contract } from '@/lib/voice/speechWriter'

describe('chess notation -> speech', () => {
  it.each([
    ['Nf3', 'Knight to f3'],
    ['Bxf7+', 'Bishop takes f7, check'],
    ['Qxd5', 'Queen takes d5'],
    ['O-O', 'kingside castling'],
    ['O-O-O', 'queenside castling'],
    ['0-0-0', 'queenside castling'],
    ['e8=Q', 'pawn promotes to a queen on e8'],
    ['Rfe1', 'Rook from the f-file to e1'],
    ['Qh7#', 'Queen to h7, checkmate'],
    ['R1e2', 'Rook from rank 1 to e2'],
    ['Nbxd2', 'Knight from the b-file takes d2'],
    ['exd5', 'e-pawn takes d5'],
    ['exd6 e.p.', 'e-pawn takes d6 on passon'],
    ['dxe8=N+', 'pawn takes e8 and promotes to a knight, check'],
  ])('%s -> %s', (i, o) => expect(P(i)).toBe(o))

  it('handles notation inside sentences and move numbers', () => {
    expect(P('Play 1. e4 e5 2. Nf3 Nc6.')).toContain('move 1, e4')
    expect(P('Play 1. e4 e5 2. Nf3 Nc6.')).toContain('move 2, Knight to f3 Knight to c6')
    expect(P('After Bxf7+ Kxf7 you are lost.')).toBe('After Bishop takes f7, check King takes f7 you are lost.')
  })

  it('does not corrupt ordinary English words', () => {
    const s = 'The bishop and knight can be a bad pair. Bad ideas, Rock music, Queen of hearts, a Nice day. Be careful, Re-check the plan.'
    expect(P(s)).toBe(s)
    expect(P('Bad bishops often fail.')).toBe('Bad bishops often fail.')
    expect(P('Use Kb or Qa as shorthand')).toBe('Use Kb or Qa as shorthand')
  })

  it('speaks evaluations and mate scores', () => {
    expect(P('(+0.8)')).toBe('(plus zero point eight)')
    expect(P('−1.35 for Black')).toBe('minus 1 point three five for Black')
    expect(P('That is -140 cp')).toBe('That is minus 140 centipawns')
    expect(P('+M3')).toBe('mate in 3')
    expect(P('-M2')).toBe('getting mated in 2')
    expect(P('62% of games')).toBe('62 percent of games')
  })

  it('pronounces chess terms and keeps plain words intact', () => {
    expect(P('fianchetto')).toBe('fyanketto')
    expect(P('En Passant')).toBe('on passon')
    expect(P('the Najdorf and the Grünfeld')).toBe('the Nye-dorf and the Groon-feld')
    expect(P('Caro-Kann')).toBe('Karo Kahn')
    expect(P('ECO code')).toBe('E C O code')
    expect(P('a spoken word: pass, pawn, fiancé')).toBe('a spoken word: pass, pawn, fiancé')
  })

  it('strips markdown, emoji and symbols', () => {
    expect(P('**Great** move! 🎉 ♞ Nf3 → d4')).toBe('Great move! Knight to f3, then d4')
  })
})

describe('speech writer', () => {
  it('uses contractions', () => {
    expect(contract('You are fine. It is not over; do not resign.')).toBe("You're fine. It isn't over; don't resign.")
  })
  it('splits into sentences and keeps meaning', () => {
    const c = writeForSpeech('Nf3 develops a piece. It also controls e5! Do you see the threat?')
    expect(c.map((x) => x.text)).toEqual(['Knight to f3 develops a piece.', 'It also controls e5!', 'Do you see the threat?'])
    expect(c[2].question).toBe(true)
  })
  it('breaks long sentences at clause boundaries, never into tiny fragments', () => {
    const long = 'The knight on f3 develops a piece and controls the centre, and it prepares kingside castling because the king needs to be safe before you open the position, but remember that Black may react with a strong central break.'
    const c = writeForSpeech(long)
    expect(c.length).toBeGreaterThan(1)
    expect(c.every((x) => x.text.length >= 20)).toBe(true)
    expect(c.filter((x) => x.sentenceEnd)).toHaveLength(1)
  })
  it('caps very long text by whole sentences', () => {
    const t = Array.from({ length: 40 }, (_, i) => `Sentence number ${i} is here.`).join(' ')
    const out = writeForSpeech(t).map((x) => x.text).join(' ')
    expect(out.length).toBeLessThanOrEqual(560)
    expect(out.endsWith('.')).toBe(true)
  })
})
