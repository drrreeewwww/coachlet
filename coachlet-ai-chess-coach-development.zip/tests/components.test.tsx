// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import type { ReactNode } from 'react'

vi.mock('next/navigation', () => ({ usePathname: () => '/openings' }))
vi.mock('next/link', () => ({
  default: ({ href, children, ...rest }: { href: string; children: ReactNode }) => <a href={href} {...rest}>{children}</a>,
}))

import AppShell, { NAV_ITEMS } from '@/components/Nav/AppShell'
import PlaybackBar from '@/components/Openings/PlaybackBar'
import OpeningLibrary from '@/components/Openings/OpeningLibrary'
import VoiceControls from '@/components/CoachPanel/VoiceControls'
import { DatabasePanel } from '@/components/Openings/DatabasePanels'
import { buildCatalogue } from '@/lib/openings/catalogue'
import rows from '@/lib/openings/data/openings.json'

afterEach(cleanup)

describe('navigation', () => {
  it('every nav entry is a real route and the active one is marked', () => {
    render(<AppShell><p>content</p></AppShell>)
    expect(NAV_ITEMS.map((n) => n.href)).toEqual(['/', '/play', '/openings', '/review', '/settings'])
    for (const n of NAV_ITEMS) expect(screen.getAllByRole('link', { name: new RegExp(n.label) }).length).toBeGreaterThan(0)
    const active = screen.getAllByRole('link', { name: /Openings/ }).filter((a) => a.getAttribute('aria-current') === 'page')
    expect(active.length).toBeGreaterThan(0)
    expect(screen.getByText('content')).toBeTruthy()
    expect(screen.queryByText(/Custom Drills|Progress/)).toBeNull()
  })
})

describe('playback bar', () => {
  const base = { running: false, atStart: false, atEnd: false, mode: 'most-played' as const, speedMs: 1500 as const, message: null }
  const handlers = () => ({ onMode: vi.fn(), onSpeed: vi.fn(), onPlay: vi.fn(), onPause: vi.fn(), onPrev: vi.fn(), onNext: vi.fn(), onRestart: vi.fn(), onFlip: vi.fn() })
  it('wires every control', () => {
    const h = handlers()
    render(<PlaybackBar {...base} {...h} />)
    fireEvent.click(screen.getByLabelText('Play line'))
    fireEvent.click(screen.getByLabelText('Previous move'))
    fireEvent.click(screen.getByLabelText('Next move'))
    fireEvent.click(screen.getByLabelText('Restart from the first move'))
    fireEvent.click(screen.getByLabelText('Flip board'))
    fireEvent.click(screen.getByRole('radio', { name: 'Engine best line' }))
    fireEvent.click(screen.getByRole('radio', { name: 'Selected variation' }))
    fireEvent.change(screen.getByLabelText(/Playback speed/), { target: { value: '2000' } })
    expect(h.onPlay).toHaveBeenCalledTimes(1)
    expect(h.onPrev).toHaveBeenCalledTimes(1)
    expect(h.onNext).toHaveBeenCalledTimes(1)
    expect(h.onRestart).toHaveBeenCalledTimes(1)
    expect(h.onFlip).toHaveBeenCalledTimes(1)
    expect(h.onMode).toHaveBeenNthCalledWith(1, 'engine')
    expect(h.onMode).toHaveBeenNthCalledWith(2, 'selected')
    expect(h.onSpeed).toHaveBeenCalledWith(2000)
  })
  it('offers exactly the three speeds, shows Pause while running, disables unavailable steps', () => {
    const h = handlers()
    render(<PlaybackBar {...base} running atStart atEnd {...h} />)
    expect(screen.getAllByRole('option').map((o) => o.textContent)).toEqual(['1 s / move', '1.5 s / move', '2 s / move'])
    fireEvent.click(screen.getByLabelText('Pause playback'))
    expect(h.onPause).toHaveBeenCalled()
    expect((screen.getByLabelText('Previous move') as HTMLButtonElement).disabled).toBe(true)
    expect((screen.getByLabelText('Next move') as HTMLButtonElement).disabled).toBe(true)
    fireEvent.click(screen.getByLabelText('Previous move'))
    expect(h.onPrev).not.toHaveBeenCalled()
  })
})

describe('opening library', () => {
  const cat = buildCatalogue(rows as unknown as Array<[string, string, string, string]>)
  it('searches by name and ECO and selects an opening', () => {
    const onSelect = vi.fn()
    render(<OpeningLibrary cat={cat} loadError={null} activeName={null} onSelect={onSelect} />)
    fireEvent.change(screen.getByLabelText(/Search openings/), { target: { value: 'B90' } })
    const hit = screen.getAllByRole('button').find((b) => /Najdorf/.test(b.textContent ?? ''))!
    fireEvent.click(hit)
    expect(onSelect).toHaveBeenCalledTimes(1)
    expect(onSelect.mock.calls[0][0].eco).toBe('B90')
  })
  it('browses categories', () => {
    render(<OpeningLibrary cat={cat} loadError={null} activeName={null} onSelect={() => {}} />)
    fireEvent.click(screen.getByRole('button', { name: 'Gambits' }))
    expect(screen.getAllByRole('button').some((b) => /Gambit/.test(b.textContent ?? ''))).toBe(true)
  })
})

describe('voice controls', () => {
  const props = { voiceOn: true, onVoice: vi.fn(), speed: 1, onSpeed: vi.fn(), volume: 0.8, onVolume: vi.fn(), provider: 'kokoro' as const, onSpeak: vi.fn(), onReplay: vi.fn(), onStop: vi.fn(), canSpeak: true }
  it('Speak calls only onSpeak (never stop); Stop is disabled while silent', () => {
    const onSpeak = vi.fn()
    const onStop = vi.fn()
    render(<VoiceControls {...props} onSpeak={onSpeak} onStop={onStop} />)
    fireEvent.click(screen.getByRole('button', { name: /Speak/ }))
    expect(onSpeak).toHaveBeenCalledTimes(1)
    expect(onStop).not.toHaveBeenCalled()
    expect((screen.getByRole('button', { name: /Stop/ }) as HTMLButtonElement).disabled).toBe(true)
  })
  it('disables speech actions when voice is off', () => {
    render(<VoiceControls {...props} voiceOn={false} />)
    expect((screen.getByRole('button', { name: /Speak/ }) as HTMLButtonElement).disabled).toBe(true)
    expect((screen.getByRole('button', { name: /Replay/ }) as HTMLButtonElement).disabled).toBe(true)
  })
})

describe('database panel honesty', () => {
  const p = { source: 'masters' as const, onSource: vi.fn(), token: '', onToken: vi.fn(), onTestToken: async () => 'ok', onRefresh: vi.fn(), onPlay: vi.fn(), selectedUci: null }
  it('explains the token requirement instead of showing made-up numbers', () => {
    render(<DatabasePanel {...p} state={{ phase: 'done', result: { status: 'no-token' } }} />)
    expect(screen.getByText(/requires a free personal API token/)).toBeTruthy()
    expect(screen.queryByRole('table')).toBeNull()
  })
  it('renders real statistics and lets you play a move', () => {
    const onPlay = vi.fn()
    const data = { source: 'masters' as const, fen: 'x', white: 60, draws: 30, black: 10, total: 100, opening: null, moves: [
      { uci: 'd2d4', san: 'd4', white: 10, draws: 6, black: 4, total: 20 },
      { uci: 'e2e4', san: 'e4', white: 40, draws: 20, black: 5, total: 65 },
    ] }
    render(<DatabasePanel {...p} onPlay={onPlay} state={{ phase: 'done', result: { status: 'ok', data, cached: false, fetchedAt: 0, stale: false } }} />)
    const rowsEl = screen.getAllByRole('row').slice(1)
    expect(rowsEl[0].textContent).toContain('e4')
    expect(rowsEl[0].textContent).toContain('65%')
    expect(rowsEl[1].textContent).toContain('20%')
    fireEvent.click(screen.getByRole('button', { name: /Play e4/ }))
    expect(onPlay).toHaveBeenCalledWith(data.moves[1])
  })
})
