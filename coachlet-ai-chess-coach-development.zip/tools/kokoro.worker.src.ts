/* Kokoro-82M (ONNX, q8) synthesis worker. Built to public/voice/kokoro.worker.js with:
 *   node tools/build-voice-worker.mjs
 * Runs entirely locally in a Web Worker so the UI/board never blocks. */
import { KokoroTTS } from 'kokoro-js'
import { env } from '@huggingface/transformers'

const ctx = self as unknown as {
  postMessage: (msg: unknown, transfer?: Transferable[]) => void
  onmessage: ((e: MessageEvent) => void) | null
}

env.allowLocalModels = false
env.useBrowserCache = true
// Self-hosted onnxruntime wasm (copied to /public/ort) — no CDN requests.
const wasm = (env.backends.onnx as { wasm?: { wasmPaths?: string; numThreads?: number } }).wasm
if (wasm) {
  wasm.wasmPaths = '/ort/'
  wasm.numThreads = 1
}

const MODEL_ID = 'onnx-community/Kokoro-82M-v1.0-ONNX'
let tts: KokoroTTS | null = null
let loading: Promise<void> | null = null

async function load() {
  if (tts) return
  if (!loading) {
    loading = KokoroTTS.from_pretrained(MODEL_ID, { dtype: 'q8', device: 'wasm' })
      .then((m) => {
        tts = m
      })
      .finally(() => {
        loading = null
      })
  }
  await loading
}

ctx.onmessage = async (e: MessageEvent) => {
  const m = e.data as
    | { type: 'load'; id: number }
    | { type: 'synth'; id: number; text: string; voice: string; speed: number }
    | { type: 'dispose'; id: number }
  try {
    if (m.type === 'load') {
      await load()
      ctx.postMessage({ type: 'loaded', id: m.id, voices: Object.keys(tts!.voices) })
    } else if (m.type === 'synth') {
      await load()
      const audio = await tts!.generate(m.text, {
        voice: m.voice as Parameters<KokoroTTS['generate']>[1] extends { voice?: infer V } ? V : never,
        speed: m.speed,
      })
      const samples = audio.audio as Float32Array
      ctx.postMessage({ type: 'audio', id: m.id, samples, sampleRate: audio.sampling_rate }, [samples.buffer])
    } else if (m.type === 'dispose') {
      tts = null
      ctx.postMessage({ type: 'disposed', id: m.id })
    }
  } catch (err) {
    ctx.postMessage({ type: 'error', id: (m as { id: number }).id, message: err instanceof Error ? err.message : String(err) })
  }
}
