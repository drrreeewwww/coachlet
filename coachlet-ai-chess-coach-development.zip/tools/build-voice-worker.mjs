// Bundles the Kokoro worker and copies the onnxruntime wasm runtime into /public so the
// voice engine is fully self-hosted. Re-run after upgrading kokoro-js / transformers.
import { build } from 'esbuild'
import { copyFileSync, mkdirSync } from 'node:fs'

mkdirSync('public/voice', { recursive: true })
mkdirSync('public/ort', { recursive: true })
await build({
  entryPoints: ['tools/kokoro.worker.src.ts'],
  outfile: 'public/voice/kokoro.worker.js',
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: 'es2022',
  minify: true,
  external: ['sharp', 'onnxruntime-node'],
  logLevel: 'info',
})
for (const f of ['ort-wasm-simd-threaded.mjs', 'ort-wasm-simd-threaded.wasm', 'ort-wasm-simd-threaded.jsep.mjs', 'ort-wasm-simd-threaded.jsep.wasm']) {
  copyFileSync(`node_modules/onnxruntime-web/dist/${f}`, `public/ort/${f}`)
}
