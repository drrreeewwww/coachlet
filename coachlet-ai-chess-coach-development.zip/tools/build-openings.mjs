// Builds src/lib/openings/data/openings.json from the lichess-org/chess-openings TSVs (CC0 / public domain).
// Usage: node tools/build-openings.mjs <dir containing a.tsv..e.tsv>
import { readFileSync, writeFileSync } from 'node:fs'
import { Chess } from 'chess.js'

const dir = process.argv[2] ?? '/tmp'
const out = []
let bad = 0
for (const f of ['a', 'b', 'c', 'd', 'e']) {
  const rows = readFileSync(`${dir}/${f}.tsv`, 'utf8').split('\n').slice(1).filter(Boolean)
  for (const row of rows) {
    const [eco, name, pgn] = row.split('\t')
    const sans = pgn.replace(/\d+\.(\.\.)?/g, ' ').split(/\s+/).filter(Boolean)
    const c = new Chess()
    try {
      for (const s of sans) c.move(s)
    } catch {
      bad++
      continue
    }
    out.push([eco, name, sans.join(' '), c.fen().split(' ').slice(0, 4).join(' ')])
  }
}
writeFileSync('src/lib/openings/data/openings.json', JSON.stringify(out))
console.log('openings', out.length, 'skipped', bad)
