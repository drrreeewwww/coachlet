import { useEffect, useState } from 'react'
import { ArrowLeft, Volume2 } from 'lucide-react'
import Chessboard from '@/components/Chessboard/Chessboard'
import Avatar from '@/components/CoachPanel/Avatar'
import EvalBar from '@/components/EvalBar/EvalBar'
import { COACHES } from '@/lib/coaching/coaches'
import { train } from '@/lib/coaching/profile'
import { reactionFor } from '@/lib/coaching/reactions'
import {
  accuracyOf,
  CLASS_META,
  formatScore,
  winPct,
  type MoveClass,
} from '@/lib/evaluation/classify'
import { loadGame, type SavedGame } from '@/lib/review/record'
import { uciToMoveObj } from '@/lib/stockfish/engine'
import { useSettings } from '@/lib/useSettings'
import { speak, stopSpeaking } from '@/lib/voice/speak'
import type { BoardArrow, MoveBadgeOverlay } from '@/types'

const ORDER: MoveClass[] = [
  'brilliant',
  'great',
  'best',
  'excellent',
  'good',
  'inaccuracy',
  'mistake',
  'blunder',
]

export default function ReviewView({
  onBackToGame,
}: {
  onBackToGame: () => void
}) {
  const [g, setG] = useState<SavedGame | null>(null)
  const [idx, setIdx] = useState(0)
  const [tryMode, setTryMode] = useState(false)
  const [msg, setMsg] = useState('')
  const [st] = useSettings()

  useEffect(() => {
    const loaded = loadGame()
    setG(loaded)
    if (loaded) setIdx(Math.max(0, loaded.moves.length - 1))
    return stopSpeaking
  }, [])

  if (!g || !g.moves.length) {
    return (
      <div className="mx-auto max-w-2xl p-6 text-center">
        <div className="rounded-xl border border-[#3a3834] bg-[#262522] p-8 shadow-xl">
          <h1 className="text-2xl font-extrabold text-white">Game Review</h1>
          <p className="mt-2 text-sm text-stone-400">
            No finished or in-progress game to review yet. Play a few moves
            first!
          </p>
          <button
            type="button"
            onClick={onBackToGame}
            className="mt-5 inline-flex items-center gap-2 rounded-lg bg-[#81b64c] px-5 py-2.5 text-sm font-extrabold text-[#1c1b19] hover:brightness-110"
          >
            <ArrowLeft className="h-4 w-4" />
            Return to Board
          </button>
        </div>
      </div>
    )
  }

  const moves = g.moves
  const cur = moves[idx]
  const coach = COACHES.find((c) => c.id === g.coach) ?? COACHES[0]
  const playerColor = g.playerColor ?? 'w'
  const acc = (c: 'w' | 'b') => {
    const ms = moves.filter((m) => m.color === c)
    return ms.length
      ? Math.round(
          ms.reduce((s, m) => s + accuracyOf(m.winLoss), 0) / ms.length
        )
      : 100
  }
  const counts = (c: 'w' | 'b') =>
    ORDER.map((k) => ({
      k,
      n: moves.filter((m) => m.color === c && m.cls === k).length,
    }))
  const keyMoments = moves
    .map((m, i) => ({ m, i }))
    .filter(
      ({ m }) =>
        m.winLoss >= 10 || m.cls === 'brilliant' || m.cls === 'great'
    )
  const focus = train(g.coach, g.elo, moves, playerColor)

  const go = (i: number) => {
    setIdx(Math.max(0, Math.min(moves.length - 1, i)))
    setTryMode(false)
    setMsg('')
  }
  const tryMove = (from: string, to: string, promo = 'q') => {
    const u = from + to + (promo === 'q' && cur.best.length === 4 ? '' : promo)
    if (u === cur.best || from + to === cur.best.slice(0, 4)) {
      setMsg(`Correct! ${cur.bestSan} is the engine’s top choice.`)
      setTryMode(false)
    } else {
      setMsg(`Not quite — try again, or exit retry to see ${cur.bestSan}.`)
    }
  }
  const line = reactionFor(g.coach, cur.cls, idx, cur.bestSan)

  const reviewArrows: BoardArrow[] = []
  if (!tryMode) {
    const playedObj = uciToMoveObj(cur.uci)
    reviewArrows.push({
      from: playedObj.from,
      to: playedObj.to,
      color: CLASS_META[cur.cls].color,
      opacity: 0.85,
    })
    if (cur.best && cur.best !== cur.uci && cur.best.length >= 4) {
      const bestObj = uciToMoveObj(cur.best)
      reviewArrows.push({
        from: bestObj.from,
        to: bestObj.to,
        color: '#81b64c',
        dashed: true,
        label: '★',
        opacity: 0.9,
      })
    }
  }

  const reviewBadge: MoveBadgeOverlay | null = !tryMode
    ? {
        square: cur.uci.slice(2, 4),
        cls: cur.cls,
        icon: CLASS_META[cur.cls].icon,
        color: CLASS_META[cur.cls].color,
        label: CLASS_META[cur.cls].label,
      }
    : null

  return (
    <div className="mx-auto grid max-w-[1360px] gap-6 p-4 lg:grid-cols-[minmax(0,680px)_1fr]">
      <div>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-[#3a3834] bg-[#262522] px-3.5 py-2.5">
          <div>
            <h1 className="text-lg font-extrabold text-white">
              Game Review • Result {g.result}
            </h1>
            {g.terminationReason && (
              <p className="text-xs text-stone-400">{g.terminationReason}</p>
            )}
          </div>
          <button
            type="button"
            onClick={onBackToGame}
            className="inline-flex items-center gap-1.5 rounded-md bg-[#81b64c] px-3 py-1.5 text-xs font-extrabold text-[#1c1b19] hover:brightness-110"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to Board
          </button>
        </div>

        <div className="flex gap-2">
          <EvalBar
            score={{ cp: tryMode ? cur.before : cur.after }}
            flipped={playerColor === 'b'}
          />
          <Chessboard
            fen={tryMode ? cur.fenBefore : cur.fenAfter}
            flipped={playerColor === 'b'}
            lastMove={tryMode ? null : uciToMoveObj(cur.uci)}
            marks={
              !tryMode && cur.best && cur.best !== cur.uci
                ? [cur.best.slice(0, 2), cur.best.slice(2, 4)]
                : []
            }
            arrows={reviewArrows}
            badge={reviewBadge}
            look={st}
            disabled={!tryMode}
            onMove={tryMove}
          />
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          <button
            type="button"
            onClick={() => go(0)}
            disabled={idx === 0}
            className="rounded-md border border-[#3a3834] bg-[#262522] px-3 py-1.5 font-semibold text-stone-200 hover:bg-[#302e2b] disabled:opacity-40"
          >
            ⏮ First
          </button>
          <button
            type="button"
            onClick={() => go(idx - 1)}
            disabled={idx === 0}
            className="rounded-md border border-[#3a3834] bg-[#262522] px-3 py-1.5 font-semibold text-stone-200 hover:bg-[#302e2b] disabled:opacity-40"
          >
            ◀ Prev
          </button>
          <button
            type="button"
            onClick={() => go(idx + 1)}
            disabled={idx === moves.length - 1}
            className="rounded-md border border-[#3a3834] bg-[#262522] px-3 py-1.5 font-semibold text-stone-200 hover:bg-[#302e2b] disabled:opacity-40"
          >
            Next ▶
          </button>
          <button
            type="button"
            onClick={() => go(moves.length - 1)}
            disabled={idx === moves.length - 1}
            className="rounded-md border border-[#3a3834] bg-[#262522] px-3 py-1.5 font-semibold text-stone-200 hover:bg-[#302e2b] disabled:opacity-40"
          >
            Last ⏭
          </button>
          {(cur.cls === 'inaccuracy' ||
            cur.cls === 'mistake' ||
            cur.cls === 'blunder') && (
            <button
              type="button"
              onClick={() => {
                setTryMode(!tryMode)
                setMsg('')
              }}
              className="rounded-md border border-[#81b64c] bg-[#81b64c]/15 px-3 py-1.5 font-bold text-[#a3d160] hover:bg-[#81b64c]/25"
            >
              {tryMode ? 'Exit Retry' : '↺ Retry This Move'}
            </button>
          )}
        </div>

        {/* Evaluation Graph */}
        <div className="mt-3 rounded-lg border border-[#3a3834] bg-[#262522] p-3">
          <p className="mb-1 text-xs font-semibold text-stone-400">
            Evaluation Timeline (click any point to jump)
          </p>
          <svg
            viewBox={`0 0 ${Math.max(moves.length * 12, 120)} 60`}
            className="h-16 w-full cursor-pointer"
            onClick={(e) => {
              const r = e.currentTarget.getBoundingClientRect()
              go(
                Math.floor(((e.clientX - r.left) / r.width) * moves.length)
              )
            }}
          >
            <line
              x1="0"
              y1="30"
              x2={moves.length * 12}
              y2="30"
              stroke="#3a3834"
            />
            <polyline
              fill="none"
              stroke="#81b64c"
              strokeWidth="2"
              points={moves
                .map((m, i) => `${i * 12 + 6},${60 - winPct(m.after) * 0.6}`)
                .join(' ')}
            />
            <circle
              cx={idx * 12 + 6}
              cy={60 - winPct(cur.after) * 0.6}
              r="4"
              fill="#ffffff"
            />
          </svg>
        </div>
      </div>

      <section className="space-y-3">
        {/* Accuracy & 8-Tier Classification Breakdown */}
        <div className="grid grid-cols-2 gap-3 rounded-lg border border-[#3a3834] bg-[#262522] p-4">
          {(
            [
              [
                'w',
                playerColor === 'w' ? 'You (White)' : `${coach.name} (White)`,
              ],
              [
                'b',
                playerColor === 'b' ? 'You (Black)' : `${coach.name} (Black)`,
              ],
            ] as const
          ).map(([c, who]) => (
            <div key={c}>
              <p className="text-xs font-semibold text-stone-400">{who}</p>
              <p className="text-2xl font-extrabold text-[#a3d160]">
                {acc(c)}%{' '}
                <span className="text-xs font-normal text-stone-400">
                  accuracy
                </span>
              </p>
              <ul className="mt-2 space-y-1 text-xs">
                {counts(c).map(({ k, n }) => (
                  <li key={k} className="flex items-center justify-between">
                    <span
                      style={{ color: CLASS_META[k].color }}
                      className="font-semibold"
                    >
                      {CLASS_META[k].icon} {CLASS_META[k].label}
                    </span>
                    <b className="font-mono text-stone-200">{n}</b>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Selected Move Analysis & Coach Explanation */}
        <div className="rounded-lg border border-[#3a3834] bg-[#262522] p-4">
          <div className="flex items-center gap-3">
            <Avatar id={coach.id} accent={coach.accent} size={44} />
            <div className="flex-1 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <b>
                  Move {Math.floor(idx / 2) + 1}
                  {cur.color === 'w' ? '.' : '…'} {cur.san}
                </b>
                <span
                  className="inline-flex items-center gap-1 rounded px-2 py-0.5 text-xs font-extrabold text-white"
                  style={{ background: CLASS_META[cur.cls].color }}
                >
                  {CLASS_META[cur.cls].icon} {CLASS_META[cur.cls].label}
                </span>
              </div>
              <p className="mt-0.5 text-xs text-stone-400">
                Eval {formatScore({ cp: cur.before })} →{' '}
                {formatScore({ cp: cur.after })} (−{cur.cpLoss} cp) • Best:{' '}
                <b className="font-mono text-stone-200">{cur.bestSan}</b>
              </p>
            </div>
            <button
              type="button"
              onClick={() =>
                speak(line, g.coach, {
                  speed: st.speed,
                  volume: st.voiceVolume,
                  provider: st.voiceProvider,
                  voiceId: st.kokoroVoice,
                  context: { moveClass: cur.cls },
                })
              }
              className="inline-flex items-center gap-1 rounded border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-1 text-xs text-stone-200 hover:bg-[#302e2b]"
            >
              <Volume2 className="h-3.5 w-3.5 text-[#81b64c]" /> Speak
            </button>
          </div>
          <p className="mt-2.5 text-sm italic text-stone-200">
            “{msg || line}”
          </p>
        </div>

        {/* Coach Training Summary */}
        <div className="rounded-lg border border-[#81b64c]/40 bg-[#262522] p-4 text-sm">
          <div className="flex items-center justify-between">
            <b className="text-[#a3d160]">
              What to Practise Next ({coach.name})
            </b>
            <button
              type="button"
              onClick={() =>
                speak(focus, g.coach, {
                  speed: st.speed,
                  volume: st.voiceVolume,
                  provider: st.voiceProvider,
                  voiceId: st.kokoroVoice,
                })
              }
              className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-1 text-xs text-stone-200 hover:bg-[#302e2b]"
            >
              🔊 Listen
            </button>
          </div>
          <p className="mt-1.5 text-xs leading-relaxed text-stone-200">
            {focus}
          </p>
        </div>

        {/* Key Moments */}
        {keyMoments.length > 0 && (
          <div className="rounded-lg border border-[#3a3834] bg-[#262522] p-3 text-xs">
            <b className="text-stone-300">Key Moments & Swings:</b>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {keyMoments.map(({ m, i }) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => go(i)}
                  className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-1 font-mono hover:border-[#81b64c]"
                >
                  {Math.floor(i / 2) + 1}
                  {m.color === 'w' ? '.' : '…'} {m.san}{' '}
                  <span style={{ color: CLASS_META[m.cls].color }}>
                    ({CLASS_META[m.cls].icon})
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Full Move List */}
        <ol className="flex max-h-56 flex-wrap gap-1.5 overflow-y-auto rounded-lg border border-[#3a3834] bg-[#262522] p-3 font-mono text-xs">
          {moves.map((m, i) => (
            <li key={i}>
              <button
                type="button"
                onClick={() => go(i)}
                className={`rounded px-2 py-1 transition ${
                  i === idx
                    ? 'bg-[#81b64c] font-bold text-[#1c1b19]'
                    : 'bg-[#1e1d1b] text-stone-300 hover:bg-[#302e2b]'
                }`}
              >
                {i % 2 === 0 ? `${i / 2 + 1}. ` : ''}
                {m.san}{' '}
                <span
                  style={{
                    color: i === idx ? '#1c1b19' : CLASS_META[m.cls].color,
                  }}
                >
                  {CLASS_META[m.cls].icon}
                </span>
              </button>
            </li>
          ))}
        </ol>
      </section>
    </div>
  )
}
