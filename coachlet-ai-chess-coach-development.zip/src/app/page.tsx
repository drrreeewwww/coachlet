'use client'
import { useRouter } from 'next/navigation'
import HomeView from '@/views/HomeView'

export default function Page() {
  const r = useRouter()
  return <HomeView onStartPlay={() => r.push('/play')} />
}
