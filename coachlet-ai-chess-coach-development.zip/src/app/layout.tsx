import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import AppShell from "@/components/Nav/AppShell";

export const metadata: Metadata = {
  title: "Coachlet — AI Chess Coach",
  description: "Play, learn and explore openings with a Stockfish-powered chess coach.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: "#1e1d1b",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#1e1d1b] text-stone-100 antialiased">
        <AppShell>{children}</AppShell>
      </body>
    </html>
  );
}
