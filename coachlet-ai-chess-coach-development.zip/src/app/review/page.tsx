'use client'
import { useRouter } from 'next/navigation'
import ReviewView from '@/views/ReviewView'

export default function Page() {
  const r = useRouter()
  return <ReviewView onBackToGame={() => r.push('/play')} />
}
