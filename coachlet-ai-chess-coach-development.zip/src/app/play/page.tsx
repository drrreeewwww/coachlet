'use client'
import { useRouter } from 'next/navigation'
import GameView from '@/views/GameView'

export default function Page() {
  const r = useRouter()
  return <GameView onNavigateReview={() => r.push('/review')} onNavigateSettings={() => r.push('/settings')} />
}
