import OpeningExplorerView from '@/views/OpeningExplorerView'

export const metadata = { title: 'Opening Explorer — Coachlet' }

export default function Page() {
  return <OpeningExplorerView />
}
