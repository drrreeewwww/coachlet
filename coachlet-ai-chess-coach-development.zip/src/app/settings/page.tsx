'use client'
import { useRouter } from 'next/navigation'
import SettingsView from '@/views/SettingsView'

export default function Page() {
  const r = useRouter()
  return <SettingsView onBackToGame={() => r.push('/play')} />
}
