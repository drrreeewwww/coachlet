import {
  CLASS_META,
  formatScore,
  toCp,
  type Score,
} from '@/lib/evaluation/classify'
import { train } from './profile'
import type { MoveRecord } from '@/lib/review/record'
import type { CoachId, PVLine, PlayerColor, PositionTactics } from '@/types'

/** Everything a reply may use comes from real engine data passed in here. Nothing is invented. */
export interface Ctx {
  coach: CoachId
  elo: number
  playerColor?: PlayerColor
  fen?: string
  bestSan?: string
  score?: Score
  variations?: PVLine[]
  tactics?: PositionTactics
  recs: MoveRecord[]
  over: boolean
}

const W: Record<
  CoachId,
  Record<'best' | 'eval' | 'last' | 'none' | 'help', string>
> = {
  vale: {
    best: 'If you want it: {san}. It improves the position with precision.',
    eval: 'The engine says {ev}, so {who}. Small edges are enough if you are patient.',
    last: 'Your last move, {san}, was {cls}. {note}',
    none: 'There is nothing to discuss yet.',
    help: 'Ask me why a move is a mistake, what a grandmaster would play, why your king is unsafe, how to win this endgame, or to explain the position in simpler terms.',
  },
  flash: {
    best: '{san}! Check it: checks, captures, threats.',
    eval: 'Engine says {ev}, so {who}. Keep the pressure on!',
    last: '{san} was {cls}. {note}',
    none: 'Make a move first, then we can break it down!',
    help: 'Try asking: what would a GM play, what happens if I sacrifice, why is my king unsafe, or why was that a mistake!',
  },
  gambit: {
    best: 'Okay, you asked nicely: {san}! Can you see why it works?',
    eval: 'The engine shows {ev}, so {who}. Does that match your gut feeling?',
    last: 'Your move {san} was {cls}. {note} What would you play instead?',
    none: 'We haven’t played a move yet, friend!',
    help: 'You can ask me for the best move, the evaluation, about your last move, king safety, or what to practise. Go on, ask!',
  },
}

export function answer(q: string, c: Ctx): string {
  const t = q.toLowerCase(),
    w = W[c.coach],
    pCol = c.playerColor ?? 'w'
  const mine = c.recs.filter((m) => m.color === pCol),
    last = mine[mine.length - 1]
  if (/best|hint|suggest|grandmaster|gm|what (do|should|would) .*play/.test(t)) {
    if (!c.bestSan || c.over)
      return 'The game is over, so there is no move to suggest.'
    const v1 = c.variations?.[0]
    const v2 = c.variations?.[1]
    const lineInfo = v1
      ? ` Continuation: ${v1.sanMoves.slice(0, 4).join(' ')}.${v2 ? ` Alternative: ${v2.firstMove.san} (${formatScore(v2.score)}).` : ''}`
      : ''
    return w.best.replace('{san}', c.bestSan) + lineInfo
  }
  if (/eval|better|winning|advantage|score|simpler|simple/.test(t)) {
    if (!c.score) return w.none
    const cp = toCp(c.score),
      who =
        Math.abs(cp) < 30
          ? 'it is level'
          : cp > 0
            ? 'White is better'
            : 'Black is better'
    return w.eval.replace('{ev}', formatScore(c.score)).replace('{who}', who)
  }
  if (/last|why|mistake|blunder|wrong|rated/.test(t)) {
    if (!last) return w.none
    const note =
      last.uci === last.best
        ? 'It was the engine’s top choice.'
        : `The engine preferred ${last.bestSan} (−${last.cpLoss} cp).`
    return w.last
      .replace('{san}', last.san)
      .replace('{cls}', CLASS_META[last.cls].label.toLowerCase())
      .replace('{note}', note)
  }
  if (/train|practi|improv|weak|learn|study/.test(t))
    return train(c.coach, c.elo, c.recs, pCol)
  return w.help
}
