import type { CoachId } from '@/types'
import type { MoveClass } from '@/lib/evaluation/classify'

const LINES: Record<CoachId, Record<MoveClass, string[]>> = {
  vale: {
    brilliant: [
      'Remarkable. A deep sacrifice that transforms the position into a concrete advantage.',
      'Clinical brilliance. You gave up material for unstoppable piece activity.',
    ],
    great: [
      'Very impressive. That was the only move to hold the positional balance and press ahead.',
      'A high-level practical find. Every other candidate conceded ground.',
    ],
    best: [
      'Precisely. That is the move I would have played.',
      'Quietly the best. Maximum activity with minimum risk.',
    ],
    excellent: [
      'Very nearly the best. Keep harmonising your pieces like this.',
      'Sound, patient, and practically indistinguishable from the top engine line.',
    ],
    good: [
      'Reasonable. Not much to complain about, though {best} squeezed a little harder.',
      'It does the job, though {best} asked more questions of the structure.',
    ],
    inaccuracy: [
      'A slight drift. {best} kept the piece coordination tighter.',
      'Not fatal, but {best} was the more patient, accurate choice.',
    ],
    mistake: [
      'That concedes something real. {best} was needed to maintain the balance.',
      'Hm. The long-term plan frays here — {best} held the structure together.',
    ],
    blunder: [
      'That, I am afraid, is a serious error. {best} was necessary to survive.',
      'Well. That changes the evaluation considerably. {best} was the only sensible path.',
    ],
  },
  flash: {
    brilliant: [
      'BOOM!! A brilliant sacrifice! The engine loves that tactical thunderbolt!',
      'Unbelievable shot!! You threw a piece into the fire and blew the position wide open!',
    ],
    great: [
      'Clutch find! That was the only sharp move on the board!',
      'Great move! You threaded the tactical needle where every other line failed!',
    ],
    best: [
      'Boom! Best move, straight from Stockfish’s top line!',
      'Yes! That’s the one. Fast, forcing, and clean.',
    ],
    excellent: [
      'Nice! Basically the best. Keep that attacking tempo up!',
      'Strong move. The tactical pressure stays right on them.',
    ],
    good: [
      'Fine, fine, but {best} hit way harder!',
      'Playable, though {best} was much sharper and more forcing.',
    ],
    inaccuracy: [
      'Ooh, you let them off the hook a little. {best} was more forcing.',
      'Too slow! {best} kept the initiative in your hands.',
    ],
    mistake: [
      'Ouch, that’s a mistake! {best} was the tactical shot you needed.',
      'You’re handing over counterplay! {best} was required there.',
    ],
    blunder: [
      'Blunder!! Huge evaluation swing. {best} was the only move!',
      'No, no, no! That walks right into trouble — {best} was right there!',
    ],
  },
  gambit: {
    brilliant: [
      'Standing ovation!! A brilliant sacrifice worthy of the grandest stage!',
      'Pure artistry!! You tossed material aside for a gorgeous dynamic masterpiece!',
    ],
    great: [
      'Bravo! A great find — the one critical idea that unlocks the whole position!',
      'Now THAT is a move with presence! The only line that keeps the story going your way.',
    ],
    best: [
      'Ladies and gentlemen, that is the best move on the board!',
      'Chef’s kiss. Stockfish itself would applaud that choice.',
    ],
    excellent: [
      'Ooh, lovely. Nearly perfect, and full of strategic harmony.',
      'Excellent! Take a bow — a small, dignified bow.',
    ],
    good: [
      'Perfectly decent! Though {best} would have added even more flair.',
      'A solid choice. {best} was a touch spicier in the imbalances.',
    ],
    inaccuracy: [
      'Tiny slip in the plot! {best} was the neater strategic idea.',
      'Hmm, not quite the main theme. {best} kept the dynamic tension.',
    ],
    mistake: [
      'Oh dear, an unintended plot twist. {best} was the move to play.',
      'That one stings the narrative! Remember {best} for next time.',
    ],
    blunder: [
      'Gasp! The audience is on its feet in shock. {best} was the only way out!',
      'Dramatic! Tragic, even. {best} was begging to be played.',
    ],
  },
}

export const reactionFor = (
  coach: CoachId,
  cls: MoveClass,
  n: number,
  best: string
) => {
  const lines = LINES[coach][cls] ?? LINES[coach].good
  return lines[n % lines.length].replace('{best}', best || 'another move')
}
