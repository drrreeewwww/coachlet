import type { MoveRecord } from '@/lib/review/record'
import type { CoachId, PlayerColor } from '@/types'

export type Phase = 'opening' | 'middlegame' | 'endgame'
const PIECES: Record<string, string> = {
  N: 'knight',
  B: 'bishop',
  R: 'rook',
  Q: 'queen',
  K: 'king',
  O: 'king',
}
const tier = (elo: number) => (elo < 1100 ? 0 : elo < 1850 ? 1 : 2)

/** Elo-adapted thinking prompts: simpler for beginners, more technical for strong players. */
const TIP: Record<CoachId, string[]> = {
  vale: [
    'Before you move, check that every piece is defended and your king is safe.',
    'Compare your worst-placed piece with the one you just moved, and watch for pawn weaknesses.',
    'Evaluate the resulting pawn transformation and whether the multi-move PV favours your endgame structure.',
  ],
  flash: [
    'Always check if your opponent can capture your piece for free on the very next move!',
    'Scan checks, captures, and threats for both sides before committing to a move.',
    'Calculate the forcing replies 3–4 plies deep — verify no counter-sacrifice or intermediate check refutes your idea.',
  ],
  gambit: [
    'Quick question: what could your opponent capture or attack right after that move?',
    'Ask yourself: what was your opponent’s last move threatening, and how does your plan address the centre?',
    'Compare the top two engine candidate lines: what strategic imbalance changes between them?',
  ],
}

export const tipFor = (coach: CoachId, elo: number) => TIP[coach][tier(elo)]

export const phaseOf = (fen: string, ply: number): Phase =>
  (fen.split(' ')[0].match(/[qrbnQRBN]/g) ?? []).length <= 6
    ? 'endgame'
    : ply < 20
      ? 'opening'
      : 'middlegame'

/** Recurring weaknesses in the human player's real inaccuracies, mistakes and blunders. */
export function weaknesses(recs: MoveRecord[], playerColor: PlayerColor = 'w') {
  const bad = recs
    .map((m, i) => ({ m, i }))
    .filter(
      ({ m }) =>
        m.color === playerColor &&
        (m.cls === 'mistake' || m.cls === 'blunder' || m.cls === 'inaccuracy')
    )
  const serious = bad.filter(
    ({ m }) => m.cls === 'mistake' || m.cls === 'blunder'
  )

  const tally = (keys: string[]) => {
    const c = new Map<string, number>()
    keys.forEach((k) => c.set(k, (c.get(k) ?? 0) + 1))
    const top = [...c].sort((a, b) => b[1] - a[1])[0]
    return top && top[1] >= 2 ? top : undefined
  }

  const missedTactics = bad.filter(
    ({ m }) => m.bestSan.includes('x') || m.bestSan.includes('+')
  ).length

  return {
    mistakes: serious.length,
    totalSlips: bad.length,
    missedTactics: missedTactics >= 2 ? missedTactics : 0,
    phase: tally(serious.map(({ m, i }) => phaseOf(m.fenBefore, i))) as
      | [Phase, number]
      | undefined,
    piece: tally(serious.map(({ m }) => PIECES[m.san[0]] ?? 'pawn')),
  }
}

const OPEN: Record<CoachId, string> = {
  vale: 'Here is my clinical assessment.',
  flash: 'Okay, here’s the tactical breakdown!',
  gambit: 'Great question! Here’s the strategic theme to practise.',
}

const ADVICE: Record<Phase, string> = {
  opening:
    'opening principles: develop minor pieces toward the centre, castle early, and avoid moving the same piece twice without a concrete reason.',
  middlegame:
    'middlegame calculation: before every move, check forcing moves (checks, captures, threats) for both you and your opponent.',
  endgame:
    'endgame technique: centralise your king immediately, activate your rooks behind passed pawns, and calculate pawn races accurately.',
}

export function train(
  coach: CoachId,
  elo: number,
  recs: MoveRecord[],
  playerColor: PlayerColor = 'w'
): string {
  if (recs.filter((m) => m.color === playerColor).length < 3)
    return `${OPEN[coach]} Play a few more moves so I have real game decisions to analyse.`
  const w = weaknesses(recs, playerColor)
  if (!w.mistakes && !w.totalSlips)
    return `${OPEN[coach]} No mistakes or blunders so far — your accuracy is high. Keep playing principled moves.`
  const parts = [
    `${OPEN[coach]} You have made ${w.mistakes} serious error${w.mistakes === 1 ? '' : 's'} (${w.totalSlips} total inaccuracies/mistakes) in this game.`,
  ]
  parts.push(
    w.phase
      ? `Most occurred in the ${w.phase[0]}, so focus on ${ADVICE[w.phase[0]]}`
      : `Focus on ${ADVICE.middlegame}`
  )
  if (w.piece)
    parts.push(
      `Your ${w.piece[0]} moves have cost you ${w.piece[1]} times — verify its target square isn’t controlled before moving it.`
    )
  if (w.missedTactics)
    parts.push(
      `You also overlooked ${w.missedTactics} forcing captures or checks recommended by Stockfish.`
    )
  parts.push(tipFor(coach, elo))
  return parts.join(' ')
}
