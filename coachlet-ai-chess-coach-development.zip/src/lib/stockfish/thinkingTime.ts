import { Chess } from 'chess.js'
import type { AiPaceMode, PlayerColor } from '@/types'

export interface ThinkingTimeParams {
  fen: string
  selectedMoveUci: string
  lastOpponentToSquare?: string | null
  elo: number
  remainingClockMs: number
  initialClockMs: number
  paceMode: AiPaceMode
  customMinMs: number
  customMaxMs: number
  engineCalculationElapsedMs: number
}

/**
 * Calculates how much additional delay (in ms) the AI should wait after Stockfish has
 * finished selecting its move so that the total visible thinking time feels like a real
 * human opponent while strictly respecting the AI's remaining chess clock.
 */
export function calculateNaturalAiDelayMs(params: ThinkingTimeParams): number {
  const {
    fen,
    selectedMoveUci,
    lastOpponentToSquare,
    elo,
    remainingClockMs,
    initialClockMs,
    paceMode,
    customMinMs,
    customMaxMs,
    engineCalculationElapsedMs,
  } = params

  // Never add artificial delay if the clock is critically low (< 2.2 seconds)
  if (remainingClockMs <= 2200) {
    return 0
  }

  let chess: Chess
  try {
    chess = new Chess(fen)
  } catch {
    return 400
  }

  const legalMoves = chess.moves({ verbose: true })
  if (legalMoves.length === 0) return 0

  // Base min/max target thinking duration (in ms) based on selected pace mode
  let minTarget = 950
  let maxTarget = 2900

  if (paceMode === 'fast') {
    minTarget = 550
    maxTarget = 1450
  } else if (paceMode === 'deliberate') {
    minTarget = 1800
    maxTarget = 4600
  } else if (paceMode === 'custom') {
    minTarget = Math.max(250, Math.min(customMinMs, customMaxMs))
    maxTarget = Math.max(minTarget + 200, Math.max(customMinMs, customMaxMs))
  }

  // Scale base duration according to total time control so 1-min Bullet is brisk
  // while 10-min / 15-min / 30-min / 60-min games feel appropriately thoughtful
  const initialSeconds = initialClockMs / 1000
  let timeControlMultiplier = 1.0
  if (initialSeconds <= 60) {
    // 1 minute bullet: brisk human cadence
    timeControlMultiplier = 0.42
  } else if (initialSeconds <= 180) {
    // 3 minute blitz
    timeControlMultiplier = 0.68
  } else if (initialSeconds <= 300) {
    // 5 minute blitz
    timeControlMultiplier = 0.85
  } else if (initialSeconds >= 1800) {
    // 30m / 60m classical
    timeControlMultiplier = 1.2
  }

  // Evaluate position complexity factor (0.0 = trivial/forced, 1.0 = highly complex)
  const moveNumber = chess.moveNumber()
  const inCheck = chess.inCheck()
  const captures = legalMoves.filter((m) => m.captured)
  const checks = legalMoves.filter((m) => m.san.includes('+'))
  const selectedMoveObj = legalMoves.find(
    (m) => m.from + m.to + (m.promotion ?? '') === selectedMoveUci
  )

  let complexityFactor = 0.45

  if (legalMoves.length === 1) {
    // Forced single legal move
    complexityFactor = 0.12
  } else if (
    selectedMoveObj?.captured &&
    lastOpponentToSquare &&
    selectedMoveObj.to === lastOpponentToSquare
  ) {
    // Natural recapture on the same square
    complexityFactor = 0.24
  } else if (moveNumber <= 4 && !inCheck && captures.length <= 1) {
    // Early opening book phase
    complexityFactor = 0.3
  } else {
    // Middlegame / tactical complexity
    if (inCheck) complexityFactor += 0.18
    if (captures.length >= 3) complexityFactor += 0.22
    if (checks.length >= 2) complexityFactor += 0.15
    if (legalMoves.length >= 32) complexityFactor += 0.15
    if (selectedMoveObj?.captured) complexityFactor += 0.1
    if (elo >= 1800 && moveNumber >= 8 && moveNumber <= 30) {
      complexityFactor += 0.12
    }
  }

  complexityFactor = Math.max(0.1, Math.min(1.0, complexityFactor))

  // Interpolate target duration and apply natural human jitter (±22%)
  const rawTargetMs =
    (minTarget + (maxTarget - minTarget) * complexityFactor) *
    timeControlMultiplier
  const jitter = 0.78 + Math.random() * 0.44
  let totalTargetMs = Math.round(rawTargetMs * jitter)

  // Time trouble speedup: if AI has less than 20 seconds or < 15% of initial clock left
  if (remainingClockMs < 10_000) {
    totalTargetMs = Math.min(totalTargetMs, 550)
  } else if (remainingClockMs < 25_000) {
    totalTargetMs = Math.min(totalTargetMs, 1050)
  }

  // Never use more than 10% of remaining clock on a single move, and always leave a safety buffer
  const maxSafeByClock = Math.max(
    0,
    Math.min(remainingClockMs * 0.1, remainingClockMs - 1000)
  )
  totalTargetMs = Math.min(totalTargetMs, maxSafeByClock)

  // Subtract actual Stockfish calculation time that has already elapsed
  const remainingWaitMs = Math.max(
    0,
    Math.round(totalTargetMs - engineCalculationElapsedMs)
  )

  return remainingWaitMs
}

/**
 * Determines whether `color` has sufficient mating material on the board.
 * Used when the opponent's clock expires: if `color` cannot possibly checkmate
 * (e.g., Lone King, K+N, or K+B with no other pieces/pawns), a timeout is a Draw.
 */
export function hasSufficientMatingMaterial(
  fen: string,
  color: PlayerColor
): boolean {
  try {
    const c = new Chess(fen)
    const board = c.board()
    let pawns = 0
    let rooksOrQueens = 0
    let knights = 0
    let bishops = 0

    for (const row of board) {
      for (const cell of row) {
        if (!cell || cell.color !== color) continue
        if (cell.type === 'p') pawns++
        else if (cell.type === 'r' || cell.type === 'q') rooksOrQueens++
        else if (cell.type === 'n') knights++
        else if (cell.type === 'b') bishops++
      }
    }

    if (pawns > 0 || rooksOrQueens > 0) return true
    if (bishops >= 2) return true
    if (bishops >= 1 && knights >= 1) return true
    if (knights >= 2) return true // K+2N can theoretically mate against opponent pieces
    return false
  } catch {
    return true
  }
}
