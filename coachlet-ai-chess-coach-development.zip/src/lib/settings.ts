import type {
  AiPaceMode,
  ColorChoice,
  TimeControlMinutes,
  TimeControlOption,
  VoiceProviderId,
} from '@/types'

export type ThemeId = 'green' | 'walnut' | 'ice' | 'rose'
export type PieceStyle = 'classic' | 'outline' | 'letters'

export const THEMES: Record<
  ThemeId,
  { label: string; light: string; dark: string; coordLight: string; coordDark: string }
> = {
  green: {
    label: 'Chess.com Green',
    light: '#eeeed2',
    dark: '#769656',
    coordLight: '#769656',
    coordDark: '#eeeed2',
  },
  walnut: {
    label: 'Classic Wood',
    light: '#f0d9b5',
    dark: '#b58863',
    coordLight: '#b58863',
    coordDark: '#f0d9b5',
  },
  ice: {
    label: 'Icy Sea',
    light: '#dee3e6',
    dark: '#8ca2ad',
    coordLight: '#8ca2ad',
    coordDark: '#dee3e6',
  },
  rose: {
    label: 'Tournament Rosewood',
    light: '#f3e3e3',
    dark: '#b5727c',
    coordLight: '#b5727c',
    coordDark: '#f3e3e3',
  },
}

export const PIECE_STYLES: Record<PieceStyle, string> = {
  classic: 'Staunton Neo (SVG)',
  outline: 'Classic Outline',
  letters: 'Tournament Discs',
}

export const TIME_CONTROL_OPTIONS: TimeControlOption[] = [
  {
    minutes: 1,
    label: '1 minute',
    category: 'Bullet',
    seconds: 60,
    description: '1 min • Hyper-fast Bullet',
  },
  {
    minutes: 3,
    label: '3 minutes',
    category: 'Blitz',
    seconds: 180,
    description: '3 min • Sharp Blitz',
  },
  {
    minutes: 5,
    label: '5 minutes',
    category: 'Blitz',
    seconds: 300,
    description: '5 min • Standard Blitz',
  },
  {
    minutes: 10,
    label: '10 minutes',
    category: 'Rapid',
    seconds: 600,
    description: '10 min • Club Rapid',
  },
  {
    minutes: 15,
    label: '15 minutes',
    category: 'Rapid',
    seconds: 900,
    description: '15 min • Deep Rapid',
  },
  {
    minutes: 30,
    label: '30 minutes',
    category: 'Classical',
    seconds: 1800,
    description: '30 min • Classical Training',
  },
  {
    minutes: 60,
    label: '1 hour',
    category: 'Classical',
    seconds: 3600,
    description: '60 min • Full Tournament',
  },
]

export interface Settings {
  // Voice & TTS
  voice: boolean
  voiceProvider: VoiceProviderId
  speed: number
  voiceVolume: number
  autoSpeakCriticalOnly: boolean
  /** 'coach' = each coach's default Kokoro voice, otherwise a Kokoro voice id. */
  kokoroVoice: string
  /** Speak new coaching automatically (off by default: written coaching first). */
  autoSpeak: boolean

  // Coaching & Gameplay
  reactions: boolean
  hints: boolean
  training: boolean
  threshold: number
  evalBar: boolean

  // Appearance
  theme: ThemeId
  pieces: PieceStyle
  coords: boolean

  // Sound Effects
  sound: boolean
  volume: number

  // Engine Analysis
  analysisDepth: number
  analysisTime: number
  multiPv: number
  showArrows: boolean

  // Time Control & Player Setup
  timeControlMinutes: TimeControlMinutes
  colorChoice: ColorChoice

  // Natural AI Thinking Pacing
  aiPace: AiPaceMode
  aiMinDelayMs: number
  aiMaxDelayMs: number
}

export const DEFAULTS: Settings = {
  voice: true,
  voiceProvider: 'kokoro',
  speed: 1,
  voiceVolume: 0.85,
  autoSpeakCriticalOnly: false,
  kokoroVoice: 'coach',
  autoSpeak: false,

  reactions: true,
  hints: true,
  training: false,
  threshold: 20,
  evalBar: true,

  theme: 'green',
  pieces: 'classic',
  coords: true,

  sound: true,
  volume: 0.65,

  analysisDepth: 14,
  analysisTime: 700,
  multiPv: 3,
  showArrows: true,

  timeControlMinutes: 10,
  colorChoice: 'w',

  aiPace: 'natural',
  aiMinDelayMs: 900,
  aiMaxDelayMs: 2800,
}
