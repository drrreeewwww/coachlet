import { useCallback, useEffect, useState } from 'react'
import type { ExplorerSource } from './explorerApi'

const KEY = 'coachlet:explorer:v1'
export interface ExplorerPrefs {
  token: string
  source: ExplorerSource
  flipped: boolean
  speedMs: 1000 | 1500 | 2000
}
const DEFAULT: ExplorerPrefs = { token: '', source: 'masters', flipped: false, speedMs: 1500 }

function read(): ExplorerPrefs {
  if (typeof window === 'undefined') return DEFAULT
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) return { ...DEFAULT, ...JSON.parse(raw) }
  } catch {
    /* defaults */
  }
  return DEFAULT
}

export function useExplorerPrefs(): [ExplorerPrefs, (p: Partial<ExplorerPrefs>) => void] {
  const [p, setP] = useState<ExplorerPrefs>(DEFAULT)
  useEffect(() => setP(read()), [])
  const update = useCallback((patch: Partial<ExplorerPrefs>) => {
    setP((prev) => {
      const n = { ...prev, ...patch }
      try {
        localStorage.setItem(KEY, JSON.stringify(n))
      } catch {
        /* storage unavailable */
      }
      return n
    })
  }, [])
  return [p, update]
}
