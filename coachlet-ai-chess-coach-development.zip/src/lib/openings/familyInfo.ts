import type { Category } from './catalogue'

export interface FamilyInfo {
  summary: string
  white: string[]
  black: string[]
  plans: string[]
  structure: string
  motifs: string[]
  mistakes: string[]
  traps?: string[]
}

/** Hand-written, curated explanations. Keys are opening FAMILY names from the catalogue. */
export const FAMILY_INFO: Record<string, FamilyInfo> = {
  'Italian Game': {
    summary: 'White develops the bishop to c4, eyeing the f7 square, and builds a broad centre with c3 and d4 — the classic open-game way to play for quick development.',
    white: ['Aim the bishop and queen at f7', 'Prepare c3 and d4 to build a big pawn centre', 'Castle kingside early'],
    black: ['Meet Bc4 with ...Bc5 or the solid ...Be7', 'Challenge the centre with ...d5 at the right moment', 'Avoid early weaknesses on f7'],
    plans: ['c3 + d4 to seize the centre (Giuoco Piano)', 'Slow d3 set-ups (Giuoco Pianissimo) with Nbd2, a4, h3', 'Kingside attack when Black castles short'],
    structure: 'Typically a pair of central pawns versus e5 and d6/d5; open or semi-open centre after d4 exchanges.',
    motifs: ['Pressure on f7', 'Pins with Bg5', 'The ...d5 break', 'Fried Liver ideas with Ng5 and Nxf7'],
    mistakes: ['Moving the same piece twice for no reason', 'Attacking f7 without enough support', 'Forgetting to castle before opening the centre'],
    traps: ['Fried Liver Attack after ...Nf6 Ng5 d5 exd5 Nxd5?! Nxf7', 'Légal-type ideas when Black pins and grabs on e4 carelessly'],
  },
  'Ruy Lopez': {
    summary: 'White pins the knight that defends e5 with Bb5. It is the oldest big-theory opening: White keeps long-term pressure while Black fights for a stable centre.',
    white: ['Keep tension on the e5 pawn and Black\'s queenside knight', 'Build the c3–d4 centre', 'Use the bishop on the long diagonal after a4/Ba4'],
    black: ['Kick the bishop with ...a6 and ...b5', 'Develop with ...Nf6 and ...Be7, then ...O-O', 'Strike with ...d5 or ...c5 when ready'],
    plans: ['Closed Spanish: c3, h3, d4, then Nbd2–f1–g3 manoeuvres', 'Exchange Variation: damage Black\'s pawn structure and head for an endgame', 'Berlin: trade queens early and play a technical endgame'],
    structure: 'Closed centre with White pawns on d3/e4 or d4/e4 versus Black e5/d6; ideas revolve around the d4 and f4 breaks.',
    motifs: ['Pressure on the e5 pawn', 'Pin on the c6-knight', 'Long-term queenside pawn majority', 'Kingside space attacks'],
    mistakes: ['Capturing Bxc6 without a concrete reason', 'Rushing d4 before the centre is prepared', 'Allowing ...Nxe4 tricks before castling'],
    traps: ['Noah\'s Ark Trap (...b5, ...c5, ...c4 trapping the bishop)', 'Fishing Pole ideas after ...Ng4 and ...h5 in some lines'],
  },
  'Sicilian Defense': {
    summary: 'Black answers 1.e4 with ...c5, fighting for the centre asymmetrically. It leads to sharp, unbalanced positions where both sides have winning chances.',
    white: ['Open the centre with d4 and use extra space and development', 'Attack on the kingside with f4, Bg5, Qd2 and long castling (Open Sicilian)', 'Play positionally with c3 or Bb5+ (Anti-Sicilians)'],
    black: ['Trade the c-pawn for the d-pawn to gain a queenside majority', 'Use the half-open c-file for counterplay', 'Break with ...d5 or ...b5 at the right time'],
    plans: ['Opposite-side castling races', 'Queenside pawn storm for Black; kingside pawn storm for White', 'Piece sacrifices on d5, e6 or b5 for the initiative'],
    structure: 'Black gets a half-open c-file and White holds the d4/e4 space; the d5 square often becomes a key outpost.',
    motifs: ['Sacrifice on d5 or e6', 'Exchange sacrifice on c3', 'Half-open files for rooks', 'Weak d6 / backward d-pawn'],
    mistakes: ['Neglecting development while grabbing pawns', 'Slow play against the Najdorf/Scheveningen set-ups', 'Ignoring the ...Nxe4 or ...d5 breaks'],
    traps: ['Siberian Trap in the Smith–Morra Gambit', 'Poisoned pawn lines in the Najdorf with Qxb2'],
  },
  'French Defense': {
    summary: 'Black plays ...e6 and ...d5 to challenge e4, accepting a slightly cramped position for a rock-solid pawn chain and counterplay against White\'s centre.',
    white: ['Use the space advantage with e5', 'Attack on the kingside', 'Keep the knight outpost on d4/f4 and the light squares'],
    black: ['Undermine d4 with ...c5', 'Hit the chain base with ...f6', 'Solve the light-squared bishop problem'],
    plans: ['Advance variation: White clamps the centre, Black attacks d4 with ...c5 and ...Qb6', 'Exchange variation: symmetrical and equal', 'Winawer: pin on c3 and double pawns for a sharp battle'],
    structure: 'Locked pawn chain e5/d4 vs e6/d5; the fight revolves around ...c5 and ...f6 breaks.',
    motifs: ['Bad light-squared bishop for Black', 'Greek-gift style bishop sacrifices on h7', 'Pawn breaks ...c5 and ...f6'],
    mistakes: ['Passive play with no ...c5 counterplay', 'Allowing a crushing kingside attack', 'Exchanging the wrong pieces and leaving the c8 bishop buried'],
    traps: ['Early queen trap on the Winawer after careless Qg4 grabs'],
  },
  'Caro-Kann Defense': {
    summary: 'Black prepares ...d5 with ...c6, keeping a solid structure and a healthy light-squared bishop. It trades some activity for reliability.',
    white: ['Advance with e5 for space', 'Pressure with Nc3/Nf3 and quick development', 'Aim for a favourable minority or a kingside attack'],
    black: ['Develop the bishop to f5 or g4 before ...e6', 'Challenge with ...c5 and ...Nc6', 'Reach a healthy endgame with no weaknesses'],
    plans: ['Advance: Bf5, ...e6, ...c5 against the d4 pawn', 'Classical 4...Bf5: harmonious development and ...Nd7', 'Panov: isolated pawn positions with active pieces'],
    structure: 'Solid c6–d5 chain; in the Advance it becomes e5/d4 vs. e6/c5 with open play on the queenside.',
    motifs: ['Light-squared bishop outside the chain', 'IQP positions in the Panov', 'Pawn breaks ...c5 and ...e5'],
    mistakes: ['Developing the bishop to f5 and forgetting White\'s Qb3 or g4 ideas', 'Ignoring White\'s space in the Advance', 'Playing too slowly in the Panov'],
  },
  'Scandinavian Defense': {
    summary: 'Black immediately challenges e4 with ...d5. The queen comes out early, so Black aims for rapid development and solid structure.',
    white: ['Gain tempi against the queen with Nc3 and d4', 'Develop quickly and aim for a lead in development', 'Keep control of the centre'],
    black: ['Retreat the queen to a5 or d6 and complete development', 'Play ...c6 and ...Bf5 for a Caro-like structure', 'Aim for a stable position with ...Nf6 and ...e6'],
    plans: ['Central pressure and open lines for White', 'Black aims for a solid structure and later ...c5 or ...e5 breaks'],
    structure: 'Open centre with Black having a lone d-pawn captured; White often gets a space edge, Black a robust set-up.',
    motifs: ['Tempo gains on the queen', 'Pins on the b4–e1 diagonal', 'Quick development'],
    mistakes: ['Leaving the queen exposed to tempo moves', 'Over-pushing pawns and ignoring development', 'Missing Bb5+ ideas after ...Qa5'],
  },
  "Queen's Gambit Declined": {
    summary: 'After 1.d4 d5 2.c4 e6 Black keeps the centre solid and declines the pawn, accepting a slightly passive but sturdy position.',
    white: ['Pressure on d5 and the queenside', 'Minority attack (b4–b5) in Exchange structures', 'Use the Bg5 pin'],
    black: ['Develop ...Nf6, ...Be7, ...O-O and ...c6 or ...dxc4', 'Free the game with ...c5 or ...e5', 'Solve the c8 bishop'],
    plans: ['Exchange variation: Minority attack vs. kingside piece play', 'Orthodox: Bg5, e3, Rc1, cxd5 ideas', 'Tartakower/Lasker: simplifying defences'],
    structure: 'Pawns on d4/c4 vs d5/e6; the Exchange variation creates a Carlsbad structure.',
    motifs: ['Minority attack', 'Pin on f6', 'Break ...e5 or ...c5', 'Hanging pawn structures'],
    mistakes: ['Locking the c8 bishop in', 'Ignoring White\'s pressure on c4/d5', 'Exchanging the wrong minor pieces'],
    traps: ['Elephant Trap: ...Nxd5 after Nxd5? with Bb4+ ideas'],
  },
  "Queen's Gambit Accepted": {
    summary: 'Black accepts the c4 pawn with ...dxc4 to relieve the centre, planning to return the pawn at a good moment for easy development.',
    white: ['Regain the pawn with e3 and Bxc4', 'Build a big centre with e4', 'Use the lead in development'],
    black: ['Hit the centre with ...c5 or ...a6/…b5 ideas', 'Develop pieces and avoid hanging on to the pawn', 'Trade queens in some lines'],
    plans: ['Classical: ...Nf6, ...e6, ...c5 and ...Nc6', 'White: e3, Bxc4, O-O, Nc3, and the e4 push'],
    structure: 'White usually gets a pawn on d4 and e4 centre; Black has an isolated or hanging pawn chances.',
    motifs: ['Pressure on d5', 'Isolated queen pawn', 'Early queen trades'],
    mistakes: ['Hanging onto the extra pawn at all cost', 'Leaving the queen exposed to Qxb7', 'Delaying ...e6'],
  },
  'Slav Defense': {
    summary: 'Black defends d5 with ...c6, keeping the light-squared bishop free. It is a solid, flexible response to the Queen\'s Gambit.',
    white: ['Fight for the centre with Nf3, Nc3, e3', 'Use space on the queenside', 'Play for a small, safe edge'],
    black: ['Develop the bishop outside the chain', 'Hold the d5 pawn and aim for ...e5 or ...c5', 'Use ...dxc4 and ...b5 to keep extra space'],
    plans: ['Slav proper: ...dxc4 and ...Be6 or ...Bf5', 'Semi-Slav: ...e6 and Meran/Botvinnik structures'],
    structure: 'c6–d5 pawn chain with a free c8 bishop; the d4 and e5 squares are the main battleground.',
    motifs: ['The ...e5 break', 'Pressure along the c-file', 'Queenside majority for Black'],
    mistakes: ['Locking in the c8 bishop with ...e6 too early', 'Letting White build a big centre unopposed', 'Missing Qb3/Nh4 tactical shots'],
  },
  "King's Indian Defense": {
    summary: 'Black lets White build a big centre, fianchettoes the bishop on g7, and attacks the centre later with ...e5 or ...c5, aiming for a kingside attack.',
    white: ['Take space with c4, d4, e4 and Nc3', 'Attack on the queenside with c5 and b4', 'Keep the centre closed and safe'],
    black: ['Castle quickly and strike with ...e5', 'Use the g7 bishop and kingside pawn storm (...f5, ...g5)', 'Keep pieces coordinated for counterplay'],
    plans: ['Classical: Be2, O-O, Nf3 and d5 vs. ...Nbd7 and ...e5 or ...c6', 'Sämisch: f3 and Be3, with opposite-side attacks', 'Fianchetto: slow manoeuvring'],
    structure: 'Locked centre: White pawn on d5 and Black pawn on e5; White attacks on the queenside, Black on the kingside.',
    motifs: ['Pawn storm with ...f5–f4', 'Exchange sacrifices on c3', 'Strong g7 bishop'],
    mistakes: ['Ignoring the kingside pawn storm timing', 'Losing the race on the wrong wing', 'Misplacing the g7 bishop behind its own pawns'],
  },
  'Nimzo-Indian Defense': {
    summary: 'Black pins the c3 knight with ...Bb4 and fights for e4 with pieces rather than pawns. It is one of the most respected defences to 1.d4.',
    white: ['Gain the bishop pair after a3 and Bxc3', 'Take the centre with e3 and Nge2', 'Use central space (Rubinstein with e3)'],
    black: ['Control e4 with ...Nf6 and ...d5/…c5', 'Double White\'s pawns on c3', 'Use light-square control and piece play'],
    plans: ['Rubinstein: e3, Bd3, Nf3 with kingside castling', 'Classical: Qc2 to avoid doubled pawns', 'Sämisch: a3 for the bishop pair'],
    structure: 'Flexible; often doubled c-pawns for White offset by bishop pair, or a central pawn chain after ...d5.',
    motifs: ['Doubled c-pawns', 'Bishop pair vs. structure', 'Control of e4'],
    mistakes: ['Giving up the bishop too early', 'Ignoring White\'s central expansion with e4', 'Misplacing the c8 bishop'],
  },
  'English Opening': {
    summary: 'White plays 1.c4, controlling d5 from the flank and keeping central options open. Often transposes to Queen\'s Gambit or Sicilian-style positions.',
    white: ['Control d5 and the centre with pieces', 'Fianchetto the king\'s bishop', 'Play on the queenside with b4 and Rb1'],
    black: ['Mirror with ...c5 or meet with ...e5', 'Fight for d4 with ...d5', 'Choose between symmetrical and Reversed Sicilian set-ups'],
    plans: ['Reversed Sicilian after 1...e5', 'Symmetrical: fianchetto both bishops', 'Botvinnik set-up with Bg2, Nc3, e4'],
    structure: 'Flexible; either a reversed Sicilian with an extra tempo, or a symmetrical hedgehog-like structure.',
    motifs: ['Pressure on d5', 'Queenside space', 'Hedgehog structures'],
    mistakes: ['Passive piece placement', 'Allowing ...d5 under good conditions', 'Misjudging transpositions'],
  },
  'London System': {
    summary: 'White sets up with d4, Nf3, Bf4 and e3 in nearly every game — a reliable, low-theory system that rewards understanding of the structure.',
    white: ['Develop Bf4 outside the pawn chain', 'Build a solid pyramid with c3, e3', 'Aim for e4 or Ne5 breaks'],
    black: ['Challenge with ...c5 and ...Qb6 to hit b2', 'Play ...Bf5 and ...e6 for solidity', 'Play on the queenside while White waits'],
    plans: ['e4 break after Nbd2 and Bd3', 'Ne5 outpost', 'Kingside attack with h3 and Bh2'],
    structure: 'Pawns on d4/e3/c3 vs. d5/e6; the light-squared bishop attacks the opposite wing.',
    motifs: ['Ne5 outposts', 'b2 weakness', 'e4 break'],
    mistakes: ['Ignoring ...Qb6 on b2', 'Overusing the same plan against all set-ups', 'Letting Black play ...c5 and ...Nc6 freely'],
  },
  'Scotch Game': {
    summary: 'White opens the centre at once with d4. The result is open, active play with a space edge and rapid development.',
    white: ['Open the centre for the pieces', 'Recapture with the knight on d4 and develop Nxc6, Bc4', 'Keep a lead in development'],
    black: ['Counter with ...Bc5 or ...Nf6 for active play', 'Use the ...d5 break', 'Avoid a weak d6 pawn'],
    plans: ['Classical: Bc4, Nb3', 'Mieses: a kingside attack with e5', 'Open positions with active pieces'],
    structure: 'Open centre with an e-pawn vs. d-pawn exchange; the e5 square can be a target.',
    motifs: ['Pressure on d4', 'Pins on Nc6', 'Central pawn majority'],
    mistakes: ['Forgetting about Qh4 attacks', 'Delaying development', 'Capturing too many central pawns for no clear reason'],
  },
  "Petrov's Defense": {
    summary: 'Black mirrors White with ...Nf6, hitting e4 immediately. It is extremely solid and often leads to drawish, symmetrical play.',
    white: ['Take the pawn on e5 and play Nxe5', 'Play d4 and Bd3 for a solid centre', 'Look for small structural edges'],
    black: ['Counterattack with ...Nxe4 and trade down', 'Use the pin on the e-file', 'Neutralise White\'s initiative'],
    plans: ['Main line: Nxe5 d6 Nf3 Nxe4 d4', 'Steinitz Variation with d4 early', 'Symmetrical endgames'],
    structure: 'Open e-file and symmetrical or near-symmetrical pawns.',
    motifs: ['Pin on the e-file', 'Pawn-grab tricks', 'Queen trade endgames'],
    mistakes: ['Taking on e5 and repeating the same moves with no plan', 'Allowing a back-rank problem after trades', 'Ignoring the pin'],
    traps: ['Early Qe2 trap after ...Nxe4?? Qe2 Nf6?? Nxe5+'],
  },
  "King's Gambit Accepted": {
    summary: 'White sacrifices the f-pawn for rapid development and an open f-file. It is the most romantic opening, trading safety for attacking chances.',
    white: ['Open the f-file and attack f7', 'Develop quickly with Nf3 and Bc4', 'Rebuild a pawn centre with d4'],
    black: ['Keep the pawn and hit with ...g5 or ...d6', 'Return the pawn at the right moment', 'Defend f7 and king safety'],
    plans: ['Kieseritzky and Muzio: wild attacking lines', 'Fischer Defence: safe counterattack', 'Bishop\'s Gambit ideas with Bc4'],
    structure: 'Open f-file, exposed kings, rapid development battles.',
    motifs: ['Open f-file', 'Sacrifices on f7', 'Pawn storm with ...g5 and ...h5'],
    mistakes: ['Overextending with ...g5 and no support', 'Ignoring king safety', 'Delaying development'],
  },
  'Catalan Opening': {
    summary: 'White combines the Queen\'s Gambit with a kingside fianchetto, putting long-term pressure on the c6–h1 diagonal and queenside.',
    white: ['Use the g2 bishop on the long diagonal', 'Pressure on c6 and d5', 'Win back the c4 pawn if taken'],
    black: ['Take the c4 pawn and hold it with ...b5 or return it', 'Solid ...Be7, ...O-O and ...c6', 'Play ...c5 and ...Nc6 for activity'],
    plans: ['Open Catalan: regain the pawn with Qa4 or Ne5 ideas', 'Closed Catalan: slow manoeuvres', 'Queenside pressure'],
    structure: 'Open diagonal for the g2-bishop; semi-open positions with a queenside pawn majority for White.',
    motifs: ['Long-diagonal pressure', 'Pawn grab on c4', 'Ne5 outposts'],
    mistakes: ['Blocking the g2 bishop', 'Ignoring ...dxc4 plans', 'Weakening the kingside'],
  },
  'Grünfeld Defense': {
    summary: 'Black allows a huge White pawn centre, then attacks it with ...c5, ...Nc6, and the bishop on g7, relying on piece play and counterattack.',
    white: ['Build a pawn centre with e4 and d4', 'Pressure the c5 and d5 squares with piece play', 'Keep an eye on the g7 bishop'],
    black: ['Undermine the centre with ...c5', 'Use the g7 bishop on the long diagonal', 'Look for ...Nxe4 or ...Bg4 tactics'],
    plans: ['Exchange variation: central pawn mass vs. ...c5 and ...Bg4', 'Russian variation: queen to b3 or Qa4+', 'Fianchetto lines with quieter play'],
    structure: 'Open pawn centre for White and piece activity for Black; the d4 pawn is the main target.',
    motifs: ['Pressure on d4', 'g7 bishop diagonal', 'Pin on e4 or f3'],
    mistakes: ['Underestimating White\'s centre', 'Retreating too passively', 'Leaving the king in the middle in sharp lines'],
  },
  'Pirc Defense': {
    summary: 'Black allows White a big centre and plans to fianchetto and strike with ...e5 or ...c5. It is flexible and counter-attacking.',
    white: ['Take central space with e4, d4 and f4 (Austrian) or Be3/Qd2', 'Build a kingside attack with h4–h5', 'Keep pieces coordinated'],
    black: ['Fianchetto on g7 and castle', 'Break with ...e5 or ...c5', 'Counterattack against the centre'],
    plans: ['Classical: Be2 and O-O', 'Austrian Attack: f4 and sharp attacks', 'Fianchetto lines'],
    structure: 'White gets pawn centre e4/d4; Black responds with piece pressure.',
    motifs: ['g7 bishop pressure on d4', 'Pawn breaks ...c5 and ...e5', 'Kingside attacks'],
    mistakes: ['Passive play without breaks', 'Letting White build a crushing centre', 'Ignoring tactics on e5'],
  },
  'Dutch Defense': {
    summary: 'Black plays ...f5 to fight for e4 and aim for an attack on the kingside. It is ambitious but weakens the king\'s position.',
    white: ['Target the weakened e6 and king position', 'Use Bg5 and e4 breaks', 'Play for positional advantages'],
    black: ['Control e4 with pawns', 'Use the Stonewall or Leningrad structures', 'Attack on the kingside'],
    plans: ['Stonewall: ...d5, ...c6, ...Bd6', 'Leningrad: ...g6 and ...Bg7 with ...d6', 'Classical: ...e6 and ...d6'],
    structure: 'Black clamps e4 with f5/d5; the e5 square is a key outpost.',
    motifs: ['Control of e4', 'Weak e6 pawn', 'Kingside attacks'],
    mistakes: ['Weakening the king without compensation', 'Ignoring the e5 outpost', 'Allowing a strong Bg5 pin'],
  },
}

const CATEGORY_FALLBACK: Record<Category, FamilyInfo> = {
  Popular: genericInfo('a well-trodden opening with plenty of theory'),
  'Open Games': genericInfo('an Open Game (1.e4 e5) built on quick development, central tension and open lines'),
  'Semi-Open Games': genericInfo('a Semi-Open Game where Black answers 1.e4 with something other than ...e5, creating an asymmetrical fight'),
  'Closed Games': genericInfo('a Closed Game (1.d4 d5) where pawn structure and manoeuvring matter more than quick tactics'),
  'Indian Defences': genericInfo('an Indian-style defence where Black fights for the centre with pieces, often with a fianchettoed bishop'),
  'Flank Openings': genericInfo('a flank opening that influences the centre from the wings before committing the central pawns'),
  Gambits: genericInfo('a gambit: one side gives up material for time, space or initiative'),
  'Classical Openings': genericInfo('a classical opening based on direct central control and rapid development'),
  'Modern & Hypermodern': genericInfo('a hypermodern set-up that controls the centre with pieces and delays or provokes the central pawn advance'),
}

function genericInfo(what: string): FamilyInfo {
  return {
    summary: `This is ${what}. Follow the move list to see how the plans develop.`,
    white: ['Develop pieces quickly toward the centre', 'Castle and connect the rooks', 'Look for the standard pawn break for the structure'],
    black: ['Develop pieces and challenge the centre', 'Castle and keep the structure healthy', 'Prepare a pawn break to free the position'],
    plans: ['Complete development before launching an attack', 'Identify the pawn structure and play the matching plan'],
    structure: 'Depends on the line; check the pawn chain and open files after each move.',
    motifs: ['Piece development and central control', 'Typical pawn breaks for the structure'],
    mistakes: ['Moving the same piece repeatedly', 'Neglecting king safety', 'Grabbing pawns while behind in development'],
  }
}

/** Curated info when we have it, otherwise an honest generic description for the category. */
export function infoFor(family: string, category: Category): { info: FamilyInfo; curated: boolean } {
  const f = FAMILY_INFO[family]
  return f ? { info: f, curated: true } : { info: CATEGORY_FALLBACK[category], curated: false }
}
