import { Chess, type Square } from 'chess.js'

export const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'

export interface Ply {
  san: string
  uci: string
  from: string
  to: string
  promotion?: string
  /** Position after this ply. */
  fen: string
}

/** The explored line. `cursor` plies are on the board; plies beyond the cursor are the (still replayable) future of the line. */
export interface LineState {
  plies: Ply[]
  cursor: number
}

export const emptyLine = (): LineState => ({ plies: [], cursor: 0 })

export function fenAt(l: LineState, cursor = l.cursor): string {
  return cursor <= 0 ? START_FEN : l.plies[cursor - 1].fen
}

export function lastMoveAt(l: LineState, cursor = l.cursor): { from: string; to: string } | null {
  if (cursor <= 0) return null
  const p = l.plies[cursor - 1]
  return { from: p.from, to: p.to }
}

export const sansOf = (l: LineState, upto = l.plies.length) => l.plies.slice(0, upto).map((p) => p.san)

export type MoveInput = { san: string } | { from: string; to: string; promotion?: string } | { uci: string }

/** Normalises Lichess "king takes rook" castling UCI (e1h1) into e1g1 etc. */
export function normaliseUci(uci: string, fen: string): string {
  const map: Record<string, string> = { e1h1: 'e1g1', e1a1: 'e1c1', e8h8: 'e8g8', e8a8: 'e8c8' }
  const m = map[uci]
  if (!m) return uci
  const piece = new Chess(fen).get(uci.slice(0, 2) as Square)
  return piece?.type === 'k' ? m : uci
}

function toPly(chess: Chess, input: MoveInput): Ply | null {
  try {
    const before = chess.fen()
    const mv =
      'san' in input
        ? chess.move(input.san)
        : 'uci' in input
          ? (() => {
              const u = normaliseUci(input.uci, before)
              return chess.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u.slice(4, 5) || undefined })
            })()
          : chess.move({ from: input.from, to: input.to, promotion: input.promotion })
    return { san: mv.san, uci: mv.from + mv.to + (mv.promotion ?? ''), from: mv.from, to: mv.to, promotion: mv.promotion, fen: chess.fen() }
  } catch {
    return null
  }
}

/** Plays a move at the cursor. Same as the stored next ply -> just advance. Different -> branch (future replaced). Illegal -> null. */
export function tryPlay(l: LineState, input: MoveInput): LineState | null {
  const chess = new Chess(fenAt(l))
  const ply = toPly(chess, input)
  if (!ply) return null
  const next = l.plies[l.cursor]
  if (next && next.uci === ply.uci) return { plies: l.plies, cursor: l.cursor + 1 }
  return { plies: [...l.plies.slice(0, l.cursor), ply], cursor: l.cursor + 1 }
}

export function goTo(l: LineState, cursor: number): LineState {
  return { ...l, cursor: Math.max(0, Math.min(l.plies.length, cursor)) }
}

/** Builds a line from SAN moves; null if any move is illegal. Cursor at the end. */
export function lineFromSans(sans: string[], atEnd = true): LineState | null {
  let l = emptyLine()
  for (const san of sans) {
    const n = tryPlay(l, { san })
    if (!n) return null
    l = n
  }
  return atEnd ? l : goTo(l, 0)
}

export function moveLabel(index: number, san: string): string {
  const n = Math.floor(index / 2) + 1
  return index % 2 === 0 ? `${n}. ${san}` : `${n}… ${san}`
}
