import { Chess, type Square, type PieceSymbol, type Color } from 'chess.js'

const NAME: Record<PieceSymbol, string> = { p: 'pawn', n: 'knight', b: 'bishop', r: 'rook', q: 'queen', k: 'king' }
const VALUE: Record<PieceSymbol, number> = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 }
const colorName = (c: Color) => (c === 'w' ? 'White' : 'Black')

const HOME: Record<string, string[]> = {
  wn: ['b1', 'g1'], wb: ['c1', 'f1'], bn: ['b8', 'g8'], bb: ['c8', 'f8'],
}

/**
 * Position-specific observations computed from the actual board (chess.js). Every statement is a
 * direct fact about the position or the last move — nothing is inferred from opening names.
 */
export function positionInsights(fen: string, lastSan: string | null): string[] {
  const chess = new Chess(fen)
  const out: string[] = []
  const board = chess.board().flat()
  const at = (sq: string) => chess.get(sq as Square)

  if (lastSan) {
    const mover: Color = chess.turn() === 'w' ? 'b' : 'w'
    if (/^O-O-O/.test(lastSan)) out.push(`${colorName(mover)} castles queenside, tucking the king away and bringing the rook toward the centre.`)
    else if (/^O-O/.test(lastSan)) out.push(`${colorName(mover)} castles kingside, getting the king safe and connecting the rooks.`)
    else if (lastSan.includes('x')) out.push(`${lastSan} is a capture, which changes the pawn structure or piece balance.`)
    if (lastSan.endsWith('#')) out.push('That is checkmate.')
    else if (lastSan.endsWith('+')) out.push(`${lastSan} gives check, so ${colorName(chess.turn())} must respond to the king threat first.`)
  }

  // Centre
  const centre = (c: Color) => ['d4', 'e4', 'd5', 'e5'].filter((s) => at(s)?.type === 'p' && at(s)?.color === c)
  const wc = centre('w')
  const bc = centre('b')
  if (wc.length === 2 && bc.length === 0) out.push(`White holds both central pawns (${wc.join(' and ')}) while Black has none there, so Black needs a plan to challenge the centre.`)
  else if (bc.length === 2 && wc.length === 0) out.push(`Black holds both central pawns (${bc.join(' and ')}) and White has none in the centre.`)
  else if (wc.length === 0 && bc.length === 0 && chess.moveNumber() > 2) out.push('Neither side has a pawn on d4, e4, d5 or e5 yet; the centre is controlled by pieces.')

  // Development (minor pieces off their home squares)
  const dev = (c: Color) => {
    let n = 0
    for (const t of ['n', 'b'] as const) for (const sq of HOME[c + t]) { const p = at(sq); if (!(p && p.type === t && p.color === c)) n++ }
    return n
  }
  const dw = dev('w')
  const db = dev('b')
  if (chess.moveNumber() <= 12) out.push(`Development: White has moved ${dw} of 4 minor pieces off the back rank; Black ${db} of 4.`)

  // Castling status
  const kingSq = (c: Color) => board.find((p) => p && p.type === 'k' && p.color === c)?.square
  const rights = chess.fen().split(' ')[2]
  for (const c of ['w', 'b'] as const) {
    const k = kingSq(c)
    const castled = c === 'w' ? k === 'g1' || k === 'c1' : k === 'g8' || k === 'c8'
    const r = c === 'w' ? rights.replace(/[a-z-]/g, '') : rights.replace(/[A-Z-]/g, '')
    if (castled && r === '') out.push(`${colorName(c)}'s king has castled to ${k}.`)
    else if (!castled && r === '' && chess.moveNumber() > 4) out.push(`${colorName(c)} can no longer castle and the king is on ${k}.`)
  }

  // Half-open central files
  for (const f of ['d', 'e']) {
    const pawns = (c: Color) => board.some((p) => p && p.type === 'p' && p.color === c && p.square[0] === f)
    const w = pawns('w')
    const b = pawns('b')
    if (!w && !b) out.push(`The ${f}-file is fully open, so rooks can use it.`)
    else if (!w) out.push(`The ${f}-file is half-open for White (no white pawn on it).`)
    else if (!b) out.push(`The ${f}-file is half-open for Black (no black pawn on it).`)
  }

  // Hanging pieces (attacked, not defended)
  for (const p of board) {
    if (!p || p.type === 'k' || p.type === 'p') continue
    const enemy: Color = p.color === 'w' ? 'b' : 'w'
    const atk = chess.attackers(p.square, enemy)
    if (atk.length === 0) continue
    const def = chess.attackers(p.square, p.color)
    const cheapest = Math.min(...atk.map((s) => VALUE[at(s)!.type]))
    if (def.length === 0) out.push(`${colorName(p.color)}'s ${NAME[p.type]} on ${p.square} is attacked and has no defender.`)
    else if (cheapest < VALUE[p.type]) out.push(`${colorName(p.color)}'s ${NAME[p.type]} on ${p.square} is attacked by a lower-value piece.`)
  }

  if (chess.isCheckmate()) out.push('The game is over: checkmate.')
  else if (chess.isDraw()) out.push('The position is a draw by rule.')
  return out.slice(0, 7)
}
