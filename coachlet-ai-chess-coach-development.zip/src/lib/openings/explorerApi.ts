/**
 * Lichess Opening Explorer client (https://explorer.lichess.org).
 *
 * NOTE: as of this implementation the explorer answers 401 without a personal API token
 * (create a free one, no scopes needed, at https://lichess.org/account/oauth/token).
 * The token is stored only in the user's browser and sent as `Authorization: Bearer`.
 *
 * Etiquette implemented here: one request at a time, minimum gap between requests,
 * 429 => block ALL requests for >= 60 s (exponential, max 10 min), aborted requests are
 * never sent, identical positions are served from IndexedDB/memory cache.
 */
import { epdOf } from './catalogue'

export type ExplorerSource = 'masters' | 'lichess'

export interface ExplorerMove {
  uci: string
  san: string
  white: number
  draws: number
  black: number
  total: number
  averageRating?: number
}

export interface ExplorerPosition {
  source: ExplorerSource
  fen: string
  white: number
  draws: number
  black: number
  total: number
  moves: ExplorerMove[]
  opening: { eco: string; name: string } | null
}

export type ExplorerResult =
  | { status: 'ok'; data: ExplorerPosition; cached: boolean; fetchedAt: number; stale: boolean }
  | { status: 'no-token' }
  | { status: 'unauthorized' }
  | { status: 'rate-limited'; retryAt: number }
  | { status: 'offline'; message: string }
  | { status: 'error'; message: string }

const isNum = (n: unknown): n is number => typeof n === 'number' && Number.isFinite(n)

/** Strict-ish parse of the explorer JSON. Returns null when the shape is not what the API documents. */
export function parseExplorer(json: unknown, source: ExplorerSource, fen: string): ExplorerPosition | null {
  if (!json || typeof json !== 'object') return null
  const j = json as Record<string, unknown>
  if (!isNum(j.white) || !isNum(j.draws) || !isNum(j.black)) return null
  const moves: ExplorerMove[] = []
  for (const m of Array.isArray(j.moves) ? (j.moves as Array<Record<string, unknown>>) : []) {
    if (typeof m.uci !== 'string' || typeof m.san !== 'string' || !isNum(m.white) || !isNum(m.draws) || !isNum(m.black)) continue
    moves.push({
      uci: m.uci,
      san: m.san,
      white: m.white,
      draws: m.draws,
      black: m.black,
      total: m.white + m.draws + m.black,
      averageRating: isNum(m.averageRating) ? m.averageRating : undefined,
    })
  }
  const op = j.opening as { eco?: unknown; name?: unknown } | null | undefined
  return {
    source,
    fen,
    white: j.white,
    draws: j.draws,
    black: j.black,
    total: j.white + j.draws + j.black,
    moves,
    opening: op && typeof op.eco === 'string' && typeof op.name === 'string' ? { eco: op.eco, name: op.name } : null,
  }
}

/** Share of the position's games in which this move was chosen (0..100). */
export function moveShare(m: ExplorerMove, pos: Pick<ExplorerPosition, 'total'>): number {
  return pos.total > 0 ? (m.total / pos.total) * 100 : 0
}

/** White / draw / black percentages for a move (sum to 100 unless there are no games). */
export function resultSplit(m: Pick<ExplorerMove, 'white' | 'draws' | 'black' | 'total'>): { white: number; draws: number; black: number } {
  if (m.total <= 0) return { white: 0, draws: 0, black: 0 }
  return { white: (m.white / m.total) * 100, draws: (m.draws / m.total) * 100, black: (m.black / m.total) * 100 }
}

/** Moves ordered by popularity (most games first); stable for equal counts. */
export function rankMoves(pos: ExplorerPosition): ExplorerMove[] {
  return pos.moves.map((m, i) => [m, i] as const).sort((a, b) => b[0].total - a[0].total || a[1] - b[1]).map((x) => x[0])
}

export const positionKey = (source: ExplorerSource, fen: string) => `${source}|${epdOf(fen)}`

export function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M`
  if (n >= 10_000) return `${Math.round(n / 1000)}k`
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`
  return String(n)
}

// ------------------------------------------------------------------ cache
interface CacheRow {
  key: string
  data: ExplorerPosition
  fetchedAt: number
}
const TTL: Record<ExplorerSource, number> = { masters: 30 * 86_400_000, lichess: 86_400_000 }
const mem = new Map<string, CacheRow>()
let dbp: Promise<IDBDatabase | null> | null = null

function openDb(): Promise<IDBDatabase | null> {
  if (!dbp) {
    dbp = new Promise((resolve) => {
      if (typeof indexedDB === 'undefined') return resolve(null)
      try {
        const req = indexedDB.open('coachlet-explorer-cache', 1)
        req.onupgradeneeded = () => req.result.createObjectStore('positions', { keyPath: 'key' })
        req.onsuccess = () => resolve(req.result)
        req.onerror = () => resolve(null)
      } catch {
        resolve(null)
      }
    })
  }
  return dbp
}

async function cacheGet(key: string): Promise<CacheRow | null> {
  const m = mem.get(key)
  if (m) return m
  const db = await openDb()
  if (!db) return null
  return new Promise((resolve) => {
    try {
      const r = db.transaction('positions').objectStore('positions').get(key)
      r.onsuccess = () => {
        const row = (r.result as CacheRow | undefined) ?? null
        if (row) mem.set(key, row)
        resolve(row)
      }
      r.onerror = () => resolve(null)
    } catch {
      resolve(null)
    }
  })
}

async function cachePut(row: CacheRow) {
  mem.set(row.key, row)
  const db = await openDb()
  if (!db) return
  try {
    db.transaction('positions', 'readwrite').objectStore('positions').put(row)
  } catch {
    /* quota or closed — memory cache still works */
  }
}

export async function clearExplorerCache() {
  mem.clear()
  const db = await openDb()
  if (!db) return
  try {
    db.transaction('positions', 'readwrite').objectStore('positions').clear()
  } catch {
    /* ignore */
  }
}

// ------------------------------------------------------------------ queue / rate limit
let chain: Promise<unknown> = Promise.resolve()
let lastRequestAt = 0
let blockedUntil = 0
let backoffMs = 60_000
export const MIN_GAP_MS = 300

export const getRateLimitedUntil = () => blockedUntil

/** Test hook. */
export function _resetExplorerState() {
  mem.clear()
  chain = Promise.resolve()
  lastRequestAt = 0
  blockedUntil = 0
  backoffMs = 60_000
}

export interface GetExplorerOptions {
  token?: string
  signal?: AbortSignal
  forceRefresh?: boolean
  fetchImpl?: typeof fetch
  now?: () => number
}

export function explorerUrl(source: ExplorerSource, fen: string): string {
  const q = new URLSearchParams({ fen, moves: '12', topGames: '0', recentGames: '0' })
  if (source === 'lichess') q.set('variant', 'standard')
  return `https://explorer.lichess.org/${source}?${q.toString()}`
}

export async function getExplorer(source: ExplorerSource, fen: string, opts: GetExplorerOptions = {}): Promise<ExplorerResult> {
  const now = opts.now ?? Date.now
  const key = positionKey(source, fen)
  const cached = await cacheGet(key)
  const fresh = cached && now() - cached.fetchedAt < TTL[source]
  if (cached && fresh && !opts.forceRefresh) return { status: 'ok', data: cached.data, cached: true, fetchedAt: cached.fetchedAt, stale: false }

  const fallback = (): ExplorerResult | null =>
    cached ? { status: 'ok', data: cached.data, cached: true, fetchedAt: cached.fetchedAt, stale: true } : null

  if (!opts.token?.trim()) return fallback() ?? { status: 'no-token' }
  if (now() < blockedUntil) return fallback() ?? { status: 'rate-limited', retryAt: blockedUntil }
  if (typeof navigator !== 'undefined' && navigator.onLine === false) return fallback() ?? { status: 'offline', message: 'You are offline.' }

  const run = async (): Promise<ExplorerResult> => {
    if (opts.signal?.aborted) return { status: 'error', message: 'cancelled' }
    if (now() < blockedUntil) return fallback() ?? { status: 'rate-limited', retryAt: blockedUntil }
    const wait = lastRequestAt + MIN_GAP_MS - now()
    if (wait > 0) await new Promise((r) => setTimeout(r, wait))
    if (opts.signal?.aborted) return { status: 'error', message: 'cancelled' }
    lastRequestAt = now()
    try {
      const res = await (opts.fetchImpl ?? fetch)(explorerUrl(source, fen), {
        signal: opts.signal,
        headers: { Authorization: `Bearer ${opts.token!.trim()}`, Accept: 'application/json' },
      })
      if (res.status === 401 || res.status === 403) return { status: 'unauthorized' }
      if (res.status === 429) {
        blockedUntil = now() + backoffMs
        backoffMs = Math.min(backoffMs * 2, 600_000)
        return fallback() ?? { status: 'rate-limited', retryAt: blockedUntil }
      }
      if (!res.ok) return fallback() ?? { status: 'error', message: `Lichess explorer returned HTTP ${res.status}.` }
      backoffMs = 60_000
      const data = parseExplorer(await res.json(), source, fen)
      if (!data) return fallback() ?? { status: 'error', message: 'Unexpected response format from the explorer.' }
      const row = { key, data, fetchedAt: now() }
      void cachePut(row)
      return { status: 'ok', data, cached: false, fetchedAt: row.fetchedAt, stale: false }
    } catch (e) {
      if (opts.signal?.aborted || (e instanceof DOMException && e.name === 'AbortError')) return { status: 'error', message: 'cancelled' }
      return fallback() ?? { status: 'offline', message: 'Could not reach explorer.lichess.org (offline or blocked).' }
    }
  }
  const p = chain.then(run, run)
  chain = p.catch(() => undefined)
  return p
}
