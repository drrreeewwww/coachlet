export type StepResult = 'continue' | 'stop'

export interface AutoplayOptions {
  /** Performs one ply. Must check `isActive()` before applying anything (stale-callback guard). */
  step: (isActive: () => boolean) => Promise<StepResult>
  getIntervalMs: () => number
  onRunning: (running: boolean) => void
  sleep?: (ms: number) => Promise<void>
}

/**
 * One-ply-at-a-time autoplay with a single logical timer.
 * Each start() bumps an epoch; pause()/stop()/restart invalidates all in-flight work,
 * so a late engine/network result can never advance an obsolete line.
 * The first ply is played immediately; later plies every `intervalMs` (measured start-to-start).
 */
export class Autoplay {
  private epoch = 0
  private running = false
  private pending: { cancel: () => void } | null = null

  constructor(private opts: AutoplayOptions) {}

  get isRunning() {
    return this.running
  }

  private sleep(ms: number): Promise<void> {
    if (this.opts.sleep) return this.opts.sleep(ms)
    return new Promise((resolve) => {
      const t = setTimeout(resolve, ms)
      this.pending = { cancel: () => clearTimeout(t) }
    })
  }

  start() {
    if (this.running) return
    this.running = true
    const e = ++this.epoch
    this.opts.onRunning(true)
    void this.loop(e)
  }

  stop() {
    this.epoch++
    this.pending?.cancel()
    this.pending = null
    if (this.running) {
      this.running = false
      this.opts.onRunning(false)
    }
  }

  private async loop(e: number) {
    const active = () => this.running && this.epoch === e
    while (active()) {
      const t0 = Date.now()
      let result: StepResult
      try {
        result = await this.opts.step(active)
      } catch {
        result = 'stop'
      }
      if (!active()) return
      if (result === 'stop') {
        this.stop()
        return
      }
      // Interval is read AFTER the step so a speed change applies to the very next gap.
      await this.sleep(Math.max(0, this.opts.getIntervalMs() - (Date.now() - t0)))
    }
  }
}
