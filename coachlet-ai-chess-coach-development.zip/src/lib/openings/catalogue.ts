/**
 * Opening catalogue built from lichess-org/chess-openings (CC0 / public domain).
 * Data: ./data/openings.json  (regenerate with tools/build-openings.mjs).
 * Row format: [eco, name, "san san san", epd].
 */
export type Category =
  | 'Popular'
  | 'Open Games'
  | 'Semi-Open Games'
  | 'Closed Games'
  | 'Indian Defences'
  | 'Flank Openings'
  | 'Gambits'
  | 'Classical Openings'
  | 'Modern & Hypermodern'

export const CATEGORIES: Category[] = [
  'Popular',
  'Open Games',
  'Semi-Open Games',
  'Closed Games',
  'Indian Defences',
  'Flank Openings',
  'Gambits',
  'Classical Openings',
  'Modern & Hypermodern',
]

export interface OpeningEntry {
  eco: string
  name: string
  family: string
  variation: string
  sans: string[]
  epd: string
}

export interface FamilyGroup {
  family: string
  /** Shortest line of the family = its "main" entry. */
  main: OpeningEntry
  entries: OpeningEntry[]
}

export interface Catalogue {
  entries: OpeningEntry[]
  byEpd: Map<string, OpeningEntry>
  families: Map<string, FamilyGroup>
}

export const POPULAR_FAMILIES = [
  'Italian Game',
  'Ruy Lopez',
  'Sicilian Defense',
  'French Defense',
  'Caro-Kann Defense',
  "Queen's Gambit Declined",
  "Queen's Gambit Accepted",
  'Slav Defense',
  "King's Indian Defense",
  'Nimzo-Indian Defense',
  'English Opening',
  'London System',
  'Scotch Game',
  'Scandinavian Defense',
  "Petrov's Defense",
  "King's Gambit Accepted",
  'Catalan Opening',
  'Grünfeld Defense',
  'Pirc Defense',
  'Dutch Defense',
]

const CLASSICAL = new Set([
  'Italian Game', 'Ruy Lopez', 'Scotch Game', 'Four Knights Game', 'Vienna Game', "King's Gambit Accepted",
  "King's Gambit Declined", "Queen's Gambit Declined", "Queen's Gambit Accepted", "Petrov's Defense",
  'Philidor Defense', "Bishop's Opening", 'Center Game', 'Ponziani Opening',
])
const MODERN = new Set([
  'Pirc Defense', 'Modern Defense', 'Alekhine Defense', 'Réti Opening', 'Zukertort Opening', 'Grünfeld Defense',
  "King's Indian Defense", 'Nimzo-Indian Defense', "Queen's Indian Defense", 'English Opening', 'Nimzowitsch Defense',
  'Nimzo-Larsen Attack', 'Catalan Opening', 'Bogo-Indian Defense', 'Benoni Defense', 'Hungarian Opening',
  "King's Indian Attack", 'Polish Opening', 'Grob Opening', 'Neo-Grünfeld Defense', 'Old Indian Defense',
])

export function primaryCategory(eco: string): Exclude<Category, 'Popular' | 'Gambits' | 'Classical Openings' | 'Modern & Hypermodern'> | 'Modern & Hypermodern' {
  const L = eco[0]
  const n = Number(eco.slice(1))
  if (L === 'A') return n <= 39 ? 'Flank Openings' : n <= 44 ? 'Modern & Hypermodern' : n <= 79 ? 'Indian Defences' : 'Closed Games'
  if (L === 'B') return 'Semi-Open Games'
  if (L === 'C') return n <= 19 ? 'Semi-Open Games' : 'Open Games'
  if (L === 'D') return n <= 69 ? 'Closed Games' : 'Indian Defences'
  return 'Indian Defences'
}

export function categoriesOf(e: OpeningEntry): Category[] {
  const cats = new Set<Category>([primaryCategory(e.eco)])
  if (/gambit/i.test(e.name)) cats.add('Gambits')
  if (CLASSICAL.has(e.family)) cats.add('Classical Openings')
  if (MODERN.has(e.family)) cats.add('Modern & Hypermodern')
  if (POPULAR_FAMILIES.includes(e.family)) cats.add('Popular')
  return [...cats]
}

export function epdOf(fen: string): string {
  return fen.split(' ').slice(0, 4).join(' ')
}

export function buildCatalogue(rows: Array<[string, string, string, string]>): Catalogue {
  const entries: OpeningEntry[] = rows.map(([eco, name, moves, epd]) => {
    const i = name.indexOf(':')
    return {
      eco,
      name,
      family: i < 0 ? name : name.slice(0, i),
      variation: i < 0 ? '' : name.slice(i + 1).trim(),
      sans: moves.split(' ').filter(Boolean),
      epd,
    }
  })
  const byEpd = new Map<string, OpeningEntry>()
  const families = new Map<string, FamilyGroup>()
  for (const e of entries) {
    if (!byEpd.has(e.epd)) byEpd.set(e.epd, e)
    const g = families.get(e.family)
    if (!g) families.set(e.family, { family: e.family, main: e, entries: [e] })
    else {
      g.entries.push(e)
      if (e.sans.length < g.main.sans.length) g.main = e
    }
  }
  return { entries, byEpd, families }
}

let memo: Promise<Catalogue> | null = null
export function loadCatalogue(): Promise<Catalogue> {
  if (!memo) {
    memo = import('./data/openings.json').then((m) => buildCatalogue(m.default as unknown as Array<[string, string, string, string]>))
  }
  return memo
}

const norm = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()

export function searchOpenings(cat: Catalogue, query: string, limit = 60): OpeningEntry[] {
  const q = norm(query.trim())
  if (!q) return []
  const eco = /^[a-e]\d{0,2}$/i.test(q)
  const tokens = q.split(/\s+/)
  const scored: Array<[number, OpeningEntry]> = []
  for (const e of cat.entries) {
    const name = norm(e.name)
    let score = -1
    if (eco && e.eco.toLowerCase().startsWith(q)) score = e.eco.toLowerCase() === q ? 0 : 1
    else if (tokens.every((t) => name.includes(t))) score = name.startsWith(q) ? 2 : 3
    if (score >= 0) scored.push([score * 100 + e.sans.length, e])
  }
  scored.sort((a, b) => a[0] - b[0])
  return scored.slice(0, limit).map((s) => s[1])
}

/** Families (one row each) belonging to a category, most variations first. 'Gambits' lists distinct gambit lines. */
export function browseCategory(cat: Catalogue, category: Category): Array<{ label: string; main: OpeningEntry; count: number }> {
  if (category === 'Popular') {
    return POPULAR_FAMILIES.flatMap((f) => {
      const g = cat.families.get(f)
      return g ? [{ label: f, main: g.main, count: g.entries.length }] : []
    })
  }
  if (category === 'Gambits') {
    const best = new Map<string, OpeningEntry>()
    const counts = new Map<string, number>()
    for (const e of cat.entries) {
      if (!/gambit/i.test(e.name)) continue
      const parts = e.name.split(':').map((p) => p.trim())
      const idx = parts.findIndex((p) => /gambit/i.test(p))
      const key = parts.slice(0, idx + 1).join(': ')
      counts.set(key, (counts.get(key) ?? 0) + 1)
      const cur = best.get(key)
      if (!cur || e.sans.length < cur.sans.length) best.set(key, e)
    }
    return [...best.entries()].map(([label, main]) => ({ label, main, count: counts.get(label) ?? 1 })).sort((a, b) => b.count - a.count || a.label.localeCompare(b.label)).slice(0, 80)
  }
  const out: Array<{ label: string; main: OpeningEntry; count: number }> = []
  for (const g of cat.families.values()) {
    const n = g.entries.filter((e) => categoriesOf(e).includes(category)).length
    if (n > 0) out.push({ label: g.family, main: g.main, count: n })
  }
  return out.sort((a, b) => b.count - a.count || a.label.localeCompare(b.label)).slice(0, 80)
}

/** Deepest named position along a line: epds[i] is the position after i plies. */
export function nameForLine(cat: Catalogue, epds: string[], uptoPly: number): { entry: OpeningEntry; ply: number } | null {
  for (let i = Math.min(uptoPly, epds.length - 1); i >= 0; i--) {
    const e = cat.byEpd.get(epds[i])
    if (e) return { entry: e, ply: i }
  }
  return null
}
