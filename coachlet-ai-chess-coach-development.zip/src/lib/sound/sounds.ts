export type Sfx =
  | 'move'
  | 'capture'
  | 'check'
  | 'castle'
  | 'lowtime'
  | 'start'
  | 'end'

const TONES: Record<Sfx, [number, number, number][]> = {
  move: [[340, 0, 0.055]],
  capture: [
    [240, 0, 0.075],
    [165, 0.035, 0.075],
  ],
  castle: [
    [340, 0, 0.05],
    [300, 0.065, 0.055],
  ],
  check: [
    [620, 0, 0.09],
    [790, 0.09, 0.12],
  ],
  lowtime: [
    [880, 0, 0.07],
    [880, 0.11, 0.07],
  ],
  start: [
    [440, 0, 0.08],
    [554, 0.09, 0.12],
  ],
  end: [
    [392, 0, 0.18],
    [494, 0.14, 0.18],
    [587, 0.28, 0.32],
  ],
}

let ctx: AudioContext | null = null

export function playSound(kind: Sfx, volume: number) {
  if (typeof window === 'undefined' || volume <= 0) return
  try {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext
    if (!Ctor) return
    const c = (ctx ??= new Ctor())
    if (c.state === 'suspended') void c.resume()
    for (const [f, t0, d] of TONES[kind]) {
      const o = c.createOscillator()
      const g = c.createGain()
      const t = c.currentTime + t0
      o.type = kind === 'move' || kind === 'castle' ? 'triangle' : 'sine'
      o.frequency.value = f
      g.gain.setValueAtTime(volume * 0.28, t)
      g.gain.exponentialRampToValueAtTime(0.0001, t + d)
      o.connect(g)
      g.connect(c.destination)
      o.start(t)
      o.stop(t + d + 0.02)
    }
  } catch {
    /* audio unavailable */
  }
}
