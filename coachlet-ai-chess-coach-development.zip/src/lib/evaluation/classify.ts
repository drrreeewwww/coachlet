// Pure evaluation maths & Chess.com-style 8-tier move classification:
// no browser or worker dependencies so it can be unit-tested directly in Node.js.

export interface Score {
  cp?: number
  mate?: number
} // Always from White's point of view

export type MoveClass =
  | 'brilliant'
  | 'great'
  | 'best'
  | 'excellent'
  | 'good'
  | 'inaccuracy'
  | 'mistake'
  | 'blunder'

export interface ClassifyThresholds {
  bestMaxWinLoss: number // default 0.5%
  excellentMaxWinLoss: number // default 2%
  goodMaxWinLoss: number // default 5%
  inaccuracyMaxWinLoss: number // default 10%
  mistakeMaxWinLoss: number // default 20%
  greatMinSecondBestGapWinPct: number // default 10% winPct gap to 2nd-best candidate
  brilliantMaxWinLoss: number // default 1.5%
}

export const DEFAULT_THRESHOLDS: ClassifyThresholds = {
  bestMaxWinLoss: 0.5,
  excellentMaxWinLoss: 2,
  goodMaxWinLoss: 5,
  inaccuracyMaxWinLoss: 10,
  mistakeMaxWinLoss: 20,
  greatMinSecondBestGapWinPct: 10,
  brilliantMaxWinLoss: 1.5,
}

export interface ClassifyContext {
  /** White-POV centipawns of Stockfish's #2 candidate move before the move was played */
  secondBestBefore?: number
  /** Whether the move sacrifices material (leaves a higher-value piece en prise or gives up material for compensation) */
  isSacrifice?: boolean
  /** Mate score before the move (White-POV) */
  mateBefore?: number
  /** Mate score after the move (White-POV) */
  mateAfter?: number
  /** Whether the position was already completely won (> +600cp for mover) before the sacrifice */
  alreadyCrushing?: boolean
  /** Optional custom thresholds */
  thresholds?: Partial<ClassifyThresholds>
}

const clamp = (n: number) => Math.max(-1000, Math.min(1000, n))

export const toCp = (s: Score): number =>
  s.mate !== undefined
    ? (s.mate > 0 ? 1 : -1) * (10000 - Math.abs(s.mate) * 10)
    : (s.cp ?? 0)

/** Win probability (0-100) for the side that is ahead in `cp`, using the Lichess/Chess.com logistic curve. */
export const winPct = (cp: number): number =>
  50 + 50 * (2 / (1 + Math.exp(-0.00368208 * clamp(cp))) - 1)

export const formatScore = (s: Score): string =>
  s.mate !== undefined
    ? `${s.mate > 0 ? '+' : '-'}M${Math.abs(s.mate)}`
    : Math.abs(s.cp ?? 0) >= 9000
      ? (s.cp ?? 0) > 0
        ? '1-0'
        : '0-1'
      : `${(s.cp ?? 0) >= 0 ? '+' : ''}${((s.cp ?? 0) / 100).toFixed(1)}`

export const CLASS_META: Record<
  MoveClass,
  { label: string; icon: string; color: string; bgTint: string; note: string }
> = {
  brilliant: {
    label: 'Brilliant',
    icon: '!!',
    color: '#1baca6',
    bgTint: 'rgba(27, 172, 166, 0.16)',
    note: 'A strong piece sacrifice or tactical resource that finds the best continuation!',
  },
  great: {
    label: 'Great',
    icon: '!',
    color: '#5c8bb0',
    bgTint: 'rgba(92, 139, 176, 0.16)',
    note: 'A critical find — the only move that seizes or preserves the advantage.',
  },
  best: {
    label: 'Best',
    icon: '★',
    color: '#81b64c',
    bgTint: 'rgba(129, 182, 76, 0.16)',
    note: 'The engine’s top choice.',
  },
  excellent: {
    label: 'Excellent',
    icon: '✓',
    color: '#96bc4b',
    bgTint: 'rgba(150, 188, 75, 0.15)',
    note: 'Almost as strong as the best move.',
  },
  good: {
    label: 'Good',
    icon: '✓',
    color: '#97af8b',
    bgTint: 'rgba(151, 175, 139, 0.15)',
    note: 'A fine move that gives up very little.',
  },
  inaccuracy: {
    label: 'Inaccuracy',
    icon: '?!',
    color: '#f7c631',
    bgTint: 'rgba(247, 198, 49, 0.16)',
    note: 'A better move was available.',
  },
  mistake: {
    label: 'Mistake',
    icon: '?',
    color: '#e58f2a',
    bgTint: 'rgba(229, 143, 42, 0.16)',
    note: 'This gave away a real advantage.',
  },
  blunder: {
    label: 'Blunder',
    icon: '??',
    color: '#ca3431',
    bgTint: 'rgba(202, 52, 49, 0.16)',
    note: 'This changed the result of the position or missed a critical tactic.',
  },
}

/**
 * Compares evaluation before and after a move (both White-POV centipawns) from the mover's side.
 * Supports all 8 classifications (Brilliant, Great, Best, Excellent, Good, Inaccuracy, Mistake, Blunder),
 * accounting for side to move, forced mates, position transitions, 2nd-best candidate gap, and sacrifices.
 */
export function classify(
  before: number,
  after: number,
  mover: 'w' | 'b',
  playedBest: boolean,
  ctx?: ClassifyContext
): { cls: MoveClass; cpLoss: number; winLoss: number; transition: string } {
  const T = { ...DEFAULT_THRESHOLDS, ...(ctx?.thresholds ?? {}) }
  const sign = mover === 'w' ? 1 : -1
  const moverBefore = sign * before
  const moverAfter = sign * after
  const winBefore = winPct(moverBefore)
  const winAfter = winPct(moverAfter)
  const winLoss = Math.max(0, winBefore - winAfter)
  const cpLoss = Math.max(0, Math.round(clamp(moverBefore) - clamp(moverAfter)))

  // Detect position transition from mover's perspective
  const stateOf = (cp: number) =>
    cp >= 150 ? 'winning' : cp <= -150 ? 'losing' : 'balanced'
  const transition = `${stateOf(moverBefore)} → ${stateOf(moverAfter)}`

  // Check forced mate transitions when mate context is provided
  const mateBeforeMover =
    ctx?.mateBefore !== undefined ? sign * ctx.mateBefore : undefined
  const mateAfterMover =
    ctx?.mateAfter !== undefined ? sign * ctx.mateAfter : undefined

  // Allowing a forced mate against oneself when not previously being mated is a Blunder (or Mistake if already lost)
  if (
    mateAfterMover !== undefined &&
    mateAfterMover < 0 &&
    (mateBeforeMover === undefined || mateBeforeMover >= 0)
  ) {
    return {
      cls: moverBefore <= -500 ? 'mistake' : 'blunder',
      cpLoss: Math.max(cpLoss, 300),
      winLoss: Math.max(winLoss, 25),
      transition: `${stateOf(moverBefore)} → forced mate against`,
    }
  }

  // Missing a forced mate for the mover and dropping to non-winning is a Mistake/Blunder
  if (
    mateBeforeMover !== undefined &&
    mateBeforeMover > 0 &&
    (mateAfterMover === undefined || mateAfterMover <= 0) &&
    !playedBest
  ) {
    const stillWinning = moverAfter >= 300
    return {
      cls: stillWinning ? 'inaccuracy' : moverAfter >= 100 ? 'mistake' : 'blunder',
      cpLoss: Math.max(cpLoss, stillWinning ? 60 : 200),
      winLoss: Math.max(winLoss, stillWinning ? 6 : 22),
      transition: 'missed forced mate',
    }
  }

  // Brilliant move detection:
  if (
    ctx?.isSacrifice &&
    (playedBest || winLoss <= T.brilliantMaxWinLoss) &&
    moverAfter >= -50 &&
    !ctx.alreadyCrushing &&
    moverBefore < 600
  ) {
    return { cls: 'brilliant', cpLoss, winLoss, transition }
  }

  // Great move detection:
  if (playedBest || winLoss <= T.bestMaxWinLoss) {
    if (ctx?.secondBestBefore !== undefined) {
      const moverSecondBest = sign * ctx.secondBestBefore
      const secondBestGap = winBefore - winPct(moverSecondBest)
      if (secondBestGap >= T.greatMinSecondBestGapWinPct && moverAfter >= -80) {
        return { cls: 'great', cpLoss, winLoss, transition }
      }
    }
    if (
      mateAfterMover !== undefined &&
      mateAfterMover > 0 &&
      Math.abs(mateAfterMover) <= 5 &&
      (mateBeforeMover === undefined || Math.abs(mateBeforeMover) > Math.abs(mateAfterMover)) &&
      moverBefore < 700
    ) {
      return { cls: 'great', cpLoss, winLoss, transition }
    }
  }

  // Standard centipawn / win-probability classification
  const cls: MoveClass =
    playedBest || winLoss < T.bestMaxWinLoss
      ? 'best'
      : winLoss <= T.excellentMaxWinLoss
        ? 'excellent'
        : winLoss <= T.goodMaxWinLoss
          ? 'good'
          : winLoss <= T.inaccuracyMaxWinLoss
            ? 'inaccuracy'
            : winLoss <= T.mistakeMaxWinLoss
              ? 'mistake'
              : 'blunder'

  return { cls, cpLoss, winLoss, transition }
}

/** Per-move accuracy (0-100) from win-probability lost, using the Lichess/Chess.com exponential formula. */
export const accuracyOf = (winLoss: number): number =>
  Math.max(0, Math.min(100, 103.1668 * Math.exp(-0.04354 * winLoss) - 3.1669))
