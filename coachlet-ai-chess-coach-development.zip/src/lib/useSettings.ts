import { useCallback, useEffect, useState } from 'react'
import { DEFAULTS, type Settings } from './settings'

const KEY = 'chess-coach:settings:v2'
const SYNC_EVENT = 'chess-coach:settings-sync'

/** Drops values from older versions (e.g. removed cloud TTS providers). */
function normalise(s: Settings): Settings {
  const out = { ...s }
  if (out.voiceProvider !== 'kokoro' && out.voiceProvider !== 'browser-neural') out.voiceProvider = DEFAULTS.voiceProvider
  if (typeof out.kokoroVoice !== 'string') out.kokoroVoice = 'coach'
  return out
}

export function useSettings(): [
  Settings,
  (patch: Partial<Settings>) => void,
  () => void,
] {
  const [s, setS] = useState<Settings>(() => {
    if (typeof window === 'undefined') return DEFAULTS
    try {
      const raw = localStorage.getItem(KEY) ?? localStorage.getItem('chess-coach:settings')
      if (raw) return normalise({ ...DEFAULTS, ...JSON.parse(raw) })
    } catch {
      /* use defaults */
    }
    return DEFAULTS
  })

  useEffect(() => {
    const onSync = (e: Event) => {
      const detail = (e as CustomEvent<Settings>).detail
      if (detail) setS(detail)
    }
    window.addEventListener(SYNC_EVENT, onSync)
    return () => window.removeEventListener(SYNC_EVENT, onSync)
  }, [])

  const save = (n: Settings) => {
    try {
      localStorage.setItem(KEY, JSON.stringify(n))
      window.dispatchEvent(new CustomEvent(SYNC_EVENT, { detail: n }))
    } catch {
      /* storage unavailable */
    }
  }

  const update = useCallback((p: Partial<Settings>) => {
    setS((prev) => {
      const n = { ...prev, ...p }
      save(n)
      return n
    })
  }, [])

  const reset = useCallback(() => {
    setS(DEFAULTS)
    save(DEFAULTS)
  }, [])

  return [s, update, reset]
}
