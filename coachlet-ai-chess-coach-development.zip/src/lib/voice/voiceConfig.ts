import type { CoachId, VoiceProviderId } from '@/types'

export interface VoiceProviderMeta {
  id: VoiceProviderId
  name: string
  badge: string
  description: string
}

/** Only local, free providers. */
export const VOICE_PROVIDERS: VoiceProviderMeta[] = [
  {
    id: 'kokoro',
    name: 'Kokoro-82M (local neural)',
    badge: 'Most natural • ~92 MB one-time download',
    description:
      'Open-weight neural voice that runs on your device in a background worker. Speed is applied inside the model (pitch-preserving). Falls back to your browser voice until the model is downloaded.',
  },
  {
    id: 'browser-neural',
    name: 'Browser voice',
    badge: 'Instant • no download',
    description:
      'Uses the best English voice your browser/OS provides. Quality depends on your device; rate, pitch and volume are applied per phrase.',
  },
]

export interface CoachVoiceProfile {
  coachId: CoachId
  label: string
  inspirationNote: string
  /** Default Kokoro voice id (exists in Kokoro-82M v1.0). */
  kokoroVoice: string
  /** Relative speed multiplier applied on top of the user's speed (Kokoro + browser). */
  baseRate: number
  /** Browser-voice pitch (Kokoro has no pitch control). */
  basePitch: number
  /** Scales pauses between phrases. */
  pauseScale: number
  preferredBrowserVoiceKeywords: string[]
}

export const COACH_VOICE_PROFILES: Record<CoachId, CoachVoiceProfile> = {
  vale: {
    coachId: 'vale',
    label: 'Calm & analytical',
    inspirationNote: 'Measured delivery, lower register, thoughtful pauses and quiet confidence.',
    kokoroVoice: 'bm_george',
    baseRate: 0.95,
    basePitch: 0.9,
    pauseScale: 1.2,
    preferredBrowserVoiceKeywords: ['Google UK English Male', 'Daniel', 'Arthur', 'Oliver', 'Microsoft Ryan', 'Alex'],
  },
  flash: {
    coachId: 'flash',
    label: 'Energetic & tactical',
    inspirationNote: 'Brisker conversational pace with clear emphasis on forcing moves.',
    kokoroVoice: 'af_bella',
    baseRate: 1.06,
    basePitch: 1.06,
    pauseScale: 0.8,
    preferredBrowserVoiceKeywords: ['Samantha', 'Microsoft Aria', 'Google US English', 'Zira', 'Jenny'],
  },
  gambit: {
    coachId: 'gambit',
    label: 'Expressive & entertaining',
    inspirationNote: 'Varied cadence and storytelling, with natural moments of excitement.',
    kokoroVoice: 'bm_fable',
    baseRate: 1.0,
    basePitch: 1.0,
    pauseScale: 1.05,
    preferredBrowserVoiceKeywords: ['Google UK English Female', 'Microsoft Sonia', 'Serena', 'Karen', 'Moira'],
  },
}
