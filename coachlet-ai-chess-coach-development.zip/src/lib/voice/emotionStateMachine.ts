import type { MoveClass } from '@/lib/evaluation/classify'
import type { CoachEmotion, CoachId } from '@/types'
import { writeForSpeech, type SpokenChunk } from './speechWriter'
import { COACH_VOICE_PROFILES } from './voiceConfig'

export interface SpeechContext {
  moveClass?: MoveClass
  inCheck?: boolean
  isTimeLow?: boolean
  isComplexExplanation?: boolean
  customEmotion?: CoachEmotion
}

export interface PlannedChunk extends SpokenChunk {
  /** Multiplier on the user's speed (used by BOTH Kokoro (model speed) and browser rate). */
  rate: number
  /** Browser-only (Kokoro has no pitch control). */
  pitch: number
  /** Relative loudness 0..1 multiplier (browser utterance volume; Kokoro uses master gain). */
  volume: number
  pauseAfterMs: number
}

export interface SpeechPlan {
  emotion: CoachEmotion
  emotionLabel: string
  chunks: PlannedChunk[]
}

export const EMOTION_LABELS: Record<CoachEmotion, string> = {
  calm_analytical: 'Calm & analytical',
  approving: 'Warm & approving',
  excited: 'Excited',
  dramatic: 'Storytelling',
  constructive_criticism: 'Constructive',
  urgent: 'Urgent',
}

export function resolveCoachEmotion(coachId: CoachId, ctx?: SpeechContext): CoachEmotion {
  if (ctx?.customEmotion) return ctx.customEmotion
  if (ctx?.isTimeLow) return 'urgent'
  const cls = ctx?.moveClass
  if (cls === 'brilliant' || cls === 'great') return coachId === 'gambit' ? 'dramatic' : coachId === 'flash' ? 'excited' : 'approving'
  if (cls === 'best' || cls === 'excellent') return 'approving'
  if (cls === 'blunder' || cls === 'mistake' || cls === 'inaccuracy') return 'constructive_criticism'
  if (ctx?.inCheck) return 'urgent'
  return 'calm_analytical'
}

const SHAPE: Record<CoachEmotion, { rate: number; pitch: number; pause: number; volume: number }> = {
  calm_analytical: { rate: 1.0, pitch: 1.0, pause: 1.0, volume: 0.95 },
  approving: { rate: 1.0, pitch: 1.04, pause: 0.95, volume: 1.0 },
  excited: { rate: 1.07, pitch: 1.08, pause: 0.8, volume: 1.0 },
  dramatic: { rate: 0.97, pitch: 1.05, pause: 1.3, volume: 1.0 },
  constructive_criticism: { rate: 0.95, pitch: 0.96, pause: 1.15, volume: 0.97 },
  urgent: { rate: 1.1, pitch: 1.03, pause: 0.7, volume: 1.0 },
}

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n))

/**
 * Written text + coach + context -> chunked speech plan. No SSML is generated: neither
 * Kokoro nor the Web Speech API reliably honour it, so prosody is applied per chunk
 * (rate / pitch / pause) through controls each provider really supports.
 */
export function buildSpeechPlan(raw: string, coachId: CoachId, ctx?: SpeechContext): SpeechPlan {
  const emotion = resolveCoachEmotion(coachId, ctx)
  const p = COACH_VOICE_PROFILES[coachId]
  const s = SHAPE[emotion]
  const base = writeForSpeech(raw)
  const complexSlow = ctx?.isComplexExplanation ? 0.96 : 1
  const chunks: PlannedChunk[] = base.map((c, i) => {
    // Gambit: varied cadence. Deterministic wobble so replays sound identical.
    const wobble = coachId === 'gambit' ? [1, 1.03, 0.97, 1.02][i % 4] : 1
    // First phrase after a mistake lands a touch slower; the closing phrase of a tactic slows to land.
    const first = i === 0 && emotion === 'constructive_criticism' ? 0.97 : 1
    const last = i === base.length - 1 && base.length > 2 ? 0.97 : 1
    const basePause = c.sentenceEnd ? 330 : 130
    return {
      ...c,
      rate: clamp(p.baseRate * s.rate * complexSlow * wobble * first * last, 0.6, 1.4),
      pitch: clamp(p.basePitch * s.pitch * (c.question ? 1.04 : 1), 0.6, 1.6),
      volume: s.volume,
      pauseAfterMs: Math.round(basePause * s.pause * p.pauseScale),
    }
  })
  return { emotion, emotionLabel: EMOTION_LABELS[emotion], chunks }
}
