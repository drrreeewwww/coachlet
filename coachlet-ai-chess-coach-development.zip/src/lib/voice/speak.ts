/**
 * Central speech controller.
 *
 *  text -> speechWriter (conversational rewrite + notation) -> emotion plan (per-chunk rate/pitch/pause)
 *       -> provider:  Kokoro (worker synth -> Web Audio, GainNode volume, gapless scheduling)
 *                     Browser SpeechSynthesis (per-chunk utterances) — also the fallback.
 *
 * Guarantees: one speech at a time; every async step checks a session token so stale speech
 * never plays; speaking state follows real playback end events; stop() is immediate.
 */
import type { CoachId, VoiceProviderId } from '@/types'
import { buildSpeechPlan, type SpeechContext, type SpeechPlan } from './emotionStateMachine'
import { getKokoroState, initKokoro, isKnownKokoroVoice, synthesize } from './kokoro'
import { COACH_VOICE_PROFILES } from './voiceConfig'

export interface SpeakOptions {
  speed?: number
  volume?: number
  provider?: VoiceProviderId
  /** Kokoro voice id; 'coach' / undefined = the coach's default voice. */
  voiceId?: string
  context?: SpeechContext
  /** Ignore the request if this exact key is already speaking/preparing (React double-render guard). */
  dedupeKey?: string
}

export type SpeechStatus = 'idle' | 'preparing' | 'speaking' | 'paused'

export interface SpeechState {
  status: SpeechStatus
  isSpeaking: boolean
  provider: 'kokoro' | 'browser' | null
  coachId: CoachId | null
  text: string
  emotionLabel: string
  /** Set when Kokoro failed/was unavailable and the browser voice was used instead. */
  notice?: string
}

const IDLE: SpeechState = { status: 'idle', isSpeaking: false, provider: null, coachId: null, text: '', emotionLabel: '' }
let state: SpeechState = IDLE
const listeners = new Set<(s: SpeechState) => void>()

function setState(patch: Partial<SpeechState>) {
  const status = patch.status ?? state.status
  state = { ...state, ...patch, isSpeaking: status === 'speaking' || status === 'preparing' || status === 'paused' }
  listeners.forEach((l) => l(state))
}

export const getSpeechState = () => state
export function subscribeSpeechState(fn: (s: SpeechState) => void): () => void {
  listeners.add(fn)
  fn(state)
  return () => {
    listeners.delete(fn)
  }
}
// Kept for older call sites.
export const getLastSpeechDiagnostic = getSpeechState

let session = 0
let lastRequest: { raw: string; coach: CoachId; opts: SpeakOptions } | null = null
let currentKey: string | undefined
let volumeNow = 0.85

// ---------------------------------------------------------------- Web Audio
let audioCtx: AudioContext | null = null
let master: GainNode | null = null
let sources: AudioBufferSourceNode[] = []

function ensureAudio(): { ctx: AudioContext; gain: GainNode } {
  if (!audioCtx || audioCtx.state === 'closed') {
    audioCtx = new AudioContext()
    master = audioCtx.createGain()
    master.connect(audioCtx.destination)
  }
  master!.gain.value = volumeNow
  return { ctx: audioCtx, gain: master! }
}

/** Live volume (applies immediately to Kokoro playback through the GainNode). */
export function setSpeechVolume(v: number) {
  volumeNow = Math.min(1, Math.max(0, v))
  if (master && audioCtx) master.gain.setTargetAtTime(volumeNow, audioCtx.currentTime, 0.015)
}

function stopAudioSources() {
  for (const s of sources) {
    s.onended = null
    try {
      s.stop()
    } catch {
      /* already stopped */
    }
    try {
      s.disconnect()
    } catch {
      /* ignore */
    }
  }
  sources = []
}

function trimSilence(samples: Float32Array, sr: number): Float32Array {
  const thr = 0.004
  let a = 0
  let b = samples.length - 1
  while (a < b && Math.abs(samples[a]) < thr) a++
  while (b > a && Math.abs(samples[b]) < thr) b--
  const pad = Math.round(sr * 0.03)
  return samples.subarray(Math.max(0, a - pad), Math.min(samples.length, b + pad))
}

// ---------------------------------------------------------------- Browser TTS
let timers: ReturnType<typeof setTimeout>[] = []
const hasWebSpeech = () => typeof window !== 'undefined' && 'speechSynthesis' in window

function pickBrowserVoice(coach: CoachId): SpeechSynthesisVoice | undefined {
  if (!hasWebSpeech()) return undefined
  const all = window.speechSynthesis.getVoices()
  const en = all.filter((v) => /^en(-|_|$)/i.test(v.lang))
  if (en.length === 0) return all[0]
  for (const kw of COACH_VOICE_PROFILES[coach].preferredBrowserVoiceKeywords) {
    const m = en.find((v) => v.name.toLowerCase().includes(kw.toLowerCase()))
    if (m) return m
  }
  const natural = en.filter((v) => /natural|neural|google|premium|enhanced/i.test(v.name))
  const pool = natural.length ? natural : en
  return pool[{ vale: 0, flash: 1, gambit: 2 }[coach] % pool.length]
}

function playBrowser(plan: SpeechPlan, coach: CoachId, speed: number, mySession: number, from = 0) {
  const synth = window.speechSynthesis
  const voice = pickBrowserVoice(coach)
  const next = (i: number) => {
    if (mySession !== session) return
    if (i >= plan.chunks.length) {
      setState({ status: 'idle' })
      return
    }
    const c = plan.chunks[i]
    const u = new SpeechSynthesisUtterance(c.text)
    u.lang = voice?.lang || 'en-US'
    if (voice) u.voice = voice
    u.rate = Math.min(2, Math.max(0.5, c.rate * speed))
    u.pitch = Math.min(2, Math.max(0, c.pitch))
    u.volume = Math.min(1, volumeNow * c.volume)
    u.onstart = () => {
      if (mySession === session && state.status === 'preparing') setState({ status: 'speaking' })
    }
    u.onend = () => {
      if (mySession !== session) return
      if (i < plan.chunks.length - 1 && c.pauseAfterMs > 0) timers.push(setTimeout(() => next(i + 1), c.pauseAfterMs))
      else next(i + 1)
    }
    u.onerror = (e) => {
      if (mySession !== session) return
      if ((e as SpeechSynthesisErrorEvent).error === 'canceled' || (e as SpeechSynthesisErrorEvent).error === 'interrupted') return
      setState({ status: 'idle', notice: 'The browser voice failed to play.' })
    }
    synth.speak(u)
  }
  next(from)
}

// ---------------------------------------------------------------- Kokoro playback
async function playKokoro(plan: SpeechPlan, coach: CoachId, voiceId: string, speed: number, mySession: number): Promise<boolean> {
  const stale = () => mySession !== session
  const { ctx } = ensureAudio()
  try {
    if (ctx.state === 'suspended') await ctx.resume()
  } catch {
    /* autoplay policy: a user gesture will be required */
  }
  let cursor = 0
  let last: AudioBufferSourceNode | null = null
  let scheduledAny = false
  for (let i = 0; i < plan.chunks.length; i++) {
    const c = plan.chunks[i]
    let r
    try {
      r = await synthesize(c.text, voiceId, Math.min(1.6, Math.max(0.6, c.rate * speed)), stale)
    } catch (e) {
      if (stale()) return true
      if (!scheduledAny) throw e
      // Mid-way failure: finish what was scheduled and report fallback in the notice.
      setState({ notice: 'Local voice stopped mid-way; the rest was skipped.' })
      break
    }
    if (stale()) return true
    const samples = trimSilence(r.samples, r.sampleRate)
    const buf = ctx.createBuffer(1, samples.length, r.sampleRate)
    buf.copyToChannel(samples as Float32Array<ArrayBuffer>, 0)
    const src = ctx.createBufferSource()
    src.buffer = buf
    src.connect(master!)
    const startAt = Math.max(ctx.currentTime + 0.03, cursor)
    src.start(startAt)
    cursor = startAt + buf.duration + c.pauseAfterMs / 1000
    sources.push(src)
    last = src
    if (!scheduledAny) {
      scheduledAny = true
      setState({ status: 'speaking' })
    }
  }
  if (last) {
    last.onended = () => {
      if (!stale()) setState({ status: 'idle' })
    }
  } else if (!stale()) {
    setState({ status: 'idle' })
  }
  return true
}

// ---------------------------------------------------------------- Public API
export function stopSpeaking() {
  session++
  currentKey = undefined
  timers.forEach(clearTimeout)
  timers = []
  stopAudioSources()
  if (audioCtx && audioCtx.state === 'suspended') void audioCtx.resume().catch(() => undefined)
  if (hasWebSpeech()) {
    try {
      window.speechSynthesis.cancel()
    } catch {
      /* ignore */
    }
  }
  if (state.status !== 'idle') setState({ status: 'idle' })
}

export function pauseSpeaking() {
  if (state.status !== 'speaking') return
  if (state.provider === 'kokoro' && audioCtx) void audioCtx.suspend()
  else if (hasWebSpeech()) window.speechSynthesis.pause()
  setState({ status: 'paused' })
}

export function resumeSpeaking() {
  if (state.status !== 'paused') return
  if (state.provider === 'kokoro' && audioCtx) void audioCtx.resume()
  else if (hasWebSpeech()) window.speechSynthesis.resume()
  setState({ status: 'speaking' })
}

export function replaySpeech(): boolean {
  if (!lastRequest) return false
  speak(lastRequest.raw, lastRequest.coach, { ...lastRequest.opts, dedupeKey: undefined })
  return true
}

export const hasReplayableSpeech = () => lastRequest !== null

export function speak(rawText: string, coach: CoachId, speedOrOpts: number | SpeakOptions = 1): void {
  if (typeof window === 'undefined' || !rawText.trim()) return
  const opts: SpeakOptions = typeof speedOrOpts === 'number' ? { speed: speedOrOpts } : speedOrOpts

  if (opts.dedupeKey && opts.dedupeKey === currentKey && state.status !== 'idle') return

  stopSpeaking()
  const mySession = session
  currentKey = opts.dedupeKey
  lastRequest = { raw: rawText, coach, opts }

  const speed = Math.min(1.5, Math.max(0.6, opts.speed ?? 1))
  volumeNow = Math.min(1, Math.max(0, opts.volume ?? 0.85))
  const plan = buildSpeechPlan(rawText, coach, opts.context)
  if (plan.chunks.length === 0) return

  const spokenText = plan.chunks.map((c) => c.text).join(' ')
  const kokoro = getKokoroState()
  const wantKokoro = (opts.provider ?? 'kokoro') === 'kokoro'
  const kokoroUsable = wantKokoro && (kokoro.status === 'downloaded' || kokoro.status === 'ready' || kokoro.status === 'loading')
  const voiceId = opts.voiceId && opts.voiceId !== 'coach' && isKnownKokoroVoice(opts.voiceId) ? opts.voiceId : COACH_VOICE_PROFILES[coach].kokoroVoice

  const useBrowser = (notice?: string) => {
    if (mySession !== session) return
    if (!hasWebSpeech()) {
      setState({ status: 'idle', provider: null, notice: 'No speech engine is available in this browser.' })
      return
    }
    setState({ status: 'preparing', provider: 'browser', coachId: coach, text: spokenText, emotionLabel: plan.emotionLabel, notice })
    playBrowser(plan, coach, speed, mySession)
  }

  if (!kokoroUsable) {
    useBrowser(wantKokoro ? 'Local voice model is not downloaded yet — using the browser voice.' : undefined)
    return
  }

  setState({ status: 'preparing', provider: 'kokoro', coachId: coach, text: spokenText, emotionLabel: plan.emotionLabel, notice: undefined })
  void (async () => {
    try {
      await initKokoro()
      if (mySession !== session) return
      await playKokoro(plan, coach, voiceId, speed, mySession)
    } catch (e) {
      if (mySession !== session) return
      stopAudioSources()
      useBrowser(`Local voice failed (${e instanceof Error ? e.message : 'unknown error'}) — used the browser voice instead.`)
    }
  })()
}
