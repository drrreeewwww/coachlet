/**
 * Converts chess notation and chess jargon to speakable English.
 * Notation patterns are anchored (word boundaries, real file/rank ranges) so ordinary
 * English words are never rewritten.
 */

const PIECE: Record<string, string> = { K: 'King', Q: 'Queen', R: 'Rook', B: 'Bishop', N: 'Knight' }
const PROMO: Record<string, string> = { Q: 'queen', R: 'rook', B: 'bishop', N: 'knight' }

const suffix = (s?: string) => (s === '#' ? ', checkmate' : s === '+' ? ', check' : '')
const fileSpoken = (f: string) => `the ${f}-file`

/** Pronunciation respellings. Whole-word, case-insensitive; chosen so no common English word is affected. */
export const PRONUNCIATIONS: Array<[RegExp, string | ((m: string) => string)]> = [
  [/\bfianchetto(s|ed)?\b/gi, 'fyanketto$1'],
  [/\ben passant\b/gi, 'on passon'],
  [/\bzugzwang\b/gi, 'tsoogtsvahng'],
  [/\bzwischenzug\b/gi, 'tsvishentsoog'],
  [/\bnajdorf\b/gi, 'Nye-dorf'],
  [/\bcaro[- ]kann\b/gi, 'Karo Kahn'],
  [/\bnimzo[- ]indian\b/gi, 'Nimtso Indian'],
  [/\bnimzowitsch\b/gi, 'Nimtsovitch'],
  [/\bgr[uü]nfeld\b/gi, 'Groon-feld'],
  [/\br[eé]ti\b/g, 'Ray-tee'],
  [/\balekhine\b/gi, 'Ah-lyekhin'],
  [/\bscheveningen\b/gi, 'Skay-vuh-ning-en'],
  [/\btarrasch\b/gi, 'Tarrash'],
  [/\bpirc\b/gi, 'Peerts'],
  [/\bruy lopez\b/gi, 'Roo-ee Lopez'],
  [/\bgiuoco piano\b/gi, 'Jwoko Pyahno'],
  [/\bbenoni\b/gi, 'Beh-no-nee'],
  [/\bbogo[- ]indian\b/gi, 'Bogo Indian'],
  [/\bphilidor\b/gi, 'Fill-ih-dor'],
  [/\bcatalan\b/gi, 'Cat-uh-lan'],
  [/\bkasparov\b/gi, 'Kass-par-ov'],
  [/\bcarlsen\b/gi, 'Carl-sen'],
  [/\bbotvinnik\b/gi, 'Bot-vin-ik'],
  [/\bElo\b/g, 'Eelo'],
  [/\bECO\b/g, 'E C O'],
  [/\bPGN\b/g, 'P G N'],
  [/\bFEN\b/g, 'fen'],
  [/\bMultiPV\b/gi, 'multi P V'],
  [/\bUCI\b/g, 'U C I'],
]

function digitsSpoken(n: string): string {
  const words = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']
  return n.replace(/\d/g, (d) => ` ${words[Number(d)]}`).trim()
}

/** "0.35" -> "zero point three five" */
export function decimalSpoken(s: string): string {
  const [i, f] = s.split('.')
  return f === undefined ? i : `${i === '0' ? 'zero' : i} point ${digitsSpoken(f)}`
}

export function preprocessChessTextForSpeech(input: string): string {
  let t = input

  // --- Visual clean-up -------------------------------------------------------
  t = t
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, ' ') // emoji & dingbats (keeps ♞ ♟ out too)
    .replace(/[♔♕♖♗♘♙♚♛♜♝♞♟]/g, ' ')
    .replace(/[*_`#>]{1,3}(?=\S)/g, '')
    .replace(/(?<=\S)[*_`]{1,3}/g, '')
    .replace(/\s*[→⇒]\s*/g, ', then ')
    .replace(/\s*&\s*/g, ' and ')
    .replace(/\bvs\.?\s/gi, 'versus ')
    .replace(/\s[—–]\s/g, ', ')
    .replace(/…/g, '...')
    .replace(/\u2212/g, '-') // unicode minus

  // --- Castling ---------------------------------------------------------------
  t = t.replace(/\b(?:O-O-O|0-0-0)([+#])?(?![\w-])/g, (_m, s) => `queenside castling${suffix(s)}`)
  t = t.replace(/\b(?:O-O|0-0)([+#])?(?![\w-])/g, (_m, s) => `kingside castling${suffix(s)}`)

  // --- Promotion: exd8=Q+  /  e8=Q ----------------------------------------------
  t = t.replace(/\b(?:([a-h])x)?([a-h][18])=([QRBN])([+#])?(?![\w])/g, (_m, from, sq, p, s) =>
    from
      ? `pawn takes ${sq} and promotes to a ${PROMO[p]}${suffix(s)}`
      : `pawn promotes to a ${PROMO[p]} on ${sq}${suffix(s)}`
  )

  // --- Piece moves: Nf3, Bxf7+, Rfe1, R1e1, Qh4xe1, Nbxd2 -----------------------
  t = t.replace(
    /\b([KQRBN])([a-h]|[1-8])?(x)?([a-h][1-8])([+#])?(?![\w])/g,
    (_m, piece: string, dis: string | undefined, cap: string | undefined, sq: string, s: string | undefined) => {
      const from = dis ? (/[a-h]/.test(dis) ? ` from ${fileSpoken(dis)}` : ` from rank ${dis}`) : ''
      return `${PIECE[piece]}${from} ${cap ? 'takes' : 'to'} ${sq}${suffix(s)}`
    }
  )

  // --- Pawn captures: exd5, bxa6 (optionally "e.p.") ---------------------------
  t = t.replace(/\b([a-h])x([a-h][1-8])(\s?e\.p\.)?([+#])?(?![\w])/g, (_m, f, sq, ep, s) =>
    `${f}-pawn takes ${sq}${ep ? ' en passant' : ''}${suffix(s)}`
  )

  // --- Move numbers: "1." / "12..." only when followed by a move-like token ------
  t = t.replace(/\b(\d{1,3})\.\.\.\s*(?=[A-Za-z])/g, 'move $1 for Black, ')
  t = t.replace(/\b(\d{1,3})\.\s+(?=(?:[KQRBN]|[a-h][1-8]|kingside|queenside|[a-h]-pawn|pawn))/g, 'move $1, ')

  // --- Evaluations ----------------------------------------------------------------
  t = t.replace(/(?<![\w.])([+-])?M(\d{1,2})\b/g, (_m, sign, n) =>
    sign === '-' ? `getting mated in ${n}` : `mate in ${n}`
  )
  t = t.replace(/(?<![\w.])#(-)?(\d{1,2})\b/g, (_m, neg, n) => (neg ? `getting mated in ${n}` : `mate in ${n}`))
  t = t.replace(/(?<![\w.])([+-])\s?(\d{2,4})\s?cp\b/gi, (_m, sign, n) => `${sign === '-' ? 'minus' : 'plus'} ${n} centipawns`)
  t = t.replace(/(?<![\w.])(\d{2,4})\s?cp\b/gi, '$1 centipawns')
  t = t.replace(/(?<![\w.])([+-])(\d{1,2}\.\d{1,2})(?![\d])/g, (_m, sign, n) => `${sign === '-' ? 'minus' : 'plus'} ${decimalSpoken(n)}`)
  t = t.replace(/(\d+(?:\.\d+)?)\s?%/g, '$1 percent')
  t = t.replace(/\b(\d{1,2})\.(\d)\b(?=\s*(?:pawns?|points?)\b)/gi, (_m, i, f) => `${i} point ${f}`)

  // --- Standalone check/mate marks after a leftover square, e.g. "h7#" ------------------
  t = t.replace(/\b([a-h][1-8])#/g, '$1, checkmate').replace(/\b([a-h][1-8])\+(?!\d)/g, '$1, check')

  // --- Annotation glyphs that survived ---------------------------------------------------
  t = t.replace(/\?\?(?=\s|$)/g, '').replace(/!!(?=\s|$)/g, '!').replace(/\b(\w+)[!?]{1,2}\?(?=\s|$)/g, '$1?')

  // --- Pronunciations ----------------------------------------------------------------------
  for (const [re, rep] of PRONUNCIATIONS) t = t.replace(re, rep as string)

  return t.replace(/\s{2,}/g, ' ').replace(/\s+([,.;:!?])/g, '$1').replace(/,\s*,/g, ',').trim()
}
