import { preprocessChessTextForSpeech } from './chessNotationPreprocessor'

/** Contractions + light conversational rewrites. Meaning is never changed. */
const CONTRACTIONS: Array<[RegExp, string]> = [
  [/\bdo not\b/gi, "don't"],
  [/\bdoes not\b/gi, "doesn't"],
  [/\bdid not\b/gi, "didn't"],
  [/\bis not\b/gi, "isn't"],
  [/\bare not\b/gi, "aren't"],
  [/\bwas not\b/gi, "wasn't"],
  [/\bcannot\b/gi, "can't"],
  [/\bcan not\b/gi, "can't"],
  [/\bwill not\b/gi, "won't"],
  [/\bwould not\b/gi, "wouldn't"],
  [/\bshould not\b/gi, "shouldn't"],
  [/\bit is\b/gi, "it's"],
  [/\bthat is\b/gi, "that's"],
  [/\bthere is\b/gi, "there's"],
  [/\bwhat is\b/gi, "what's"],
  [/\byou are\b/gi, "you're"],
  [/\bwe are\b/gi, "we're"],
  [/\bthey are\b/gi, "they're"],
  [/\byou have\b/gi, "you've"],
  [/\byou will\b/gi, "you'll"],
  [/\blet us\b/gi, "let's"],
]

const matchCase = (src: string, rep: string) => (/^[A-Z]/.test(src) ? rep[0].toUpperCase() + rep.slice(1) : rep)

export function contract(text: string): string {
  let t = text
  for (const [re, rep] of CONTRACTIONS) t = t.replace(re, (m) => matchCase(m, rep))
  return t
}

function hash(s: string): number {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0
  return Math.abs(h)
}

/** Deterministic wording variety for stock engine phrases (same text -> same words, no flip-flopping on replay). */
const VARIANTS: Array<[RegExp, string[]]> = [
  [/\bThe engine recommends\b/g, ['The engine likes', 'Stockfish prefers', 'The engine recommends']],
  [/\bStockfish recommends\b/g, ['Stockfish likes', 'Stockfish prefers', 'Stockfish recommends']],
  [/\bThe best move (?:here )?is\b/g, ["The best move here is", "Best here is", "The strongest move is"]],
]

function vary(t: string): string {
  const h = hash(t)
  return VARIANTS.reduce((acc, [re, opts]) => acc.replace(re, opts[h % opts.length]), t)
}

export interface SpokenChunk {
  text: string
  /** true when this chunk ends a sentence (longer pause) rather than a clause (short pause). */
  sentenceEnd: boolean
  question: boolean
}

const MAX_CHARS_AUTO = 520

/** Strips markdown/list formatting so lists read as sentences. */
function flatten(raw: string): string {
  return raw
    .replace(/^\s*[-•*]\s+/gm, '')
    .replace(/^\s*\d+\)\s+/gm, '')
    .replace(/\n{2,}/g, '. ')
    .replace(/\n/g, ' ')
    .replace(/\.\s*\./g, '.')
}

const CLAUSE_SPLIT = /(?<=[;:])\s+|(?<=,)\s+(?=(?:and|but|so|because|while|which|though|since|then|when|if)\b)|\s+(?=(?:because|which means|so that|but)\b)/i

/**
 * Written coaching text -> spoken chunks. Splits into sentences, breaks long sentences at
 * natural clause boundaries (never mid-phrase), keeps chunks reasonably long (>= ~35 chars).
 */
export function writeForSpeech(raw: string, opts: { maxChars?: number } = {}): SpokenChunk[] {
  const max = opts.maxChars ?? MAX_CHARS_AUTO
  const text = preprocessChessTextForSpeech(contract(vary(flatten(raw))))
  const sentences = text.split(/(?<=[.!?])\s+/).map((s) => s.trim()).filter(Boolean)

  // Respect the length cap by whole sentences.
  const kept: string[] = []
  let len = 0
  for (const s of sentences) {
    if (len + s.length > max && kept.length > 0) break
    kept.push(s)
    len += s.length + 1
  }

  const chunks: SpokenChunk[] = []
  for (const s of kept) {
    const question = /\?\s*$/.test(s)
    if (s.length <= 150) {
      chunks.push({ text: s, sentenceEnd: true, question })
      continue
    }
    const parts = s.split(CLAUSE_SPLIT).map((p) => p.trim()).filter(Boolean)
    const merged: string[] = []
    for (const p of parts) {
      const last = merged[merged.length - 1]
      if (last !== undefined && (last.length < 35 || p.length < 20)) merged[merged.length - 1] = `${last} ${p}`
      else merged.push(p)
    }
    merged.forEach((m, i) => chunks.push({ text: m, sentenceEnd: i === merged.length - 1, question: question && i === merged.length - 1 }))
  }
  return chunks
}

export function spokenPreview(raw: string): string {
  return writeForSpeech(raw, { maxChars: 4000 }).map((c) => c.text).join(' ')
}
