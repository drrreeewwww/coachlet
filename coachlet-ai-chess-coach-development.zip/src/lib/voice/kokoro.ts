/**
 * Local Kokoro-82M voice engine (client side).
 *
 * - Model files are downloaded by US (fetch + AbortController) so the download can be
 *   genuinely cancelled; incomplete data is never written to the cache.
 * - Completed files are stored in CacheStorage ('transformers-cache') under the exact keys
 *   transformers.js uses, so the worker finds them without any further network access.
 * - Synthesis runs in /voice/kokoro.worker.js (Web Worker) so the board never blocks.
 * - Only one synthesis is ever in flight (ONNX sessions are not re-entrant).
 */

export type KokoroStatus =
  | 'unsupported'
  | 'not-downloaded'
  | 'downloading'
  | 'downloaded'
  | 'loading'
  | 'ready'
  | 'error'

export interface KokoroState {
  status: KokoroStatus
  /** 0..1 while downloading */
  progress: number
  receivedBytes: number
  totalBytes: number
  error?: string
}

export const KOKORO_REPO = 'onnx-community/Kokoro-82M-v1.0-ONNX'
const BASE = `https://huggingface.co/${KOKORO_REPO}/resolve/main/`
export const KOKORO_FILES = [
  { path: 'config.json', approx: 5_000 },
  { path: 'tokenizer.json', approx: 3_000 },
  { path: 'tokenizer_config.json', approx: 1_000 },
  { path: 'onnx/model_quantized.onnx', approx: 92_361_116 },
] as const
const CACHE_NAME = 'transformers-cache'

export interface KokoroVoiceInfo {
  id: string
  label: string
  accent: 'American' | 'British'
  gender: 'Female' | 'Male'
  /** Upstream Kokoro quality grade (A best). */
  grade: string
}

/** Voices that exist in Kokoro-82M v1.0 (names verified against kokoro-js@1.2.1's voice table). */
export const KOKORO_VOICES: KokoroVoiceInfo[] = [
  { id: 'af_heart', label: 'Heart', accent: 'American', gender: 'Female', grade: 'A' },
  { id: 'af_bella', label: 'Bella', accent: 'American', gender: 'Female', grade: 'A-' },
  { id: 'af_nicole', label: 'Nicole', accent: 'American', gender: 'Female', grade: 'B-' },
  { id: 'bf_emma', label: 'Emma', accent: 'British', gender: 'Female', grade: 'B-' },
  { id: 'am_michael', label: 'Michael', accent: 'American', gender: 'Male', grade: 'C+' },
  { id: 'am_fenrir', label: 'Fenrir', accent: 'American', gender: 'Male', grade: 'C+' },
  { id: 'bm_george', label: 'George', accent: 'British', gender: 'Male', grade: 'C' },
  { id: 'bm_fable', label: 'Fable', accent: 'British', gender: 'Male', grade: 'C' },
]

export const isKnownKokoroVoice = (id: string) => KOKORO_VOICES.some((v) => v.id === id)

let state: KokoroState = { status: 'not-downloaded', progress: 0, receivedBytes: 0, totalBytes: 0 }
const listeners = new Set<(s: KokoroState) => void>()
let abort: AbortController | null = null
let worker: Worker | null = null
let msgId = 0
const pending = new Map<number, { resolve: (v: never) => void; reject: (e: Error) => void }>()
let loadPromise: Promise<void> | null = null
let tail: Promise<unknown> = Promise.resolve()
let initialCheck: Promise<void> | null = null

function set(patch: Partial<KokoroState>) {
  state = { ...state, ...patch }
  listeners.forEach((l) => l(state))
}

export const getKokoroState = () => state

export function subscribeKokoro(fn: (s: KokoroState) => void): () => void {
  listeners.add(fn)
  fn(state)
  void refreshKokoroStatus()
  return () => {
    listeners.delete(fn)
  }
}

export function kokoroSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof Worker !== 'undefined' &&
    typeof caches !== 'undefined' &&
    typeof WebAssembly !== 'undefined' &&
    typeof AudioContext !== 'undefined'
  )
}

async function isModelCached(): Promise<boolean> {
  try {
    const cache = await caches.open(CACHE_NAME)
    for (const f of KOKORO_FILES) {
      if (!(await cache.match(BASE + f.path))) return false
    }
    return true
  } catch {
    return false
  }
}

/** Reads the real cache/worker state into `state` (never overwrites an active download/load). */
export function refreshKokoroStatus(): Promise<void> {
  if (!initialCheck) {
    initialCheck = (async () => {
      if (!kokoroSupported()) {
        set({ status: 'unsupported', error: 'This browser lacks Web Workers, CacheStorage or WebAssembly.' })
        return
      }
      if (state.status === 'not-downloaded') {
        if (await isModelCached()) set({ status: 'downloaded', progress: 1 })
      }
    })().finally(() => {
      initialCheck = null
    })
  }
  return initialCheck
}

/** Downloads the model. Resolves true when complete, false when cancelled. Throws on failure. */
export async function downloadKokoro(): Promise<boolean> {
  if (!kokoroSupported()) {
    set({ status: 'unsupported' })
    throw new Error('Local voice is not supported in this browser.')
  }
  if (state.status === 'downloading') return false
  if (state.status === 'downloaded' || state.status === 'ready' || state.status === 'loading') return true
  const ctl = new AbortController()
  abort = ctl
  const total = KOKORO_FILES.reduce((n, f) => n + f.approx, 0)
  set({ status: 'downloading', progress: 0, receivedBytes: 0, totalBytes: total, error: undefined })
  const staged: Array<{ url: string; blob: Blob; type: string }> = []
  let done = 0
  try {
    for (const f of KOKORO_FILES) {
      const res = await fetch(BASE + f.path, { signal: ctl.signal })
      if (!res.ok || !res.body) throw new Error(`Download failed (${res.status}) for ${f.path}`)
      const len = Number(res.headers.get('content-length'))
      if (len > 0) {
        // Replace the estimate for this file with the real size.
        set({ totalBytes: state.totalBytes - f.approx + len })
      }
      const reader = res.body.getReader()
      const parts: BlobPart[] = []
      let fileBytes = 0
      for (;;) {
        const { done: end, value } = await reader.read()
        if (end) break
        parts.push(value as BlobPart)
        fileBytes += value.byteLength
        const received = done + fileBytes
        set({ receivedBytes: received, progress: Math.min(0.99, received / Math.max(state.totalBytes, 1)) })
      }
      done += fileBytes
      staged.push({
        url: BASE + f.path,
        blob: new Blob(parts),
        type: res.headers.get('content-type') ?? 'application/octet-stream',
      })
    }
    // All files complete -> commit to the cache in one go.
    const cache = await caches.open(CACHE_NAME)
    for (const s of staged) {
      await cache.put(s.url, new Response(s.blob, { headers: { 'content-type': s.type, 'content-length': String(s.blob.size) } }))
    }
    set({ status: 'downloaded', progress: 1 })
    return true
  } catch (e) {
    staged.length = 0 // discard incomplete data
    if (ctl.signal.aborted || (e instanceof DOMException && e.name === 'AbortError')) {
      set({ status: 'not-downloaded', progress: 0, receivedBytes: 0, error: undefined })
      return false
    }
    set({ status: 'error', error: e instanceof Error ? e.message : String(e) })
    throw e
  } finally {
    if (abort === ctl) abort = null
  }
}

export function cancelKokoroDownload() {
  abort?.abort()
}

export async function deleteKokoroModel() {
  cancelKokoroDownload()
  disposeKokoro()
  try {
    const cache = await caches.open(CACHE_NAME)
    for (const f of KOKORO_FILES) await cache.delete(BASE + f.path)
  } catch {
    /* ignore */
  }
  set({ status: kokoroSupported() ? 'not-downloaded' : 'unsupported', progress: 0, receivedBytes: 0, error: undefined })
}

function ensureWorker(): Worker {
  if (worker) return worker
  const w = new Worker('/voice/kokoro.worker.js', { type: 'module' })
  w.onmessage = (e: MessageEvent) => {
    const m = e.data as { type: string; id: number; message?: string }
    const p = pending.get(m.id)
    if (!p) return
    pending.delete(m.id)
    if (m.type === 'error') p.reject(new Error(m.message ?? 'Kokoro worker error'))
    else p.resolve(m as never)
  }
  w.onerror = (e) => {
    const err = new Error(e.message || 'Kokoro worker crashed')
    pending.forEach((p) => p.reject(err))
    pending.clear()
    worker = null
    loadPromise = null
    set({ status: 'error', error: err.message })
  }
  worker = w
  return w
}

function call<T>(msg: Record<string, unknown>, transfer?: Transferable[]): Promise<T> {
  const id = ++msgId
  const w = ensureWorker()
  return new Promise<T>((resolve, reject) => {
    pending.set(id, { resolve: resolve as (v: never) => void, reject })
    w.postMessage({ ...msg, id }, transfer ?? [])
  })
}

/** Loads the downloaded model into the worker. */
export function initKokoro(): Promise<void> {
  if (state.status === 'ready') return Promise.resolve()
  if (loadPromise) return loadPromise
  if (state.status !== 'downloaded' && state.status !== 'error' && state.status !== 'loading') {
    return Promise.reject(new Error('Kokoro model is not downloaded'))
  }
  set({ status: 'loading', error: undefined })
  loadPromise = call<{ voices: string[] }>({ type: 'load' })
    .then(() => set({ status: 'ready' }))
    .catch((e: Error) => {
      set({ status: 'error', error: e.message })
      throw e
    })
    .finally(() => {
      loadPromise = null
    })
  return loadPromise
}

export interface SynthResult {
  samples: Float32Array
  sampleRate: number
}

/** Serialized synthesis. `isStale` lets callers skip queued work after cancel/new speech. */
export function synthesize(text: string, voice: string, speed: number, isStale?: () => boolean): Promise<SynthResult> {
  const run = async (): Promise<SynthResult> => {
    if (isStale?.()) throw new Error('cancelled')
    await initKokoro()
    if (isStale?.()) throw new Error('cancelled')
    const r = await call<{ samples: Float32Array; sampleRate: number }>({ type: 'synth', text, voice, speed })
    return { samples: r.samples, sampleRate: r.sampleRate }
  }
  const p = tail.then(run, run)
  tail = p.catch(() => undefined)
  return p
}

export function disposeKokoro() {
  pending.forEach((p) => p.reject(new Error('cancelled')))
  pending.clear()
  worker?.terminate()
  worker = null
  loadPromise = null
  tail = Promise.resolve()
  if (state.status === 'ready' || state.status === 'loading') set({ status: 'downloaded' })
}
