'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Pause, Play, RotateCcw, Square, Volume2, VolumeX, Sparkles, Mic } from 'lucide-react'
import {
  getSpeechState,
  pauseSpeaking,
  resumeSpeaking,
  setSpeechVolume,
  subscribeSpeechState,
  type SpeechState,
} from '@/lib/voice/speak'
import { getKokoroState, subscribeKokoro, type KokoroState } from '@/lib/voice/kokoro'
import type { VoiceProviderId } from '@/types'

interface Props {
  voiceOn: boolean
  onVoice: (on: boolean) => void
  speed: number
  onSpeed: (n: number) => void
  volume: number
  onVolume: (v: number) => void
  provider: VoiceProviderId
  /** Speak the latest written coaching text. */
  onSpeak: () => void
  onReplay: () => void
  onStop: () => void
  canSpeak: boolean
}

const btn =
  'inline-flex min-h-9 items-center gap-1 rounded border border-[#3a3834] bg-[#262522] px-2.5 py-1 text-[11px] font-semibold text-stone-200 transition hover:bg-[#302e2b] disabled:cursor-not-allowed disabled:opacity-40'

export function useSpeechStatus() {
  const [sp, setSp] = useState<SpeechState>(getSpeechState)
  const [kk, setKk] = useState<KokoroState>(getKokoroState)
  useEffect(() => subscribeSpeechState(setSp), [])
  useEffect(() => subscribeKokoro(setKk), [])
  return { sp, kk }
}

export function engineLabel(provider: VoiceProviderId, kk: KokoroState): string {
  if (provider === 'browser-neural') return 'Browser voice'
  if (kk.status === 'ready') return 'Kokoro (local neural)'
  if (kk.status === 'downloaded' || kk.status === 'loading') return 'Kokoro — loads on first use'
  if (kk.status === 'downloading') return `Downloading voice ${Math.round(kk.progress * 100)}%`
  return 'Browser voice (Kokoro not downloaded)'
}

export default function VoiceControls(p: Props) {
  const { sp, kk } = useSpeechStatus()
  const speaking = sp.status === 'speaking' || sp.status === 'preparing'
  const active = sp.status !== 'idle'

  return (
    <div className="mt-2.5 space-y-2 rounded-md border border-[#34322e] bg-[#1e1d1b] p-2 text-xs">
      <div className="flex flex-wrap items-center gap-1.5">
        <button
          type="button"
          onClick={() => p.onVoice(!p.voiceOn)}
          aria-pressed={p.voiceOn}
          className={`inline-flex min-h-9 items-center gap-1 rounded px-2.5 py-1 font-semibold transition ${
            p.voiceOn ? 'bg-[#81b64c]/20 text-[#a3d160]' : 'bg-[#2c2a27] text-stone-400'
          }`}
        >
          {p.voiceOn ? <Volume2 className="h-3.5 w-3.5" aria-hidden /> : <VolumeX className="h-3.5 w-3.5" aria-hidden />}
          {p.voiceOn ? 'Voice on' : 'Voice off'}
        </button>
        <button type="button" className={btn} disabled={!p.voiceOn || !p.canSpeak} onClick={p.onSpeak} title="Speak the latest coaching explanation">
          <Mic className="h-3.5 w-3.5" aria-hidden /> Speak
        </button>
        {sp.status === 'paused' ? (
          <button type="button" className={btn} onClick={resumeSpeaking} aria-label="Resume speech">
            <Play className="h-3.5 w-3.5" aria-hidden /> Resume
          </button>
        ) : (
          <button type="button" className={btn} disabled={sp.status !== 'speaking'} onClick={pauseSpeaking} aria-label="Pause speech">
            <Pause className="h-3.5 w-3.5" aria-hidden /> Pause
          </button>
        )}
        <button type="button" className={btn} disabled={!p.voiceOn} onClick={p.onReplay} title="Replay the last spoken line">
          <RotateCcw className="h-3.5 w-3.5" aria-hidden /> Replay
        </button>
        <button type="button" className={btn} disabled={!active} onClick={p.onStop} title="Stop speaking">
          <Square className="h-3.5 w-3.5" aria-hidden /> Stop
        </button>
        <span
          role="status"
          aria-live="polite"
          className={`ml-auto inline-flex items-center gap-1.5 rounded px-2 py-1 text-[10px] font-semibold ${
            speaking ? 'bg-[#81b64c]/20 text-[#a3d160]' : sp.status === 'paused' ? 'bg-amber-500/15 text-amber-300' : 'bg-[#2a2825] text-stone-400'
          }`}
        >
          {speaking && <span className="h-2 w-2 animate-pulse rounded-full bg-[#81b64c]" aria-hidden />}
          {sp.status === 'preparing' ? 'Preparing…' : sp.status === 'speaking' ? 'Speaking' : sp.status === 'paused' ? 'Paused' : 'Silent'}
        </span>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <label className="flex items-center gap-2 text-stone-300">
          <span className="w-16 shrink-0">Speed {p.speed.toFixed(1)}×</span>
          <input type="range" min={0.7} max={1.4} step={0.1} value={p.speed} onChange={(e) => p.onSpeed(Number(e.target.value))} className="min-w-0 flex-1 accent-[#81b64c]" aria-label="Voice speed" />
        </label>
        <label className="flex items-center gap-2 text-stone-300">
          <span className="w-16 shrink-0">Vol {Math.round(p.volume * 100)}%</span>
          <input
            type="range"
            min={0.1}
            max={1}
            step={0.05}
            value={p.volume}
            onChange={(e) => {
              const v = Number(e.target.value)
              p.onVolume(v)
              setSpeechVolume(v)
            }}
            className="min-w-0 flex-1 accent-[#81b64c]"
            aria-label="Voice volume"
          />
        </label>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-stone-400">
        <span className="inline-flex items-center gap-1">
          <Sparkles className="h-3 w-3 text-[#81b64c]" aria-hidden />
          {sp.status !== 'idle' && sp.provider ? `${sp.provider === 'kokoro' ? 'Kokoro' : 'Browser voice'} · ${sp.emotionLabel}` : engineLabel(p.provider, kk)}
        </span>
        <Link href="/settings#voice" className="text-[#a3d160] underline-offset-2 hover:underline">
          Voice settings
        </Link>
      </div>
      {sp.notice && <p className="text-[10px] text-amber-300/90">{sp.notice}</p>}
    </div>
  )
}
