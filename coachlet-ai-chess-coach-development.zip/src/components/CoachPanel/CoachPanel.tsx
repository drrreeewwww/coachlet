import { useState } from 'react'
import { Volume2 } from 'lucide-react'
import Avatar from './Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { CLASS_META, type MoveClass } from '@/lib/evaluation/classify'
import { bandFor, eloTierFor } from '@/lib/stockfish/elo'
import VoiceControls, { useSpeechStatus } from './VoiceControls'
import { COACH_VOICE_PROFILES } from '@/lib/voice/voiceConfig'
import type {
  CoachId,
  StructuredCoachResponse,
  VoiceProviderId,
} from '@/types'

export interface Reaction {
  text: string
  cls: MoveClass
  cpLoss: number
  san: string
  bestSan?: string
}

export interface ChatMsg {
  from: 'you' | 'coach'
  text: string
}

const QUICK_QUESTIONS = [
  'Why is this move a mistake?',
  'What would a grandmaster play here?',
  'Why is my king unsafe?',
  'How do I win this endgame?',
  'What happens if I sacrifice this piece?',
  'Explain this position in simpler terms.',
]

interface Props {
  coachId: CoachId
  elos: Record<CoachId, number>
  onCoach: (id: CoachId) => void
  onElo: (id: CoachId, elo: number) => void
  reaction: Reaction | null
  structured: StructuredCoachResponse | null
  coachLoading?: boolean
  voiceOn: boolean
  onVoice: (on: boolean) => void
  speed: number
  onSpeed: (n: number) => void
  voiceVolume?: number
  onVoiceVolume?: (v: number) => void
  voiceProvider?: VoiceProviderId
  canSpeak?: boolean
  onSpeak: () => void
  onPreview: (id: CoachId) => void
  onReplay: () => void
  onStop: () => void
  chat: ChatMsg[]
  onAsk: (q: string) => void
}

export default function CoachPanel(p: Props) {
  const [q, setQ] = useState('')
  const [showBreakdown, setShowBreakdown] = useState(true)
  const [showCoachesList, setShowCoachesList] = useState(false)
  const { sp: speechDiag } = useSpeechStatus()

  const coach = COACHES.find((c) => c.id === p.coachId)!
  const r = p.reaction
  const currentElo = p.elos[p.coachId]
  const eloTier = eloTierFor(currentElo)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const t = q.trim()
    if (t) {
      p.onAsk(t)
      setQ('')
    }
  }

  return (
    <section className="space-y-3">
      {/* Main Active Coach & Analysis Card */}
      <div className="rounded-lg border border-[#3a3834] bg-[#262522] p-3.5 shadow-lg">
        {/* Coach Header */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Avatar id={coach.id} accent={coach.accent} size={46} />
              {speechDiag?.isSpeaking && speechDiag.coachId === coach.id && (
                <span
                  title="Speaking"
                  className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#81b64c] text-[#1c1b19] shadow"
                >
                  <Volume2 className="h-2.5 w-2.5 animate-pulse" />
                </span>
              )}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base font-bold leading-tight text-stone-100">
                  {coach.name}
                </h2>
                <span className="rounded border border-[#81b64c]/45 bg-[#81b64c]/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#a3d160]">
                  {eloTier} • {currentElo} Elo
                </span>
              </div>
              <p className="text-xs text-stone-400">{coach.style}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {p.coachLoading && (
              <span className="flex items-center gap-1.5 rounded-full border border-[#81b64c]/40 bg-[#1e1d1b] px-2.5 py-1 text-[11px] text-[#a3d160]">
                <span className="h-2 w-2 animate-ping rounded-full bg-[#81b64c]" />
                Analysing…
              </span>
            )}
            <button
              type="button"
              onClick={() => setShowCoachesList(!showCoachesList)}
              className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-1 text-xs font-medium text-stone-200 transition hover:border-[#81b64c] hover:text-white"
            >
              {showCoachesList ? 'Hide Coaches ▲' : 'Switch Coach / Elo ▼'}
            </button>
          </div>
        </div>

        {/* Collapsible Coach & Elo Switcher Drawer */}
        {showCoachesList && (
          <div className="mt-3 space-y-2.5 rounded-lg border border-[#3a3834] bg-[#1c1b19] p-3">
            <div className="grid gap-2.5">
              {COACHES.map((c) => {
                const sel = c.id === p.coachId
                const vp = COACH_VOICE_PROFILES[c.id]
                return (
                  <div
                    key={c.id}
                    className={`rounded-lg border p-3 transition ${
                      sel
                        ? 'border-[#81b64c] bg-[#262522] shadow-md'
                        : 'border-[#33312d] bg-[#21201d] hover:border-[#46433e]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <Avatar id={c.id} accent={c.accent} size={38} />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h3 className="text-sm font-bold text-stone-100">
                              {c.name}
                            </h3>
                            <span className="rounded bg-[#33312d] px-1.5 py-0.5 text-[10px] text-stone-300">
                              {vp.label}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-400">
                            {c.inspiredBy}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => p.onPreview(c.id)}
                          className="rounded border border-[#3a3834] bg-[#1c1b19] px-2 py-1 text-[11px] text-stone-300 hover:bg-[#302e2b]"
                        >
                          🔊 Sample
                        </button>
                        <button
                          type="button"
                          onClick={() => p.onCoach(c.id)}
                          className={`rounded px-2.5 py-1 text-xs font-bold transition ${
                            sel
                              ? 'bg-[#81b64c] text-[#1c1b19]'
                              : 'border border-[#81b64c]/60 text-[#a3d160] hover:bg-[#81b64c]/15'
                          }`}
                        >
                          {sel ? 'Active' : 'Select'}
                        </button>
                      </div>
                    </div>

                    <div className="mt-2.5 flex items-center gap-3 text-xs">
                      <label
                        htmlFor={`elo-${c.id}`}
                        className="shrink-0 text-stone-400"
                      >
                        Strength:{' '}
                        <b className="font-mono text-stone-100">
                          {p.elos[c.id]}
                        </b>{' '}
                        <span className="text-[11px] text-stone-400">
                          ({bandFor(p.elos[c.id])})
                        </span>
                      </label>
                      <input
                        id={`elo-${c.id}`}
                        type="range"
                        min={300}
                        max={3200}
                        step={50}
                        value={p.elos[c.id]}
                        onChange={(e) => p.onElo(c.id, Number(e.target.value))}
                        className="w-full accent-[#81b64c]"
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Chess.com-style Move Classification Pill + Coach Dialogue Bubble */}
        <div className="mt-3 rounded-lg border border-[#363430] bg-[#1c1b19] p-3">
          {r && (
            <div
              className="mb-2 flex flex-wrap items-center gap-2 text-xs"
              title={CLASS_META[r.cls].note}
            >
              <span
                className="inline-flex items-center gap-1 rounded px-2 py-0.5 font-extrabold text-white shadow-xs"
                style={{ background: CLASS_META[r.cls].color }}
              >
                <span>{CLASS_META[r.cls].icon}</span>
                <span>{CLASS_META[r.cls].label}</span>
              </span>
              <span className="font-mono text-sm font-bold text-white">
                {r.san}
              </span>
              {r.cpLoss > 0 && (
                <span className="text-xs text-stone-400">
                  (−{r.cpLoss} cp
                  {r.bestSan && r.bestSan !== r.san
                    ? ` • Best: ${r.bestSan}`
                    : ''}
                  )
                </span>
              )}
            </div>
          )}
          <p
            className="text-sm leading-relaxed text-stone-200"
            aria-live="polite"
          >
            “{r ? r.text : coach.greeting}”
          </p>
        </div>

        <VoiceControls
          voiceOn={p.voiceOn}
          onVoice={p.onVoice}
          speed={p.speed}
          onSpeed={p.onSpeed}
          volume={p.voiceVolume ?? 0.85}
          onVolume={(v) => p.onVoiceVolume?.(v)}
          provider={p.voiceProvider ?? 'kokoro'}
          onSpeak={p.onSpeak}
          onReplay={p.onReplay}
          onStop={p.onStop}
          canSpeak={p.canSpeak ?? true}
        />

        {/* Structured Grandmaster Position Breakdown */}
        {p.structured && (
          <div className="mt-3 rounded-lg border border-[#363430] bg-[#1e1d1b] p-3 text-xs">
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold text-[#a3d160]">
                ✦ {p.structured.headline}
              </span>
              <button
                type="button"
                onClick={() => setShowBreakdown(!showBreakdown)}
                className="text-[11px] text-stone-400 hover:text-white"
              >
                {showBreakdown ? 'Hide ▲' : 'Details ▼'}
              </button>
            </div>
            {showBreakdown && (
              <dl className="mt-2 space-y-2 border-t border-[#33312d] pt-2 text-stone-300">
                <div>
                  <dt className="font-semibold text-stone-200">
                    Move Assessment:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.moveAssessment}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-amber-300">
                    What Was Overlooked:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.overlooked}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-red-300">
                    Opponent Threat:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.opponentThreat}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-emerald-300">
                    Engine Recommendation:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.engineRecommendation}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-sky-300">
                    Strategic Plan ({coach.name}):
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.strategicPlan}
                  </dd>
                </div>
                <div className="rounded border border-[#81b64c]/30 bg-[#81b64c]/8 p-2">
                  <dt className="font-semibold text-[#a3d160]">
                    Coach Improvement Tip:
                  </dt>
                  <dd className="mt-0.5 text-stone-200">
                    {p.structured.improvementTip}
                  </dd>
                </div>
              </dl>
            )}
          </div>
        )}

        {/* Quick-Ask Position Prompts */}
        <div className="mt-3 border-t border-[#363430] pt-2.5">
          <p className="mb-1.5 text-[11px] font-medium text-stone-400">
            Ask {coach.name} about this position:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_QUESTIONS.map((qq) => (
              <button
                key={qq}
                type="button"
                disabled={p.coachLoading}
                onClick={() => p.onAsk(qq)}
                className="rounded-full border border-[#3a3834] bg-[#1c1b19] px-2.5 py-1 text-[11px] text-stone-300 transition hover:border-[#81b64c] hover:text-[#a3d160] disabled:opacity-40"
              >
                {qq}
              </button>
            ))}
          </div>
        </div>

        {/* Conversation Log */}
        {p.chat.length > 0 && (
          <ul
            className="mt-2.5 max-h-44 space-y-2 overflow-y-auto rounded-lg border border-[#33312d] bg-[#181715] p-2.5 text-xs"
            aria-live="polite"
          >
            {p.chat.slice(-10).map((m, i) => (
              <li
                key={i}
                className={
                  m.from === 'you'
                    ? 'ml-6 rounded-lg bg-[#302e2b] px-2.5 py-1.5 text-right text-stone-200'
                    : 'mr-4 rounded-lg border border-[#3a3834] bg-[#262522] px-2.5 py-1.5 text-stone-100'
                }
              >
                {m.from === 'you' ? (
                  <span>You: {m.text}</span>
                ) : (
                  <span>
                    <b className="text-[#a3d160]">{coach.name}:</b> {m.text}
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}

        {/* Free-form Question Input */}
        <form onSubmit={submit} className="mt-2.5 flex gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Ask about this move, variations, king safety, or endgame plan…"
            aria-label="Ask your coach"
            className="min-w-0 flex-1 rounded-md border border-[#3a3834] bg-[#1c1b19] px-3 py-1.5 text-xs text-stone-100 placeholder:text-stone-500 focus:border-[#81b64c] focus:outline-none"
          />
          <button
            type="submit"
            disabled={p.coachLoading}
            className="rounded-md bg-[#81b64c] px-3.5 py-1.5 text-xs font-bold text-[#1c1b19] transition hover:brightness-110 disabled:opacity-50"
          >
            Ask
          </button>
        </form>
      </div>
    </section>
  )
}
