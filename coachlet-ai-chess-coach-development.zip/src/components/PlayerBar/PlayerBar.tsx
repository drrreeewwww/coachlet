import type { PieceSymbol } from 'chess.js'
import { Clock } from 'lucide-react'
import Avatar from '@/components/CoachPanel/Avatar'
import { StauntonPieceSvg } from '@/components/Chessboard/StauntonPieces'
import type { CoachId, PlayerColor } from '@/types'

export function formatChessClock(ms: number): string {
  const clamped = Math.max(0, ms)
  if (clamped === 0) return '0:00.0'

  const totalSeconds = Math.floor(clamped / 1000)
  const hours = Math.floor(totalSeconds / 3600)
  const minutes = Math.floor((totalSeconds % 3600) / 60)
  const seconds = totalSeconds % 60

  // Show tenths of a second when under 20 seconds
  if (clamped < 20_000) {
    const tenths = Math.floor((clamped % 1000) / 100)
    return `0:${String(seconds).padStart(2, '0')}.${tenths}`
  }

  if (hours > 0) {
    return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
  }

  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
}

interface PlayerBarProps {
  name: string
  subtitle?: string
  rating: number
  avatarId: CoachId | 'player'
  avatarAccent: string
  pieceColor: PlayerColor
  capturedPieces: PieceSymbol[] // Pieces captured BY this player (so they are of the opposite color)
  materialAdvantage: number
  clockMs: number
  isClockActive: boolean
  isThinking?: boolean
  isFlagged?: boolean
}

export default function PlayerBar({
  name,
  subtitle,
  rating,
  avatarId,
  avatarAccent,
  pieceColor,
  capturedPieces,
  materialAdvantage,
  clockMs,
  isClockActive,
  isThinking,
  isFlagged,
}: PlayerBarProps) {
  const capturedPieceColor: PlayerColor = pieceColor === 'w' ? 'b' : 'w'
  const isLowTime = clockMs > 0 && clockMs < 30_000
  const formattedClock = formatChessClock(clockMs)

  return (
    <div className="flex w-full max-w-[676px] items-center justify-between gap-3 rounded-lg border border-[#3a3834] bg-[#262522] px-3 py-2 shadow-md">
      {/* Left: Avatar + Player Info + Captured Pieces */}
      <div className="flex min-w-0 items-center gap-2.5">
        <div className="relative">
          <Avatar id={avatarId} accent={avatarAccent} size={40} />
          <span
            title={pieceColor === 'w' ? 'Playing White' : 'Playing Black'}
            className={`absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-[#262522] ${
              pieceColor === 'w' ? 'bg-[#f4f4f0]' : 'bg-[#181715]'
            }`}
          />
        </div>

        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="truncate text-sm font-bold text-stone-100">
              {name}
            </span>
            <span className="font-mono text-xs font-semibold text-stone-400">
              ({rating})
            </span>
            {subtitle && (
              <span className="hidden rounded bg-[#33312e] px-1.5 py-0.5 text-[10px] font-medium text-stone-300 sm:inline-block">
                {subtitle}
              </span>
            )}
            {isThinking && (
              <span className="inline-flex items-center gap-1 rounded-full bg-[#81b64c]/18 px-2 py-0.5 text-[11px] font-semibold text-[#a3d160]">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#81b64c]" />
                Thinking…
              </span>
            )}
          </div>

          {/* Captured Pieces & Material Advantage Row */}
          <div className="mt-0.5 flex min-h-[18px] flex-wrap items-center gap-1">
            {capturedPieces.length > 0 ? (
              <div className="flex items-center -space-x-1.5">
                {capturedPieces.slice(0, 15).map((type, idx) => (
                  <span key={`${type}-${idx}`} className="inline-block h-4 w-4">
                    <StauntonPieceSvg type={type} color={capturedPieceColor} />
                  </span>
                ))}
              </div>
            ) : (
              <span className="text-[11px] text-stone-500">
                {pieceColor === 'w' ? 'White pieces' : 'Black pieces'}
              </span>
            )}
            {materialAdvantage > 0 && (
              <span className="ml-1 rounded bg-[#363430] px-1.5 py-0.2 font-mono text-[11px] font-bold text-stone-200">
                +{materialAdvantage}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right: Chess.com-style Digital Chess Clock */}
      <div
        role="timer"
        aria-label={`${name} clock ${formattedClock}`}
        className={`flex shrink-0 items-center gap-2 rounded-md px-3 py-1.5 font-mono text-base font-extrabold tracking-tight transition-all duration-150 sm:min-w-[116px] sm:justify-between sm:px-3.5 sm:text-lg ${
          isFlagged || clockMs <= 0
            ? 'border border-red-500/80 bg-[#8b1e1e] text-white shadow-[0_0_12px_rgba(220,38,38,0.4)]'
            : isClockActive && isLowTime
              ? 'border border-red-400/80 bg-[#b92b27] text-white shadow-[0_0_14px_rgba(220,38,38,0.35)]'
              : isClockActive
                ? pieceColor === 'w'
                  ? 'border border-white bg-[#f5f5f1] text-[#1c1b19] shadow-[0_2px_10px_rgba(255,255,255,0.18)]'
                  : 'border border-[#81b64c] bg-[#1c1b19] text-white shadow-[0_0_12px_rgba(129,182,76,0.28)]'
                : 'border border-[#383632] bg-[#1e1d1b] text-stone-400 opacity-80'
        }`}
      >
        <Clock
          className={`h-4 w-4 shrink-0 ${
            isClockActive
              ? isLowTime
                ? 'animate-bounce text-white'
                : pieceColor === 'w'
                  ? 'animate-spin text-[#4b4843] [animation-duration:4s]'
                  : 'animate-spin text-[#81b64c] [animation-duration:4s]'
              : 'text-stone-500'
          }`}
        />
        <span>{formattedClock}</span>
      </div>
    </div>
  )
}
