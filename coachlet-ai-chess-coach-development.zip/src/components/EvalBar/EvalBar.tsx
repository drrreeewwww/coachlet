import {
  formatScore,
  toCp,
  winPct,
  type Score,
} from '@/lib/evaluation/classify'

export default function EvalBar({
  score,
  flipped,
  thinking,
}: {
  score: Score
  flipped: boolean
  thinking?: boolean
}) {
  const cp = toCp(score)
  const whitePct = winPct(cp)
  const label = formatScore(score).replace(/^\+/, '')
  const whiteAhead = cp >= 0

  return (
    <div
      aria-label={`Position evaluation ${formatScore(score)}`}
      className="relative flex w-6 shrink-0 flex-col overflow-hidden rounded-[5px] bg-[#262421] shadow-lg ring-1 ring-black/50 select-none sm:w-7"
    >
      <div
        style={{ height: `${flipped ? whitePct : 100 - whitePct}%` }}
        className={`w-full transition-[height] duration-500 ease-out ${
          flipped ? 'bg-[#f0f0ed]' : 'bg-[#363431]'
        }`}
      />
      <div
        style={{ height: `${flipped ? 100 - whitePct : whitePct}%` }}
        className={`w-full transition-[height] duration-500 ease-out ${
          flipped ? 'bg-[#363431]' : 'bg-[#f0f0ed]'
        }`}
      />
      <span
        className={`pointer-events-none absolute inset-x-0 text-center font-mono text-[9.5px] font-extrabold tracking-tighter ${
          (whiteAhead && !flipped) || (!whiteAhead && flipped)
            ? 'bottom-1.5 text-[#262421]'
            : 'top-1.5 text-[#e7e5e4]'
        }`}
      >
        {label}
      </span>
      {thinking && (
        <span
          title="Engine analysing"
          className="pointer-events-none absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 animate-ping rounded-full bg-[#81b64c]"
        />
      )}
    </div>
  )
}
