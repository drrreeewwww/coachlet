import { useState } from 'react'
import { formatScore, toCp, type Score } from '@/lib/evaluation/classify'
import type { PVLine, PositionTactics } from '@/types'

export interface ActiveVariationReplay {
  lineIndex: number // 0, 1, or 2
  stepIndex: number // 0 .. line.steps.length - 1
}

interface Props {
  score: Score
  bestSan: string
  variations: PVLine[]
  tactics?: PositionTactics | null
  depth: number
  seldepth?: number
  thinking: boolean
  isHumanTurn: boolean
  activeReplay: ActiveVariationReplay | null
  onSelectReplay: (replay: ActiveVariationReplay | null) => void
  analysisDepth: number
  analysisTime: number
  multiPv: number
  showArrows: boolean
  onConfigChange: (patch: {
    analysisDepth?: number
    analysisTime?: number
    multiPv?: number
    showArrows?: boolean
  }) => void
}

const LINE_LABELS = ['1. Best line', '2. 2nd candidate', '3. 3rd candidate']
const LINE_COLORS = ['#81b64c', '#5aa9c9', '#f7c631']

export default function LiveAnalysisBar({
  score,
  bestSan,
  variations,
  tactics,
  depth,
  seldepth,
  thinking,
  isHumanTurn,
  activeReplay,
  onSelectReplay,
  analysisDepth,
  analysisTime,
  multiPv,
  showArrows,
  onConfigChange,
}: Props) {
  const [configOpen, setConfigOpen] = useState(false)
  const evalLabel = formatScore(score)
  const cp = toCp(score)

  // Only expose coaching recommendations when it is the human player's turn and analysis is complete
  const showHumanCoachingLines = isHumanTurn && !thinking
  const safeVariations = showHumanCoachingLines ? variations : []

  const activeLine =
    activeReplay !== null ? safeVariations[activeReplay.lineIndex] : null
  const activeStep =
    activeLine && activeReplay !== null
      ? activeLine.steps[activeReplay.stepIndex]
      : null

  return (
    <section
      aria-label="Stockfish Engine Coaching Analysis"
      className="mt-2.5 rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-md"
    >
      {/* Top Engine Status & Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#363430] pb-2">
        <div className="flex flex-wrap items-center gap-2">
          {/* Numerical Evaluation Badge */}
          <span
            className={`rounded px-2 py-0.5 font-mono text-xs font-extrabold shadow-xs ${
              cp >= 0
                ? 'bg-[#f0f0ed] text-[#1c1b19]'
                : 'border border-stone-600 bg-[#1c1b19] text-[#f0f0ed]'
            }`}
            title="White-perspective engine evaluation"
          >
            {evalLabel}
          </span>

          {/* Best Move Recommendation (Only on Human Turn after completed analysis) */}
          {showHumanCoachingLines && bestSan && (
            <span className="flex items-center gap-1 rounded border border-[#81b64c]/45 bg-[#81b64c]/15 px-2 py-0.5 text-xs font-medium text-[#b7e085]">
              <span className="text-[#81b64c]">★ Best:</span>
              <b className="font-mono text-xs text-white">{bestSan}</b>
            </span>
          )}

          {/* Engine Status & Depth Indicator */}
          <span className="flex items-center gap-1.5 text-xs text-stone-400">
            <span
              className={`inline-block h-2 w-2 rounded-full ${
                thinking ? 'animate-pulse bg-amber-400' : 'bg-[#81b64c]'
              }`}
            />
            <span>
              {thinking
                ? isHumanTurn
                  ? 'Analysing your position…'
                  : 'Opponent turn'
                : `Stockfish 19 WASM • Depth ${depth || analysisDepth}${seldepth ? `/${seldepth}` : ''}`}
            </span>
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => onConfigChange({ showArrows: !showArrows })}
            aria-pressed={showArrows}
            className={`rounded border px-2.5 py-1 text-xs font-semibold transition ${
              showArrows
                ? 'border-[#81b64c]/70 bg-[#81b64c]/18 text-[#a3d160]'
                : 'border-[#3a3834] bg-[#1e1d1b] text-stone-400 hover:bg-[#302e2b]'
            }`}
          >
            {showArrows ? '↗ Coaching Arrows: ON' : '↗ Coaching Arrows: OFF'}
          </button>
          <button
            type="button"
            onClick={() => setConfigOpen(!configOpen)}
            aria-expanded={configOpen}
            className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-1 text-xs text-stone-300 hover:bg-[#302e2b]"
          >
            ⚙ Engine
          </button>
        </div>
      </div>

      {/* Configurable Depth & Calculation Time Drawer */}
      {configOpen && (
        <div className="mt-2.5 grid gap-3 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-xs sm:grid-cols-3">
          <label className="flex flex-col gap-1 text-stone-300">
            <span>
              Analysis Depth: <b className="text-[#81b64c]">{analysisDepth}</b>
            </span>
            <input
              type="range"
              min={8}
              max={20}
              step={1}
              value={analysisDepth}
              onChange={(e) =>
                onConfigChange({ analysisDepth: Number(e.target.value) })
              }
              className="accent-[#81b64c]"
            />
          </label>
          <label className="flex flex-col gap-1 text-stone-300">
            <span>
              Analysis Time:{' '}
              <b className="text-[#81b64c]">{analysisTime} ms</b>
            </span>
            <input
              type="range"
              min={300}
              max={2500}
              step={100}
              value={analysisTime}
              onChange={(e) =>
                onConfigChange({ analysisTime: Number(e.target.value) })
              }
              className="accent-[#81b64c]"
            />
          </label>
          <label className="flex flex-col gap-1 text-stone-300">
            <span>
              Candidate Lines (MultiPV):{' '}
              <b className="text-[#81b64c]">{multiPv}</b>
            </span>
            <select
              value={multiPv}
              onChange={(e) =>
                onConfigChange({ multiPv: Number(e.target.value) })
              }
              className="rounded border border-[#3a3834] bg-[#262522] px-2 py-1 text-stone-200"
            >
              <option value={1}>1 (Best line only)</option>
              <option value={2}>2 (Top 2 lines)</option>
              <option value={3}>3 (Top 3 lines)</option>
            </select>
          </label>
        </div>
      )}

      {/* Active Variation Replay Controls Banner */}
      {activeLine && activeReplay && (
        <div className="mt-2.5 rounded-lg border border-[#81b64c]/60 bg-[#1e261a] p-2.5 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="rounded bg-[#81b64c] px-2 py-0.5 font-bold text-[#1b1a17]">
                Replaying{' '}
                {LINE_LABELS[activeReplay.lineIndex] ??
                  `Line #${activeReplay.lineIndex + 1}`}
              </span>
              {activeStep && (
                <span className="text-stone-200">
                  Move {activeReplay.stepIndex + 1}/{activeLine.steps.length}:{' '}
                  <b className="font-mono text-[#a3d160]">{activeStep.san}</b> (
                  {activeStep.from} → {activeStep.to}) • Eval:{' '}
                  <b className="font-mono text-white">
                    {formatScore(activeStep.score)}
                  </b>
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                disabled={activeReplay.stepIndex <= 0}
                onClick={() =>
                  onSelectReplay({
                    lineIndex: activeReplay.lineIndex,
                    stepIndex: 0,
                  })
                }
                className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2 py-1 text-stone-200 hover:bg-[#302e2b] disabled:opacity-40"
              >
                ⏮
              </button>
              <button
                type="button"
                disabled={activeReplay.stepIndex <= 0}
                onClick={() =>
                  onSelectReplay({
                    lineIndex: activeReplay.lineIndex,
                    stepIndex: Math.max(0, activeReplay.stepIndex - 1),
                  })
                }
                className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2 py-1 text-stone-200 hover:bg-[#302e2b] disabled:opacity-40"
              >
                ◀ Prev
              </button>
              <button
                type="button"
                disabled={
                  activeReplay.stepIndex >= activeLine.steps.length - 1
                }
                onClick={() =>
                  onSelectReplay({
                    lineIndex: activeReplay.lineIndex,
                    stepIndex: Math.min(
                      activeLine.steps.length - 1,
                      activeReplay.stepIndex + 1
                    ),
                  })
                }
                className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2 py-1 text-stone-200 hover:bg-[#302e2b] disabled:opacity-40"
              >
                Next ▶
              </button>
              <button
                type="button"
                onClick={() => onSelectReplay(null)}
                className="rounded bg-[#81b64c] px-2.5 py-1 font-bold text-[#1b1a17] hover:brightness-110"
              >
                ↩ Live Board
              </button>
            </div>
          </div>

          <div className="mt-2 flex flex-wrap items-center gap-1">
            {activeLine.steps.map((st, sIdx) => {
              const isCur = sIdx === activeReplay.stepIndex
              return (
                <button
                  key={`${st.uci}-${sIdx}`}
                  type="button"
                  onClick={() =>
                    onSelectReplay({
                      lineIndex: activeReplay.lineIndex,
                      stepIndex: sIdx,
                    })
                  }
                  className={`rounded px-2 py-0.5 font-mono text-xs transition ${
                    isCur
                      ? 'bg-[#81b64c] font-bold text-[#1b1a17]'
                      : 'bg-[#1e1d1b] text-stone-300 hover:bg-[#302e2b]'
                  }`}
                >
                  {sIdx + 1}. {st.san}{' '}
                  <span className="text-[10px] opacity-75">
                    ({formatScore(st.score)})
                  </span>
                </button>
              )
            })}
          </div>
        </div>
      )}

      {/* Three Principal Variations List (Only shown on Human Turn after analysis completes) */}
      <div className="mt-2 space-y-1.5">
        {!isHumanTurn ? (
          <p className="py-1 text-xs text-stone-400">
            Opponent is on move — coaching arrows and candidate variations are
            exclusively shown on your turn.
          </p>
        ) : thinking ? (
          <p className="py-1 text-xs text-stone-400">
            Stockfish is completing full-depth analysis for your turn…
          </p>
        ) : safeVariations.length > 0 ? (
          safeVariations.slice(0, multiPv).map((v, idx) => {
            const isSelectedLine = activeReplay?.lineIndex === idx
            const lineScore = formatScore(v.score)
            const lineCp = toCp(v.score)
            const label = LINE_LABELS[idx] ?? `${idx + 1}. Candidate`
            const dotColor = LINE_COLORS[idx] ?? '#8aa4b8'

            return (
              <div
                key={v.multipv}
                className={`flex flex-wrap items-center justify-between gap-2 rounded-md border px-2.5 py-1.5 text-xs transition ${
                  isSelectedLine
                    ? 'border-[#81b64c]/70 bg-[#81b64c]/12'
                    : 'border-[#34322e] bg-[#1e1d1b] hover:border-[#46433e]'
                }`}
              >
                <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5">
                  <span
                    className="inline-block h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: dotColor }}
                  />
                  <span className="shrink-0 font-semibold text-stone-300">
                    {label}:
                  </span>
                  <span
                    className={`shrink-0 rounded px-1.5 py-0.5 font-mono text-[11px] font-bold ${
                      lineCp >= 0
                        ? 'bg-stone-200 text-stone-900'
                        : 'border border-stone-600 bg-stone-900 text-stone-200'
                    }`}
                  >
                    {lineScore}
                  </span>
                  <div className="flex flex-wrap items-center gap-1 font-mono">
                    {v.steps.map((step, sIdx) => {
                      const isStepActive =
                        isSelectedLine && activeReplay?.stepIndex === sIdx
                      return (
                        <button
                          key={`${step.uci}-${sIdx}`}
                          type="button"
                          onClick={() =>
                            onSelectReplay({ lineIndex: idx, stepIndex: sIdx })
                          }
                          className={`rounded px-1.5 py-0.5 transition ${
                            isStepActive
                              ? 'bg-[#81b64c] font-bold text-[#1b1a17]'
                              : sIdx === 0
                                ? 'font-bold text-[#a3d160] hover:bg-[#302e2b]'
                                : 'text-stone-300 hover:bg-[#302e2b] hover:text-white'
                          }`}
                        >
                          {step.san}
                        </button>
                      )
                    })}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onSelectReplay(
                      isSelectedLine ? null : { lineIndex: idx, stepIndex: 0 }
                    )
                  }
                  className="shrink-0 rounded border border-[#3a3834] bg-[#262522] px-2 py-0.5 text-[11px] text-stone-300 hover:border-[#81b64c] hover:text-[#a3d160]"
                >
                  {isSelectedLine ? 'Exit' : '▶ Preview'}
                </button>
              </div>
            )
          })
        ) : (
          <p className="py-1 text-xs text-stone-400">
            Ready to analyse your next position.
          </p>
        )}
      </div>

      {/* Tactical Threats & Defensive Resources Strip */}
      {showHumanCoachingLines &&
        tactics &&
        (tactics.opponentThreat ||
          tactics.tacticalMotifs.length > 0 ||
          tactics.defensiveResources.length > 0) && (
          <div className="mt-2 flex flex-wrap gap-1.5 border-t border-[#363430] pt-2 text-[11px]">
            {tactics.opponentThreat && (
              <span className="rounded border border-red-500/40 bg-red-950/35 px-2 py-0.5 text-red-200">
                <b className="text-red-400">Threat:</b>{' '}
                {tactics.opponentThreat.description}
              </span>
            )}
            {tactics.defensiveResources.map((d, i) => (
              <span
                key={i}
                className="rounded border border-sky-500/40 bg-sky-950/35 px-2 py-0.5 text-sky-200"
              >
                <b className="text-sky-400">Defence:</b> {d}
              </span>
            ))}
            {tactics.tacticalMotifs.slice(0, 2).map((m, i) => (
              <span
                key={i}
                className="rounded border border-amber-500/40 bg-amber-950/30 px-2 py-0.5 text-amber-200"
              >
                ⚡ {m}
              </span>
            ))}
          </div>
        )}
    </section>
  )
}
