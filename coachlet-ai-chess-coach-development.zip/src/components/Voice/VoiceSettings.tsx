'use client'

import { useState } from 'react'
import { Download, Loader2, Play, Square, Trash2, Volume2, X } from 'lucide-react'
import { useSettings } from '@/lib/useSettings'
import { COACHES } from '@/lib/coaching/coaches'
import { speak, stopSpeaking, setSpeechVolume } from '@/lib/voice/speak'
import { spokenPreview } from '@/lib/voice/speechWriter'
import { VOICE_PROVIDERS, COACH_VOICE_PROFILES } from '@/lib/voice/voiceConfig'
import { KOKORO_VOICES, cancelKokoroDownload, deleteKokoroModel, downloadKokoro, initKokoro } from '@/lib/voice/kokoro'
import { useSpeechStatus, engineLabel } from '@/components/CoachPanel/VoiceControls'
import type { CoachId, VoiceProviderId } from '@/types'

/** Fixed comparison script — identical text for every voice (Part 2.5). */
export const VOICE_SCRIPT: Array<{ label: string; text: string }> = [
  { label: '1 · Encouragement', text: "Nice one. You've developed your pieces well and your king is safe. Keep that rhythm going." },
  { label: '2 · Tactical explanation', text: 'Look at f7. Your bishop on c4 and the queen are both aiming there, so Bxf7+ would win a pawn and drag the king into the open.' },
  { label: '3 · Blunder explanation', text: "That one hurts. Qxd5?? drops the queen to Nxd5, and you can't recover from that. Nf3 was the calm move, developing and covering the centre." },
  { label: '4 · Positional explanation', text: "The structure is closed, so there's no rush. Reroute the knight from b1 to d2 and then f1, add pressure on the kingside, and only open the position when your pieces are ready. Black's light-squared bishop is quite passive here, which is the long-term story of this game." },
  { label: '5 · Notation', text: 'After 1. e4 e5 2. Nf3 Nc6 3. Bb5, White can castle O-O, or play Rfe1, Qxd5, and later e8=Q+ if everything goes well. Qh7# would end it.' },
  { label: '6 · Opening terminology', text: 'The Najdorf, the Caro-Kann, the Grünfeld, the Réti, Alekhine’s Defence and the Ruy Lopez all lead to very different pawn structures. A fianchetto, a zugzwang and en passant show up constantly.' },
  { label: '7 · Checkmate', text: "And that's checkmate! Queen to h7, protected by the knight. Beautifully done. Want to look at how you got there?" },
]

const toggleRow = 'flex min-h-11 items-center justify-between gap-3 rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2'

export default function VoiceSettings() {
  const [s, set] = useSettings()
  const { sp, kk } = useSpeechStatus()
  const [scriptIdx, setScriptIdx] = useState(0)
  const [custom, setCustom] = useState('After Nf3 and Bc4 in the Ruy Lopez, Stockfish recommends O-O (+0.8) instead of Bxf7+ (−140 cp). Then Rfe1 and a fianchetto.')
  const [testCoach, setTestCoach] = useState<CoachId>('vale')
  const [err, setErr] = useState<string | null>(null)

  const autoMode = s.autoSpeak ? 'all' : s.autoSpeakCriticalOnly ? 'critical' : 'off'
  const say = (text: string, coach: CoachId, voiceId?: string) =>
    speak(text, coach, { speed: s.speed, volume: s.voiceVolume, provider: s.voiceProvider, voiceId: voiceId ?? s.kokoroVoice })

  const busyDownload = kk.status === 'downloading'
  const modelReady = kk.status === 'downloaded' || kk.status === 'ready' || kk.status === 'loading'
  const mb = (n: number) => (n / 1e6).toFixed(0)

  const doDownload = async () => {
    setErr(null)
    try {
      const ok = await downloadKokoro()
      if (ok) {
        set({ voiceProvider: 'kokoro' })
        await initKokoro().catch((e: Error) => setErr(e.message))
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : String(e))
    }
  }

  return (
    <section id="voice" className="scroll-mt-4 rounded-xl border border-[#3a3834] bg-[#262522] p-4 shadow-lg sm:p-5">
      <div className="flex items-center gap-2 border-b border-[#363430] pb-3">
        <Volume2 className="h-5 w-5 text-[#81b64c]" aria-hidden />
        <div>
          <h2 className="text-base font-extrabold text-white">Coach voice</h2>
          <p className="text-xs text-stone-400">Local and free. No cloud TTS, no API keys. Current engine: <b className="text-stone-200">{engineLabel(s.voiceProvider, kk)}</b></p>
        </div>
      </div>

      {/* Engine choice */}
      <div className="mt-4 grid gap-2.5 sm:grid-cols-2" role="radiogroup" aria-label="Voice engine">
        {VOICE_PROVIDERS.map((vp) => {
          const active = s.voiceProvider === vp.id
          return (
            <button key={vp.id} type="button" role="radio" aria-checked={active} onClick={() => set({ voiceProvider: vp.id as VoiceProviderId })}
              className={`flex flex-col items-start rounded-lg border p-3 text-left transition ${active ? 'border-[#81b64c] bg-[#81b64c]/15 ring-1 ring-[#81b64c]' : 'border-[#3a3834] bg-[#1e1d1b] hover:bg-[#2c2a27]'}`}>
              <span className="text-xs font-extrabold text-white">{vp.name}</span>
              <span className="mt-0.5 rounded bg-[#302e2b] px-2 py-0.5 text-[10px] font-semibold text-[#a3d160]">{vp.badge}</span>
              <span className="mt-1 text-[11px] leading-relaxed text-stone-400">{vp.description}</span>
            </button>
          )
        })}
      </div>

      {/* Model download */}
      <div className="mt-3 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <b className="text-stone-100">Kokoro-82M model (int8)</b>
            <p className="text-[11px] text-stone-400" role="status" aria-live="polite">
              {kk.status === 'unsupported' && 'Not supported in this browser (needs Web Workers, CacheStorage and WebAssembly). The browser voice is used.'}
              {kk.status === 'not-downloaded' && 'Not downloaded. About 92 MB from Hugging Face, stored in your browser cache. Nothing is sent anywhere afterwards.'}
              {kk.status === 'downloading' && `Downloading… ${mb(kk.receivedBytes)} / ${mb(kk.totalBytes)} MB (${Math.round(kk.progress * 100)}%)`}
              {kk.status === 'downloaded' && 'Downloaded and cached. It loads the first time the coach speaks.'}
              {kk.status === 'loading' && 'Loading the model into memory…'}
              {kk.status === 'ready' && 'Loaded and ready.'}
              {kk.status === 'error' && `Error: ${kk.error ?? 'unknown'}. You can retry; the browser voice is used meanwhile.`}
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            {busyDownload ? (
              <button type="button" onClick={cancelKokoroDownload} className="inline-flex min-h-10 items-center gap-1 rounded border border-red-500/60 px-3 py-1.5 font-bold text-red-300 hover:bg-red-500/10">
                <X className="h-3.5 w-3.5" aria-hidden /> Cancel download
              </button>
            ) : !modelReady && kk.status !== 'unsupported' ? (
              <button type="button" onClick={doDownload} className="inline-flex min-h-10 items-center gap-1 rounded bg-[#81b64c] px-3 py-1.5 font-bold text-[#1c1b19] hover:brightness-110">
                <Download className="h-3.5 w-3.5" aria-hidden /> {kk.status === 'error' ? 'Retry download' : 'Download voice'}
              </button>
            ) : null}
            {kk.status === 'loading' && <Loader2 className="h-4 w-4 animate-spin text-[#81b64c]" aria-label="Loading" />}
            {modelReady && (
              <button type="button" onClick={() => void deleteKokoroModel()} className="inline-flex min-h-10 items-center gap-1 rounded border border-[#3a3834] px-3 py-1.5 text-stone-300 hover:bg-[#302e2b]">
                <Trash2 className="h-3.5 w-3.5" aria-hidden /> Remove model
              </button>
            )}
          </div>
        </div>
        {busyDownload && (
          <div className="mt-2 h-2 overflow-hidden rounded bg-[#33312d]" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(kk.progress * 100)}>
            <div className="h-full bg-[#81b64c] transition-[width]" style={{ width: `${kk.progress * 100}%` }} />
          </div>
        )}
        {err && <p className="mt-2 text-red-300">{err}</p>}
      </div>

      {/* Toggles and sliders */}
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="space-y-2.5 text-xs text-stone-200">
          <label className={toggleRow}>
            <span>Enable coach voice</span>
            <input type="checkbox" checked={s.voice} onChange={(e) => { set({ voice: e.target.checked }); if (!e.target.checked) stopSpeaking() }} className="h-4 w-4 accent-[#81b64c]" />
          </label>
          <label className={toggleRow}>
            <span>Automatic speech</span>
            <select value={autoMode} onChange={(e) => {
              const v = e.target.value
              set({ autoSpeak: v === 'all', autoSpeakCriticalOnly: v === 'critical' })
            }} className="rounded border border-[#3a3834] bg-[#141312] px-2 py-1.5 text-stone-100">
              <option value="off">Off (use Speak button)</option>
              <option value="critical">Critical moments only</option>
              <option value="all">Every coaching message</option>
            </select>
          </label>
        </div>
        <div className="space-y-2.5 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-xs text-stone-200">
          <label className="flex items-center justify-between gap-3">
            <span>Speed: <b className="text-[#a3d160]">{s.speed.toFixed(1)}×</b></span>
            <input type="range" min={0.7} max={1.4} step={0.1} value={s.speed} onChange={(e) => set({ speed: Number(e.target.value) })} className="w-36 accent-[#81b64c]" aria-label="Speaking speed" />
          </label>
          <label className="flex items-center justify-between gap-3">
            <span>Volume: <b className="text-[#a3d160]">{Math.round(s.voiceVolume * 100)}%</b></span>
            <input type="range" min={0.1} max={1} step={0.05} value={s.voiceVolume} onChange={(e) => { const v = Number(e.target.value); set({ voiceVolume: v }); setSpeechVolume(v) }} className="w-36 accent-[#81b64c]" aria-label="Voice volume" />
          </label>
          <p className="text-[10px] text-stone-500">Kokoro: speed is applied inside the model (pitch-preserving); volume through a Web Audio gain stage. Browser voice: rate and volume per phrase.</p>
        </div>
      </div>

      {/* Voice picker + previews */}
      <div className="mt-4 rounded-lg border border-[#3a3834] bg-[#1c1b19] p-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <b className="text-[#a3d160]">Voice &amp; preview</b>
          <label className="flex items-center gap-2 text-stone-300">
            Script
            <select value={scriptIdx} onChange={(e) => setScriptIdx(Number(e.target.value))} className="rounded border border-[#3a3834] bg-[#141312] px-2 py-1.5 text-stone-100">
              {VOICE_SCRIPT.map((v, i) => <option key={v.label} value={i}>{v.label}</option>)}
            </select>
          </label>
        </div>
        <p className="mt-1.5 rounded bg-[#141312] p-2 text-[11px] text-stone-400">{VOICE_SCRIPT[scriptIdx].text}</p>
        <div className="mt-2 grid gap-2 sm:grid-cols-2 lg:grid-cols-3" role="radiogroup" aria-label="Kokoro voice">
          <div className={`flex items-center justify-between gap-2 rounded-lg border p-2 ${s.kokoroVoice === 'coach' ? 'border-[#81b64c] bg-[#81b64c]/10' : 'border-[#3a3834]'}`}>
            <button type="button" role="radio" aria-checked={s.kokoroVoice === 'coach'} onClick={() => set({ kokoroVoice: 'coach' })} className="min-h-9 flex-1 text-left">
              <b className="block text-stone-100">Coach default</b>
              <span className="text-[10px] text-stone-400">Each coach uses their own voice</span>
            </button>
          </div>
          {KOKORO_VOICES.map((v) => (
            <div key={v.id} className={`flex items-center justify-between gap-2 rounded-lg border p-2 ${s.kokoroVoice === v.id ? 'border-[#81b64c] bg-[#81b64c]/10' : 'border-[#3a3834]'}`}>
              <button type="button" role="radio" aria-checked={s.kokoroVoice === v.id} onClick={() => set({ kokoroVoice: v.id })} className="min-h-9 flex-1 text-left">
                <b className="block text-stone-100">{v.label}</b>
                <span className="text-[10px] text-stone-400">{v.accent} · {v.gender} · grade {v.grade}</span>
              </button>
              <button type="button" onClick={() => say(VOICE_SCRIPT[scriptIdx].text, testCoach, v.id)} aria-label={`Preview ${v.label}`} className="inline-flex h-9 w-9 items-center justify-center rounded border border-[#3a3834] text-[#a3d160] hover:bg-[#302e2b]">
                <Play className="h-3.5 w-3.5" aria-hidden />
              </button>
            </div>
          ))}
        </div>
        {s.voiceProvider === 'kokoro' && !modelReady && <p className="mt-2 text-[11px] text-amber-300/90">Previews use the browser voice until the Kokoro model is downloaded.</p>}
      </div>

      {/* Coach tester + notation tester */}
      <div className="mt-4 rounded-lg border border-[#3a3834] bg-[#1c1b19] p-3 text-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <b className="text-[#a3d160]">Coach delivery &amp; notation tester</b>
          <div className="flex items-center gap-1.5">
            {COACHES.map((c) => (
              <button key={c.id} type="button" aria-pressed={testCoach === c.id} onClick={() => { setTestCoach(c.id); say(custom, c.id, 'coach') }}
                className={`min-h-9 rounded px-2.5 py-1 font-semibold ${testCoach === c.id ? 'bg-[#81b64c] text-[#1c1b19]' : 'border border-[#3a3834] text-stone-300 hover:bg-[#302e2b]'}`}>
                {c.name}
              </button>
            ))}
            <button type="button" onClick={stopSpeaking} disabled={sp.status === 'idle'} className="inline-flex min-h-9 items-center gap-1 rounded border border-[#3a3834] px-2.5 py-1 text-stone-300 hover:bg-[#302e2b] disabled:opacity-40">
              <Square className="h-3 w-3" aria-hidden /> Stop
            </button>
          </div>
        </div>
        <p className="mt-1 text-[10px] text-stone-500">{COACH_VOICE_PROFILES[testCoach].inspirationNote} Default voice: {COACH_VOICE_PROFILES[testCoach].kokoroVoice}.</p>
        <textarea value={custom} onChange={(e) => setCustom(e.target.value)} rows={3} aria-label="Text to speak" className="mt-2 w-full rounded border border-[#3a3834] bg-[#141312] p-2 text-stone-200" />
        <p className="mt-1 text-[10px] font-semibold text-stone-400">Spoken as:</p>
        <p className="rounded bg-[#141312] p-2 text-[11px] text-[#a3d160]">{spokenPreview(custom)}</p>
        {sp.notice && <p className="mt-2 text-[11px] text-amber-300/90">{sp.notice}</p>}
      </div>
    </section>
  )
}
