'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, type ReactNode } from 'react'
import { BarChart3, BookOpen, Home, Settings, Swords } from 'lucide-react'
import { stopSpeaking } from '@/lib/voice/speak'

export const NAV_ITEMS = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/play', label: 'Play', icon: Swords },
  { href: '/openings', label: 'Openings', icon: BookOpen },
  { href: '/review', label: 'Review', icon: BarChart3 },
  { href: '/settings', label: 'Settings', icon: Settings },
] as const

function isActive(path: string, href: string) {
  return href === '/' ? path === '/' : path === href || path.startsWith(href + '/')
}

/**
 * App frame. The workspace uses dynamic viewport height; on md+ a left rail
 * (icons at md, labels at xl) and below md a bottom tab bar with safe-area padding.
 * Pages render inside <main>, which is the actual workspace the board sizes against.
 */
export default function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname()

  // Any route change cancels coach speech so old audio never leaks into a new view.
  useEffect(() => {
    stopSpeaking()
  }, [path])

  return (
    <div className="flex h-dvh w-full flex-col overflow-hidden bg-[#1e1d1b] pl-[env(safe-area-inset-left)] pr-[env(safe-area-inset-right)] md:flex-row">
      <aside
        className="hidden shrink-0 flex-col border-r border-[#34322e] bg-[#262522] md:flex md:w-[68px] xl:w-[210px]"
        aria-label="Primary"
      >
        <Link href="/" className="flex items-center gap-2.5 px-3.5 py-4 xl:px-4" aria-label="Coachlet home">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#81b64c] text-xl font-black text-[#1c1b19]">♞</span>
          <span className="hidden min-w-0 xl:block">
            <span className="block text-base font-extrabold leading-none text-white">Coachlet</span>
            <span className="block text-[10px] font-medium text-[#a3d160]">AI Chess Coach</span>
          </span>
        </Link>
        <nav className="flex flex-1 flex-col gap-1 px-2 py-2">
          {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
            const active = isActive(path, href)
            return (
              <Link
                key={href}
                href={href}
                aria-current={active ? 'page' : undefined}
                aria-label={label}
                title={label}
                className={`flex min-h-11 items-center justify-center gap-3 rounded-lg px-3 text-sm font-bold transition xl:justify-start ${
                  active ? 'bg-[#81b64c] text-[#1c1b19]' : 'text-stone-300 hover:bg-[#33312d] hover:text-white'
                }`}
              >
                <Icon className="h-5 w-5 shrink-0" aria-hidden />
                <span className="hidden xl:inline">{label}</span>
              </Link>
            )
          })}
        </nav>
        <p className="hidden px-4 py-3 text-[10px] text-stone-500 xl:block">Stockfish 19 · local-first</p>
      </aside>

      <main className="min-h-0 min-w-0 flex-1 overflow-y-auto overflow-x-hidden">{children}</main>

      <nav
        className="safe-pb flex shrink-0 border-t border-[#34322e] bg-[#262522] md:hidden"
        aria-label="Primary"
      >
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = isActive(path, href)
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? 'page' : undefined}
              className={`flex min-h-14 flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-bold ${
                active ? 'text-[#a3d160]' : 'text-stone-400'
              }`}
            >
              <Icon className="h-5 w-5" aria-hidden />
              {label}
            </Link>
          )
        })}
      </nav>
    </div>
  )
}
