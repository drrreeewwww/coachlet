'use client'

import type { FamilyInfo } from '@/lib/openings/familyInfo'
import type { OpeningEntry } from '@/lib/openings/catalogue'

interface Props {
  entry: OpeningEntry | null
  plyOfEntry: number
  cursor: number
  info: FamilyInfo | null
  curated: boolean
  insights: string[]
  lineLabel: string
}

const List = ({ title, items }: { title: string; items: string[] }) => (
  <div>
    <h3 className="text-[11px] font-bold uppercase tracking-wide text-[#a3d160]">{title}</h3>
    <ul className="mt-1 list-disc space-y-0.5 pl-4 text-xs leading-relaxed text-stone-300">{items.map((t) => <li key={t}>{t}</li>)}</ul>
  </div>
)

export default function LearnPanel({ entry, plyOfEntry, cursor, info, curated, insights, lineLabel }: Props) {
  return (
    <section className="space-y-3 rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg" aria-label="Opening information">
      <div>
        {entry ? (
          <>
            <div className="flex items-center gap-2">
              <span className="rounded bg-[#81b64c] px-1.5 py-0.5 font-mono text-[11px] font-extrabold text-[#1c1b19]">{entry.eco}</span>
              <h2 className="text-base font-extrabold leading-tight text-white">{entry.name}</h2>
            </div>
            {cursor > plyOfEntry && <p className="mt-1 text-[11px] text-amber-300/90">The line has gone {cursor - plyOfEntry} ply beyond the last named position ({lineLabel}).</p>}
          </>
        ) : (
          <h2 className="text-base font-extrabold text-white">{cursor === 0 ? 'Starting position' : 'Unnamed position'}</h2>
        )}
      </div>

      {insights.length > 0 && (
        <div>
          <h3 className="text-[11px] font-bold uppercase tracking-wide text-[#a3d160]">In this position</h3>
          <ul className="mt-1 list-disc space-y-0.5 pl-4 text-xs leading-relaxed text-stone-200">{insights.map((t) => <li key={t}>{t}</li>)}</ul>
          <p className="mt-1 text-[10px] text-stone-500">Computed directly from the board after each move.</p>
        </div>
      )}

      {info && (
        <>
          <p className="text-xs leading-relaxed text-stone-200">{info.summary}</p>
          {!curated && <p className="text-[10px] text-stone-500">No hand-written notes for this specific opening yet — showing general guidance for its category.</p>}
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-1 2xl:grid-cols-2">
            <List title="Ideas for White" items={info.white} />
            <List title="Ideas for Black" items={info.black} />
          </div>
          <List title="Typical plans" items={info.plans} />
          <div>
            <h3 className="text-[11px] font-bold uppercase tracking-wide text-[#a3d160]">Pawn structure</h3>
            <p className="mt-1 text-xs leading-relaxed text-stone-300">{info.structure}</p>
          </div>
          <List title="Tactical motifs" items={info.motifs} />
          <List title="Common mistakes" items={info.mistakes} />
          {info.traps && <List title="Traps to know" items={info.traps} />}
        </>
      )}
    </section>
  )
}
