'use client'

import { useState } from 'react'
import { ExternalLink, KeyRound, Loader2, RefreshCw } from 'lucide-react'
import type { Analysis } from '@/lib/stockfish/engine'
import { formatScore } from '@/lib/evaluation/classify'
import { formatCount, moveShare, rankMoves, resultSplit, type ExplorerMove, type ExplorerResult, type ExplorerSource } from '@/lib/openings/explorerApi'

export interface ExplorerView {
  phase: 'idle' | 'loading' | 'done'
  result?: ExplorerResult
}

interface DbProps {
  state: ExplorerView
  source: ExplorerSource
  onSource: (s: ExplorerSource) => void
  token: string
  onToken: (t: string) => void
  onTestToken: () => Promise<string>
  onRefresh: () => void
  onPlay: (m: ExplorerMove) => void
  selectedUci: string | null
}

const pct = (n: number) => (n >= 10 ? n.toFixed(0) : n.toFixed(1))

export function DatabasePanel(p: DbProps) {
  const [draft, setDraft] = useState('')
  const [testMsg, setTestMsg] = useState<string | null>(null)
  const [testing, setTesting] = useState(false)
  const r = p.state.result
  const ok = r?.status === 'ok' ? r : null
  const ranked = ok ? rankMoves(ok.data) : []

  return (
    <section className="rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg" aria-label="Opening database statistics">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-extrabold text-white">Most played <span className="font-normal text-stone-400">· Lichess database</span></h2>
        <div className="flex items-center gap-1.5">
          <div className="flex overflow-hidden rounded-md border border-[#3a3834]" role="radiogroup" aria-label="Database">
            {(['masters', 'lichess'] as const).map((s) => (
              <button key={s} type="button" role="radio" aria-checked={p.source === s} onClick={() => p.onSource(s)} className={`min-h-9 px-2.5 text-[11px] font-bold ${p.source === s ? 'bg-[#81b64c] text-[#1c1b19]' : 'bg-[#1e1d1b] text-stone-300 hover:bg-[#33312d]'}`}>
                {s === 'masters' ? 'Masters' : 'Lichess players'}
              </button>
            ))}
          </div>
          <button type="button" onClick={p.onRefresh} aria-label="Refresh statistics from Lichess" title="Refresh" className="flex h-9 w-9 items-center justify-center rounded-md border border-[#3a3834] text-stone-300 hover:bg-[#33312d]">
            <RefreshCw className={`h-4 w-4 ${p.state.phase === 'loading' ? 'animate-spin' : ''}`} aria-hidden />
          </button>
        </div>
      </div>

      <div className="mt-2 min-h-[3rem]" aria-live="polite">
        {p.state.phase === 'loading' && !ok && <p className="flex items-center gap-2 text-xs text-stone-400"><Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Loading statistics…</p>}
        {r?.status === 'no-token' && (
          <p className="text-xs leading-relaxed text-stone-300">Lichess now requires a free personal API token for explorer statistics. Add one below to see real game counts. Until then the board, opening names, learning notes and engine analysis still work, and nothing is made up.</p>
        )}
        {r?.status === 'unauthorized' && <p className="text-xs text-red-300">Lichess rejected the token (HTTP 401/403). Check it and try again.</p>}
        {r?.status === 'rate-limited' && <p className="text-xs text-amber-300">Lichess rate limit hit. Requests are paused until {new Date(r.retryAt).toLocaleTimeString()} (≥ 60 s, as Lichess requires).</p>}
        {r?.status === 'offline' && <p className="text-xs text-amber-300">{r.message} Cached positions remain available.</p>}
        {r?.status === 'error' && r.message !== 'cancelled' && <p className="text-xs text-red-300">{r.message}</p>}
        {ok && (
          <p className="text-[11px] text-stone-400">
            {ok.data.total > 0 ? `${formatCount(ok.data.total)} games in this position` : 'No games recorded for this position'} · source: {ok.data.source === 'masters' ? 'Masters database' : 'Lichess players'} ·{' '}
            {ok.cached ? `cached ${new Date(ok.fetchedAt).toLocaleDateString()}${ok.stale ? ' (stale — could not refresh)' : ''}` : 'live from lichess.org'}
          </p>
        )}
      </div>

      {ok && ranked.length > 0 && (
        <div className="mt-1 overflow-x-auto">
          <table className="w-full min-w-[320px] text-xs">
            <caption className="sr-only">Moves played in this position, most popular first</caption>
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wide text-stone-500">
                <th className="py-1 pr-2 font-semibold">#</th><th className="py-1 pr-2 font-semibold">Move</th><th className="py-1 pr-2 font-semibold">Played</th><th className="py-1 font-semibold">White / draw / Black</th>
              </tr>
            </thead>
            <tbody>
              {ranked.map((m, i) => {
                const share = moveShare(m, ok.data)
                const rs = resultSplit(m)
                return (
                  <tr key={m.uci} className={`border-t border-[#33312d] ${p.selectedUci === m.uci ? 'bg-[#81b64c]/10' : ''}`}>
                    <td className="py-1 pr-2 text-stone-500">{i + 1}</td>
                    <td className="py-0.5 pr-2">
                      <button type="button" onClick={() => p.onPlay(m)} className="min-h-10 rounded px-2 font-mono text-sm font-bold text-white hover:bg-[#33312d]" aria-label={`Play ${m.san}, ${pct(share)} percent of games`}>{m.san}</button>
                    </td>
                    <td className="py-1 pr-2">
                      <div className="font-semibold text-stone-100">{pct(share)}%</div>
                      <div className="text-[10px] text-stone-500">{formatCount(m.total)} games{m.averageRating ? ` · avg ${m.averageRating}` : ''}</div>
                      <div className="mt-0.5 h-1 w-full overflow-hidden rounded bg-[#33312d]"><div className="h-full bg-[#81b64c]" style={{ width: `${Math.max(2, share)}%` }} /></div>
                    </td>
                    <td className="min-w-[110px] py-1">
                      <div className="flex h-5 overflow-hidden rounded text-[10px] font-bold leading-5" role="img" aria-label={`White ${pct(rs.white)}%, draws ${pct(rs.draws)}%, Black ${pct(rs.black)}%`}>
                        <div className="bg-stone-100 text-center text-stone-900" style={{ width: `${rs.white}%` }}>{rs.white >= 14 ? pct(rs.white) : ''}</div>
                        <div className="bg-stone-500 text-center text-white" style={{ width: `${rs.draws}%` }}>{rs.draws >= 14 ? pct(rs.draws) : ''}</div>
                        <div className="bg-stone-900 text-center text-stone-100 ring-1 ring-inset ring-stone-600" style={{ width: `${rs.black}%` }}>{rs.black >= 14 ? pct(rs.black) : ''}</div>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          <p className="mt-1 text-[10px] text-stone-500">Popularity ≠ strength: the most-played move is not necessarily the best one. Compare with the engine below.</p>
        </div>
      )}
      {ok && ranked.length === 0 && <p className="mt-1 text-xs text-stone-300">The database has no continuations for this position. You have left the known book; the board and engine still work.</p>}

      <details className="mt-3 rounded-md border border-[#33312d] bg-[#1e1d1b] p-2 text-xs" open={r?.status === 'no-token' || r?.status === 'unauthorized'}>
        <summary className="flex min-h-9 cursor-pointer items-center gap-1.5 font-semibold text-stone-200"><KeyRound className="h-3.5 w-3.5 text-[#81b64c]" aria-hidden /> Lichess API token {p.token ? '(saved)' : '(not set)'}</summary>
        <div className="mt-2 space-y-2">
          <p className="text-[11px] leading-relaxed text-stone-400">Create a free token (no scopes needed) at lichess.org. It is stored only in this browser and sent only to explorer.lichess.org.</p>
          <a href="https://lichess.org/account/oauth/token/create?description=Coachlet+opening+explorer" target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-[#a3d160] underline-offset-2 hover:underline">Create token on Lichess <ExternalLink className="h-3 w-3" aria-hidden /></a>
          <div className="flex gap-1.5">
            <input type="password" autoComplete="off" value={draft} onChange={(e) => setDraft(e.target.value)} placeholder={p.token ? '•••••••• (saved)' : 'lip_…'} aria-label="Lichess API token" className="min-h-10 min-w-0 flex-1 rounded border border-[#3a3834] bg-[#141312] px-2 text-stone-100" />
            <button type="button" disabled={!draft.trim()} onClick={() => { p.onToken(draft.trim()); setDraft(''); setTestMsg(null) }} className="min-h-10 rounded bg-[#81b64c] px-3 font-bold text-[#1c1b19] disabled:opacity-40">Save</button>
            {p.token && <button type="button" onClick={() => { p.onToken(''); setTestMsg(null) }} className="min-h-10 rounded border border-[#3a3834] px-3 text-stone-300 hover:bg-[#33312d]">Remove</button>}
          </div>
          {p.token && (
            <button type="button" disabled={testing} onClick={async () => { setTesting(true); setTestMsg(await p.onTestToken()); setTesting(false) }} className="min-h-9 rounded border border-[#3a3834] px-3 text-stone-200 hover:bg-[#33312d] disabled:opacity-50">{testing ? 'Testing…' : 'Test token'}</button>
          )}
          {testMsg && <p role="status" className="text-[11px] text-stone-300">{testMsg}</p>}
        </div>
      </details>
    </section>
  )
}

export interface EngineView {
  status: 'starting' | 'ready' | 'fallback'
  busy: boolean
  analysis: Analysis | null
  paused: boolean
}

export function EnginePanel({ e, onPlay }: { e: EngineView; onPlay: (uci: string) => void }) {
  return (
    <section className="rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg" aria-label="Engine analysis">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-extrabold text-white">Best by engine <span className="font-normal text-stone-400">· Stockfish 19</span></h2>
        {e.busy && <Loader2 className="h-4 w-4 animate-spin text-[#81b64c]" aria-label="Analysing" />}
      </div>
      <div aria-live="polite" className="mt-1.5">
        {e.status === 'fallback' && <p className="text-xs text-red-300">Stockfish could not start in this browser, so no engine analysis is available. The database and board still work.</p>}
        {e.status === 'starting' && <p className="text-xs text-stone-400">Starting Stockfish…</p>}
        {e.status === 'ready' && e.paused && !e.analysis && <p className="text-xs text-stone-400">Analysis resumes when playback stops.</p>}
        {e.status === 'ready' && !e.analysis && !e.paused && <p className="text-xs text-stone-400">Analysing…</p>}
        {e.analysis && e.analysis.variations.length === 0 && <p className="text-xs text-stone-400">No legal moves in this position.</p>}
        {e.analysis && e.analysis.variations.length > 0 && (
          <ul className="space-y-1">
            {e.analysis.variations.map((v, i) => (
              <li key={v.firstMove.uci}>
                <button type="button" onClick={() => onPlay(v.firstMove.uci)} className="flex min-h-11 w-full items-center gap-2 rounded-md px-2 py-1 text-left hover:bg-[#302e2b]" aria-label={`Play engine move ${v.firstMove.san}, evaluation ${formatScore(v.score)}`}>
                  <span className={`w-14 shrink-0 rounded px-1.5 py-0.5 text-center font-mono text-[11px] font-bold ${i === 0 ? 'bg-[#81b64c] text-[#1c1b19]' : 'bg-[#33312d] text-stone-200'}`}>{formatScore(v.score)}</span>
                  <span className="font-mono text-sm font-bold text-white">{v.firstMove.san}</span>
                  <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-stone-500">{v.sanMoves.slice(1, 6).join(' ')}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
        {e.analysis && e.analysis.depth > 0 && <p className="mt-1 text-[10px] text-stone-500">Depth {e.analysis.depth}, evaluation from White&apos;s point of view. Engine output, not database statistics.</p>}
      </div>
    </section>
  )
}
