'use client'

import { useMemo, useState } from 'react'
import { ChevronDown, ChevronRight, Search } from 'lucide-react'
import { CATEGORIES, browseCategory, searchOpenings, type Catalogue, type Category, type OpeningEntry } from '@/lib/openings/catalogue'

interface Props {
  cat: Catalogue | null
  loadError: string | null
  activeName: string | null
  onSelect: (e: OpeningEntry) => void
}

export default function OpeningLibrary({ cat, loadError, activeName, onSelect }: Props) {
  const [q, setQ] = useState('')
  const [category, setCategory] = useState<Category>('Popular')
  const [open, setOpen] = useState<string | null>(null)

  const results = useMemo(() => (cat && q.trim() ? searchOpenings(cat, q) : []), [cat, q])
  const rows = useMemo(() => (cat ? browseCategory(cat, category) : []), [cat, category])
  const variations = useMemo(() => {
    if (!cat || !open) return []
    const g = cat.families.get(open)
    return g ? [...g.entries].sort((a, b) => a.sans.length - b.sans.length || a.name.localeCompare(b.name)).slice(0, 60) : []
  }, [cat, open])

  const item = (e: OpeningEntry, key: string) => (
    <li key={key}>
      <button
        type="button"
        onClick={() => onSelect(e)}
        aria-current={activeName === e.name ? 'true' : undefined}
        className={`flex min-h-11 w-full items-start gap-2 rounded-md px-2 py-1.5 text-left text-xs transition hover:bg-[#302e2b] ${activeName === e.name ? 'bg-[#81b64c]/15 text-white' : 'text-stone-200'}`}
      >
        <span className="mt-0.5 shrink-0 rounded bg-[#33312d] px-1.5 py-0.5 font-mono text-[10px] font-bold text-[#a3d160]">{e.eco}</span>
        <span className="min-w-0">
          <span className="block font-semibold leading-snug">{e.name}</span>
          <span className="block truncate font-mono text-[10px] text-stone-500">{e.sans.slice(0, 8).join(' ')}{e.sans.length > 8 ? ' …' : ''}</span>
        </span>
      </button>
    </li>
  )

  return (
    <section className="flex min-h-0 flex-col rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg xl:max-h-[calc(100dvh-2rem)]" aria-label="Opening library">
      <h2 className="text-sm font-extrabold text-white">Opening library</h2>
      <label className="relative mt-2 block">
        <span className="sr-only">Search openings by name or ECO code</span>
        <Search className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-500" aria-hidden />
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search name or ECO (e.g. B90)"
          className="min-h-10 w-full rounded-md border border-[#3a3834] bg-[#1e1d1b] py-2 pl-8 pr-2 text-sm text-stone-100 placeholder:text-stone-500"
        />
      </label>

      {!q.trim() && (
        <div className="mt-2 flex flex-wrap gap-1" role="group" aria-label="Opening categories">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              aria-pressed={category === c}
              onClick={() => { setCategory(c); setOpen(null) }}
              className={`min-h-8 rounded-full px-2.5 py-1 text-[11px] font-semibold ${category === c ? 'bg-[#81b64c] text-[#1c1b19]' : 'bg-[#1e1d1b] text-stone-300 hover:bg-[#33312d]'}`}
            >
              {c}
            </button>
          ))}
        </div>
      )}

      <div className="mt-2 min-h-0 flex-1 overflow-y-auto pr-1" style={{ maxHeight: 'min(60dvh, 560px)' }}>
        {loadError && <p className="p-2 text-xs text-red-300">{loadError}</p>}
        {!cat && !loadError && <p className="p-2 text-xs text-stone-400">Loading opening catalogue…</p>}
        {cat && q.trim() && (
          <>
            <p className="px-1 pb-1 text-[11px] text-stone-400">{results.length} result{results.length === 1 ? '' : 's'}{results.length === 60 ? ' (showing the first 60)' : ''}</p>
            <ul>{results.map((e, i) => item(e, `${e.eco}-${e.name}-${i}`))}</ul>
            {results.length === 0 && <p className="p-2 text-xs text-stone-400">No openings match “{q}”.</p>}
          </>
        )}
        {cat && !q.trim() && (
          <ul>
            {rows.map((r) => {
              const expandable = category !== 'Gambits' && r.count > 1
              const isOpen = open === r.label
              return (
                <li key={r.label}>
                  <div className="flex items-center">
                    <button type="button" onClick={() => onSelect(r.main)} className={`flex min-h-11 min-w-0 flex-1 items-center gap-2 rounded-md px-2 py-1.5 text-left text-xs hover:bg-[#302e2b] ${activeName === r.main.name ? 'bg-[#81b64c]/15 text-white' : 'text-stone-200'}`}>
                      <span className="shrink-0 rounded bg-[#33312d] px-1.5 py-0.5 font-mono text-[10px] font-bold text-[#a3d160]">{r.main.eco}</span>
                      <span className="min-w-0 flex-1 truncate font-semibold">{r.label}</span>
                      <span className="shrink-0 text-[10px] text-stone-500">{r.count}</span>
                    </button>
                    {expandable && (
                      <button type="button" aria-expanded={isOpen} aria-label={`${isOpen ? 'Hide' : 'Show'} variations of ${r.label}`} onClick={() => setOpen(isOpen ? null : r.label)} className="flex h-11 w-9 items-center justify-center text-stone-400 hover:text-white">
                        {isOpen ? <ChevronDown className="h-4 w-4" aria-hidden /> : <ChevronRight className="h-4 w-4" aria-hidden />}
                      </button>
                    )}
                  </div>
                  {isOpen && <ul className="ml-3 border-l border-[#3a3834] pl-1">{variations.map((e, i) => item(e, `${e.name}-${i}`))}</ul>}
                </li>
              )
            })}
          </ul>
        )}
      </div>
      <p className="mt-2 text-[10px] leading-snug text-stone-500">Names &amp; ECO codes: lichess-org/chess-openings (CC0).</p>
    </section>
  )
}
