import { Trophy, RotateCcw, BarChart3, X } from 'lucide-react'
import Avatar from '@/components/CoachPanel/Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { accuracyOf } from '@/lib/evaluation/classify'
import type { MoveRecord } from '@/lib/review/record'
import type { CoachId, PlayerColor, TimeControlMinutes } from '@/types'

interface Props {
  open: boolean
  onClose: () => void
  result: '1-0' | '0-1' | '1/2-1/2' | '*'
  terminationTitle: string
  terminationDetail: string
  playerColor: PlayerColor
  coachId: CoachId
  elo: number
  timeControlMinutes: TimeControlMinutes
  moves: MoveRecord[]
  onPlayAgain: () => void
  onOpenSetup: () => void
  onReviewGame: () => void
}

export default function GameOverModal({
  open,
  onClose,
  result,
  terminationTitle,
  terminationDetail,
  playerColor,
  coachId,
  elo,
  timeControlMinutes,
  moves,
  onPlayAgain,
  onOpenSetup,
  onReviewGame,
}: Props) {
  if (!open || result === '*') return null

  const coach = COACHES.find((c) => c.id === coachId) ?? COACHES[0]
  const playerWon =
    (result === '1-0' && playerColor === 'w') ||
    (result === '0-1' && playerColor === 'b')
  const isDraw = result === '1/2-1/2'

  const playerMoves = moves.filter((m) => m.color === playerColor)
  const aiMoves = moves.filter((m) => m.color !== playerColor)

  const calcAcc = (arr: MoveRecord[]) =>
    arr.length > 0
      ? Math.round(
          arr.reduce((sum, m) => sum + accuracyOf(m.winLoss), 0) / arr.length
        )
      : 100

  const playerAcc = calcAcc(playerMoves)
  const aiAcc = calcAcc(aiMoves)

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Game Over Summary"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md overflow-hidden rounded-xl border border-[#3c3a36] bg-[#262522] text-stone-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Banner */}
        <div
          className={`relative flex flex-col items-center px-6 py-5 text-center ${
            playerWon
              ? 'bg-gradient-to-b from-[#81b64c]/30 to-[#262522]'
              : isDraw
                ? 'bg-gradient-to-b from-stone-500/25 to-[#262522]'
                : 'bg-gradient-to-b from-red-500/20 to-[#262522]'
          }`}
        >
          <button
            type="button"
            onClick={onClose}
            aria-label="Dismiss game over modal"
            className="absolute right-3 top-3 rounded-lg p-1.5 text-stone-400 hover:bg-[#33312d] hover:text-white"
          >
            <X className="h-4.5 w-4.5" />
          </button>

          <div
            className={`flex h-12 w-12 items-center justify-center rounded-full shadow-lg ${
              playerWon
                ? 'bg-[#81b64c] text-[#1c1b19]'
                : isDraw
                  ? 'bg-stone-600 text-white'
                  : 'bg-[#363430] text-stone-300'
            }`}
          >
            <Trophy className="h-6 w-6" />
          </div>

          <h2 className="mt-2.5 text-xl font-extrabold text-white">
            {terminationTitle}
          </h2>
          <p className="mt-0.5 text-xs text-stone-300">{terminationDetail}</p>
          <span className="mt-2 rounded-full border border-[#3c3a36] bg-[#1e1d1b] px-3 py-0.5 font-mono text-xs font-bold text-stone-300">
            Result: {result} •{' '}
            {timeControlMinutes === 60
              ? '1 Hour'
              : `${timeControlMinutes} min`}
          </span>
        </div>

        {/* Player vs Coach Accuracy Comparison */}
        <div className="px-5 py-4">
          <div className="grid grid-cols-3 items-center rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-center">
            <div className="flex flex-col items-center">
              <Avatar id="player" accent="#3b4d3e" size={40} />
              <span className="mt-1 text-xs font-bold text-white">You</span>
              <span className="text-[10px] text-stone-400">
                {playerColor === 'w' ? 'White' : 'Black'}
              </span>
              <span className="mt-1.5 rounded bg-[#2c2a27] px-2 py-0.5 font-mono text-sm font-extrabold text-[#a3d160]">
                {playerAcc}%
              </span>
            </div>

            <div className="flex flex-col items-center text-xs text-stone-400">
              <span className="font-bold uppercase tracking-wider text-stone-500">
                Accuracy
              </span>
              <span className="my-1 font-mono text-sm font-bold text-stone-300">
                vs
              </span>
              <span className="text-[11px]">{moves.length} plies</span>
            </div>

            <div className="flex flex-col items-center">
              <Avatar id={coach.id} accent={coach.accent} size={40} />
              <span className="mt-1 text-xs font-bold text-white">
                {coach.name}
              </span>
              <span className="text-[10px] text-stone-400">{elo} Elo</span>
              <span className="mt-1.5 rounded bg-[#2c2a27] px-2 py-0.5 font-mono text-sm font-extrabold text-stone-200">
                {aiAcc}%
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-4 space-y-2">
            {moves.length > 0 && (
              <button
                type="button"
                onClick={onReviewGame}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-[#81b64c] py-2.5 text-sm font-extrabold text-[#1c1b19] shadow-md transition hover:brightness-110"
              >
                <BarChart3 className="h-4 w-4" />
                Game Review & Move Breakdown
              </button>
            )}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={onPlayAgain}
                className="flex items-center justify-center gap-1.5 rounded-lg border border-[#3a3834] bg-[#302e2b] py-2 text-xs font-bold text-white transition hover:bg-[#3a3834]"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Rematch ({timeControlMinutes}m)
              </button>
              <button
                type="button"
                onClick={onOpenSetup}
                className="flex items-center justify-center gap-1.5 rounded-lg border border-[#3a3834] bg-[#1e1d1b] py-2 text-xs font-bold text-stone-300 transition hover:bg-[#302e2b] hover:text-white"
              >
                Change Time / Side
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
