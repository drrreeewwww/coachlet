import { Clock, Shield, Zap, Flame, Award, X } from 'lucide-react'
import Avatar from '@/components/CoachPanel/Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { TIME_CONTROL_OPTIONS } from '@/lib/settings'
import { bandFor } from '@/lib/stockfish/elo'
import type {
  CoachId,
  ColorChoice,
  TimeControlMinutes,
} from '@/types'

interface Props {
  open: boolean
  onClose: () => void
  selectedTime: TimeControlMinutes
  onSelectTime: (minutes: TimeControlMinutes) => void
  colorChoice: ColorChoice
  onSelectColor: (c: ColorChoice) => void
  coachId: CoachId
  onSelectCoach: (id: CoachId) => void
  elos: Record<CoachId, number>
  onChangeElo: (id: CoachId, elo: number) => void
  onStartGame: () => void
}

export default function NewGameSetupModal({
  open,
  onClose,
  selectedTime,
  onSelectTime,
  colorChoice,
  onSelectColor,
  coachId,
  onSelectCoach,
  elos,
  onChangeElo,
  onStartGame,
}: Props) {
  if (!open) return null

  const activeCoach = COACHES.find((c) => c.id === coachId) ?? COACHES[0]
  const currentElo = elos[coachId]

  const categoryIcon = (cat: string) => {
    if (cat === 'Bullet') return <Flame className="h-3.5 w-3.5 text-orange-400" />
    if (cat === 'Blitz') return <Zap className="h-3.5 w-3.5 text-amber-400" />
    if (cat === 'Rapid') return <Clock className="h-3.5 w-3.5 text-[#81b64c]" />
    return <Award className="h-3.5 w-3.5 text-sky-400" />
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="New Game Setup and Time Control Selection"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-xl border border-[#3c3a36] bg-[#262522] p-5 text-stone-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#363430] pb-3">
          <div className="flex items-center gap-2.5">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#81b64c]/20 text-[#81b64c]">
              <Clock className="h-4.5 w-4.5" />
            </span>
            <div>
              <h2 className="text-lg font-extrabold tracking-tight text-white">
                New Match Setup
              </h2>
              <p className="text-xs text-stone-400">
                Select time control, playing colour, and AI coach strength
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close setup modal"
            className="rounded-lg p-1.5 text-stone-400 hover:bg-[#33312d] hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Step 1: Selectable Time Controls (All 7 Required Options) */}
        <div className="mt-4">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-300">
              1. Time Control
            </span>
            <span className="text-xs text-[#a3d160]">
              Selected:{' '}
              <b>
                {
                  TIME_CONTROL_OPTIONS.find((t) => t.minutes === selectedTime)
                    ?.label
                }
              </b>
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            {TIME_CONTROL_OPTIONS.map((opt) => {
              const isSelected = opt.minutes === selectedTime
              return (
                <button
                  key={opt.minutes}
                  type="button"
                  onClick={() => onSelectTime(opt.minutes)}
                  aria-pressed={isSelected}
                  className={`flex flex-col items-start justify-between rounded-lg border p-2.5 text-left transition ${
                    isSelected
                      ? 'border-[#81b64c] bg-[#81b64c]/18 text-white shadow-[0_0_12px_rgba(129,182,76,0.22)] ring-1 ring-[#81b64c]'
                      : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:border-[#524f49] hover:bg-[#2c2a27]'
                  }`}
                >
                  <div className="flex w-full items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                      {opt.category}
                    </span>
                    {categoryIcon(opt.category)}
                  </div>
                  <span className="mt-1 text-sm font-extrabold text-white">
                    {opt.label}
                  </span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Step 2: Choose Your Side (White / Random / Black) */}
        <div className="mt-4">
          <span className="mb-2 block text-xs font-bold uppercase tracking-wider text-stone-300">
            2. Play As
          </span>
          <div className="grid grid-cols-3 gap-2.5">
            {(
              [
                { id: 'w', label: 'White', badge: '♔ Moves First' },
                { id: 'random', label: 'Random', badge: '⚖ 50 / 50' },
                { id: 'b', label: 'Black', badge: '♚ AI Moves First' },
              ] as Array<{ id: ColorChoice; label: string; badge: string }>
            ).map((side) => {
              const isSelected = colorChoice === side.id
              return (
                <button
                  key={side.id}
                  type="button"
                  onClick={() => onSelectColor(side.id)}
                  aria-pressed={isSelected}
                  className={`flex flex-col items-center rounded-lg border py-2.5 px-3 transition ${
                    isSelected
                      ? 'border-[#81b64c] bg-[#81b64c]/18 text-white ring-1 ring-[#81b64c]'
                      : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:bg-[#2c2a27]'
                  }`}
                >
                  <span className="text-sm font-bold">{side.label}</span>
                  <span className="mt-0.5 text-[11px] text-stone-400">
                    {side.badge}
                  </span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Step 3: Select AI Coach & Elo Rating */}
        <div className="mt-4">
          <span className="mb-2 block text-xs font-bold uppercase tracking-wider text-stone-300">
            3. AI Coach & Opponent Strength
          </span>
          <div className="grid grid-cols-3 gap-2">
            {COACHES.map((c) => {
              const isSel = c.id === coachId
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onSelectCoach(c.id)}
                  aria-pressed={isSel}
                  className={`flex flex-col items-center rounded-lg border p-2.5 text-center transition ${
                    isSel
                      ? 'border-[#81b64c] bg-[#81b64c]/18 text-white ring-1 ring-[#81b64c]'
                      : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:bg-[#2c2a27]'
                  }`}
                >
                  <Avatar id={c.id} accent={c.accent} size={42} />
                  <span className="mt-1.5 text-xs font-bold text-white">
                    {c.name}
                  </span>
                  <span className="text-[10px] text-stone-400">
                    {elos[c.id]} Elo
                  </span>
                </button>
              )
            })}
          </div>

          <div className="mt-3 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3">
            <div className="flex items-center justify-between text-xs">
              <span className="flex items-center gap-1.5 font-semibold text-stone-200">
                <Shield className="h-3.5 w-3.5 text-[#81b64c]" />
                {activeCoach.name} Rating:{' '}
                <b className="font-mono text-sm text-[#a3d160]">
                  {currentElo} Elo
                </b>
              </span>
              <span className="rounded bg-[#2c2a27] px-2 py-0.5 text-[11px] text-stone-300">
                {bandFor(currentElo)}
              </span>
            </div>
            <input
              type="range"
              min={300}
              max={3200}
              step={50}
              value={currentElo}
              onChange={(e) => onChangeElo(coachId, Number(e.target.value))}
              className="mt-2 w-full accent-[#81b64c]"
              aria-label="Opponent Elo Rating"
            />
            <div className="mt-1 flex justify-between text-[10px] text-stone-500">
              <span>300 (Beginner)</span>
              <span>1200 (Club)</span>
              <span>2000 (Master)</span>
              <span>3200 (Max Engine)</span>
            </div>
          </div>
        </div>

        {/* Start Game CTA */}
        <div className="mt-5 flex items-center justify-end gap-2.5 border-t border-[#363430] pt-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-4 py-2.5 text-xs font-semibold text-stone-300 hover:bg-[#302e2b]"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onStartGame}
            className="rounded-lg bg-[#81b64c] px-6 py-2.5 text-sm font-extrabold text-[#1c1b19] shadow-lg transition hover:brightness-110 active:scale-[0.99]"
          >
            ▶ Start {selectedTime === 60 ? '1 Hour' : `${selectedTime} Min`}{' '}
            Game
          </button>
        </div>
      </div>
    </div>
  )
}
