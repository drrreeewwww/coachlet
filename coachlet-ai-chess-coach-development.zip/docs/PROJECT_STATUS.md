# Coachlet — Project Status

Legend: **Verified** = exercised by an automated test or a real headless-Chromium run in the session that wrote this.
**Implemented, not verified** = code exists, not exercised end-to-end. **Known issue / Incomplete** = see §6–§9.

## 0. IMPORTANT: what the repository actually contained

The brief described a Vite app with `AnimatedBoard`, `NeoPieces`, `kokoro.ts`, `Sidebar`, `PlayView`, MediaPipe etc. at branch
`arena/91a70fd2-coachlet`. **None of that existed.**

* The sandbox workspace was a blank Next.js + Drizzle starter (no git repo).
* `github.com/drrreeewwww/coachlet` has one commit on `main` containing only `ai-chess-coach-redesign.zip`; the branch
  `arena/91a70fd2-coachlet` does not exist. The zip is an *older* Vite iteration (Staunton pieces, `GameView`, browser-only
  speech with paid cloud TTS options, no Kokoro, no sidebar, no Stockfish `.wasm`).

So the work was: port that zip into the Next.js shell (the only runnable target here), then do the requested work on top.
Nothing was committed, pushed or deployed. There is no git history in `/app`.

Consequences: the described MediaPipe/LiteRT Kokoro path (`kokoro_int8_gpu_fp16.litertlm`) never existed and was **not** built.
Voice uses `kokoro-js` (Kokoro-82M ONNX int8 via transformers.js / onnxruntime-web). PocketTTS / Phonon were **not** benchmarked (§4).

## 1. Stack

Next.js 16 (App Router, Turbopack), React 19, TypeScript, Tailwind 4, chess.js, Stockfish 19 (WASM lite single-thread, GPL-3),
kokoro-js 1.2.1, Vitest (+ Testing Library, jsdom), Playwright. The Drizzle/Postgres template parts are untouched and only serve
`/api/health`; the app itself is client-side and local-first.

## 2. Routes

| Route | View | Status |
|---|---|---|
| `/` | Home (coach cards, voice preview) | Verified loads at all 10 viewports |
| `/play` | Live game vs Stockfish with coaching | Verified: click-to-move + real Stockfish reply; engine status shown honestly |
| `/openings` | Opening Explorer (new) | Verified (§5) |
| `/review` | Post-game review | Verified loads; not functionally audited |
| `/settings` | Settings + new Voice section | Verified loads; voice download/cancel/load/playback verified |

The old nav entries "Custom Drills" and "Progress" do not exist in the ported code and were not added: no dead links.

## 3. Architecture notes

* `src/components/Nav/AppShell.tsx` — `h-dvh` frame; left rail (icons at md, labels at xl); bottom tab bar below md with safe-area padding.
* Board sizing (Play + Explorer): wrapper `max-width: min(100%, var(--board-max))`, `--board-max` derived from `100dvh` minus reserved UI.
  A custom `short:` variant (landscape and height ≤ 560px) switches to a two-column layout with player bars beside the board. The Play eval bar
  sits outside the board's left edge (hidden < 640px) so the board itself is centred.
* `Chessboard.tsx` — added a FLIP-style piece slide (`piece-slide` keyframes); the user's own moves are not re-animated.
  Drag = HTML5 drag-and-drop (mouse/pen). **Touch uses tap-to-move**, not touch-drag.
* **Stockfish lifecycle** (`src/lib/stockfish/engine.ts`): one `Engine` = one Web Worker. Play creates its own; the Explorer creates a
  *separate* one and `destroy()`s it on unmount. Status is explicit: `starting | ready | fallback`. In `fallback` (worker failed) the old
  weak built-in evaluator keeps Play playable, but a red banner says so; the Explorer shows "unavailable" and refuses engine playback.
  Boot timeout raised 4.5 s → 20 s, and the engine recovers if it answers late.
* **Voice pipeline** (`src/lib/voice/`): text → `speechWriter` (flatten markdown, contractions, deterministic phrase variants, sentence/clause
  chunking) → `chessNotationPreprocessor` (SAN, castling, promotion, evals, mate scores, pronunciations) → `emotionStateMachine`
  (per-chunk rate/pitch/pause by coach × move class; **no SSML**, since neither provider honours it) → `speak.ts` controller → Kokoro
  (worker → Web Audio, gapless scheduling, `GainNode` volume, speed applied inside the model) or browser `speechSynthesis` (fallback;
  per-chunk rate/pitch/volume). A session token guards every async step so stale speech never plays; `dedupeKey` prevents duplicate
  auto-speech; the speaking state follows real `onended`/`onend` events.
* **Kokoro model**: `onnx-community/Kokoro-82M-v1.0-ONNX` (q8, 92,361,116 bytes + 3 small JSON files) downloaded by our own fetch with an
  `AbortController` (genuine cancel; incomplete data discarded; files are committed to CacheStorage `transformers-cache` only after all four
  complete, under transformers.js's own cache keys). Synthesis runs in `/public/voice/kokoro.worker.js` (built by
  `tools/build-voice-worker.mjs` — **re-run if kokoro-js changes**) with onnxruntime wasm self-hosted in `/public/ort`. One synthesis in
  flight at a time. No CDN/cloud calls besides the one-time Hugging Face download.
* **Opening Explorer** (`src/lib/openings/`): `catalogue.ts` (3,865 openings from lichess-org/chess-openings, **CC0**; generated by
  `tools/build-openings.mjs`), `lineState.ts` (pure line/branch state), `autoplay.ts` (single-timer, epoch-guarded one-ply autoplay),
  `explorerApi.ts` (IndexedDB cache, one-at-a-time queue, 300 ms gap, 429 ⇒ ≥ 60 s global block with exponential backoff, stale-cache
  fallback, abortable), `familyInfo.ts` (hand-written notes for ~20 families + honest category fallback), `insights.ts` (facts computed
  from the board: centre, development, castling, open files, hanging pieces).

### Lichess explorer needs a token (external limitation)
`https://explorer.lichess.org/{masters,lichess}` returned **HTTP 401 "Authorization Required"** without a token when probed. The Explorer
therefore accepts a free personal Lichess API token (no scopes; stored in this browser's localStorage; sent only as `Authorization: Bearer`
to explorer.lichess.org). Without it the page says so plainly and shows no statistics (nothing invented); board, catalogue, notes, engine
and selected-variation / engine playback still work. **The statistics path with a real token was NOT tested against the live API** (no token
available). It is unit-tested against the documented response shape (parsing, ranking, shares, W/D/B split, caching, 401/429/offline), but live
schema drift would only show up with a token. CORS: the 401 response carries `access-control-allow-origin: *` and allows the `Authorization`
header, so direct browser calls should work; no proxy was added.

## 4. Voice: model comparison — honest status

* Chosen: **Kokoro-82M int8**. Voices exposed (all exist in the model): af_heart (A), af_bella (A-), af_nicole, bf_emma, am_michael,
  am_fenrir, bm_george, bm_fable. Defaults: Vale→bm_george, Flash→af_bella, Gambit→bm_fable.
* **Not done:** PocketTTS / Phonon 31M were not evaluated (no MediaPipe TTS code or models existed). **I could not listen to audio**, so
  "sounds natural" is *unverified by ear*. Verified: the model downloads, loads, synthesises and plays through Web Audio to completion in
  headless Chromium (first preview ≈ 17 s wall time incl. cold model load, single wasm thread); the text fed to it is demonstrably rewritten (tests).
* Settings → Coach voice provides the comparison tooling: a fixed 7-item script (encouragement, tactic, blunder, positional, notation,
  opening terms, checkmate), per-voice preview buttons, and a coach/notation tester showing the exact spoken text.
* Limits: Kokoro has no pitch control and no SSML; emotion = rate + pauses + coach voice. Single-thread wasm synthesis is roughly real-time on
  a slow CPU; clause chunking hides most latency. Pronunciation respellings ("fianchetto"→"fyanketto", "en passant"→"on passon") are heuristic and unheard.
* Automatic speech is **off by default** (Settings: Off / Critical only / Every message).

## 5. Verified (automated)

`npx vitest run` — 8 files, 73 tests passing: notation→speech (incl. not corrupting ordinary words), speech writer, line state (branching,
castling, en passant, promotion, mate, Lichess castling UCI), explorer parsing/stats/cache/queue/429 backoff/abort, autoplay timing +
cancellation + stale results, catalogue/search/naming/categories, position insights, **real Stockfish 19 WASM** (legal best move, MultiPV
legality, mate-in-1), voice controller (fallback, stop, replay, dedupe, pause, Kokoro path with GainNode + speed, stale synthesis discarded,
failure fallback), component tests (nav, playback bar, library, voice controls, database-panel honesty).

`npx playwright test` (needs a production build; the config starts `next start -p 3100`) — real headless Chromium:
* 50 viewport checks (10 sizes × `/play`, `/openings`, `/`, `/settings`, `/review`): no horizontal overflow, board square, not clipped, inside the
  workspace, no uncaught page errors. Sizes: 375×667, 390×844, 430×932, 844×390, 768×1024, 820×1180, 1024×768, 1366×768, 1440×900, 1920×1080.
  Example board widths: Play 1440×900 ≈ 696 px, 1920×1080 ≈ 905 px; Explorer 1440×900 ≈ 496 px, 1920×1080 ≈ 830 px. Screenshots: `docs/screenshots/`.
* Play: click e2→e4 and receive a real Stockfish reply.
* Explorer: select opening; prev/next/restart/flip; selected-variation playback (1 ply per 1.5 s, first ply immediate); pause really pauses; resume;
  manual branch replaces the old future; **engine-best playback** (separate worker); most-played without token shows the honest message.
* Settings: voice download **cancels** mid-flight, leaving 0 cache entries and a retryable button; full Kokoro download → 4 cached files → model load →
  preview plays and Stop returns to disabled when playback really ends.

Bugs found and fixed: engine autoplay cancelled by its own panel-effect cleanup; missing `ort-wasm-simd-threaded.jsep.*` runtime (Kokoro failed
to load — found only by the real-browser run); eval bar pushing the board off-centre; nested `<main>`; old Engine silently demoting to a weak
evaluator after a 4.5 s timeout; old voice stack ignoring speed/volume, never using its emotion plans, reporting "stopped" before audio ended,
and offering paid cloud providers (removed).

## 6. Implemented, not (fully) verified

* Safari/iOS WebKit, real iPhone/iPad hardware, notch/home-indicator behaviour (CSS uses `dvh` + `env(safe-area-inset-*)`; only Chromium viewport emulation was run).
* Browser zoom and live orientation changes (only fixed viewport sizes were tested).
* Audible effect of Kokoro speed/volume; pause/resume with Kokoro (AudioContext suspend/resume) — verified in code/mocks, not by ear.
* Lichess statistics against the live API (token needed). Offline use of cached positions is unit-tested, not browser-tested.
* Play-view controls other than move + reply (takeback, draw, resign, hint, flip, time controls, promotion dialog, game-over modal, PGN/FEN import)
  are ported from the old code and were **not audited**. The old `MoveList` jump behaviour was not reviewed.
* Review-view actions and the coaching-quality items in the brief (§8.3) were not re-audited; coaching text is the ported rule-based generator, not an LLM.
* Accessibility: focus-visible styles, labelled controls, ≥ 44 px targets on new components, `prefers-reduced-motion` CSS, ARIA on the Explorer;
  no formal screen-reader or contrast audit.

## 7. Known issues / limitations

* Play's eval bar is hidden below 640 px wide; eval still shows in the analysis bar.
* No touch drag-and-drop (tap-to-move works).
* `npm audit` reports vulnerabilities in transitive dev/test dependencies; not addressed.
* `package.json` has no `test` script (the task rules forbid editing it directly) — use the commands in §8.
* The Kokoro worker bundle (2.1 MB) and onnxruntime wasm (≈ 32 MB in `public/ort`) are committed build artefacts.
* Stockfish is GPL-3, Kokoro-82M Apache-2.0; review licences/attribution before any public distribution.

## 8. Commands

```bash
npm install
npm run dev                          # http://localhost:3000 (DATABASE_URL only needed for /api/health)
npm run build && npm run start       # production
npx vitest run                       # unit + component tests (73)
npx playwright install chromium      # once; on a bare Linux box Chromium's system libs are also needed
npm run build && npx playwright test # e2e (starts next start on :3100)
node tools/build-voice-worker.mjs    # rebuild Kokoro worker + copy ORT wasm
node tools/build-openings.mjs <dir containing a.tsv..e.tsv>
npx next typegen && npm exec tsc -- --noEmit && npm run build
```

## 9. Remaining work (suggested order)

1. Test the Explorer with a real Lichess token; fix any schema drift.
2. Audit every Play control (takeback, draw, resign, promotion, game over, import) in a browser; fix MoveList jump.
3. Listen-test the three coaches on all Kokoro voices; tune `voiceConfig.ts` and pronunciations; evaluate other local TTS models if desired.
4. Real-device pass on iOS Safari; touch drag.
5. Accessibility audit (screen reader, contrast, modal focus management).
6. Review the coaching generator for factual grounding and phrase variety.
