import { Clock, Play, Volume2, Shield, Sparkles } from 'lucide-react'
import Avatar from '@/components/CoachPanel/Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { TIME_CONTROL_OPTIONS } from '@/lib/settings'
import { useSettings } from '@/lib/useSettings'
import { speak } from '@/lib/voice/speak'
import { COACH_VOICE_PROFILES } from '@/lib/voice/voiceConfig'
import type { TimeControlMinutes } from '@/types'

export default function HomeView({
  onStartPlay,
}: {
  onStartPlay: (minutes?: TimeControlMinutes) => void
}) {
  const [st, setSt] = useSettings()

  return (
    <main className="mx-auto max-w-6xl space-y-8 px-4 py-8 sm:px-6">
      {/* Hero Banner */}
      <section className="rounded-2xl border border-[#3a3834] bg-[#262522] p-6 shadow-2xl sm:p-10">
        <div className="max-w-3xl space-y-4">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-[#81b64c]/40 bg-[#81b64c]/15 px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#a3d160]">
            <Sparkles className="h-3.5 w-3.5" />
            Stockfish 19 WASM • MultiPV Coaching • Neural Coach Voices
          </span>
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-5xl">
            Play Chess With a Grandmaster-Style AI Coach at Your Side.
          </h1>
          <p className="text-base leading-relaxed text-stone-300">
            Choose from seven tournament time controls (1 minute Bullet to 1
            hour Classical), play as White or Black against natural-pacing AI
            opponents from 300 to 3200 Elo, and learn with real-time Stockfish
            coaching arrows and expressive neural voice commentary.
          </p>

          {/* Selectable Time Control Cards */}
          <div className="pt-2">
            <p className="mb-2 flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-stone-400">
              <Clock className="h-3.5 w-3.5 text-[#81b64c]" />
              Quick-Select Time Control & Play:
            </p>
            <div className="flex flex-wrap gap-2">
              {TIME_CONTROL_OPTIONS.map((tc) => {
                const active = st.timeControlMinutes === tc.minutes
                return (
                  <button
                    key={tc.minutes}
                    type="button"
                    onClick={() => {
                      setSt({ timeControlMinutes: tc.minutes })
                      onStartPlay(tc.minutes)
                    }}
                    className={`rounded-lg border px-3.5 py-2 text-xs font-extrabold transition ${
                      active
                        ? 'border-[#81b64c] bg-[#81b64c] text-[#1c1b19] shadow-md'
                        : 'border-[#3a3834] bg-[#1e1d1b] text-stone-200 hover:border-[#81b64c] hover:text-white'
                    }`}
                  >
                    {tc.label}{' '}
                    <span className="font-normal opacity-75">
                      ({tc.category})
                    </span>
                  </button>
                )
              })}
            </div>
          </div>

          <div className="flex flex-wrap gap-3 pt-2">
            <button
              type="button"
              onClick={() => onStartPlay()}
              className="inline-flex items-center gap-2 rounded-lg bg-[#81b64c] px-6 py-3 text-sm font-extrabold text-[#1c1b19] shadow-lg transition hover:brightness-110"
            >
              <Play className="h-4 w-4 fill-current" />
              Launch Chessboard ({st.timeControlMinutes === 60 ? '1 Hour' : `${st.timeControlMinutes} Min`})
            </button>
          </div>
        </div>
      </section>

      {/* Three Distinct AI Coaches & Voice Personalities */}
      <section>
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-extrabold text-white">
              Three Distinct AI Coaches & Neural Voice Personalities
            </h2>
            <p className="text-xs text-stone-400">
              Each coach features a tailored voice cadence, emotional state
              machine, and chess notation pronunciation pipeline.
            </p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          {COACHES.map((c) => {
            const vp = COACH_VOICE_PROFILES[c.id]
            return (
              <div
                key={c.id}
                className="flex flex-col justify-between rounded-xl border border-[#3a3834] bg-[#262522] p-5 shadow-lg"
              >
                <div>
                  <div className="flex items-center gap-3">
                    <Avatar id={c.id} accent={c.accent} size={52} />
                    <div>
                      <h3 className="text-lg font-extrabold text-white">
                        {c.name}
                      </h3>
                      <p className="text-xs text-[#a3d160]">{c.title}</p>
                    </div>
                  </div>
                  <p className="mt-2 rounded bg-[#1e1d1b] px-2.5 py-1 text-[11px] text-stone-300">
                    <b className="text-stone-200">Voice Profile:</b> {vp.label}{' '}
                    — {c.inspiredBy}
                  </p>
                  <p className="mt-3 text-xs leading-relaxed text-stone-300">
                    {c.philosophy}
                  </p>
                  <ul className="mt-3 flex flex-wrap gap-1.5">
                    {c.focusAreas.map((s) => (
                      <li
                        key={s}
                        className="rounded-full border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-0.5 text-[11px] text-stone-300"
                      >
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-4 flex items-center gap-2 border-t border-[#363430] pt-3">
                  <button
                    type="button"
                    onClick={() =>
                      speak(c.preview, c.id, {
                        speed: st.speed,
                        volume: st.voiceVolume,
                        provider: st.voiceProvider,
                      })
                    }
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-[#3a3834] bg-[#1e1d1b] py-2 text-xs font-bold text-stone-200 hover:border-[#81b64c] hover:text-white"
                  >
                    <Volume2 className="h-3.5 w-3.5 text-[#81b64c]" />
                    Preview Voice
                  </button>
                  <button
                    type="button"
                    onClick={() => onStartPlay()}
                    className="inline-flex items-center justify-center gap-1 rounded-lg bg-[#81b64c] px-4 py-2 text-xs font-extrabold text-[#1c1b19] hover:brightness-110"
                  >
                    <Shield className="h-3.5 w-3.5" />
                    Play
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      </section>
    </main>
  )
}
