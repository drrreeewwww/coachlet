import { useState } from 'react'
import { ArrowLeft, RotateCcw, Volume2, Brain, Palette, Cpu } from 'lucide-react'
import Chessboard from '@/components/Chessboard/Chessboard'
import Avatar from '@/components/CoachPanel/Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import {
  PIECE_STYLES,
  THEMES,
  TIME_CONTROL_OPTIONS,
  type PieceStyle,
  type ThemeId,
} from '@/lib/settings'
import { playSound } from '@/lib/sound/sounds'
import { useSettings } from '@/lib/useSettings'
import { preprocessChessTextForSpeech } from '@/lib/voice/chessNotationPreprocessor'
import { buildModulatedSpeechPlan } from '@/lib/voice/emotionStateMachine'
import { speak, stopSpeaking } from '@/lib/voice/speak'
import { COACH_VOICE_PROFILES, VOICE_PROVIDERS } from '@/lib/voice/voiceConfig'
import type { AiPaceMode, CoachId, VoiceProviderId } from '@/types'

const PREVIEW_FEN =
  'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3'

export default function SettingsView({
  onBackToGame,
}: {
  onBackToGame: () => void
}) {
  const [s, set, reset] = useSettings()
  const [testText, setTestText] = useState(
    'After Nf3 and Bc4 in the Ruy Lopez, Stockfish recommends O-O (+0.8) instead of Bxf7+ (−140 cp) to prepare a fianchetto and Rfe1!'
  )
  const [testCoach, setTestCoach] = useState<CoachId>('gambit')

  const preprocessedPreview = preprocessChessTextForSpeech(testText)
  const ssmlPreview = buildModulatedSpeechPlan(
    preprocessedPreview,
    testCoach,
    s.speed,
    s.voiceVolume
  )

  return (
    <main className="mx-auto max-w-4xl space-y-5 p-4 sm:p-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#3a3834] bg-[#262522] px-5 py-4 shadow-lg">
        <div>
          <h1 className="text-xl font-extrabold text-white">
            Settings & Coaching Configuration
          </h1>
          <p className="text-xs text-stone-400">
            All preferences are saved automatically in your browser.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => {
              stopSpeaking()
              reset()
            }}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3.5 py-2 text-xs font-semibold text-stone-300 hover:bg-[#302e2b] hover:text-white"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Reset Defaults
          </button>
          <button
            type="button"
            onClick={onBackToGame}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#81b64c] px-4 py-2 text-xs font-extrabold text-[#1c1b19] hover:brightness-110"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to Board
          </button>
        </div>
      </div>

      {/* Section 1: Natural AI Thinking Behaviour & Time Control Defaults */}
      <section className="rounded-xl border border-[#3a3834] bg-[#262522] p-5 shadow-lg">
        <div className="flex items-center gap-2 border-b border-[#363430] pb-3">
          <Brain className="h-5 w-5 text-[#81b64c]" />
          <div>
            <h2 className="text-base font-extrabold text-white">
              Natural AI Thinking Pacing & Default Time Control
            </h2>
            <p className="text-xs text-stone-400">
              Controls how naturally the AI opponent paces its moves (separate
              from Stockfish calculation time) while respecting its remaining
              chess clock.
            </p>
          </div>
        </div>

        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-stone-300">
              AI Thinking Pace Mode
            </span>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  {
                    id: 'natural',
                    label: 'Natural Human',
                    desc: '0.9s – 2.9s (Adapts to complexity)',
                  },
                  {
                    id: 'fast',
                    label: 'Brisk / Fast',
                    desc: '0.5s – 1.4s (Quick cadence)',
                  },
                  {
                    id: 'deliberate',
                    label: 'Deliberate',
                    desc: '1.8s – 4.6s (Thoughtful pace)',
                  },
                  {
                    id: 'custom',
                    label: 'Custom Range',
                    desc: 'Configure exact min/max delay',
                  },
                ] as Array<{ id: AiPaceMode; label: string; desc: string }>
              ).map((m) => {
                const active = s.aiPace === m.id
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => set({ aiPace: m.id })}
                    className={`flex flex-col items-start rounded-lg border p-2.5 text-left transition ${
                      active
                        ? 'border-[#81b64c] bg-[#81b64c]/18 text-white'
                        : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:bg-[#2c2a27]'
                    }`}
                  >
                    <span className="text-xs font-bold">{m.label}</span>
                    <span className="mt-0.5 text-[10px] text-stone-400">
                      {m.desc}
                    </span>
                  </button>
                )
              })}
            </div>
          </div>

          <div>
            <span className="mb-1.5 block text-xs font-bold uppercase tracking-wider text-stone-300">
              Default Time Control
            </span>
            <div className="flex flex-wrap gap-1.5">
              {TIME_CONTROL_OPTIONS.map((tc) => (
                <button
                  key={tc.minutes}
                  type="button"
                  onClick={() => set({ timeControlMinutes: tc.minutes })}
                  className={`rounded-lg border px-3 py-1.5 text-xs font-bold transition ${
                    s.timeControlMinutes === tc.minutes
                      ? 'border-[#81b64c] bg-[#81b64c] text-[#1c1b19]'
                      : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:bg-[#302e2b]'
                  }`}
                >
                  {tc.label}
                </button>
              ))}
            </div>

            {s.aiPace === 'custom' && (
              <div className="mt-3 grid grid-cols-2 gap-3 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-xs">
                <label className="flex flex-col gap-1">
                  <span>
                    Min Delay: <b className="text-[#a3d160]">{s.aiMinDelayMs}ms</b>
                  </span>
                  <input
                    type="range"
                    min={300}
                    max={3000}
                    step={100}
                    value={s.aiMinDelayMs}
                    onChange={(e) =>
                      set({ aiMinDelayMs: Number(e.target.value) })
                    }
                    className="accent-[#81b64c]"
                  />
                </label>
                <label className="flex flex-col gap-1">
                  <span>
                    Max Delay: <b className="text-[#a3d160]">{s.aiMaxDelayMs}ms</b>
                  </span>
                  <input
                    type="range"
                    min={800}
                    max={6000}
                    step={200}
                    value={s.aiMaxDelayMs}
                    onChange={(e) =>
                      set({ aiMaxDelayMs: Number(e.target.value) })
                    }
                    className="accent-[#81b64c]"
                  />
                </label>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Section 2: Modular AI Coach Voice System & Notation Studio */}
      <section className="rounded-xl border border-[#3a3834] bg-[#262522] p-5 shadow-lg">
        <div className="flex items-center gap-2 border-b border-[#363430] pb-3">
          <Volume2 className="h-5 w-5 text-[#81b64c]" />
          <div>
            <h2 className="text-base font-extrabold text-white">
              Modular Neural Voice System (Vale, Flash & Gambit)
            </h2>
            <p className="text-xs text-stone-400">
              Configure TTS provider, emotional prosody delivery, automatic
              speech triggers, and test natural chess notation pronunciation.
            </p>
          </div>
        </div>

        {/* Provider Cards */}
        <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
          {VOICE_PROVIDERS.map((vp) => {
            const active = s.voiceProvider === vp.id
            return (
              <button
                key={vp.id}
                type="button"
                onClick={() => set({ voiceProvider: vp.id as VoiceProviderId })}
                className={`flex flex-col items-start rounded-lg border p-3 text-left transition ${
                  active
                    ? 'border-[#81b64c] bg-[#81b64c]/15 text-white ring-1 ring-[#81b64c]'
                    : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:bg-[#2c2a27]'
                }`}
              >
                <div className="flex w-full items-center justify-between gap-2">
                  <span className="text-xs font-extrabold text-white">
                    {vp.name}
                  </span>
                  <span className="rounded bg-[#302e2b] px-2 py-0.5 text-[10px] font-semibold text-[#a3d160]">
                    {vp.badge}
                  </span>
                </div>
                <p className="mt-1 text-[11px] leading-relaxed text-stone-400">
                  {vp.description}
                </p>
              </button>
            )
          })}
        </div>

        {/* Optional Cloud API Key Input when Cloud Provider Selected */}
        {s.voiceProvider !== 'browser-neural' && (
          <div className="mt-3 grid gap-3 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-xs sm:grid-cols-2">
            <label className="flex flex-col gap-1">
              <span className="font-semibold text-stone-300">
                Cloud TTS API Key (Optional — auto-falls back to Browser Neural
                if blank)
              </span>
              <input
                type="password"
                value={s.cloudTtsApiKey}
                onChange={(e) => set({ cloudTtsApiKey: e.target.value })}
                placeholder="Paste Google Cloud / Azure / Polly API key..."
                className="rounded border border-[#3a3834] bg-[#141312] px-2.5 py-1.5 text-stone-200"
              />
            </label>
            <label className="flex flex-col gap-1">
              <span className="font-semibold text-stone-300">
                Cloud Region (for Azure / Polly)
              </span>
              <input
                type="text"
                value={s.cloudTtsRegion}
                onChange={(e) => set({ cloudTtsRegion: e.target.value })}
                placeholder="us-east-1"
                className="rounded border border-[#3a3834] bg-[#141312] px-2.5 py-1.5 text-stone-200"
              />
            </label>
          </div>
        )}

        {/* Voice Preferences Toggles & Sliders */}
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="space-y-2.5 text-xs text-stone-200">
            <label className="flex items-center justify-between rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2">
              <span>Enable Coach Voice Synthesis</span>
              <input
                type="checkbox"
                checked={s.voice}
                onChange={(e) => {
                  set({ voice: e.target.checked })
                  if (!e.target.checked) stopSpeaking()
                }}
                className="accent-[#81b64c]"
              />
            </label>
            <label className="flex items-center justify-between rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2">
              <span>
                Auto-Speak Only on Critical Moments (!!, !, ?, ??)
              </span>
              <input
                type="checkbox"
                checked={s.autoSpeakCriticalOnly}
                onChange={(e) =>
                  set({ autoSpeakCriticalOnly: e.target.checked })
                }
                className="accent-[#81b64c]"
              />
            </label>
          </div>

          <div className="space-y-2.5 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-xs text-stone-200">
            <label className="flex items-center justify-between gap-3">
              <span>
                Speaking Speed: <b className="text-[#a3d160]">{s.speed.toFixed(1)}×</b>
              </span>
              <input
                type="range"
                min={0.7}
                max={1.5}
                step={0.1}
                value={s.speed}
                onChange={(e) => set({ speed: Number(e.target.value) })}
                className="w-36 accent-[#81b64c]"
              />
            </label>
            <label className="flex items-center justify-between gap-3">
              <span>
                Voice Volume:{' '}
                <b className="text-[#a3d160]">
                  {Math.round(s.voiceVolume * 100)}%
                </b>
              </span>
              <input
                type="range"
                min={0.1}
                max={1}
                step={0.05}
                value={s.voiceVolume}
                onChange={(e) => set({ voiceVolume: Number(e.target.value) })}
                className="w-36 accent-[#81b64c]"
              />
            </label>
          </div>
        </div>

        {/* Interactive Coach Voice & Notation Pronunciation Tester */}
        <div className="mt-4 rounded-lg border border-[#3a3834] bg-[#1c1b19] p-3.5 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="font-bold text-[#a3d160]">
              Interactive Coach Voice & Chess Notation Tester
            </span>
            <div className="flex items-center gap-1.5">
              {COACHES.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => {
                    setTestCoach(c.id)
                    speak(testText, c.id, {
                      speed: s.speed,
                      volume: s.voiceVolume,
                      provider: s.voiceProvider,
                      apiKey: s.cloudTtsApiKey,
                      region: s.cloudTtsRegion,
                    })
                  }}
                  className={`inline-flex items-center gap-1.5 rounded border px-2.5 py-1 font-bold transition ${
                    testCoach === c.id
                      ? 'border-[#81b64c] bg-[#81b64c] text-[#1c1b19]'
                      : 'border-[#3a3834] bg-[#262522] text-stone-200 hover:bg-[#302e2b]'
                  }`}
                >
                  <Avatar id={c.id} accent={c.accent} size={18} />
                  🔊 Test {c.name}
                </button>
              ))}
            </div>
          </div>

          <p className="mt-1 text-[11px] text-stone-400">
            {COACH_VOICE_PROFILES[testCoach].inspirationNote}
          </p>

          <textarea
            value={testText}
            onChange={(e) => setTestText(e.target.value)}
            rows={2}
            className="mt-2 w-full rounded border border-[#3a3834] bg-[#141312] p-2 text-xs text-stone-200"
          />

          <div className="mt-2 rounded border border-[#302e2b] bg-[#141312] p-2.5 text-[11px]">
            <p className="text-stone-300">
              <b className="text-[#a3d160]">Natural Speech Output:</b> “
              {preprocessedPreview}”
            </p>
            <p className="mt-1 font-mono text-[10px] text-stone-400">
              <b>SSML:</b> {ssmlPreview.ssml}
            </p>
          </div>
        </div>
      </section>

      {/* Section 3: Chessboard Theme, Staunton Pieces & Live Preview */}
      <section className="rounded-xl border border-[#3a3834] bg-[#262522] p-5 shadow-lg">
        <div className="flex items-center gap-2 border-b border-[#363430] pb-3">
          <Palette className="h-5 w-5 text-[#81b64c]" />
          <div>
            <h2 className="text-base font-extrabold text-white">
              Chessboard Theme & Piece Style
            </h2>
            <p className="text-xs text-stone-400">
              Customize board colors, Staunton piece vectors, and coordinate
              labels.
            </p>
          </div>
        </div>

        <div className="mt-4 grid items-center gap-6 md:grid-cols-[1fr_240px]">
          <div className="space-y-4 text-xs">
            <div>
              <span className="mb-1.5 block font-bold uppercase tracking-wider text-stone-300">
                Board Colour Theme
              </span>
              <div className="grid grid-cols-2 gap-2">
                {(Object.keys(THEMES) as ThemeId[]).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => set({ theme: k })}
                    aria-pressed={s.theme === k}
                    className={`flex items-center gap-2.5 rounded-lg border px-3 py-2 font-semibold transition ${
                      s.theme === k
                        ? 'border-[#81b64c] bg-[#81b64c]/18 text-white'
                        : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:bg-[#2c2a27]'
                    }`}
                  >
                    <span className="flex overflow-hidden rounded border border-black/40">
                      <span
                        style={{ background: THEMES[k].light }}
                        className="h-4 w-4"
                      />
                      <span
                        style={{ background: THEMES[k].dark }}
                        className="h-4 w-4"
                      />
                    </span>
                    {THEMES[k].label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="mb-1.5 block font-bold uppercase tracking-wider text-stone-300">
                Chess Piece Set
              </span>
              <div className="flex flex-wrap gap-2">
                {(Object.keys(PIECE_STYLES) as PieceStyle[]).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => set({ pieces: k })}
                    aria-pressed={s.pieces === k}
                    className={`rounded-lg border px-3 py-2 font-semibold transition ${
                      s.pieces === k
                        ? 'border-[#81b64c] bg-[#81b64c]/18 text-white'
                        : 'border-[#3a3834] bg-[#1e1d1b] text-stone-300 hover:bg-[#2c2a27]'
                    }`}
                  >
                    {PIECE_STYLES[k]}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <label className="flex items-center justify-between rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2 text-stone-200">
                <span>Board Coordinates (a–h, 1–8)</span>
                <input
                  type="checkbox"
                  checked={s.coords}
                  onChange={(e) => set({ coords: e.target.checked })}
                  className="accent-[#81b64c]"
                />
              </label>
              <label className="flex items-center justify-between rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2 text-stone-200">
                <span>Show Evaluation Bar</span>
                <input
                  type="checkbox"
                  checked={s.evalBar}
                  onChange={(e) => set({ evalBar: e.target.checked })}
                  className="accent-[#81b64c]"
                />
              </label>
            </div>
          </div>

          <div className="mx-auto w-full max-w-[230px]">
            <Chessboard
              fen={PREVIEW_FEN}
              flipped={false}
              lastMove={{ from: 'f1', to: 'c4' }}
              look={s}
              disabled
              onMove={() => {}}
            />
          </div>
        </div>
      </section>

      {/* Section 4: Engine Analysis & Sound Effects */}
      <section className="rounded-xl border border-[#3a3834] bg-[#262522] p-5 shadow-lg">
        <div className="flex items-center gap-2 border-b border-[#363430] pb-3">
          <Cpu className="h-5 w-5 text-[#81b64c]" />
          <div>
            <h2 className="text-base font-extrabold text-white">
              Stockfish Analysis & Sound Effects
            </h2>
            <p className="text-xs text-stone-400">
              Configure human coaching arrow display, analysis depth, and board
              sound effects.
            </p>
          </div>
        </div>

        <div className="mt-4 grid gap-4 text-xs sm:grid-cols-2">
          <div className="space-y-2.5 text-stone-200">
            <label className="flex items-center justify-between rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2">
              <span>Show Human-Turn Stockfish Coaching Arrows</span>
              <input
                type="checkbox"
                checked={s.showArrows}
                onChange={(e) => set({ showArrows: e.target.checked })}
                className="accent-[#81b64c]"
              />
            </label>
            <label className="flex items-center justify-between rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2">
              <span>Enable Progressive Hint Button</span>
              <input
                type="checkbox"
                checked={s.hints}
                onChange={(e) => set({ hints: e.target.checked })}
                className="accent-[#81b64c]"
              />
            </label>
            <label className="flex items-center justify-between rounded-lg border border-[#3a3834] bg-[#1e1d1b] px-3 py-2">
              <span>Board Sound Effects</span>
              <input
                type="checkbox"
                checked={s.sound}
                onChange={(e) => set({ sound: e.target.checked })}
                className="accent-[#81b64c]"
              />
            </label>
          </div>

          <div className="space-y-2.5 rounded-lg border border-[#3a3834] bg-[#1e1d1b] p-3 text-stone-200">
            <label className="flex items-center justify-between gap-3">
              <span>
                Sound Volume:{' '}
                <b className="text-[#a3d160]">{Math.round(s.volume * 100)}%</b>
              </span>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={s.volume}
                onChange={(e) => {
                  const v = Number(e.target.value)
                  set({ volume: v })
                  playSound('move', v)
                }}
                className="w-36 accent-[#81b64c]"
              />
            </label>
            <label className="flex items-center justify-between gap-3">
              <span>
                Coaching Analysis Time:{' '}
                <b className="text-[#a3d160]">{s.analysisTime} ms</b>
              </span>
              <input
                type="range"
                min={300}
                max={2500}
                step={100}
                value={s.analysisTime}
                onChange={(e) => set({ analysisTime: Number(e.target.value) })}
                className="w-36 accent-[#81b64c]"
              />
            </label>
          </div>
        </div>
      </section>
    </main>
  )
}
