import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Chess, type Move as ChessMove } from 'chess.js'
import {
  Clock,
  Flag,
  Handshake,
  Lightbulb,
  RotateCcw,
  RefreshCw,
  Settings as SettingsIcon,
  BarChart3,
  Copy,
  Upload,
  PlusCircle,
  Check,
  AlertTriangle,
} from 'lucide-react'
import Chessboard from '@/components/Chessboard/Chessboard'
import { getCapturedAndMaterial } from '@/components/Chessboard/StauntonPieces'
import CoachPanel, {
  type ChatMsg,
  type Reaction,
} from '@/components/CoachPanel/CoachPanel'
import EvalBar from '@/components/EvalBar/EvalBar'
import LiveAnalysisBar, {
  type ActiveVariationReplay,
} from '@/components/AnalysisPanel/LiveAnalysisBar'
import PlayerBar from '@/components/PlayerBar/PlayerBar'
import NewGameSetupModal from '@/components/GameSetup/NewGameSetupModal'
import GameOverModal from '@/components/GameSetup/GameOverModal'
import { answer } from '@/lib/coaching/chat'
import { COACHES } from '@/lib/coaching/coaches'
import { tipFor, weaknesses } from '@/lib/coaching/profile'
import { reactionFor } from '@/lib/coaching/reactions'
import {
  answerPositionQuestion,
  buildEngineGroundedCoaching,
} from '@/lib/coaching/structured'
import {
  CLASS_META,
  classify,
  toCp,
  type Score,
} from '@/lib/evaluation/classify'
import { hintFor } from '@/lib/hints/hints'
import { saveGame, type MoveRecord } from '@/lib/review/record'
import { TIME_CONTROL_OPTIONS } from '@/lib/settings'
import {
  Engine,
  detectSacrifice,
  isLegalUciMove,
  uciToMoveObj,
  type Analysis,
} from '@/lib/stockfish/engine'
import { strengthFor } from '@/lib/stockfish/elo'
import {
  calculateNaturalAiDelayMs,
  hasSufficientMatingMaterial,
} from '@/lib/stockfish/thinkingTime'
import { playSound } from '@/lib/sound/sounds'
import { useSettings } from '@/lib/useSettings'
import { speak, stopSpeaking } from '@/lib/voice/speak'
import type {
  BoardArrow,
  CoachId,
  ColorChoice,
  MoveBadgeOverlay,
  PlayerColor,
  StructuredCoachResponse,
  TimeControlMinutes,
} from '@/types'

type Last = { from: string; to: string }
const START_FEN = new Chess().fen()

const PRESET_POSITIONS = [
  {
    label: 'Opera Game Sacrifice (Brilliant !!)',
    fen: '4kb1r/p2n1ppp/4q3/4p1B1/4P3/1Q6/PPP2PPP/2KR4 w k - 1 16',
  },
  {
    label: 'Italian Middlegame Tension',
    fen: 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 1 6',
  },
  {
    label: 'Rook & Pawn Endgame Squeeze',
    fen: '8/5pk1/r5pp/P7/3R4/5PP1/5K1P/8 w - - 1 40',
  },
  {
    label: 'Forced Checkmate in 2',
    fen: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',
  },
]

const sanOf = (fen: string, u: string) => {
  if (!u) return ''
  try {
    return new Chess(fen).move(uciToMoveObj(u)).san
  } catch {
    return u
  }
}

const lastOf = (r: MoveRecord[]): Last | null =>
  r.length ? uciToMoveObj(r[r.length - 1].uci) : null

function buildMoveRecord(
  m: ChessMove,
  prev: Analysis,
  afterScore: Score,
  timeRemainingMs?: number
): MoveRecord {
  const uci = m.from + m.to + (m.promotion ?? '')
  const playedBest = uci === prev.best
  const isSac = detectSacrifice(m.before, uci, prev.pv)
  const secondBestBefore = prev.secondBestScore
    ? toCp(prev.secondBestScore)
    : undefined
  const c = classify(toCp(prev.score), toCp(afterScore), m.color, playedBest, {
    secondBestBefore,
    isSacrifice: isSac,
    mateBefore: prev.score.mate,
    mateAfter: afterScore.mate,
  })
  return {
    color: m.color,
    san: m.san,
    uci,
    fenBefore: m.before,
    fenAfter: m.after,
    before: toCp(prev.score),
    after: toCp(afterScore),
    scoreBefore: prev.score,
    scoreAfter: afterScore,
    cls: c.cls,
    cpLoss: c.cpLoss,
    winLoss: c.winLoss,
    best: prev.best,
    bestSan: prev.bestSan || sanOf(m.before, prev.best),
    secondBestSan: prev.secondBestSan,
    thirdBestSan: prev.thirdBestSan,
    pv: prev.pv,
    variations: prev.variations,
    timeRemainingMs,
  }
}

interface GameViewProps {
  onNavigateReview: () => void
  onNavigateSettings: () => void
}

export default function GameView({
  onNavigateReview,
  onNavigateSettings,
}: GameViewProps) {
  const [st, setSt] = useSettings()
  const {
    voice: voiceOn,
    voiceProvider,
    voiceVolume,
    autoSpeakCriticalOnly,
    cloudTtsApiKey,
    cloudTtsRegion,
    training,
    threshold: th,
    speed,
    analysisDepth,
    analysisTime,
    multiPv,
    showArrows,
    timeControlMinutes,
    colorChoice,
    aiPace,
    aiMinDelayMs,
    aiMaxDelayMs,
  } = st

  const game = useRef(new Chess())
  const engine = useRef<Engine | null>(null)
  const cache = useRef(new Map<string, Analysis>())
  const recs = useRef<MoveRecord[]>([])
  const reactionCounter = useRef(0)

  // Monotonic IDs to prevent any stale async engine or AI callback from overwriting state
  const gameSessionIdRef = useRef(1)
  const humanAnalysisReqIdRef = useRef(0)

  const [fen, setFen] = useState(START_FEN)
  const [playerColor, setPlayerColor] = useState<PlayerColor>('w')
  const aiColor: PlayerColor = playerColor === 'w' ? 'b' : 'w'

  const [last, setLast] = useState<Last | null>(null)
  const [coachId, setCoachId] = useState<CoachId>('vale')
  const [elos, setElos] = useState<Record<CoachId, number>>({
    vale: 1200,
    flash: 1600,
    gambit: 800,
  })
  const [flipped, setFlipped] = useState(false)
  const [aiThinking, setAiThinking] = useState(false)
  const [engineAnalysing, setEngineAnalysing] = useState(false)
  const [coachLoading, setCoachLoading] = useState(false)

  // Game termination states
  const [resigned, setResigned] = useState(false)
  const [drawAgreed, setDrawAgreed] = useState(false)
  const [flaggedSide, setFlaggedSide] = useState<PlayerColor | null>(null)
  const [gameOverModalOpen, setGameOverModalOpen] = useState(false)
  const [setupModalOpen, setSetupModalOpen] = useState(false)

  // High-precision non-drifting chess clocks (in milliseconds)
  const initialClockMs = timeControlMinutes * 60 * 1000
  const [whiteClockMs, setWhiteClockMs] = useState<number>(initialClockMs)
  const [blackClockMs, setBlackClockMs] = useState<number>(initialClockMs)
  const clockStateRef = useRef<{
    wMs: number
    bMs: number
    activeSide: PlayerColor | null
    lastTimestamp: number | null
    lowTimeWarned: boolean
  }>({
    wMs: initialClockMs,
    bMs: initialClockMs,
    activeSide: 'w',
    lastTimestamp: Date.now(),
    lowTimeWarned: false,
  })

  const [error, setError] = useState('')
  const [score, setScore] = useState<Score>({ cp: 25 })
  // Strictly stores COMPLETED analysis for the HUMAN player's current turn position ONLY
  const [humanTurnAnalysis, setHumanTurnAnalysis] = useState<Analysis | null>(
    null
  )
  const [liveDepth, setLiveDepth] = useState(14)
  const [liveSeldepth, setLiveSeldepth] = useState(18)
  const [activeReplay, setActiveReplay] =
    useState<ActiveVariationReplay | null>(null)
  const [reaction, setReaction] = useState<Reaction | null>(null)
  const [structuredCoach, setStructuredCoach] =
    useState<StructuredCoachResponse | null>(null)

  const [imp, setImp] = useState('')
  const [hint, setHint] = useState(0)
  const [note, setNote] = useState('')
  const [marks, setMarks] = useState<string[]>([])
  const [chat, setChat] = useState<ChatMsg[]>([])
  const [copiedLabel, setCopiedLabel] = useState('')
  const spoken = useRef('')

  const isGameOver =
    resigned ||
    drawAgreed ||
    flaggedSide !== null ||
    game.current.isGameOver()

  const say = useCallback(
    (
      t: string,
      moveClass?: MoveRecord['cls'],
      forceSpeak = false
    ) => {
      spoken.current = t
      if (!voiceOn) return
      if (
        autoSpeakCriticalOnly &&
        !forceSpeak &&
        moveClass &&
        !['brilliant', 'great', 'mistake', 'blunder'].includes(moveClass)
      ) {
        return
      }
      speak(t, coachId, {
        speed,
        volume: voiceVolume,
        provider: voiceProvider,
        apiKey: cloudTtsApiKey,
        region: cloudTtsRegion,
        context: {
          moveClass,
          inCheck: game.current.inCheck(),
          isTimeLow:
            (playerColor === 'w' ? whiteClockMs : blackClockMs) < 30_000,
        },
      })
    },
    [
      voiceOn,
      autoSpeakCriticalOnly,
      coachId,
      speed,
      voiceVolume,
      voiceProvider,
      cloudTtsApiKey,
      cloudTtsRegion,
      playerColor,
      whiteClockMs,
      blackClockMs,
    ]
  )

  const persistGameRecord = useCallback(
    (explicitResult?: string, terminationReason?: string) => {
      const g = game.current
      let result = explicitResult
      if (!result) {
        if (g.isCheckmate()) {
          result = g.turn() === 'w' ? '0-1' : '1-0'
        } else if (g.isGameOver() || drawAgreed) {
          result = '1/2-1/2'
        } else {
          result = '*'
        }
      }
      saveGame({
        coach: coachId,
        elo: elos[coachId],
        playerColor,
        timeControlMinutes,
        terminationReason,
        moves: recs.current,
        result,
      })
    },
    [coachId, elos, playerColor, timeControlMinutes, drawAgreed]
  )

  // Accurate, drift-free wall-clock timer using Date.now() deltas + visibility/focus sync
  useEffect(() => {
    const syncClocks = () => {
      const cs = clockStateRef.current
      if (!cs.activeSide || cs.lastTimestamp === null) return
      if (
        resigned ||
        drawAgreed ||
        flaggedSide !== null ||
        game.current.isGameOver()
      ) {
        cs.activeSide = null
        cs.lastTimestamp = null
        return
      }

      const now = Date.now()
      const delta = Math.max(0, now - cs.lastTimestamp)
      cs.lastTimestamp = now

      if (cs.activeSide === 'w') {
        cs.wMs = Math.max(0, cs.wMs - delta)
        setWhiteClockMs(cs.wMs)
        if (
          playerColor === 'w' &&
          cs.wMs > 0 &&
          cs.wMs <= 20_000 &&
          !cs.lowTimeWarned
        ) {
          cs.lowTimeWarned = true
          playSound('lowtime', st.sound ? st.volume : 0)
        }
        if (cs.wMs <= 0) {
          cs.activeSide = null
          cs.lastTimestamp = null
          setFlaggedSide('w')
          setAiThinking(false)
          setEngineAnalysing(false)
          engine.current?.stop()
          playSound('end', st.sound ? st.volume : 0)
          const blackCanMate = hasSufficientMatingMaterial(
            game.current.fen(),
            'b'
          )
          persistGameRecord(
            blackCanMate ? '0-1' : '1/2-1/2',
            blackCanMate
              ? 'Black won on time'
              : 'Draw by timeout vs insufficient material'
          )
          setGameOverModalOpen(true)
        }
      } else {
        cs.bMs = Math.max(0, cs.bMs - delta)
        setBlackClockMs(cs.bMs)
        if (
          playerColor === 'b' &&
          cs.bMs > 0 &&
          cs.bMs <= 20_000 &&
          !cs.lowTimeWarned
        ) {
          cs.lowTimeWarned = true
          playSound('lowtime', st.sound ? st.volume : 0)
        }
        if (cs.bMs <= 0) {
          cs.activeSide = null
          cs.lastTimestamp = null
          setFlaggedSide('b')
          setAiThinking(false)
          setEngineAnalysing(false)
          engine.current?.stop()
          playSound('end', st.sound ? st.volume : 0)
          const whiteCanMate = hasSufficientMatingMaterial(
            game.current.fen(),
            'w'
          )
          persistGameRecord(
            whiteCanMate ? '1-0' : '1/2-1/2',
            whiteCanMate
              ? 'White won on time'
              : 'Draw by timeout vs insufficient material'
          )
          setGameOverModalOpen(true)
        }
      }
    }

    const interval = setInterval(syncClocks, 100)
    const onVisibility = () => syncClocks()
    document.addEventListener('visibilitychange', onVisibility)
    window.addEventListener('focus', onVisibility)

    return () => {
      clearInterval(interval)
      document.removeEventListener('visibilitychange', onVisibility)
      window.removeEventListener('focus', onVisibility)
    }
  }, [
    resigned,
    drawAgreed,
    flaggedSide,
    playerColor,
    st.sound,
    st.volume,
    persistGameRecord,
  ])

  /**
   * Quietly evaluates a position (e.g. for move classification) WITHOUT touching
   * `humanTurnAnalysis` or `boardArrows`.
   */
  const evaluateQuietly = useCallback(
    async (targetFen: string, movetimeMs = 350): Promise<Analysis> => {
      const cacheKey = `${targetFen}|d${analysisDepth}|t${analysisTime}|p${multiPv}`
      const hit = cache.current.get(cacheKey)
      if (hit) return hit
      if (!engine.current) throw new Error('Engine not initialized')
      const res = await engine.current.analyse(targetFen, {
        movetime: movetimeMs,
        depth: Math.min(12, analysisDepth),
        multiPv: 2,
      })
      cache.current.set(cacheKey, res)
      return res
    },
    [analysisDepth, analysisTime, multiPv]
  )

  /**
   * Runs full-strength MultiPV coaching analysis ONLY for the human player's turn.
   * - Waits for Stockfish `bestmove` completion (no preliminary/temporary arrows).
   * - Validates that the board is still at `targetFen` and still the human's turn before updating state.
   */
  const runHumanCoachingAnalysis = useCallback(
    async (
      targetFen: string,
      expectedHumanColor: PlayerColor,
      sessionId: number
    ): Promise<Analysis | null> => {
      // Never run coaching arrow analysis for the AI's turn
      const posChess = new Chess(targetFen)
      if (posChess.turn() !== expectedHumanColor || posChess.isGameOver()) {
        setHumanTurnAnalysis(null)
        return null
      }

      const reqId = ++humanAnalysisReqIdRef.current
      const cacheKey = `${targetFen}|d${analysisDepth}|t${analysisTime}|p${multiPv}`
      const cached = cache.current.get(cacheKey)
      if (cached && cached.turn === expectedHumanColor) {
        if (
          sessionId === gameSessionIdRef.current &&
          reqId === humanAnalysisReqIdRef.current &&
          game.current.fen() === targetFen &&
          game.current.turn() === expectedHumanColor
        ) {
          setHumanTurnAnalysis(cached)
          setScore(cached.score)
          setLiveDepth(cached.depth)
          setLiveSeldepth(cached.seldepth)
        }
        return cached
      }

      if (!engine.current) return null
      const epoch = engine.current.cancelPendingAnalysis()
      setEngineAnalysing(true)

      try {
        const res = await engine.current.analyse(targetFen, {
          movetime: analysisTime,
          depth: analysisDepth,
          multiPv,
          epoch,
        })
        cache.current.set(cacheKey, res)

        // Strict verification: only update UI if this exact request is still active and position hasn't changed
        if (
          sessionId === gameSessionIdRef.current &&
          reqId === humanAnalysisReqIdRef.current &&
          game.current.fen() === targetFen &&
          game.current.turn() === expectedHumanColor &&
          res.fen === targetFen &&
          res.turn === expectedHumanColor
        ) {
          setHumanTurnAnalysis(res)
          setScore(res.score)
          setLiveDepth(res.depth)
          setLiveSeldepth(res.seldepth)
          return res
        }
        return null
      } catch {
        return null
      } finally {
        if (
          sessionId === gameSessionIdRef.current &&
          reqId === humanAnalysisReqIdRef.current
        ) {
          setEngineAnalysing(false)
        }
      }
    },
    [analysisDepth, analysisTime, multiPv]
  )

  const updateStructuredCoaching = useCallback(
    (
      posAnalysis: Analysis,
      lastPlayerRec: MoveRecord | null,
      activeCoachId: CoachId,
      activeElo: number,
      pColor: PlayerColor
    ) => {
      setCoachLoading(true)
      const payload = {
        fen: posAnalysis.fen,
        moveHistory: game.current.history(),
        lastMove: lastPlayerRec
          ? {
              san: lastPlayerRec.san,
              uci: lastPlayerRec.uci,
              cls: lastPlayerRec.cls,
              cpLoss: lastPlayerRec.cpLoss,
              winLoss: lastPlayerRec.winLoss,
              beforeCp: lastPlayerRec.before,
              afterCp: lastPlayerRec.after,
              bestSan: lastPlayerRec.bestSan,
              fenBefore: lastPlayerRec.fenBefore,
            }
          : null,
        evaluation: posAnalysis.score,
        bestMoveSan: posAnalysis.bestSan,
        variations: posAnalysis.variations,
        tactics: posAnalysis.tactics,
        elo: activeElo,
        coachId: activeCoachId,
        recurringWeaknesses: weaknesses(recs.current, pColor),
      }

      const grounded = buildEngineGroundedCoaching(payload)
      setStructuredCoach(grounded)
      if (lastPlayerRec) {
        lastPlayerRec.coachExplanation = grounded
      }
      setCoachLoading(false)
    },
    []
  )

  const switchClockTo = (nextTurn: PlayerColor | null) => {
    clockStateRef.current.activeSide = nextTurn
    clockStateRef.current.lastTimestamp = nextTurn ? Date.now() : null
  }

  const applyMoveOnBoard = useCallback(
    (from: string, to: string, promotion = 'q') => {
      try {
        const m = game.current.move({ from, to, promotion })
        if (!m) return null
        const nextFen = game.current.fen()
        setFen(nextFen)
        setLast({ from: m.from, to: m.to })
        // Immediately clear outdated coaching arrows when board position changes!
        setHumanTurnAnalysis(null)
        setActiveReplay(null)

        const gg = game.current
        if (gg.isGameOver()) {
          switchClockTo(null)
          playSound('end', st.sound ? st.volume : 0)
        } else {
          switchClockTo(gg.turn())
          playSound(
            m.san.includes('+')
              ? 'check'
              : m.isKingsideCastle() || m.isQueensideCastle()
                ? 'castle'
                : m.captured
                  ? 'capture'
                  : 'move',
            st.sound ? st.volume : 0
          )
        }
        return m
      } catch {
        return null
      }
    },
    [st.sound, st.volume]
  )

  /**
   * Executes the AI opponent's turn with:
   * 1) Private move calculation via `selectAiMove` (no AI arrows ever shown)
   * 2) Natural human-like thinking delay (`calculateNaturalAiDelayMs`) respecting remaining clock
   * 3) Post-move human coaching analysis once it becomes the human player's turn
   */
  const performAiTurn = useCallback(
    async (
      currentPlayerColor: PlayerColor,
      sessionId: number,
      lastHumanRecord: MoveRecord | null,
      lastHumanToSquare?: string | null
    ) => {
      const g = game.current
      const eng = engine.current
      const expectedAiColor: PlayerColor =
        currentPlayerColor === 'w' ? 'b' : 'w'

      if (!eng || g.isGameOver() || g.turn() !== expectedAiColor) return
      if (clockStateRef.current.activeSide === null) return

      // Ensure human coaching arrows are completely cleared during AI turn
      humanAnalysisReqIdRef.current++
      setHumanTurnAnalysis(null)
      setEngineAnalysing(false)
      setAiThinking(true)

      try {
        const aiStartFen = g.fen()
        const calcStartTs = Date.now()
        const aiStrength = strengthFor(elos[coachId])

        // Cap engine calculation movetime if AI clock is low
        const aiClockRemaining =
          expectedAiColor === 'w'
            ? clockStateRef.current.wMs
            : clockStateRef.current.bMs
        const safeMovetime = Math.min(
          aiStrength.movetime,
          Math.max(50, Math.floor(aiClockRemaining * 0.15))
        )

        const chosenUci = await eng.selectAiMove(aiStartFen, {
          ...aiStrength,
          movetime: safeMovetime,
        })

        // Verify game session and clock are still valid after calculation
        if (
          sessionId !== gameSessionIdRef.current ||
          g.fen() !== aiStartFen ||
          clockStateRef.current.activeSide !== expectedAiColor
        ) {
          return
        }

        const calcElapsedMs = Date.now() - calcStartTs
        const remainingAfterCalc =
          expectedAiColor === 'w'
            ? clockStateRef.current.wMs
            : clockStateRef.current.bMs

        // Calculate natural human-like thinking delay
        const extraDelayMs = calculateNaturalAiDelayMs({
          fen: aiStartFen,
          selectedMoveUci: chosenUci,
          lastOpponentToSquare: lastHumanToSquare,
          elo: elos[coachId],
          remainingClockMs: remainingAfterCalc,
          initialClockMs: timeControlMinutes * 60 * 1000,
          paceMode: aiPace,
          customMinMs: aiMinDelayMs,
          customMaxMs: aiMaxDelayMs,
          engineCalculationElapsedMs: calcElapsedMs,
        })

        // Wait in small 80ms slices so we immediately abort if the AI's clock expires or game resets
        let waited = 0
        while (waited < extraDelayMs) {
          await new Promise((r) => setTimeout(r, Math.min(80, extraDelayMs - waited)))
          waited += 80
          if (
            sessionId !== gameSessionIdRef.current ||
            clockStateRef.current.activeSide !== expectedAiColor
          ) {
            return
          }
          const curAiClock =
            expectedAiColor === 'w'
              ? clockStateRef.current.wMs
              : clockStateRef.current.bMs
          if (curAiClock <= 250) break
        }

        if (
          sessionId !== gameSessionIdRef.current ||
          g.fen() !== aiStartFen ||
          clockStateRef.current.activeSide !== expectedAiColor
        ) {
          return
        }

        const mvObj = uciToMoveObj(chosenUci)
        const aiMove = applyMoveOnBoard(mvObj.from, mvObj.to, mvObj.promotion)
        if (!aiMove) return

        const aiRemMs =
          expectedAiColor === 'w'
            ? clockStateRef.current.wMs
            : clockStateRef.current.bMs

        // Classify AI move quietly and then run full coaching analysis for the human's new turn
        const prevAiAnalysis = await evaluateQuietly(aiMove.before, 250)
        if (sessionId !== gameSessionIdRef.current) return

        setAiThinking(false)

        if (g.isGameOver()) {
          const termEval = await evaluateQuietly(g.fen(), 200)
          recs.current.push(
            buildMoveRecord(aiMove, prevAiAnalysis, termEval.score, aiRemMs)
          )
          persistGameRecord()
          setGameOverModalOpen(true)
          return
        }

        // Now it is the human player's turn! Run full human coaching analysis.
        const humanAnalysis = await runHumanCoachingAnalysis(
          g.fen(),
          currentPlayerColor,
          sessionId
        )

        if (humanAnalysis && sessionId === gameSessionIdRef.current) {
          recs.current.push(
            buildMoveRecord(
              aiMove,
              prevAiAnalysis,
              humanAnalysis.score,
              aiRemMs
            )
          )
          persistGameRecord()
          updateStructuredCoaching(
            humanAnalysis,
            lastHumanRecord,
            coachId,
            elos[coachId],
            currentPlayerColor
          )
        }
      } catch {
        if (sessionId === gameSessionIdRef.current) {
          setError('Engine interrupted. You can continue playing or start a new game.')
        }
      } finally {
        if (sessionId === gameSessionIdRef.current) {
          setAiThinking(false)
        }
      }
    },
    [
      elos,
      coachId,
      timeControlMinutes,
      aiPace,
      aiMinDelayMs,
      aiMaxDelayMs,
      applyMoveOnBoard,
      evaluateQuietly,
      runHumanCoachingAnalysis,
      persistGameRecord,
      updateStructuredCoaching,
    ]
  )

  // Initialize Stockfish Web Worker on mount
  useEffect(() => {
    let e: Engine | null = null
    try {
      e = new Engine()
      engine.current = e
    } catch {
      setError('Stockfish could not start in this browser.')
    }
    const initSessionId = gameSessionIdRef.current
    if (e) {
      void runHumanCoachingAnalysis(START_FEN, 'w', initSessionId).then((a) => {
        if (a && initSessionId === gameSessionIdRef.current) {
          updateStructuredCoaching(a, null, 'vale', 1200, 'w')
        }
      })
    }
    return () => {
      e?.destroy()
      stopSpeaking()
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Re-run human coaching analysis if the user adjusts depth, calculation time, or MultiPV during their turn
  useEffect(() => {
    if (
      !engine.current ||
      aiThinking ||
      isGameOver ||
      game.current.turn() !== playerColor
    ) {
      return
    }
    void runHumanCoachingAnalysis(
      game.current.fen(),
      playerColor,
      gameSessionIdRef.current
    )
  }, [
    analysisDepth,
    analysisTime,
    multiPv,
    aiThinking,
    isGameOver,
    playerColor,
    runHumanCoachingAnalysis,
  ])

  const resetTurnHelpers = () => {
    setHint(0)
    setNote('')
    setMarks([])
    setActiveReplay(null)
  }

  /**
   * Starts a fresh game with the selected Time Control, Side (White/Black/Random), and Coach.
   */
  const startNewGame = useCallback(
    (
      overrideMinutes?: TimeControlMinutes,
      overrideColorChoice?: ColorChoice
    ) => {
      const mins = overrideMinutes ?? timeControlMinutes
      const cChoice = overrideColorChoice ?? colorChoice
      const chosenColor: PlayerColor =
        cChoice === 'random'
          ? Math.random() < 0.5
            ? 'w'
            : 'b'
          : cChoice

      const sessionId = ++gameSessionIdRef.current
      humanAnalysisReqIdRef.current++
      engine.current?.stop()
      stopSpeaking()

      game.current = new Chess()
      recs.current = []
      setPlayerColor(chosenColor)
      setFlipped(chosenColor === 'b')
      setFen(START_FEN)
      setLast(null)
      setResigned(false)
      setDrawAgreed(false)
      setFlaggedSide(null)
      setGameOverModalOpen(false)
      setSetupModalOpen(false)
      setAiThinking(false)
      setEngineAnalysing(false)
      setError('')
      setScore({ cp: 25 })
      setHumanTurnAnalysis(null)
      setReaction(null)
      setStructuredCoach(null)
      setChat([])
      spoken.current = ''
      resetTurnHelpers()

      const startMs = mins * 60 * 1000
      setWhiteClockMs(startMs)
      setBlackClockMs(startMs)
      clockStateRef.current = {
        wMs: startMs,
        bMs: startMs,
        activeSide: 'w',
        lastTimestamp: Date.now(),
        lowTimeWarned: false,
      }

      playSound('start', st.sound ? st.volume : 0)

      if (chosenColor === 'w') {
        void runHumanCoachingAnalysis(START_FEN, 'w', sessionId).then((a) => {
          if (a && sessionId === gameSessionIdRef.current) {
            updateStructuredCoaching(a, null, coachId, elos[coachId], 'w')
          }
        })
      } else {
        // Player chose Black: AI plays White and makes the first move naturally!
        void performAiTurn('b', sessionId, null, null)
      }
    },
    [
      timeControlMinutes,
      colorChoice,
      st.sound,
      st.volume,
      runHumanCoachingAnalysis,
      updateStructuredCoaching,
      coachId,
      elos,
      performAiTurn,
    ]
  )

  /**
   * Handles a move made by the human player on the chessboard.
   */
  const onHumanMove = async (from: string, to: string, promotion?: string) => {
    const g = game.current
    const eng = engine.current
    if (!eng || aiThinking || isGameOver) return
    if (g.turn() !== playerColor) return

    const myClockMs =
      playerColor === 'w'
        ? clockStateRef.current.wMs
        : clockStateRef.current.bMs
    if (myClockMs <= 0) return

    const sessionId = gameSessionIdRef.current
    // Capture any already-completed analysis of the position before the human moved
    const preMoveAnalysisSnapshot =
      humanTurnAnalysis && humanTurnAnalysis.fen === g.fen()
        ? humanTurnAnalysis
        : null

    // Cancel any in-flight human coaching search immediately
    humanAnalysisReqIdRef.current++
    eng.cancelPendingAnalysis()
    setEngineAnalysing(false)

    const m = applyMoveOnBoard(from, to, promotion)
    if (!m) return
    resetTurnHelpers()

    if (g.isGameOver()) {
      try {
        const prevA =
          preMoveAnalysisSnapshot ?? (await evaluateQuietly(m.before, 250))
        const afterA = await evaluateQuietly(g.fen(), 200)
        const rec = buildMoveRecord(m, prevA, afterA.score, myClockMs)
        recs.current.push(rec)
        persistGameRecord()
        setGameOverModalOpen(true)
      } catch {
        persistGameRecord()
        setGameOverModalOpen(true)
      }
      return
    }

    // Start AI thinking immediately so the game feels responsive, and evaluate the human's move
    setAiThinking(true)
    try {
      const prevA =
        preMoveAnalysisSnapshot ?? (await evaluateQuietly(m.before, 300))
      const afterPlayerA = await evaluateQuietly(g.fen(), 300)
      if (sessionId !== gameSessionIdRef.current) return

      setScore(afterPlayerA.score)
      const rec = buildMoveRecord(m, prevA, afterPlayerA.score, myClockMs)
      const bad = rec.cls === 'mistake' || rec.cls === 'blunder'
      const text =
        reactionFor(coachId, rec.cls, reactionCounter.current++, rec.bestSan) +
        (bad ? ' ' + tipFor(coachId, elos[coachId]) : '')

      if (st.reactions || bad) {
        setReaction({
          text,
          cls: rec.cls,
          cpLoss: rec.cpLoss,
          san: m.san,
          bestSan: rec.bestSan,
        })
        say(text, rec.cls)
      }

      // Training mode: take back a major blunder and let the player retry
      if (training && rec.winLoss >= th) {
        g.undo()
        switchClockTo(playerColor)
        setFen(g.fen())
        setLast(lastOf(recs.current))
        setScore(prevA.score)
        setHumanTurnAnalysis(prevA)
        setMarks([m.from, m.to])
        setNote('Blunder taken back. Try a different move, or ask for a hint.')
        setAiThinking(false)
        return
      }

      recs.current.push(rec)
      if (bad) {
        const w = weaknesses(recs.current, playerColor)
        if (w.phase || w.piece) {
          setNote(
            `Pattern noticed: ${
              w.phase
                ? `${w.phase[1]} mistakes in the ${w.phase[0]}`
                : `${w.piece![1]} costly ${w.piece![0]} moves`
            }.`
          )
        }
      }

      await performAiTurn(playerColor, sessionId, rec, m.to)
    } catch {
      setAiThinking(false)
    }
  }

  const onHint = async () => {
    const g = game.current
    if (g.turn() !== playerColor || isGameOver || aiThinking) return
    const lvl = Math.min(4, hint + 1) as 1 | 2 | 3 | 4
    try {
      const a =
        humanTurnAnalysis && humanTurnAnalysis.fen === g.fen()
          ? humanTurnAnalysis
          : await runHumanCoachingAnalysis(
              g.fen(),
              playerColor,
              gameSessionIdRef.current
            )
      if (!a || !a.best) {
        setNote('Still calculating best move — try again in a moment.')
        return
      }
      const h = hintFor(g.fen(), a.best, a.score, lvl)
      setHint(lvl)
      setNote(`Hint ${lvl} of 4: ${h.text}`)
      setMarks(h.marks)
      say(h.text, undefined, true)
    } catch {
      setNote('No hint available right now.')
    }
  }

  const undoMovePair = () => {
    const g = game.current
    if (aiThinking || !g.history().length) return
    const pliesToUndo = g.turn() === playerColor ? 2 : 1
    for (let i = 0; i < pliesToUndo && g.history().length > 0; i++) {
      g.undo()
      recs.current.pop()
    }
    const nextFen = g.fen()
    setFen(nextFen)
    setLast(lastOf(recs.current))
    setReaction(null)
    setHumanTurnAnalysis(null)
    resetTurnHelpers()
    persistGameRecord()
    if (g.turn() === playerColor) {
      switchClockTo(playerColor)
      void runHumanCoachingAnalysis(
        nextFen,
        playerColor,
        gameSessionIdRef.current
      )
    }
  }

  const loadFenOrPgn = (rawInput: string) => {
    const text = rawInput.trim()
    if (!text) return
    const c = new Chess()
    try {
      if (text.split(/\s+/).length >= 4 && text.includes('/')) c.load(text)
      else c.loadPgn(text)
    } catch {
      setError('That does not look like a valid PGN or FEN.')
      return
    }

    const sessionId = ++gameSessionIdRef.current
    humanAnalysisReqIdRef.current++
    engine.current?.stop()
    stopSpeaking()

    const loadedTurn = c.turn()
    game.current = c
    recs.current = []
    setPlayerColor(loadedTurn)
    setFlipped(loadedTurn === 'b')
    const targetFen = c.fen()
    setFen(targetFen)
    setLast(null)
    setResigned(false)
    setDrawAgreed(false)
    setFlaggedSide(null)
    setGameOverModalOpen(false)
    setError('')
    setImp('')
    setReaction(null)
    setHumanTurnAnalysis(null)
    resetTurnHelpers()

    const startMs = timeControlMinutes * 60 * 1000
    setWhiteClockMs(startMs)
    setBlackClockMs(startMs)
    clockStateRef.current = {
      wMs: startMs,
      bMs: startMs,
      activeSide: loadedTurn,
      lastTimestamp: Date.now(),
      lowTimeWarned: false,
    }

    void runHumanCoachingAnalysis(targetFen, loadedTurn, sessionId).then(
      (a) => {
        if (a && sessionId === gameSessionIdRef.current) {
          updateStructuredCoaching(a, null, coachId, elos[coachId], loadedTurn)
        }
      }
    )
  }

  const askCoachQuestion = async (q: string) => {
    const g = game.current
    const a =
      humanTurnAnalysis && humanTurnAnalysis.fen === g.fen()
        ? humanTurnAnalysis
        : await evaluateQuietly(g.fen(), 400)

    const mine = recs.current.filter((m) => m.color === playerColor)
    const lastPlayerRec = mine[mine.length - 1] ?? null

    const payload = {
      fen: g.fen(),
      moveHistory: g.history(),
      lastMove: lastPlayerRec
        ? {
            san: lastPlayerRec.san,
            uci: lastPlayerRec.uci,
            cls: lastPlayerRec.cls,
            cpLoss: lastPlayerRec.cpLoss,
            winLoss: lastPlayerRec.winLoss,
            beforeCp: lastPlayerRec.before,
            afterCp: lastPlayerRec.after,
            bestSan: lastPlayerRec.bestSan,
            fenBefore: lastPlayerRec.fenBefore,
          }
        : null,
      evaluation: a?.score ?? score,
      bestMoveSan: a?.bestSan ?? '',
      variations: a?.variations ?? [],
      tactics: a?.tactics ?? null,
      elo: elos[coachId],
      coachId,
      recurringWeaknesses: weaknesses(recs.current, playerColor),
      question: q,
    }

    const baseStructured =
      structuredCoach ?? buildEngineGroundedCoaching(payload)
    const localQa = answerPositionQuestion(q, payload, baseStructured)
    const fallbackReply =
      localQa.text ||
      answer(q, {
        coach: coachId,
        elo: elos[coachId],
        playerColor,
        fen: g.fen(),
        bestSan: a?.bestSan,
        score: a?.score,
        variations: a?.variations,
        tactics: a?.tactics,
        recs: recs.current,
        over: isGameOver,
      })

    setStructuredCoach(localQa.structured)
    setChat((prev) => [
      ...prev,
      { from: 'you', text: q },
      { from: 'coach', text: fallbackReply },
    ])
    say(fallbackReply, undefined, true)
  }

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedLabel(label)
      setTimeout(() => setCopiedLabel(''), 2000)
    } catch {
      setNote(`${label}: ${text}`)
    }
  }

  // Strictly validated human-turn-only variations and arrows (Requirement 4)
  const isCurrentlyHumanTurn =
    !isGameOver && !aiThinking && game.current.turn() === playerColor

  const validatedHumanVariations = useMemo(() => {
    if (
      !isCurrentlyHumanTurn ||
      engineAnalysing ||
      !humanTurnAnalysis ||
      humanTurnAnalysis.fen !== fen ||
      humanTurnAnalysis.turn !== playerColor
    ) {
      return []
    }
    return humanTurnAnalysis.variations.filter((v) =>
      isLegalUciMove(fen, v.firstMove.uci)
    )
  }, [
    isCurrentlyHumanTurn,
    engineAnalysing,
    humanTurnAnalysis,
    fen,
    playerColor,
  ])

  const activeStep = useMemo(() => {
    if (!activeReplay || !isCurrentlyHumanTurn) return null
    const line = validatedHumanVariations[activeReplay.lineIndex]
    return line?.steps[activeReplay.stepIndex] ?? null
  }, [activeReplay, isCurrentlyHumanTurn, validatedHumanVariations])

  const displayedFen = activeStep ? activeStep.fenAfter : fen
  const displayedScore = activeStep ? activeStep.score : score
  const displayedLastMove = activeStep
    ? { from: activeStep.from, to: activeStep.to }
    : last

  /**
   * Requirement 4A, 4B, 4C, 4D, 4E:
   * - ONLY show arrows when it is the human player's turn (`isCurrentlyHumanTurn`)
   * - ONLY show arrows after Stockfish has completed its analysis (`!engineAnalysing`)
   * - Validate every arrow against the current `fen`
   * - NEVER show arrows for the AI's side
   */
  const boardArrows = useMemo<BoardArrow[]>(() => {
    if (!isCurrentlyHumanTurn || engineAnalysing) return []

    if (activeStep && activeReplay) {
      const line = validatedHumanVariations[activeReplay.lineIndex]
      const nextStep = line?.steps[activeReplay.stepIndex + 1]
      const arr: BoardArrow[] = [
        {
          from: activeStep.from,
          to: activeStep.to,
          color: '#81b64c',
          label: `${activeReplay.stepIndex + 1}`,
          opacity: 0.92,
        },
      ]
      if (nextStep) {
        arr.push({
          from: nextStep.from,
          to: nextStep.to,
          color: '#f7c631',
          dashed: true,
          label: `${activeReplay.stepIndex + 2}`,
          opacity: 0.72,
        })
      }
      return arr
    }

    if (!showArrows || validatedHumanVariations.length === 0) return []

    const colors = ['#81b64c', '#5aa9c9', '#f7c631']
    return validatedHumanVariations.slice(0, multiPv).map((v, idx) => ({
      from: v.firstMove.from,
      to: v.firstMove.to,
      color: colors[idx] ?? '#8aa4b8',
      label: idx === 0 ? '★' : `#${idx + 1}`,
      opacity: idx === 0 ? 0.88 : idx === 1 ? 0.65 : 0.5,
    }))
  }, [
    isCurrentlyHumanTurn,
    engineAnalysing,
    activeStep,
    activeReplay,
    validatedHumanVariations,
    showArrows,
    multiPv,
  ])

  const highlightSquares = useMemo<string[]>(() => {
    if (!isCurrentlyHumanTurn || engineAnalysing) return []
    if (activeStep) return [activeStep.to]
    if (showArrows && validatedHumanVariations[0]) {
      return [validatedHumanVariations[0].firstMove.to]
    }
    return []
  }, [
    isCurrentlyHumanTurn,
    engineAnalysing,
    activeStep,
    showArrows,
    validatedHumanVariations,
  ])

  const lastPlayerMoveBadge = useMemo<MoveBadgeOverlay | null>(() => {
    if (activeStep) return null
    const all = recs.current
    if (!all.length) return null
    const latestPlayer = [...all].reverse().find((m) => m.color === playerColor)
    if (!latestPlayer) return null
    const meta = CLASS_META[latestPlayer.cls]
    return {
      square: latestPlayer.uci.slice(2, 4),
      cls: latestPlayer.cls,
      icon: meta.icon,
      color: meta.color,
      label: meta.label,
    }
  }, [activeStep, fen, playerColor])

  // Captured pieces and material advantage
  const materialInfo = useMemo(
    () => getCapturedAndMaterial(displayedFen),
    [displayedFen]
  )

  const g = game.current
  const coach = COACHES.find((c) => c.id === coachId)!

  // Determine game result & termination message
  const gameResultInfo = useMemo<{
    result: '1-0' | '0-1' | '1/2-1/2' | '*'
    title: string
    detail: string
  }>(() => {
    if (flaggedSide === 'w') {
      const blackCanMate = hasSufficientMatingMaterial(fen, 'b')
      return blackCanMate
        ? {
            result: '0-1',
            title:
              playerColor === 'b' ? 'You Won on Time!' : `${coach.name} Won on Time`,
            detail: 'White’s clock reached 0:00.0',
          }
        : {
            result: '1/2-1/2',
            title: 'Draw • Timeout vs Insufficient Material',
            detail:
              'White ran out of time, but Black has insufficient mating material.',
          }
    }
    if (flaggedSide === 'b') {
      const whiteCanMate = hasSufficientMatingMaterial(fen, 'w')
      return whiteCanMate
        ? {
            result: '1-0',
            title:
              playerColor === 'w' ? 'You Won on Time!' : `${coach.name} Won on Time`,
            detail: 'Black’s clock reached 0:00.0',
          }
        : {
            result: '1/2-1/2',
            title: 'Draw • Timeout vs Insufficient Material',
            detail:
              'Black ran out of time, but White has insufficient mating material.',
          }
    }
    if (resigned) {
      return {
        result: playerColor === 'w' ? '0-1' : '1-0',
        title: `${coach.name} Won by Resignation`,
        detail: 'You resigned the game.',
      }
    }
    if (drawAgreed) {
      return {
        result: '1/2-1/2',
        title: 'Game Drawn by Agreement',
        detail: 'Mutual draw agreed.',
      }
    }
    if (g.isCheckmate()) {
      const winner: PlayerColor = g.turn() === 'w' ? 'b' : 'w'
      return {
        result: winner === 'w' ? '1-0' : '0-1',
        title:
          winner === playerColor
            ? 'Victory by Checkmate!'
            : `Checkmate • ${coach.name} Wins`,
        detail: `${winner === 'w' ? 'White' : 'Black'} delivered checkmate.`,
      }
    }
    if (g.isDraw()) {
      return {
        result: '1/2-1/2',
        title: 'Game Drawn',
        detail: g.isStalemate()
          ? 'Draw by Stalemate.'
          : g.isThreefoldRepetition()
            ? 'Draw by Threefold Repetition.'
            : g.isInsufficientMaterial()
              ? 'Draw by Insufficient Material.'
              : 'Draw by 50-move rule.',
      }
    }
    return { result: '*', title: '', detail: '' }
  }, [flaggedSide, fen, playerColor, coach.name, resigned, drawAgreed, g])

  // Helpful status banner text (Requirement 5)
  const playerClockMs = playerColor === 'w' ? whiteClockMs : blackClockMs
  const isPlayerTimeLow = !isGameOver && playerClockMs > 0 && playerClockMs < 30_000

  const statusBannerText = activeReplay
    ? `Replaying Engine Variation #${activeReplay.lineIndex + 1} (Move ${activeReplay.stepIndex + 1})`
    : isGameOver
      ? `${gameResultInfo.title} — ${gameResultInfo.detail}`
      : aiThinking
        ? `${coach.name} is thinking…`
        : g.inCheck()
          ? 'Check! Your turn — defend your king.'
          : isPlayerTimeLow
            ? 'Time running low! Make your move.'
            : 'Your turn.'

  // Paired move history rows (1. e4 e5) with move classification icons
  const hist = g.history()
  const movePairs = useMemo(() => {
    const pairs: Array<{
      moveNumber: number
      whiteSan?: string
      whiteCls?: MoveRecord['cls']
      blackSan?: string
      blackCls?: MoveRecord['cls']
    }> = []
    for (let i = 0; i < hist.length; i += 2) {
      const wRec = recs.current[i]
      const bRec = recs.current[i + 1]
      pairs.push({
        moveNumber: Math.floor(i / 2) + 1,
        whiteSan: hist[i],
        whiteCls: wRec?.cls,
        blackSan: hist[i + 1],
        blackCls: bRec?.cls,
      })
    }
    return pairs
  }, [hist, fen]) // eslint-disable-line react-hooks/exhaustive-deps

  // Determine which player is shown at top vs bottom based on board flip orientation
  const topSideColor: PlayerColor = flipped ? 'w' : 'b'
  const bottomSideColor: PlayerColor = flipped ? 'b' : 'w'

  const renderBarForSide = (sideColor: PlayerColor) => {
    const isAiSide = sideColor === aiColor
    const sideClockMs = sideColor === 'w' ? whiteClockMs : blackClockMs
    const captured =
      sideColor === 'w'
        ? materialInfo.capturedByWhite
        : materialInfo.capturedByBlack
    const advantage =
      sideColor === 'w'
        ? materialInfo.whiteAdvantage
        : materialInfo.blackAdvantage
    const isClockRunning =
      !isGameOver && clockStateRef.current.activeSide === sideColor

    if (isAiSide) {
      return (
        <PlayerBar
          name={coach.name}
          subtitle={coach.style}
          rating={elos[coachId]}
          avatarId={coach.id}
          avatarAccent={coach.accent}
          pieceColor={aiColor}
          capturedPieces={captured}
          materialAdvantage={advantage}
          clockMs={sideClockMs}
          isClockActive={isClockRunning}
          isThinking={aiThinking}
          isFlagged={flaggedSide === aiColor}
        />
      )
    }

    return (
      <PlayerBar
        name="You"
        subtitle={playerColor === 'w' ? 'Playing White' : 'Playing Black'}
        rating={elos[coachId]}
        avatarId="player"
        avatarAccent="#3b4d3e"
        pieceColor={playerColor}
        capturedPieces={captured}
        materialAdvantage={advantage}
        clockMs={sideClockMs}
        isClockActive={isClockRunning}
        isThinking={false}
        isFlagged={flaggedSide === playerColor}
      />
    )
  }

  return (
    <div className="mx-auto max-w-[1360px] px-3 py-3 sm:px-5 sm:py-4">
      {/* Top Time-Control Quick Selector & Status Bar (Requirement 2 & 5) */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2.5 rounded-lg border border-[#3a3834] bg-[#262522] px-3.5 py-2 shadow-md">
        {/* Status Indicator */}
        <div className="flex items-center gap-2.5">
          <span
            className={`inline-flex h-2.5 w-2.5 shrink-0 rounded-full ${
              isGameOver
                ? 'bg-stone-400'
                : aiThinking
                  ? 'animate-pulse bg-amber-400'
                  : g.inCheck() || isPlayerTimeLow
                    ? 'animate-ping bg-red-500'
                    : 'bg-[#81b64c]'
            }`}
          />
          <p
            role="status"
            className="text-sm font-bold tracking-tight text-stone-100 sm:text-base"
          >
            {error || statusBannerText}
          </p>
          {isPlayerTimeLow && !isGameOver && (
            <span className="inline-flex items-center gap-1 rounded bg-red-500/20 px-2 py-0.5 text-[11px] font-bold text-red-300">
              <AlertTriangle className="h-3 w-3" /> Low Time
            </span>
          )}
        </div>

        {/* Selectable Time Control Pills (All 7 Required Time Controls) */}
        <div
          role="group"
          aria-label="Select Chess Time Control"
          className="flex flex-wrap items-center gap-1"
        >
          <span className="mr-1 flex items-center gap-1 text-xs font-semibold text-stone-400">
            <Clock className="h-3.5 w-3.5 text-[#81b64c]" /> Time:
          </span>
          {TIME_CONTROL_OPTIONS.map((tc) => {
            const isSelected = tc.minutes === timeControlMinutes
            return (
              <button
                key={tc.minutes}
                type="button"
                onClick={() => {
                  setSt({ timeControlMinutes: tc.minutes })
                  startNewGame(tc.minutes, colorChoice)
                }}
                aria-pressed={isSelected}
                title={`Start ${tc.label} (${tc.category}) game`}
                className={`rounded px-2 py-1 text-xs font-bold transition ${
                  isSelected
                    ? 'bg-[#81b64c] text-[#1c1b19] shadow-xs'
                    : 'bg-[#1e1d1b] text-stone-300 hover:bg-[#33312d] hover:text-white'
                }`}
              >
                {tc.label}
              </button>
            )
          })}
        </div>
      </div>

      {/* Main Chess.com-style Two-Column Layout */}
      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,680px)_1fr]">
        {/* Left / Center Column: Opponent Bar + EvalBar & Chessboard + Player Bar + Live Engine Bar */}
        <div className="flex flex-col items-center">
          {/* Opponent Information & Clock Above Board */}
          <div className="mb-2 w-full flex justify-center">
            {renderBarForSide(topSideColor)}
          </div>

          {/* Central Evaluation Bar + 8x8 Staunton Chessboard */}
          <div className="flex w-full max-w-[676px] justify-center gap-2">
            {st.evalBar && (
              <EvalBar
                score={displayedScore}
                flipped={flipped}
                thinking={engineAnalysing}
              />
            )}
            <Chessboard
              fen={displayedFen}
              flipped={flipped}
              lastMove={displayedLastMove}
              marks={marks}
              highlightSquares={highlightSquares}
              arrows={boardArrows}
              badge={lastPlayerMoveBadge}
              replayOverlay={
                activeStep && activeReplay
                  ? `Variation #${activeReplay.lineIndex + 1} Preview • Move ${activeReplay.stepIndex + 1}: ${activeStep.san} (${activeStep.from}→${activeStep.to})`
                  : null
              }
              look={st}
              disabled={!isCurrentlyHumanTurn || activeReplay !== null}
              onMove={onHumanMove}
            />
          </div>

          {/* Player Information & Clock Below Board */}
          <div className="mt-2 w-full flex justify-center">
            {renderBarForSide(bottomSideColor)}
          </div>

          {/* Note / Hint Alert Banner */}
          {note && (
            <div
              className="mt-2.5 flex w-full max-w-[676px] items-center justify-between gap-2 rounded-lg border border-[#81b64c]/50 bg-[#232b1e] px-3.5 py-2 text-xs text-stone-100 shadow"
              aria-live="polite"
            >
              <span>{note}</span>
              <button
                type="button"
                onClick={() => setNote('')}
                className="text-stone-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {/* Live Stockfish MultiPV Analysis & Variation Explorer */}
          <div className="w-full max-w-[676px]">
            <LiveAnalysisBar
              score={displayedScore}
              bestSan={
                isCurrentlyHumanTurn && !engineAnalysing
                  ? (humanTurnAnalysis?.bestSan ?? '')
                  : ''
              }
              variations={validatedHumanVariations}
              tactics={
                isCurrentlyHumanTurn && !engineAnalysing
                  ? humanTurnAnalysis?.tactics
                  : null
              }
              depth={liveDepth}
              seldepth={liveSeldepth}
              thinking={engineAnalysing}
              isHumanTurn={isCurrentlyHumanTurn}
              activeReplay={activeReplay}
              onSelectReplay={setActiveReplay}
              analysisDepth={analysisDepth}
              analysisTime={analysisTime}
              multiPv={multiPv}
              showArrows={showArrows}
              onConfigChange={(patch) => setSt(patch)}
            />
          </div>
        </div>

        {/* Right Sidebar: Game Controls + Move History Table + AI Coach & Voice Panel */}
        <div className="space-y-3">
          {/* Chess.com-style Game Action Toolbar & Move History Card */}
          <div className="rounded-lg border border-[#3a3834] bg-[#262522] p-3.5 shadow-lg">
            {/* Primary Game Control Buttons */}
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => setSetupModalOpen(true)}
                className="inline-flex items-center gap-1.5 rounded-md bg-[#81b64c] px-3 py-1.5 text-xs font-extrabold text-[#1c1b19] shadow-xs transition hover:brightness-110"
              >
                <PlusCircle className="h-3.5 w-3.5" />
                New Game
              </button>

              {st.hints && (
                <button
                  type="button"
                  onClick={onHint}
                  disabled={!isCurrentlyHumanTurn}
                  className="inline-flex items-center gap-1 rounded-md border border-[#3a3834] bg-[#302e2b] px-2.5 py-1.5 text-xs font-semibold text-stone-200 transition hover:bg-[#3a3834] disabled:opacity-40"
                >
                  <Lightbulb className="h-3.5 w-3.5 text-amber-400" />
                  Hint{hint ? ` (${hint}/4)` : ''}
                </button>
              )}

              <button
                type="button"
                onClick={undoMovePair}
                disabled={aiThinking || !hist.length || isGameOver}
                title="Take back last move"
                className="inline-flex items-center gap-1 rounded-md border border-[#3a3834] bg-[#302e2b] px-2.5 py-1.5 text-xs font-semibold text-stone-200 transition hover:bg-[#3a3834] disabled:opacity-40"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Takeback
              </button>

              <button
                type="button"
                onClick={() => setFlipped(!flipped)}
                title="Flip board orientation"
                className="inline-flex items-center gap-1 rounded-md border border-[#3a3834] bg-[#302e2b] px-2.5 py-1.5 text-xs font-semibold text-stone-200 transition hover:bg-[#3a3834]"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Flip
              </button>

              <button
                type="button"
                onClick={() => {
                  if (isGameOver) return
                  // Offer draw: accepted if evaluation is balanced (within ±120cp), otherwise coach explains why they play on
                  const currentCp = toCp(score)
                  const aiCp = aiColor === 'w' ? currentCp : -currentCp
                  if (aiCp <= 80 && hist.length >= 6) {
                    setDrawAgreed(true)
                    switchClockTo(null)
                    playSound('end', st.sound ? st.volume : 0)
                    persistGameRecord('1/2-1/2', 'Draw by mutual agreement')
                    setGameOverModalOpen(true)
                  } else {
                    setNote(
                      hist.length < 6
                        ? `${coach.name}: Let’s play at least a few moves before discussing a draw!`
                        : `${coach.name} declines the draw offer (${aiCp > 80 ? 'opponent holds an advantage' : 'wants to play on'}).`
                    )
                  }
                }}
                disabled={aiThinking || isGameOver}
                className="inline-flex items-center gap-1 rounded-md border border-[#3a3834] bg-[#302e2b] px-2.5 py-1.5 text-xs font-semibold text-stone-200 transition hover:bg-[#3a3834] disabled:opacity-40"
              >
                <Handshake className="h-3.5 w-3.5" />
                Draw
              </button>

              <button
                type="button"
                onClick={() => {
                  if (isGameOver) return
                  setResigned(true)
                  switchClockTo(null)
                  engine.current?.stop()
                  playSound('end', st.sound ? st.volume : 0)
                  persistGameRecord(
                    playerColor === 'w' ? '0-1' : '1-0',
                    'Resignation'
                  )
                  setGameOverModalOpen(true)
                }}
                disabled={aiThinking || isGameOver}
                className="inline-flex items-center gap-1 rounded-md border border-red-500/35 bg-red-950/30 px-2.5 py-1.5 text-xs font-semibold text-red-200 transition hover:bg-red-900/40 disabled:opacity-40"
              >
                <Flag className="h-3.5 w-3.5" />
                Resign
              </button>

              <button
                type="button"
                onClick={onNavigateSettings}
                title="Open Settings"
                className="ml-auto inline-flex items-center gap-1 rounded-md border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-1.5 text-xs font-semibold text-stone-300 transition hover:bg-[#302e2b] hover:text-white"
              >
                <SettingsIcon className="h-3.5 w-3.5" />
                Settings
              </button>
            </div>

            {/* Chess.com-style Tabular Move History Panel */}
            <div className="mt-3 rounded-md border border-[#34322e] bg-[#1c1b19]">
              <div className="flex items-center justify-between border-b border-[#302e2b] px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-stone-400">
                <span>Move History ({hist.length} plies)</span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => copyToClipboard(g.pgn(), 'PGN')}
                    className="inline-flex items-center gap-1 text-stone-400 hover:text-white"
                  >
                    {copiedLabel === 'PGN' ? (
                      <Check className="h-3 w-3 text-[#81b64c]" />
                    ) : (
                      <Copy className="h-3 w-3" />
                    )}
                    PGN
                  </button>
                  <button
                    type="button"
                    onClick={() => copyToClipboard(g.fen(), 'FEN')}
                    className="inline-flex items-center gap-1 text-stone-400 hover:text-white"
                  >
                    {copiedLabel === 'FEN' ? (
                      <Check className="h-3 w-3 text-[#81b64c]" />
                    ) : (
                      <Copy className="h-3 w-3" />
                    )}
                    FEN
                  </button>
                  {recs.current.length > 0 && (
                    <button
                      type="button"
                      onClick={onNavigateReview}
                      className="inline-flex items-center gap-1 rounded bg-[#81b64c]/20 px-2 py-0.5 text-[10px] font-bold text-[#a3d160] hover:bg-[#81b64c]/30"
                    >
                      <BarChart3 className="h-3 w-3" />
                      Review Game
                    </button>
                  )}
                </div>
              </div>

              <div className="max-h-36 overflow-y-auto px-2 py-1.5 font-mono text-xs">
                {movePairs.length > 0 ? (
                  <div className="space-y-0.5">
                    {movePairs.map((row) => (
                      <div
                        key={row.moveNumber}
                        className="grid grid-cols-[36px_1fr_1fr] items-center rounded px-2 py-0.5 odd:bg-[#22211e]"
                      >
                        <span className="text-stone-500">
                          {row.moveNumber}.
                        </span>
                        <span className="flex items-center gap-1 font-semibold text-stone-200">
                          {row.whiteSan}
                          {row.whiteCls && (
                            <span
                              style={{
                                color: CLASS_META[row.whiteCls].color,
                              }}
                              className="text-[10px] font-extrabold"
                              title={CLASS_META[row.whiteCls].label}
                            >
                              {CLASS_META[row.whiteCls].icon}
                            </span>
                          )}
                        </span>
                        <span className="flex items-center gap-1 font-semibold text-stone-300">
                          {row.blackSan ?? ''}
                          {row.blackCls && (
                            <span
                              style={{
                                color: CLASS_META[row.blackCls].color,
                              }}
                              className="text-[10px] font-extrabold"
                              title={CLASS_META[row.blackCls].label}
                            >
                              {CLASS_META[row.blackCls].icon}
                            </span>
                          )}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="py-3 text-center font-sans text-xs text-stone-500">
                    Make a move on the board to start the game.
                  </p>
                )}
              </div>
            </div>

            {/* Training Blunder-Takeback & Position Loader */}
            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-stone-300">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={training}
                  onChange={(e) => setSt({ training: e.target.checked })}
                  className="accent-[#81b64c]"
                />
                <span>Training Mode (Auto-retry blunders ≥ {th}%)</span>
              </label>

              <details className="text-xs">
                <summary className="flex cursor-pointer items-center gap-1 text-stone-400 hover:text-stone-200">
                  <Upload className="h-3 w-3" /> Load FEN / PGN / Tactical Preset
                </summary>
                <div className="mt-2 rounded-lg border border-[#3a3834] bg-[#1c1b19] p-2.5">
                  <div className="flex flex-wrap gap-1.5">
                    {PRESET_POSITIONS.map((pos) => (
                      <button
                        key={pos.label}
                        type="button"
                        disabled={aiThinking}
                        onClick={() => loadFenOrPgn(pos.fen)}
                        className="rounded border border-[#3a3834] bg-[#262522] px-2 py-1 text-[11px] text-stone-300 hover:border-[#81b64c] hover:text-[#a3d160]"
                      >
                        ♟ {pos.label}
                      </button>
                    ))}
                  </div>
                  <div className="mt-2 flex gap-1.5">
                    <input
                      value={imp}
                      onChange={(e) => setImp(e.target.value)}
                      placeholder="Paste FEN or PGN..."
                      aria-label="Paste FEN or PGN"
                      className="min-w-0 flex-1 rounded border border-[#3a3834] bg-[#141312] px-2.5 py-1 text-xs text-stone-200"
                    />
                    <button
                      type="button"
                      disabled={aiThinking || !imp.trim()}
                      onClick={() => loadFenOrPgn(imp)}
                      className="rounded bg-[#81b64c] px-3 py-1 text-xs font-bold text-[#1c1b19] disabled:opacity-40"
                    >
                      Load
                    </button>
                  </div>
                </div>
              </details>
            </div>
          </div>

          {/* AI Coach & Modular Voice Panel */}
          <CoachPanel
            coachId={coachId}
            elos={elos}
            onCoach={(id) => {
              stopSpeaking()
              setCoachId(id)
              if (humanTurnAnalysis) {
                const mine = recs.current.filter(
                  (m) => m.color === playerColor
                )
                updateStructuredCoaching(
                  humanTurnAnalysis,
                  mine[mine.length - 1] ?? null,
                  id,
                  elos[id],
                  playerColor
                )
              }
            }}
            onElo={(id, e) => {
              const next = { ...elos, [id]: e }
              setElos(next)
              if (id === coachId && humanTurnAnalysis) {
                const mine = recs.current.filter(
                  (m) => m.color === playerColor
                )
                updateStructuredCoaching(
                  humanTurnAnalysis,
                  mine[mine.length - 1] ?? null,
                  id,
                  e,
                  playerColor
                )
              }
            }}
            reaction={reaction}
            structured={structuredCoach}
            coachLoading={coachLoading}
            voiceOn={voiceOn}
            onVoice={(on) => {
              setSt({ voice: on })
              if (!on) stopSpeaking()
            }}
            speed={speed}
            onSpeed={(s) => setSt({ speed: s })}
            voiceVolume={voiceVolume}
            onVoiceVolume={(v) => setSt({ voiceVolume: v })}
            voiceProvider={voiceProvider}
            onVoiceProvider={(p) => setSt({ voiceProvider: p })}
            onPreview={(id) =>
              speak(COACHES.find((c) => c.id === id)!.preview, id, {
                speed,
                volume: voiceVolume,
                provider: voiceProvider,
                apiKey: cloudTtsApiKey,
                region: cloudTtsRegion,
              })
            }
            onReplay={() =>
              spoken.current &&
              speak(spoken.current, coachId, {
                speed,
                volume: voiceVolume,
                provider: voiceProvider,
                apiKey: cloudTtsApiKey,
                region: cloudTtsRegion,
              })
            }
            onStop={stopSpeaking}
            chat={chat}
            onAsk={askCoachQuestion}
          />
        </div>
      </div>

      {/* Pre-Game Time Control & Match Setup Modal */}
      <NewGameSetupModal
        open={setupModalOpen}
        onClose={() => setSetupModalOpen(false)}
        selectedTime={timeControlMinutes}
        onSelectTime={(m) => setSt({ timeControlMinutes: m })}
        colorChoice={colorChoice}
        onSelectColor={(c) => setSt({ colorChoice: c })}
        coachId={coachId}
        onSelectCoach={setCoachId}
        elos={elos}
        onChangeElo={(id, val) => setElos((prev) => ({ ...prev, [id]: val }))}
        onStartGame={() => startNewGame(timeControlMinutes, colorChoice)}
      />

      {/* Game Over Summary Modal */}
      <GameOverModal
        open={gameOverModalOpen}
        onClose={() => setGameOverModalOpen(false)}
        result={gameResultInfo.result}
        terminationTitle={gameResultInfo.title}
        terminationDetail={gameResultInfo.detail}
        playerColor={playerColor}
        coachId={coachId}
        elo={elos[coachId]}
        timeControlMinutes={timeControlMinutes}
        moves={recs.current}
        onPlayAgain={() => startNewGame(timeControlMinutes, colorChoice)}
        onOpenSetup={() => {
          setGameOverModalOpen(false)
          setSetupModalOpen(true)
        }}
        onReviewGame={onNavigateReview}
      />
    </div>
  )
}
