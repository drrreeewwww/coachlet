import { useState } from 'react'
import { BarChart3, Settings, Shield, Users } from 'lucide-react'
import GameView from '@/views/GameView'
import HomeView from '@/views/HomeView'
import ReviewView from '@/views/ReviewView'
import SettingsView from '@/views/SettingsView'
import { stopSpeaking } from '@/lib/voice/speak'

type ActiveView = 'game' | 'home' | 'review' | 'settings'

export function App() {
  const [view, setView] = useState<ActiveView>('game')

  const switchView = (next: ActiveView) => {
    stopSpeaking()
    setView(next)
  }

  return (
    <div className="min-h-screen bg-[#1e1d1b] text-stone-100">
      {/* Top Chess.com-inspired Navigation Bar */}
      <header className="sticky top-0 z-30 border-b border-[#34322e] bg-[#262522]/95 backdrop-blur-xs">
        <nav className="mx-auto flex max-w-[1360px] items-center justify-between px-3 py-2.5 sm:px-5">
          <button
            type="button"
            onClick={() => switchView('game')}
            className="flex items-center gap-2.5 text-left group"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#81b64c] text-lg font-black text-[#1c1b19] shadow-sm transition group-hover:brightness-110">
              ♞
            </span>
            <div>
              <span className="block text-base font-extrabold tracking-tight text-white leading-none">
                Coachlet
              </span>
              <span className="block text-[10px] font-medium text-[#a3d160]">
                AI Chess Coach • Stockfish 19
              </span>
            </div>
          </button>

          <div className="flex items-center gap-1.5 sm:gap-2">
            <button
              type="button"
              onClick={() => switchView('game')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-extrabold transition ${
                view === 'game'
                  ? 'bg-[#81b64c] text-[#1c1b19] shadow-xs'
                  : 'text-stone-300 hover:bg-[#33312d] hover:text-white'
              }`}
            >
              <Shield className="h-3.5 w-3.5" />
              <span>Play</span>
            </button>

            <button
              type="button"
              onClick={() => switchView('home')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                view === 'home'
                  ? 'bg-[#363430] text-white'
                  : 'text-stone-300 hover:bg-[#33312d] hover:text-white'
              }`}
            >
              <Users className="h-3.5 w-3.5 text-[#81b64c]" />
              <span>Coaches & Voices</span>
            </button>

            <button
              type="button"
              onClick={() => switchView('review')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                view === 'review'
                  ? 'bg-[#363430] text-white'
                  : 'text-stone-300 hover:bg-[#33312d] hover:text-white'
              }`}
            >
              <BarChart3 className="h-3.5 w-3.5 text-[#81b64c]" />
              <span>Review</span>
            </button>

            <button
              type="button"
              onClick={() => switchView('settings')}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
                view === 'settings'
                  ? 'bg-[#363430] text-white'
                  : 'text-stone-300 hover:bg-[#33312d] hover:text-white'
              }`}
            >
              <Settings className="h-3.5 w-3.5" />
              <span>Settings</span>
            </button>
          </div>
        </nav>
      </header>

      {/* Main Content View */}
      {view === 'game' && (
        <GameView
          onNavigateReview={() => switchView('review')}
          onNavigateSettings={() => switchView('settings')}
        />
      )}
      {view === 'home' && (
        <HomeView onStartPlay={() => switchView('game')} />
      )}
      {view === 'review' && (
        <ReviewView onBackToGame={() => switchView('game')} />
      )}
      {view === 'settings' && (
        <SettingsView onBackToGame={() => switchView('game')} />
      )}
    </div>
  )
}

export default App
