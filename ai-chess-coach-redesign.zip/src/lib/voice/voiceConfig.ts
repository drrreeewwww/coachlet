import type { CoachId, VoiceProviderId } from '@/types'

export interface VoiceProviderMeta {
  id: VoiceProviderId
  name: string
  badge: string
  description: string
  supportsSsml: boolean
  supportsStreaming: boolean
  requiresApiKey: boolean
}

export const VOICE_PROVIDERS: VoiceProviderMeta[] = [
  {
    id: 'browser-neural',
    name: 'Browser Neural TTS (Instant)',
    badge: 'Zero Latency • Built-in',
    description:
      'Uses the browser’s highest-grade local/neural voices with multi-segment prosody and chess notation preprocessing.',
    supportsSsml: true,
    supportsStreaming: true,
    requiresApiKey: false,
  },
  {
    id: 'google-wavenet',
    name: 'Google Cloud TTS (WaveNet / Neural2)',
    badge: 'WaveNet • Emotional Nuance',
    description:
      'Google Cloud WaveNet voices with full W3C SSML <prosody> and <emphasis> support (falls back automatically if no API key).',
    supportsSsml: true,
    supportsStreaming: false,
    requiresApiKey: true,
  },
  {
    id: 'amazon-polly',
    name: 'Amazon Polly (Neural Engine)',
    badge: 'Neural • Low Latency',
    description:
      'AWS Polly expressive neural synthesis with SSML dynamic pacing and emphasis tags.',
    supportsSsml: true,
    supportsStreaming: true,
    requiresApiKey: true,
  },
  {
    id: 'azure-neural',
    name: 'Microsoft Azure Speech (Neural)',
    badge: 'mstts:express-as • Streaming',
    description:
      'Azure Cognitive Services Neural voices with real-time emotional style tags and custom prosody contours.',
    supportsSsml: true,
    supportsStreaming: true,
    requiresApiKey: true,
  },
]

export interface CoachVoiceProfile {
  coachId: CoachId
  label: string
  inspirationNote: string
  basePitch: number // 1.0 = neutral
  baseRate: number // 1.0 = neutral
  baseVolume: number
  dramaticPauseMs: number
  complexExplanationSlowdown: number
  preferredBrowserVoiceKeywords: string[]
  googleWaveNetVoice: string
  amazonPollyVoice: string
  azureNeuralVoice: string
}

export const COACH_VOICE_PROFILES: Record<CoachId, CoachVoiceProfile> = {
  vale: {
    coachId: 'vale',
    label: 'Deep, Measured & Analytical',
    inspirationNote:
      'Magnus-inspired cadence: deeper register, calm clinical delivery, thoughtful pauses, and understated positional authority.',
    basePitch: 0.84,
    baseRate: 0.92,
    baseVolume: 0.92,
    dramaticPauseMs: 340,
    complexExplanationSlowdown: 0.94,
    preferredBrowserVoiceKeywords: [
      'Daniel',
      'Arthur',
      'George',
      'Guy',
      'Google UK English Male',
      'Microsoft Ryan',
      'Microsoft Christopher',
      'Alex',
    ],
    googleWaveNetVoice: 'en-GB-Wavenet-B',
    amazonPollyVoice: 'Arthur',
    azureNeuralVoice: 'en-GB-RyanNeural',
  },
  flash: {
    coachId: 'flash',
    label: 'Rapid, Energetic & Tactical',
    inspirationNote:
      'Hikaru-inspired cadence: slightly higher pitch, fast conversational tempo, sharp emphasis on checks/captures, and high energy on combinations.',
    basePitch: 1.09,
    baseRate: 1.18,
    baseVolume: 1.0,
    dramaticPauseMs: 140,
    complexExplanationSlowdown: 0.96,
    preferredBrowserVoiceKeywords: [
      'Andrew',
      'Eric',
      'Aaron',
      'Google US English',
      'Microsoft Andrew',
      'Microsoft Steffan',
      'Fred',
    ],
    googleWaveNetVoice: 'en-US-Wavenet-D',
    amazonPollyVoice: 'Matthew',
    azureNeuralVoice: 'en-US-AndrewNeural',
  },
  gambit: {
    coachId: 'gambit',
    label: 'Expressive, Dynamic & Theatrical',
    inspirationNote:
      'Levy-inspired cadence: mid-range pitch with dynamic pace shifts, dramatic pauses before big reveals, and lively storytelling emphasis.',
    basePitch: 1.03,
    baseRate: 1.03,
    baseVolume: 0.98,
    dramaticPauseMs: 280,
    complexExplanationSlowdown: 0.9,
    preferredBrowserVoiceKeywords: [
      'Brian',
      'Oliver',
      'Nathan',
      'Microsoft Brian',
      'Google US English',
      'Samantha',
    ],
    googleWaveNetVoice: 'en-US-Wavenet-J',
    amazonPollyVoice: 'Stephen',
    azureNeuralVoice: 'en-US-BrianNeural',
  },
}
