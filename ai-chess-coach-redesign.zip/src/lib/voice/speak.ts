import type { CoachId, VoiceProviderId } from '@/types'
import { preprocessChessTextForSpeech } from './chessNotationPreprocessor'
import {
  buildModulatedSpeechPlan,
  type ModulatedSpeechPlan,
  type SpeechContext,
} from './emotionStateMachine'
import { COACH_VOICE_PROFILES } from './voiceConfig'

export interface SpeakOptions {
  speed?: number
  volume?: number
  provider?: VoiceProviderId
  apiKey?: string
  region?: string
  context?: SpeechContext
}

export interface SpeechDiagnosticState {
  isSpeaking: boolean
  coachId: CoachId
  rawText: string
  spokenText: string
  ssml: string
  emotionLabel: string
  providerUsed: VoiceProviderId
  cachedHit: boolean
}

const PLAN_CACHE = new Map<string, ModulatedSpeechPlan>()
const AUDIO_URL_CACHE = new Map<string, string>()
const MAX_CACHE_ENTRIES = 80

let activeAudio: HTMLAudioElement | null = null
let activeTimers: ReturnType<typeof setTimeout>[] = []
let lastDiagnostic: SpeechDiagnosticState | null = null
const stateListeners = new Set<(state: SpeechDiagnosticState | null) => void>()

function notifyListeners(state: SpeechDiagnosticState | null) {
  lastDiagnostic = state
  stateListeners.forEach((fn) => fn(state))
}

export function subscribeSpeechState(
  fn: (state: SpeechDiagnosticState | null) => void
): () => void {
  stateListeners.add(fn)
  fn(lastDiagnostic)
  return () => stateListeners.delete(fn)
}

export function getLastSpeechDiagnostic(): SpeechDiagnosticState | null {
  return lastDiagnostic
}

const hasWebSpeech = () =>
  typeof window !== 'undefined' && 'speechSynthesis' in window

export function stopSpeaking() {
  for (const t of activeTimers) clearTimeout(t)
  activeTimers = []
  if (activeAudio) {
    try {
      activeAudio.pause()
      activeAudio.currentTime = 0
    } catch {
      /* ignore */
    }
    activeAudio = null
  }
  if (hasWebSpeech()) {
    try {
      window.speechSynthesis.cancel()
    } catch {
      /* ignore */
    }
  }
  if (lastDiagnostic?.isSpeaking) {
    notifyListeners({ ...lastDiagnostic, isSpeaking: false })
  }
}

/**
 * Selects the best distinct English voice from the browser's available SpeechSynthesisVoice list
 * for each of the three coaches (Vale = deep/UK/measured, Flash = brisk/US, Gambit = expressive).
 */
function pickBrowserVoice(coachId: CoachId): SpeechSynthesisVoice | undefined {
  if (!hasWebSpeech()) return undefined
  const allVoices = window.speechSynthesis.getVoices()
  const enVoices = allVoices.filter((v) => /^en(-|_|$)/i.test(v.lang))
  if (enVoices.length === 0) return allVoices[0]

  const profile = COACH_VOICE_PROFILES[coachId]
  for (const kw of profile.preferredBrowserVoiceKeywords) {
    const match = enVoices.find((v) =>
      v.name.toLowerCase().includes(kw.toLowerCase())
    )
    if (match) return match
  }

  // Prefer natural/neural voices if present, distributed deterministically across the 3 coaches
  const naturalVoices = enVoices.filter((v) =>
    /natural|neural|google|premium|enhanced/i.test(v.name)
  )
  const pool = naturalVoices.length >= 3 ? naturalVoices : enVoices
  const indexMap: Record<CoachId, number> = { vale: 0, flash: 1, gambit: 2 }
  return pool[indexMap[coachId] % pool.length]
}

async function tryCloudSynthesis(
  plan: ModulatedSpeechPlan,
  coachId: CoachId,
  provider: VoiceProviderId,
  apiKey: string,
  region = 'us-east-1'
): Promise<string | null> {
  const cacheKey = `${provider}|${coachId}|${plan.ssml}`
  const cachedUrl = AUDIO_URL_CACHE.get(cacheKey)
  if (cachedUrl) return cachedUrl

  const profile = COACH_VOICE_PROFILES[coachId]

  try {
    if (provider === 'google-wavenet' && apiKey) {
      const res = await fetch(
        `https://texttospeech.googleapis.com/v1/text:synthesize?key=${encodeURIComponent(apiKey)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            input: { ssml: plan.ssml },
            voice: {
              languageCode: profile.googleWaveNetVoice.slice(0, 5),
              name: profile.googleWaveNetVoice,
            },
            audioConfig: {
              audioEncoding: 'MP3',
              speakingRate: plan.rate,
              pitch: (plan.pitch - 1) * 10,
            },
          }),
        }
      )
      if (res.ok) {
        const data = (await res.json()) as { audioContent?: string }
        if (data.audioContent) {
          const url = `data:audio/mp3;base64,${data.audioContent}`
          if (AUDIO_URL_CACHE.size >= MAX_CACHE_ENTRIES) {
            const first = AUDIO_URL_CACHE.keys().next().value
            if (first) AUDIO_URL_CACHE.delete(first)
          }
          AUDIO_URL_CACHE.set(cacheKey, url)
          return url
        }
      }
    } else if (provider === 'azure-neural' && apiKey) {
      const res = await fetch(
        `https://${encodeURIComponent(region)}.tts.speech.microsoft.com/cognitiveservices/v1`,
        {
          method: 'POST',
          headers: {
            'Ocp-Apim-Subscription-Key': apiKey,
            'Content-Type': 'application/ssml+xml',
            'X-Microsoft-OutputFormat': 'audio-16khz-128kbitrate-mono-mp3',
          },
          body: `<speak version="1.0" xml:lang="en-US"><voice name="${profile.azureNeuralVoice}">${plan.segments.map((s) => s.text).join(' ')}</voice></speak>`,
        }
      )
      if (res.ok) {
        const blob = await res.blob()
        const url = URL.createObjectURL(blob)
        AUDIO_URL_CACHE.set(cacheKey, url)
        return url
      }
    }
  } catch {
    /* Cloud synthesis unavailable or failed; fall back to Browser Neural TTS */
  }
  return null
}

/**
 * Speaks `rawText` in the selected coach's distinct voice, applying:
 * 1) Chess notation & terminology preprocessing (e.g. "Nf3" -> "Knight to f3")
 * 2) Dynamic emotional prosody state machine & SSML generation
 * 3) LRU caching & non-blocking playback
 */
export function speak(
  rawText: string,
  coach: CoachId,
  speedOrOpts: number | SpeakOptions = 1
) {
  if (typeof window === 'undefined' || !rawText.trim()) return

  const opts: SpeakOptions =
    typeof speedOrOpts === 'number' ? { speed: speedOrOpts } : speedOrOpts
  const speed = opts.speed ?? 1
  const volume = opts.volume ?? 0.85
  const requestedProvider = opts.provider ?? 'browser-neural'

  stopSpeaking()

  const spokenText = preprocessChessTextForSpeech(rawText)
  const planKey = `${coach}|${speed}|${volume}|${opts.context?.moveClass ?? ''}|${opts.context?.customEmotion ?? ''}|${spokenText}`

  let cachedHit = false
  let plan = PLAN_CACHE.get(planKey)
  if (plan) {
    cachedHit = true
  } else {
    plan = buildModulatedSpeechPlan(
      spokenText,
      coach,
      speed,
      volume,
      opts.context
    )
    if (PLAN_CACHE.size >= MAX_CACHE_ENTRIES) {
      const oldest = PLAN_CACHE.keys().next().value
      if (oldest) PLAN_CACHE.delete(oldest)
    }
    PLAN_CACHE.set(planKey, plan)
  }

  const activePlan = plan

  const runBrowserSynthesis = () => {
    if (!hasWebSpeech()) return
    const synth = window.speechSynthesis
    const chosenVoice = pickBrowserVoice(coach)

    notifyListeners({
      isSpeaking: true,
      coachId: coach,
      rawText,
      spokenText,
      ssml: activePlan.ssml,
      emotionLabel: activePlan.emotionLabel,
      providerUsed: 'browser-neural',
      cachedHit,
    })

    const speakSegmentAt = (idx: number) => {
      if (idx >= activePlan.segments.length) {
        notifyListeners({
          isSpeaking: false,
          coachId: coach,
          rawText,
          spokenText,
          ssml: activePlan.ssml,
          emotionLabel: activePlan.emotionLabel,
          providerUsed: 'browser-neural',
          cachedHit,
        })
        return
      }
      const seg = activePlan.segments[idx]
      const u = new SpeechSynthesisUtterance(seg.text)
      u.lang = chosenVoice?.lang || 'en-US'
      u.pitch = seg.pitch
      u.rate = seg.rate
      u.volume = seg.volume
      if (chosenVoice) u.voice = chosenVoice

      u.onend = () => {
        if (seg.pauseAfterMs > 0 && idx < activePlan.segments.length - 1) {
          const timer = setTimeout(
            () => speakSegmentAt(idx + 1),
            seg.pauseAfterMs
          )
          activeTimers.push(timer)
        } else {
          speakSegmentAt(idx + 1)
        }
      }
      u.onerror = () => {
        notifyListeners({
          isSpeaking: false,
          coachId: coach,
          rawText,
          spokenText,
          ssml: activePlan.ssml,
          emotionLabel: activePlan.emotionLabel,
          providerUsed: 'browser-neural',
          cachedHit,
        })
      }
      synth.speak(u)
    }

    speakSegmentAt(0)
  }

  if (requestedProvider !== 'browser-neural' && opts.apiKey?.trim()) {
    void tryCloudSynthesis(
      activePlan,
      coach,
      requestedProvider,
      opts.apiKey.trim(),
      opts.region
    ).then((audioUrl) => {
      if (!audioUrl) {
        runBrowserSynthesis()
        return
      }
      try {
        const audio = new Audio(audioUrl)
        audio.volume = activePlan.volume
        activeAudio = audio
        notifyListeners({
          isSpeaking: true,
          coachId: coach,
          rawText,
          spokenText,
          ssml: activePlan.ssml,
          emotionLabel: activePlan.emotionLabel,
          providerUsed: requestedProvider,
          cachedHit: true,
        })
        audio.onended = () => {
          notifyListeners({
            isSpeaking: false,
            coachId: coach,
            rawText,
            spokenText,
            ssml: activePlan.ssml,
            emotionLabel: activePlan.emotionLabel,
            providerUsed: requestedProvider,
            cachedHit: true,
          })
        }
        audio.onerror = () => runBrowserSynthesis()
        void audio.play().catch(() => runBrowserSynthesis())
      } catch {
        runBrowserSynthesis()
      }
    })
  } else {
    runBrowserSynthesis()
  }
}
