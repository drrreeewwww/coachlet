import type { MoveClass } from '@/lib/evaluation/classify'
import type { CoachEmotion, CoachId } from '@/types'
import { COACH_VOICE_PROFILES } from './voiceConfig'

export interface SpeechContext {
  moveClass?: MoveClass
  inCheck?: boolean
  isTimeLow?: boolean
  isComplexExplanation?: boolean
  customEmotion?: CoachEmotion
}

export interface ModulatedSpeechPlan {
  emotion: CoachEmotion
  emotionLabel: string
  pitch: number
  rate: number
  volume: number
  ssml: string
  segments: Array<{
    text: string
    pitch: number
    rate: number
    volume: number
    pauseAfterMs: number
  }>
}

export const EMOTION_LABELS: Record<CoachEmotion, string> = {
  calm_analytical: 'Calm & Analytical',
  approving: 'Warm & Approving',
  excited: 'Excited Tactical Energy',
  dramatic: 'Dramatic Storytelling',
  constructive_criticism: 'Constructive Alert',
  urgent: 'Urgent / Time Pressure',
}

/**
 * State machine that determines the coach's emotional delivery state from the current game context.
 */
export function resolveCoachEmotion(
  coachId: CoachId,
  ctx?: SpeechContext
): CoachEmotion {
  if (ctx?.customEmotion) return ctx.customEmotion
  if (ctx?.isTimeLow) return 'urgent'

  const cls = ctx?.moveClass
  if (cls === 'brilliant' || cls === 'great') {
    return coachId === 'gambit'
      ? 'dramatic'
      : coachId === 'flash'
        ? 'excited'
        : 'approving'
  }
  if (cls === 'best' || cls === 'excellent') {
    return 'approving'
  }
  if (cls === 'blunder' || cls === 'mistake') {
    return 'constructive_criticism'
  }
  if (cls === 'inaccuracy') {
    return 'constructive_criticism'
  }
  if (ctx?.inCheck) {
    return 'urgent'
  }
  return 'calm_analytical'
}

/**
 * Builds the modulated prosody parameters, W3C SSML document, and multi-segment Web Speech plan.
 */
export function buildModulatedSpeechPlan(
  spokenText: string,
  coachId: CoachId,
  userSpeed = 1,
  userVolume = 0.85,
  ctx?: SpeechContext
): ModulatedSpeechPlan {
  const profile = COACH_VOICE_PROFILES[coachId]
  const emotion = resolveCoachEmotion(coachId, ctx)

  let pitchDelta = 0
  let rateMultiplier = 1.0
  let volumeMultiplier = 1.0
  let emphasisLevel: 'strong' | 'moderate' | 'reduced' = 'moderate'

  switch (emotion) {
    case 'excited':
      pitchDelta = coachId === 'flash' ? 0.1 : 0.07
      rateMultiplier = 1.09
      volumeMultiplier = 1.05
      emphasisLevel = 'strong'
      break
    case 'dramatic':
      pitchDelta = 0.06
      rateMultiplier = 0.97
      volumeMultiplier = 1.04
      emphasisLevel = 'strong'
      break
    case 'approving':
      pitchDelta = 0.03
      rateMultiplier = 1.0
      volumeMultiplier = 1.0
      emphasisLevel = 'moderate'
      break
    case 'constructive_criticism':
      pitchDelta = -0.04
      rateMultiplier = 0.94
      volumeMultiplier = 0.98
      emphasisLevel = 'moderate'
      break
    case 'urgent':
      pitchDelta = 0.05
      rateMultiplier = 1.12
      volumeMultiplier = 1.05
      emphasisLevel = 'strong'
      break
    case 'calm_analytical':
    default:
      pitchDelta = 0
      rateMultiplier = ctx?.isComplexExplanation
        ? profile.complexExplanationSlowdown
        : 1.0
      volumeMultiplier = 0.95
      emphasisLevel = 'reduced'
      break
  }

  const finalPitch = Math.max(
    0.55,
    Math.min(1.5, Number((profile.basePitch + pitchDelta).toFixed(2)))
  )
  const finalRate = Math.max(
    0.6,
    Math.min(
      1.85,
      Number((profile.baseRate * rateMultiplier * userSpeed).toFixed(2))
    )
  )
  const finalVolume = Math.max(
    0,
    Math.min(
      1,
      Number((profile.baseVolume * volumeMultiplier * userVolume).toFixed(2))
    )
  )

  // Split text into natural clauses to insert dynamic pauses and prosody variation
  const rawSentences = spokenText
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean)

  const segments = (rawSentences.length ? rawSentences : [spokenText]).map(
    (sentence, idx) => {
      const isExclamation = sentence.endsWith('!')
      const isQuestion = sentence.endsWith('?')
      const isLongExplanation = sentence.split(/\s+/).length >= 16

      // Gambit and Flash shift pitch and pace across clauses for expressive delivery
      const segPitch = Math.max(
        0.55,
        Math.min(
          1.5,
          Number(
            (
              finalPitch +
              (isExclamation ? 0.05 : isQuestion ? 0.03 : 0) -
              (isLongExplanation ? 0.02 : 0)
            ).toFixed(2)
          )
        )
      )
      const segRate = Math.max(
        0.6,
        Math.min(
          1.85,
          Number(
            (
              finalRate *
              (isLongExplanation
                ? profile.complexExplanationSlowdown
                : isExclamation && coachId === 'flash'
                  ? 1.05
                  : 1.0)
            ).toFixed(2)
          )
        )
      )
      const pauseAfterMs =
        idx < rawSentences.length - 1 ? profile.dramaticPauseMs : 0

      return {
        text: sentence,
        pitch: segPitch,
        rate: segRate,
        volume: finalVolume,
        pauseAfterMs,
      }
    }
  )

  // Build valid W3C SSML representation with <prosody>, <emphasis>, and <break> tags
  const pitchPct = `${finalPitch >= 1 ? '+' : ''}${Math.round((finalPitch - 1) * 100)}%`
  const ratePct = `${Math.round(finalRate * 100)}%`

  const ssmlBody = segments
    .map((seg) => {
      // Emphasize spoken chess moves and key tactical words inside SSML
      const highlighted = seg.text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(
          /\b((?:King|Queen|Rook|Bishop|Knight|[a-h]-pawn)\s+(?:from\s+[^to]+\s+)?(?:to|takes)\s+[a-h][1-8](?:,\s*(?:checkmate|check))?|castles\s+(?:kingside|queenside)|forced\s+mate\s+in\s+\d+|brilliant\s+move|blunder)\b/gi,
          `<emphasis level="${emphasisLevel}">$1</emphasis>`
        )
      const breakTag =
        seg.pauseAfterMs > 0 ? ` <break time="${seg.pauseAfterMs}ms"/>` : ''
      return `<prosody rate="${Math.round(seg.rate * 100)}%" pitch="${seg.pitch >= 1 ? '+' : ''}${Math.round((seg.pitch - 1) * 100)}%">${highlighted}</prosody>${breakTag}`
    })
    .join(' ')

  const ssml = `<speak version="1.1" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US"><prosody rate="${ratePct}" pitch="${pitchPct}">${ssmlBody}</prosody></speak>`

  return {
    emotion,
    emotionLabel: EMOTION_LABELS[emotion],
    pitch: finalPitch,
    rate: finalRate,
    volume: finalVolume,
    ssml,
    segments,
  }
}
