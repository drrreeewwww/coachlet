const PIECE_SPOKEN: Record<string, string> = {
  K: 'King',
  Q: 'Queen',
  R: 'Rook',
  B: 'Bishop',
  N: 'Knight',
}

/**
 * Dictionary of chess openings, tactical motifs, and international terms
 * with phonetic/natural pronunciation hints for TTS synthesis.
 */
export const CHESS_TERMINOLOGY_DICTIONARY: Record<
  string,
  { spoken: string; category: 'opening' | 'term' | 'player' }
> = {
  fianchetto: { spoken: 'fee-an-ketto', category: 'term' },
  fianchettoed: { spoken: 'fee-an-kettoed', category: 'term' },
  zugzwang: { spoken: 'tsoog-tsvahng', category: 'term' },
  zwischenzug: { spoken: 'tsvish-en-tsoog', category: 'term' },
  'en passant': { spoken: 'on pah-sahnt', category: 'term' },
  prophylaxis: { spoken: 'pro-fih-lak-sis', category: 'term' },
  prophylactic: { spoken: 'pro-fih-lak-tik', category: 'term' },
  luft: { spoken: 'looft', category: 'term' },
  desperado: { spoken: 'des-per-ah-doh', category: 'term' },
  'ruy lopez': { spoken: 'Roo-ee Lopez', category: 'opening' },
  najdorf: { spoken: 'Nigh-dorf', category: 'opening' },
  'caro-kann': { spoken: 'Kah-roh Kahn', category: 'opening' },
  'nimzo-indian': { spoken: 'Nim-zoh Indian', category: 'opening' },
  grunfeld: { spoken: 'Groon-feld', category: 'opening' },
  alekhine: { spoken: 'Al-yek-heen', category: 'opening' },
  pirc: { spoken: 'Peerts', category: 'opening' },
   catalan: { spoken: 'Cat-uh-lan', category: 'opening' },
}

/**
 * Converts a single SAN chess move token (e.g. "Nf3", "Bxf7+", "Rfe1", "exd5", "O-O", "e8=Q#")
 * into natural spoken English ("Knight to f3", "Bishop takes f7, check", etc.).
 */
export function sanTokenToSpoken(token: string): string {
  // Strip trailing punctuation that belongs to sentence structure while keeping + and #
  const clean = token.trim()

  // Castling
  if (/^(O-O-O|0-0-0)([+#])?$/.test(clean)) {
    const suffix = clean.endsWith('#')
      ? ', checkmate'
      : clean.endsWith('+')
        ? ', check'
        : ''
    return `castles queenside${suffix}`
  }
  if (/^(O-O|0-0)([+#])?$/.test(clean)) {
    const suffix = clean.endsWith('#')
      ? ', checkmate'
      : clean.endsWith('+')
        ? ', check'
        : ''
    return `castles kingside${suffix}`
  }

  // Piece move: [KQRBN][a-h]?[1-8]?x?[a-h][1-8](=[QRBN])?[+#]?
  const pieceMatch =
    /^([KQRBN])([a-h])?([1-8])?(x)?([a-h][1-8])(?:=([QRBN]))?([+#])?$/.exec(
      clean
    )
  if (pieceMatch) {
    const [, pieceCode, disambigFile, disambigRank, isCapture, destSq, promo, checkSym] =
      pieceMatch
    const pieceName = PIECE_SPOKEN[pieceCode] ?? 'piece'
    let disambig = ''
    if (disambigFile && disambigRank) {
      disambig = ` from ${disambigFile}${disambigRank}`
    } else if (disambigFile) {
      disambig = ` from the ${disambigFile}-file`
    } else if (disambigRank) {
      disambig = ` from rank ${disambigRank}`
    }
    const action = isCapture ? ' takes ' : ' to '
    const promoText = promo
      ? `, promoting to a ${PIECE_SPOKEN[promo] ?? 'Queen'}`
      : ''
    const checkText =
      checkSym === '#'
        ? ', checkmate'
        : checkSym === '+'
          ? ', check'
          : ''
    return `${pieceName}${disambig}${action}${destSq}${promoText}${checkText}`
  }

  // Pawn capture: [a-h]x[a-h][1-8](=[QRBN])?[+#]?
  const pawnCapMatch =
    /^([a-h])x([a-h][1-8])(?:=([QRBN]))?([+#])?$/.exec(clean)
  if (pawnCapMatch) {
    const [, fromFile, destSq, promo, checkSym] = pawnCapMatch
    const promoText = promo
      ? `, promoting to a ${PIECE_SPOKEN[promo] ?? 'Queen'}`
      : ''
    const checkText =
      checkSym === '#'
        ? ', checkmate'
        : checkSym === '+'
          ? ', check'
          : ''
    return `${fromFile}-pawn takes ${destSq}${promoText}${checkText}`
  }

  // Pawn push with promotion or check: [a-h][1-8](=[QRBN])[+#]? or [a-h][1-8][+#]
  const pawnSpecialMatch =
    /^([a-h][1-8])(?:=([QRBN]))?([+#])?$/.exec(clean)
  if (pawnSpecialMatch && (pawnSpecialMatch[2] || pawnSpecialMatch[3])) {
    const [, destSq, promo, checkSym] = pawnSpecialMatch
    const promoText = promo
      ? ` promotes to a ${PIECE_SPOKEN[promo] ?? 'Queen'}`
      : ''
    const checkText =
      checkSym === '#'
        ? ', checkmate'
        : checkSym === '+'
          ? ', check'
          : ''
    return `pawn to ${destSq}${promoText}${checkText}`
  }

  return token
}

/**
 * Preprocesses an entire coaching sentence or paragraph so that all chess notation,
 * evaluation scores, centipawn expressions, and technical chess terms are converted
 * into smooth, natural human speech.
 */
export function preprocessChessTextForSpeech(rawText: string): string {
  if (!rawText) return ''

  let text = rawText
    // Remove decorative symbols that TTS might read awkwardly
    .replace(/[✦★✓↗⚙⏮◀▶↩]/g, '')
    .replace(/!!/g, ' brilliant move ')
    .replace(/\?\?/g, ' blunder ')
    .replace(/\?!/g, ' inaccuracy ')
    .replace(/!\?/g, ' interesting move ')
    // Normalize em-dashes and arrows
    .replace(/→/g, ' to ')
    .replace(/—/g, ', ')
    .replace(/–/g, ' to ')
    // Convert mate scores like +M3 or -M2
    .replace(/([+-])M(\d+)\b/g, (_, sign, moves) =>
      sign === '+'
        ? `forced mate in ${moves}`
        : `forced mate in ${moves} for Black`
    )
    // Convert numeric evaluations like (+1.4) or -0.8
    .replace(
      /(^|[\s(])([+-])(\d+\.\d+)\b/g,
      (_, prefix, sign, num) =>
        `${prefix}${sign === '+' ? 'plus ' : 'minus '}${num}`
    )
    // Convert centipawn losses like "-120 cp" or "−85 cp" or "85 cp"
    .replace(/[−-](\d+)\s*cp\b/gi, 'losing $1 centipawns')
    .replace(/\b(\d+)\s*cp\b/gi, '$1 centipawns')
    .replace(/\bMultiPV\b/gi, 'Multi P V')
    .replace(/\bPV\b/g, 'principal variation')
    // Strip move numbers like "1." or "12..." before moves so TTS doesn't say "one period"
    .replace(/\b\d+\.{1,3}\s*(?=[KQRBNOa-h])/g, '')

  // Replace SAN move tokens inside the text while preserving surrounding punctuation
  text = text.replace(
    /(^|[\s(“"'(])((?:O-O-O|O-O|0-0-0|0-0|[KQRBN][a-h]?[1-8]?x?[a-h][1-8](?:=[QRBN])?|[a-h]x[a-h][1-8](?:=[QRBN])?|[a-h][1-8]=[QRBN])[+#]?)(?=[\s.,;!?)"'”)]|$)/g,
    (_, lead, moveToken) => `${lead}${sanTokenToSpoken(moveToken)}`
  )

  // Apply chess terminology pronunciation dictionary (case-insensitive)
  for (const [term, entry] of Object.entries(CHESS_TERMINOLOGY_DICTIONARY)) {
    const cleanTerm = term.trim()
    const regex = new RegExp(`\\b${cleanTerm}\\b`, 'gi')
    text = text.replace(regex, entry.spoken)
  }

  return text.replace(/\s{2,}/g, ' ').trim()
}
