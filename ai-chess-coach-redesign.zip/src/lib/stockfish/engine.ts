import { Chess, type PieceSymbol, type Square } from 'chess.js'
import type { Strength } from './elo'
import { toCp, type Score } from '@/lib/evaluation/classify'
import type { PVLine, PVStep, PositionTactics } from '@/types'

export interface AnalysisOptions {
  movetime?: number
  depth?: number
  multiPv?: number
  epoch?: number
}

export interface Analysis {
  fen: string
  turn: 'w' | 'b'
  score: Score
  best: string
  bestSan: string
  secondBest?: string
  secondBestSan?: string
  secondBestScore?: Score
  thirdBest?: string
  thirdBestSan?: string
  thirdBestScore?: Score
  pv: string[]
  pvSan: string[]
  variations: PVLine[]
  depth: number
  seldepth: number
  tactics: PositionTactics
  completedAt: number
}

const PIECE_VALUES: Record<PieceSymbol, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
  k: 0,
}

const PIECE_NAMES: Record<PieceSymbol, string> = {
  p: 'pawn',
  n: 'knight',
  b: 'bishop',
  r: 'rook',
  q: 'queen',
  k: 'king',
}

export function uciToMoveObj(uci: string): {
  from: Square
  to: Square
  promotion?: PieceSymbol
} {
  return {
    from: uci.slice(0, 2) as Square,
    to: uci.slice(2, 4) as Square,
    promotion: (uci[4] as PieceSymbol | undefined) || undefined,
  }
}

/**
 * Validates that a UCI move is currently legal in `fen`.
 */
export function isLegalUciMove(fen: string, uci: string): boolean {
  if (!uci || uci.length < 4) return false
  try {
    const c = new Chess(fen)
    const m = c.move(uciToMoveObj(uci))
    return !!m
  } catch {
    return false
  }
}

/**
 * Validates a sequence of UCI moves from `startFen` using chess.js.
 * Stops at the first invalid move so an illegal variation is NEVER displayed.
 */
export function validatePvLine(
  startFen: string,
  multipv: number,
  score: Score,
  depth: number,
  seldepth: number,
  rawUciMoves: string[]
): PVLine | null {
  let chess: Chess
  try {
    chess = new Chess(startFen)
  } catch {
    return null
  }

  const uciMoves: string[] = []
  const sanMoves: string[] = []
  const steps: PVStep[] = []
  const baseCp = toCp(score)

  for (let i = 0; i < rawUciMoves.length && i < 12; i++) {
    const uci = rawUciMoves[i]?.trim()
    if (!uci || uci.length < 4) break
    try {
      const turn = chess.turn()
      const m = chess.move(uciToMoveObj(uci))
      if (!m) break
      const cleanUci = m.from + m.to + (m.promotion ?? '')
      uciMoves.push(cleanUci)
      sanMoves.push(m.san)

      let stepScore: Score = { ...score }
      if (score.mate !== undefined) {
        const sign = score.mate > 0 ? 1 : -1
        const pliesLeft = Math.max(0, Math.abs(score.mate) * 2 - (i + 1))
        const movesLeft = Math.ceil(pliesLeft / 2)
        stepScore =
          movesLeft === 0 ? { cp: sign * 10000 } : { mate: sign * movesLeft }
      } else {
        stepScore = { cp: baseCp }
      }

      steps.push({
        ply: i + 1,
        uci: cleanUci,
        san: m.san,
        from: m.from,
        to: m.to,
        promotion: m.promotion,
        fenAfter: chess.fen(),
        score: stepScore,
        turn,
      })
    } catch {
      break
    }
  }

  if (steps.length === 0) return null

  return {
    multipv,
    score,
    depth,
    seldepth,
    uciMoves,
    sanMoves,
    steps,
    firstMove: {
      uci: steps[0].uci,
      san: steps[0].san,
      from: steps[0].from,
      to: steps[0].to,
      promotion: steps[0].promotion,
    },
  }
}

/**
 * Detects whether a move in `fenBefore` is a material sacrifice (used for Brilliant !! classification).
 */
export function detectSacrifice(
  fenBefore: string,
  uciMove: string,
  pvUci: string[] = []
): boolean {
  try {
    const c = new Chess(fenBefore)
    const mover = c.turn()
    const enemy = mover === 'w' ? 'b' : 'w'

    const matOf = (ch: Chess, col: 'w' | 'b') => {
      let sum = 0
      for (const row of ch.board()) {
        for (const p of row) {
          if (p && p.color === col) sum += PIECE_VALUES[p.type]
        }
      }
      return sum
    }

    const myMatBefore = matOf(c, mover)
    const enemyMatBefore = matOf(c, enemy)
    const netBefore = myMatBefore - enemyMatBefore

    const mv = c.move(uciToMoveObj(uciMove))
    if (!mv) return false

    const movedValue = PIECE_VALUES[mv.piece]
    const capturedValue = mv.captured ? PIECE_VALUES[mv.captured] : 0

    if (
      movedValue >= 3 &&
      movedValue > capturedValue &&
      c.isAttacked(mv.to as Square, enemy)
    ) {
      const replies = c.moves({ verbose: true }).filter((r) => r.to === mv.to)
      if (
        replies.some(
          (r) => PIECE_VALUES[r.piece] < movedValue || capturedValue === 0
        )
      ) {
        return true
      }
    }

    if (pvUci.length >= 2) {
      const sim = new Chess(fenBefore)
      let ok = true
      for (let i = 0; i < Math.min(3, pvUci.length); i++) {
        try {
          if (!sim.move(uciToMoveObj(pvUci[i]))) {
            ok = false
            break
          }
        } catch {
          ok = false
          break
        }
      }
      if (ok) {
        const netAfter = matOf(sim, mover) - matOf(sim, enemy)
        if (netBefore - netAfter >= 2) return true
      }
    }

    return false
  } catch {
    return false
  }
}

/**
 * Inspects a position using chess.js and validated MultiPV lines to extract tactical and positional metadata.
 */
export function analysePositionTactics(
  fen: string,
  variations: PVLine[],
  opponentThreatLine?: PVLine | null
): PositionTactics {
  const c = new Chess(fen)
  const turn = c.turn()
  const enemy = turn === 'w' ? 'b' : 'w'
  const board = c.board()

  let whiteMat = 0
  let blackMat = 0
  let nonPawnPieces = 0
  const hangingPieces: string[] = []

  for (const row of board) {
    for (const cell of row) {
      if (!cell) continue
      const val = PIECE_VALUES[cell.type]
      if (cell.color === 'w') whiteMat += val
      else blackMat += val
      if (cell.type !== 'p' && cell.type !== 'k') nonPawnPieces++

      if (cell.type !== 'k' && val >= 3) {
        const isAttacked = c.isAttacked(
          cell.square,
          cell.color === 'w' ? 'b' : 'w'
        )
        const isDefended = c.isAttacked(cell.square, cell.color)
        if (isAttacked && !isDefended) {
          hangingPieces.push(
            `${cell.color === 'w' ? 'White' : 'Black'} ${PIECE_NAMES[cell.type]} on ${cell.square}`
          )
        }
      }
    }
  }

  const moveNum = Number(fen.split(' ')[5] ?? 1)
  const phase: 'opening' | 'middlegame' | 'endgame' =
    nonPawnPieces <= 6 ? 'endgame' : moveNum <= 10 ? 'opening' : 'middlegame'

  const tacticalMotifs: string[] = []
  const defensiveResources: string[] = []

  const top = variations[0]
  if (c.inCheck()) {
    tacticalMotifs.push('King in check — forced evasion')
  }
  if (top) {
    if (top.score.mate !== undefined) {
      const m = top.score.mate
      if ((turn === 'w' && m > 0) || (turn === 'b' && m < 0)) {
        tacticalMotifs.push(
          `Forced checkmate in ${Math.abs(m)} (${top.firstMove.san})`
        )
      } else {
        tacticalMotifs.push(`Defending against mate threat in ${Math.abs(m)}`)
      }
    }
    const firstSan = top.firstMove.san
    if (firstSan.includes('+')) {
      tacticalMotifs.push(`Forcing check with ${firstSan}`)
    }
    if (firstSan.includes('x')) {
      tacticalMotifs.push(`Tactical capture ${firstSan}`)
    }
    if (firstSan.includes('=')) {
      tacticalMotifs.push(`Pawn promotion resource ${firstSan}`)
    }
    if (detectSacrifice(fen, top.firstMove.uci, top.uciMoves)) {
      tacticalMotifs.push(`Tactical sacrifice idea ${firstSan}`)
    }
  }
  if (hangingPieces.length > 0) {
    tacticalMotifs.push(
      `Loose piece alert: ${hangingPieces.slice(0, 2).join(', ')}`
    )
  }

  const moverEval = top
    ? turn === 'w'
      ? toCp(top.score)
      : -toCp(top.score)
    : 0
  if (top && (c.inCheck() || moverEval < 0 || variations.length >= 2)) {
    const secondEval = variations[1]
      ? turn === 'w'
        ? toCp(variations[1].score)
        : -toCp(variations[1].score)
      : moverEval
    if (c.inCheck() || moverEval - secondEval >= 90) {
      defensiveResources.push(
        `${top.firstMove.san} is the key defensive resource (${
          variations[1]
            ? `alternatives like ${variations[1].firstMove.san} drop significant ground`
            : 'only move'
        })`
      )
    } else if (moverEval < -50) {
      defensiveResources.push(
        `${top.firstMove.san} offers the most stubborn resistance`
      )
    }
  }

  let opponentThreat: PositionTactics['opponentThreat'] = null
  if (opponentThreatLine && opponentThreatLine.steps.length > 0) {
    const st = opponentThreatLine.steps[0]
    opponentThreat = {
      uci: st.uci,
      san: st.san,
      from: st.from,
      to: st.to,
      description: st.san.includes('#')
        ? `Threatens checkmate with ${st.san}`
        : st.san.includes('+')
          ? `Threatens check ${st.san}`
          : st.san.includes('x')
            ? `Threatens to capture on ${st.to} with ${st.san}`
            : `Plans active continuation ${st.san}`,
      pvSan: opponentThreatLine.sanMoves.slice(0, 4),
      score: opponentThreatLine.score,
    }
  } else if (top && top.steps.length >= 2) {
    const reply = top.steps[1]
    opponentThreat = {
      uci: reply.uci,
      san: reply.san,
      from: reply.from,
      to: reply.to,
      description: reply.san.includes('+')
        ? `Counter-check with ${reply.san}`
        : reply.san.includes('x')
          ? `Captures on ${reply.to} (${reply.san})`
          : `Responds with ${reply.san}`,
      pvSan: top.sanMoves.slice(1, 5),
      score: reply.score,
    }
  }

  if (!opponentThreat && !c.inCheck()) {
    try {
      const parts = fen.split(' ')
      parts[1] = enemy
      parts[3] = '-'
      const enemyChess = new Chess(parts.join(' '))
      const enemyMoves = enemyChess.moves({ verbose: true })
      const forcing =
        enemyMoves.find((m) => m.san.includes('#')) ??
        enemyMoves.find((m) => m.captured && PIECE_VALUES[m.captured] >= 3) ??
        enemyMoves.find((m) => m.san.includes('+')) ??
        enemyMoves.find((m) => m.captured)
      if (forcing) {
        opponentThreat = {
          uci: forcing.from + forcing.to + (forcing.promotion ?? ''),
          san: forcing.san,
          from: forcing.from,
          to: forcing.to,
          description: forcing.san.includes('#')
            ? `Threatens immediate mate with ${forcing.san}`
            : forcing.captured
              ? `Threatens to capture ${PIECE_NAMES[forcing.captured]} on ${forcing.to} (${forcing.san})`
              : `Threatens check ${forcing.san}`,
          pvSan: [forcing.san],
          score: top?.score ?? { cp: 0 },
        }
      }
    } catch {
      /* ignore invalid flipped FEN when opponent king is in check */
    }
  }

  return {
    inCheck: c.inCheck(),
    isCheckmate: c.isCheckmate(),
    isDraw: c.isDraw(),
    materialBalance: whiteMat - blackMat,
    phase,
    tacticalMotifs,
    hangingPieces,
    defensiveResources,
    opponentThreat,
  }
}

export function parseUciInfoLine(
  line: string,
  sideMultiplier: 1 | -1
): {
  depth: number
  seldepth: number
  multipv: number
  score: Score
  pv: string[]
} | null {
  if (
    !line.startsWith('info') ||
    !line.includes(' pv ') ||
    !line.includes(' score ') ||
    line.includes('upperbound') ||
    line.includes('lowerbound')
  ) {
    return null
  }
  const scoreMatch = /score (cp|mate) (-?\d+)/.exec(line)
  if (!scoreMatch) return null

  const depth = Number(/\bdepth (\d+)/.exec(line)?.[1] ?? 1)
  const seldepth = Number(/\bseldepth (\d+)/.exec(line)?.[1] ?? depth)
  const multipv = Number(/\bmultipv (\d+)/.exec(line)?.[1] ?? 1)
  const val = sideMultiplier * Number(scoreMatch[2])
  const score: Score = scoreMatch[1] === 'cp' ? { cp: val } : { mate: val }
  const pvRaw = line.split(' pv ')[1]?.trim() ?? ''
  const pv = pvRaw ? pvRaw.split(/\s+/).filter(Boolean) : []
  if (pv.length === 0) return null

  return { depth, seldepth, multipv, score, pv }
}

const DEFAULT_ANALYSIS: Strength = {
  limit: false,
  uciElo: 3190,
  skill: 20,
  movetime: 700,
  blunder: 0,
  multiPv: 3,
}

/**
 * Fallback static + 2-ply tactical evaluator in case WebAssembly worker cannot load in a restricted environment.
 */
function fallbackEvaluateFen(fen: string, multiPvCount = 3): Analysis {
  const c = new Chess(fen)
  const turn = c.turn()
  if (c.isGameOver()) {
    const terminalScore: Score = c.isCheckmate()
      ? { cp: turn === 'w' ? -10000 : 10000 }
      : { cp: 0 }
    return {
      fen,
      turn,
      score: terminalScore,
      best: '',
      bestSan: '',
      pv: [],
      pvSan: [],
      variations: [],
      depth: 10,
      seldepth: 12,
      tactics: analysePositionTactics(fen, []),
      completedAt: Date.now(),
    }
  }

  const evalBoard = (ch: Chess): number => {
    if (ch.isCheckmate()) return ch.turn() === 'w' ? -9999 : 9999
    if (ch.isDraw()) return 0
    let cp = 0
    const b = ch.board()
    for (let r = 0; r < 8; r++) {
      for (let f = 0; f < 8; f++) {
        const p = b[r][f]
        if (!p) continue
        let v = PIECE_VALUES[p.type] * 100
        // Center control bonus
        if ((r === 3 || r === 4) && (f === 3 || f === 4)) v += 18
        else if (r >= 2 && r <= 5 && f >= 2 && f <= 5) v += 8
        cp += p.color === 'w' ? v : -v
      }
    }
    return cp
  }

  const moves = c.moves({ verbose: true })
  const scoredMoves = moves.map((m) => {
    c.move(m)
    // 1-ply reply check
    const replies = c.moves({ verbose: true })
    let bestReplyEval = evalBoard(c)
    let bestReplyUci = ''
    if (replies.length > 0) {
      for (const rep of replies.slice(0, 16)) {
        c.move(rep)
        const ev = evalBoard(c)
        if (
          (turn === 'w' && ev < bestReplyEval) ||
          (turn === 'b' && ev > bestReplyEval) ||
          !bestReplyUci
        ) {
          bestReplyEval = ev
          bestReplyUci = rep.from + rep.to + (rep.promotion ?? '')
        }
        c.undo()
      }
    }
    c.undo()
    const uci = m.from + m.to + (m.promotion ?? '')
    return {
      uci,
      cp: bestReplyEval,
      pv: bestReplyUci ? [uci, bestReplyUci] : [uci],
    }
  })

  scoredMoves.sort((a, b) => (turn === 'w' ? b.cp - a.cp : a.cp - b.cp))

  const variations: PVLine[] = []
  for (let i = 0; i < Math.min(multiPvCount, scoredMoves.length); i++) {
    const item = scoredMoves[i]
    const v = validatePvLine(fen, i + 1, { cp: item.cp }, 10, 12, item.pv)
    if (v) variations.push(v)
  }

  const v1 = variations[0]
  const v2 = variations[1]
  const v3 = variations[2]

  return {
    fen,
    turn,
    score: v1?.score ?? { cp: 0 },
    best: v1?.firstMove.uci ?? '',
    bestSan: v1?.firstMove.san ?? '',
    secondBest: v2?.firstMove.uci,
    secondBestSan: v2?.firstMove.san,
    secondBestScore: v2?.score,
    thirdBest: v3?.firstMove.uci,
    thirdBestSan: v3?.firstMove.san,
    thirdBestScore: v3?.score,
    pv: v1?.uciMoves ?? [],
    pvSan: v1?.sanMoves ?? [],
    variations,
    depth: 10,
    seldepth: 12,
    tactics: analysePositionTactics(fen, variations),
    completedAt: Date.now(),
  }
}

/**
 * Reliable UCI wrapper around Stockfish 19 WASM Web Worker.
 * - Uses strict `isready` / `readyok` synchronization before every search so old stopped searches can NEVER leak lines into newer searches.
 * - Waits for `bestmove` completion before resolving analysis (never emits preliminary/flickering arrows).
 * - Separates private AI move selection (`selectAiMove`) from human coaching analysis (`analyse`).
 */
export class Engine {
  private w: Worker | null = null
  private listeners = new Set<(line: string) => void>()
  private ready: Promise<void>
  private chain: Promise<unknown> = Promise.resolve()
  private searching = false
  private currentSearchPurpose: 'ai' | 'analysis' | null = null
  private useFallback = false
  private analysisEpoch = 0

  constructor() {
    try {
      this.w = new Worker('/stockfish/stockfish.js#/stockfish/stockfish.wasm')
      this.w.onmessage = (e) => {
        const text = String(e.data ?? '')
        for (const line of text.split(/\r?\n/)) {
          const trimmed = line.trim()
          if (trimmed) this.listeners.forEach((f) => f(trimmed))
        }
      }
      this.w.onerror = () => {
        this.useFallback = true
      }
      this.ready = Promise.race([
        this.until('uciok', () => this.send('uci')).then(() =>
          this.until('readyok', () => this.send('isready'))
        ),
        new Promise<void>((resolve) =>
          setTimeout(() => {
            this.useFallback = true
            resolve()
          }, 4500)
        ),
      ])
    } catch {
      this.useFallback = true
      this.ready = Promise.resolve()
    }
  }

  private send(cmd: string) {
    try {
      this.w?.postMessage(cmd)
    } catch {
      this.useFallback = true
    }
  }

  private enqueue<T>(fn: () => Promise<T>): Promise<T> {
    const p = this.chain.then(fn)
    this.chain = p.catch(() => undefined)
    return p
  }

  private until(
    token: string,
    start: () => void,
    collect?: (line: string) => void
  ) {
    return new Promise<void>((resolve) => {
      const f = (line: string) => {
        collect?.(line)
        if (line.startsWith(token)) {
          this.listeners.delete(f)
          resolve()
        }
      }
      this.listeners.add(f)
      start()
    })
  }

  /**
   * Increments the analysis epoch and stops any in-flight coaching analysis search immediately.
   * Does not interrupt an active AI move calculation unless `forceAll` is true.
   */
  cancelPendingAnalysis(forceAll = false): number {
    this.analysisEpoch++
    if (
      this.searching &&
      (forceAll || this.currentSearchPurpose === 'analysis')
    ) {
      this.send('stop')
    }
    return this.analysisEpoch
  }

  getCurrentEpoch(): number {
    return this.analysisEpoch
  }

  stop() {
    this.analysisEpoch++
    if (this.searching) {
      this.send('stop')
    }
  }

  private async syncReady(): Promise<void> {
    if (this.useFallback || !this.w) return
    await this.until('readyok', () => this.send('isready'))
  }

  private async search(
    fen: string,
    s: Strength & { depth?: number },
    purpose: 'ai' | 'analysis',
    onInfo: (line: string) => void
  ): Promise<string> {
    await this.ready
    if (this.useFallback || !this.w) {
      const fb = fallbackEvaluateFen(fen, s.multiPv)
      return fb.best
    }

    // Flush any previous search output using UCI isready/readyok barrier
    await this.syncReady()

    this.send(`setoption name UCI_LimitStrength value ${s.limit}`)
    this.send(`setoption name UCI_Elo value ${s.uciElo}`)
    this.send(`setoption name Skill Level value ${s.skill}`)
    this.send(`setoption name MultiPV value ${s.multiPv}`)
    this.send(`position fen ${fen}`)
    await this.syncReady()

    let best = ''
    this.searching = true
    this.currentSearchPurpose = purpose
    const goCmd = s.depth
      ? `go depth ${s.depth} movetime ${s.movetime}`
      : `go movetime ${s.movetime}`
    try {
      await this.until(
        'bestmove',
        () => this.send(goCmd),
        (l) => {
          if (l.startsWith('bestmove')) {
            const rawBest = l.split(' ')[1] ?? ''
            best = rawBest === '(none)' ? '' : rawBest
          } else {
            onInfo(l)
          }
        }
      )
    } finally {
      this.searching = false
      this.currentSearchPurpose = null
    }
    return best
  }

  /**
   * Private AI move selection: Stockfish chooses the AI's move internally according to `s`.
   * Never exposes or updates human coaching arrows.
   */
  selectAiMove(fen: string, s: Strength): Promise<string> {
    return this.enqueue(async () => {
      const c = new Chess(fen)
      const legalMoves = c.moves({ verbose: true })
      if (legalMoves.length === 0) return ''
      if (legalMoves.length === 1) {
        const only = legalMoves[0]
        return only.from + only.to + (only.promotion ?? '')
      }

      const candidates = new Map<number, string>()
      const best = await this.search(fen, s, 'ai', (l) => {
        if (l.startsWith('info') && l.includes(' pv ')) {
          const mpv = Number(/multipv (\d+)/.exec(l)?.[1] ?? 1)
          const moveToken = l.split(' pv ')[1]?.trim().split(/\s+/)[0] ?? ''
          if (moveToken && isLegalUciMove(fen, moveToken)) {
            candidates.set(mpv, moveToken)
          }
        }
      })

      if (s.multiPv > 1 && candidates.size > 1 && Math.random() < s.blunder) {
        const others = [...candidates]
          .filter(([k, m]) => k > 1 && isLegalUciMove(fen, m))
          .map(([, m]) => m)
        if (others.length > 0) {
          return others[Math.floor(Math.random() * others.length)]
        }
      }

      if (best && isLegalUciMove(fen, best)) {
        return best
      }

      const topCandidate = candidates.get(1)
      if (topCandidate && isLegalUciMove(fen, topCandidate)) {
        return topCandidate
      }

      // Guaranteed legal fallback
      const fallback = legalMoves[0]
      return fallback.from + fallback.to + (fallback.promotion ?? '')
    })
  }

  /** Alias preserved for backward compatibility */
  bestMove(fen: string, s: Strength): Promise<string> {
    return this.selectAiMove(fen, s)
  }

  /**
   * Full-strength MultiPV evaluation of a position, scored from White's point of view.
   * Completes the entire search until `bestmove` before returning the validated result.
   * Never emits partial/flickering arrow states.
   */
  analyse(
    fen: string,
    optsOrMovetime: number | AnalysisOptions = 700
  ): Promise<Analysis> {
    const opts: AnalysisOptions =
      typeof optsOrMovetime === 'number'
        ? { movetime: optsOrMovetime }
        : optsOrMovetime
    const movetime = Math.max(250, opts.movetime ?? DEFAULT_ANALYSIS.movetime)
    const depthLimit = Math.max(8, opts.depth ?? 14)
    const multiPv = opts.multiPv ?? 3
    const requestedEpoch = opts.epoch

    return this.enqueue(async () => {
      const rootChess = new Chess(fen)
      const turn = rootChess.turn()

      if (rootChess.isGameOver()) {
        const terminalScore: Score = rootChess.isCheckmate()
          ? { cp: turn === 'w' ? -10000 : 10000 }
          : { cp: 0 }
        return {
          fen,
          turn,
          score: terminalScore,
          best: '',
          bestSan: '',
          pv: [],
          pvSan: [],
          variations: [],
          depth: 0,
          seldepth: 0,
          tactics: analysePositionTactics(fen, []),
          completedAt: Date.now(),
        }
      }

      // If this analysis request was already superseded before starting in the queue, skip heavy search
      if (
        requestedEpoch !== undefined &&
        requestedEpoch !== this.analysisEpoch
      ) {
        throw new Error('ANALYSIS_SUPERSEDED')
      }

      if (this.useFallback || !this.w) {
        return fallbackEvaluateFen(fen, multiPv)
      }

      const side: 1 | -1 = turn === 'w' ? 1 : -1
      // Store only the deepest valid info line per multipv slot
      const deepestLines = new Map<
        number,
        { depth: number; seldepth: number; score: Score; pv: string[] }
      >()
      let maxDepth = 0
      let maxSeldepth = 0

      const bestUci = await this.search(
        fen,
        { ...DEFAULT_ANALYSIS, movetime, multiPv, depth: depthLimit },
        'analysis',
        (line) => {
          const parsed = parseUciInfoLine(line, side)
          if (parsed) {
            const existing = deepestLines.get(parsed.multipv)
            if (!existing || parsed.depth >= existing.depth) {
              deepestLines.set(parsed.multipv, {
                depth: parsed.depth,
                seldepth: parsed.seldepth,
                score: parsed.score,
                pv: parsed.pv,
              })
            }
            if (parsed.depth > maxDepth) {
              maxDepth = parsed.depth
            }
            if (parsed.seldepth > maxSeldepth) {
              maxSeldepth = parsed.seldepth
            }
          }
        }
      )

      // Check if superseded while searching
      if (
        requestedEpoch !== undefined &&
        requestedEpoch !== this.analysisEpoch
      ) {
        throw new Error('ANALYSIS_SUPERSEDED')
      }

      const sortedEntries = [...deepestLines.entries()].sort(
        (a, b) => a[0] - b[0]
      )
      const variations: PVLine[] = []
      const seenFirstMoves = new Set<string>()

      // Ensure the final `bestmove` from Stockfish is always honored as variation #1 if valid
      for (const [, item] of sortedEntries) {
        const validated = validatePvLine(
          fen,
          variations.length + 1,
          item.score,
          item.depth,
          item.seldepth,
          item.pv
        )
        if (validated && !seenFirstMoves.has(validated.firstMove.uci)) {
          seenFirstMoves.add(validated.firstMove.uci)
          variations.push(validated)
        }
      }

      if (
        variations.length === 0 &&
        bestUci &&
        isLegalUciMove(fen, bestUci)
      ) {
        const single = validatePvLine(fen, 1, { cp: 0 }, 1, 1, [bestUci])
        if (single) variations.push(single)
      }

      // If bestUci is legal and differs from variation[0], ensure variation[0] is valid
      if (variations.length === 0) {
        return fallbackEvaluateFen(fen, multiPv)
      }

      const v1 = variations[0]
      const v2 = variations[1]
      const v3 = variations[2]

      return {
        fen,
        turn,
        score: v1?.score ?? { cp: 0 },
        best: v1?.firstMove.uci ?? bestUci,
        bestSan: v1?.firstMove.san ?? '',
        secondBest: v2?.firstMove.uci,
        secondBestSan: v2?.firstMove.san,
        secondBestScore: v2?.score,
        thirdBest: v3?.firstMove.uci,
        thirdBestSan: v3?.firstMove.san,
        thirdBestScore: v3?.score,
        pv: v1?.uciMoves ?? [],
        pvSan: v1?.sanMoves ?? [],
        variations,
        depth: maxDepth || (v1?.depth ?? 1),
        seldepth: maxSeldepth || (v1?.seldepth ?? 1),
        tactics: analysePositionTactics(fen, variations),
        completedAt: Date.now(),
      }
    })
  }

  destroy() {
    this.w?.terminate()
  }
}
