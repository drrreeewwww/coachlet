import { useCallback, useEffect, useState } from 'react'
import { DEFAULTS, type Settings } from './settings'

const KEY = 'chess-coach:settings:v2'
const SYNC_EVENT = 'chess-coach:settings-sync'

export function useSettings(): [
  Settings,
  (patch: Partial<Settings>) => void,
  () => void,
] {
  const [s, setS] = useState<Settings>(() => {
    if (typeof window === 'undefined') return DEFAULTS
    try {
      const raw = localStorage.getItem(KEY) ?? localStorage.getItem('chess-coach:settings')
      if (raw) return { ...DEFAULTS, ...JSON.parse(raw) }
    } catch {
      /* use defaults */
    }
    return DEFAULTS
  })

  useEffect(() => {
    const onSync = (e: Event) => {
      const detail = (e as CustomEvent<Settings>).detail
      if (detail) setS(detail)
    }
    window.addEventListener(SYNC_EVENT, onSync)
    return () => window.removeEventListener(SYNC_EVENT, onSync)
  }, [])

  const save = (n: Settings) => {
    try {
      localStorage.setItem(KEY, JSON.stringify(n))
      window.dispatchEvent(new CustomEvent(SYNC_EVENT, { detail: n }))
    } catch {
      /* storage unavailable */
    }
  }

  const update = useCallback((p: Partial<Settings>) => {
    setS((prev) => {
      const n = { ...prev, ...p }
      save(n)
      return n
    })
  }, [])

  const reset = useCallback(() => {
    setS(DEFAULTS)
    save(DEFAULTS)
  }, [])

  return [s, update, reset]
}
