import { Chess, type PieceSymbol, type Square } from 'chess.js'
import { useEffect, useMemo, useState } from 'react'
import { DEFAULTS, THEMES, type Settings } from '@/lib/settings'
import type { BoardArrow, MoveBadgeOverlay } from '@/types'
import { StauntonPieceSvg } from './StauntonPieces'

const FILES = 'abcdefgh'
const HOLLOW: Record<string, string> = {
  p: '♙',
  n: '♘',
  b: '♗',
  r: '♖',
  q: '♕',
  k: '♔',
}
const SOLID: Record<string, string> = {
  p: '♟',
  n: '♞',
  b: '♝',
  r: '♜',
  q: '♛',
  k: '♚',
}

const nameAt = (i: number) => (FILES[i % 8] + (8 - Math.floor(i / 8))) as Square

function squareCenter(
  sq: string,
  flipped: boolean
): { x: number; y: number } | null {
  if (!sq || sq.length < 2) return null
  const f = FILES.indexOf(sq[0])
  const r = 8 - Number(sq[1])
  if (f < 0 || f > 7 || r < 0 || r > 7 || Number.isNaN(r)) return null
  const col = flipped ? 7 - f : f
  const row = flipped ? 7 - r : r
  return { x: col * 100 + 50, y: row * 100 + 50 }
}

interface Props {
  fen: string
  flipped: boolean
  lastMove: { from: string; to: string } | null
  disabled: boolean
  marks?: string[]
  highlightSquares?: string[]
  arrows?: BoardArrow[]
  badge?: MoveBadgeOverlay | null
  replayOverlay?: string | null
  look?: Partial<Pick<Settings, 'theme' | 'pieces' | 'coords'>>
  onMove: (from: string, to: string, promotion?: string) => void
}

export default function Chessboard({
  fen,
  flipped,
  lastMove,
  disabled,
  marks,
  highlightSquares,
  arrows,
  badge,
  replayOverlay,
  look,
  onMove,
}: Props) {
  const [sel, setSel] = useState<Square | null>(null)
  const [dragOverSq, setDragOverSq] = useState<Square | null>(null)
  const [promo, setPromo] = useState<{ from: Square; to: Square } | null>(null)

  // Clear selection whenever position changes
  useEffect(() => {
    setSel(null)
    setDragOverSq(null)
    setPromo(null)
  }, [fen])

  const { theme, pieces, coords } = {
    theme: DEFAULTS.theme,
    pieces: DEFAULTS.pieces,
    coords: DEFAULTS.coords,
    ...look,
  }
  const T = THEMES[theme] ?? THEMES.green

  const chess = useMemo(() => {
    try {
      return new Chess(fen)
    } catch {
      return new Chess()
    }
  }, [fen])

  const board = chess.board().flat()
  const turn = chess.turn()

  const targets = useMemo(
    () =>
      new Set(
        sel ? chess.moves({ square: sel, verbose: true }).map((m) => m.to) : []
      ),
    [sel, chess]
  )

  const checkedKingSq = chess.inCheck()
    ? board.find((p) => p && p.type === 'k' && p.color === turn)?.square
    : undefined

  const executeOrPromptPromotion = (from: Square, to: Square) => {
    setSel(null)
    setDragOverSq(null)
    const isPromotion = chess
      .moves({ square: from, verbose: true })
      .some((m) => m.to === to && m.promotion)
    if (isPromotion) {
      setPromo({ from, to })
    } else {
      onMove(from, to)
    }
  }

  const handleSquareClick = (sq: Square) => {
    if (disabled) return
    if (sel && targets.has(sq)) {
      executeOrPromptPromotion(sel, sq)
      return
    }
    const p = chess.get(sq)
    if (p && p.color === turn) {
      setSel((prev) => (prev === sq ? null : sq))
    } else {
      setSel(null)
    }
  }

  return (
    <div className="relative aspect-square w-full max-w-[640px] overflow-hidden rounded-[6px] shadow-[0_14px_38px_rgba(0,0,0,0.55)] ring-1 ring-black/50 select-none">
      <div className="grid h-full w-full grid-cols-8 grid-rows-8">
        {Array.from({ length: 64 }, (_, d) => {
          const i = flipped ? 63 - d : d
          const sq = nameAt(i)
          const p = board[i]
          const isDark = ((i % 8) + Math.floor(i / 8)) % 2 === 1
          const bgColor = isDark ? T.dark : T.light
          const coordColor = isDark ? T.coordDark : T.coordLight
          const canInteractWithPiece = !disabled && !!p && p.color === turn
          const isWhitePiece = p?.color === 'w'
          const isLastMoveSq =
            lastMove && (sq === lastMove.from || sq === lastMove.to)
          const isSelectedSq = sq === sel
          const isTargetSq = targets.has(sq)
          const isDragHover = dragOverSq === sq && isTargetSq
          const isHighlightedDest = highlightSquares?.includes(sq)
          const hasBadge = badge && badge.square === sq

          return (
            <div
              key={sq}
              data-square={sq}
              onClick={() => handleSquareClick(sq)}
              onDragOver={(e) => {
                if (disabled) return
                e.preventDefault()
                if (dragOverSq !== sq) setDragOverSq(sq)
              }}
              onDragLeave={() => {
                if (dragOverSq === sq) setDragOverSq(null)
              }}
              onDrop={(e) => {
                e.preventDefault()
                setDragOverSq(null)
                if (disabled) return
                if (sel && targets.has(sq)) {
                  executeOrPromptPromotion(sel, sq)
                } else {
                  setSel(null)
                }
              }}
              style={{ backgroundColor: bgColor }}
              className={`relative flex items-center justify-center transition-colors duration-75 ${
                canInteractWithPiece || isTargetSq ? 'cursor-pointer' : ''
              }`}
            >
              {/* Chess.com-style Last Move Highlight */}
              {isLastMoveSq && (
                <span
                  className="pointer-events-none absolute inset-0"
                  style={{
                    backgroundColor: isDark
                      ? 'rgba(186, 202, 43, 0.58)'
                      : 'rgba(246, 246, 105, 0.68)',
                  }}
                />
              )}

              {/* Selected Piece Highlight */}
              {isSelectedSq && (
                <span
                  className="pointer-events-none absolute inset-0"
                  style={{
                    backgroundColor: isDark
                      ? 'rgba(186, 202, 43, 0.78)'
                      : 'rgba(246, 246, 105, 0.82)',
                  }}
                />
              )}

              {/* Drag Target Hover Ring */}
              {isDragHover && (
                <span className="pointer-events-none absolute inset-0 ring-4 ring-inset ring-white/75" />
              )}

              {/* Variation / Recommended Square Subtle Highlight */}
              {isHighlightedDest && !isSelectedSq && (
                <span className="pointer-events-none absolute inset-0 bg-[#81b64c]/25 ring-2 ring-inset ring-[#81b64c]/70" />
              )}

              {/* Progressive Hint / Blunder Square Ring */}
              {marks?.includes(sq) && (
                <span className="pointer-events-none absolute inset-0 bg-amber-400/25 ring-4 ring-inset ring-amber-400/90" />
              )}

              {/* King in Check Radial Alert Highlight */}
              {sq === checkedKingSq && (
                <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle,rgba(235,45,45,0.92)_0%,rgba(205,25,25,0.65)_48%,transparent_72%)]" />
              )}

              {/* Rank Coordinate Label (Left Edge) */}
              {coords && d % 8 === 0 && (
                <span
                  className="pointer-events-none absolute left-1 top-0.5 z-[2] text-[10px] font-bold leading-none sm:text-[11px]"
                  style={{ color: coordColor }}
                >
                  {8 - Math.floor(i / 8)}
                </span>
              )}

              {/* File Coordinate Label (Bottom Edge) */}
              {coords && d >= 56 && (
                <span
                  className="pointer-events-none absolute bottom-0.5 right-1 z-[2] text-[10px] font-bold leading-none sm:text-[11px]"
                  style={{ color: coordColor }}
                >
                  {FILES[i % 8]}
                </span>
              )}

              {/* Chess.com-style Legal Move Indicators (Dot for empty, Ring for capture) */}
              {isTargetSq &&
                (p ? (
                  <span className="pointer-events-none absolute inset-[5%] z-[3] rounded-full border-[5px] border-black/22 sm:border-[6px]" />
                ) : (
                  <span className="pointer-events-none absolute z-[3] h-[31%] w-[31%] rounded-full bg-black/20" />
                ))}

              {/* Chess Piece Rendering */}
              {p && (
                <div
                  draggable={canInteractWithPiece}
                  onDragStart={(e) => {
                    if (!canInteractWithPiece) {
                      e.preventDefault()
                      return
                    }
                    setSel(sq)
                    e.dataTransfer.effectAllowed = 'move'
                  }}
                  onDragEnd={() => {
                    setDragOverSq(null)
                  }}
                  className={`relative z-[2] flex h-[85%] w-[85%] items-center justify-center transition-transform duration-100 ${
                    canInteractWithPiece
                      ? 'cursor-grab active:scale-110 active:cursor-grabbing hover:scale-[1.03]'
                      : ''
                  }`}
                >
                  {pieces === 'classic' ? (
                    <StauntonPieceSvg
                      type={p.type}
                      color={p.color}
                      className="h-full w-full"
                    />
                  ) : pieces === 'letters' ? (
                    <span
                      className={`grid h-[82%] w-[82%] place-items-center rounded-full border-2 text-sm font-extrabold shadow-md sm:text-xl ${
                        isWhitePiece
                          ? 'border-stone-800 bg-stone-50 text-stone-900'
                          : 'border-stone-200 bg-stone-900 text-stone-50'
                      }`}
                    >
                      {p.type.toUpperCase()}
                    </span>
                  ) : (
                    <span
                      className={`text-[length:min(7.8vw,3.3rem)] leading-none ${
                        isWhitePiece
                          ? 'text-stone-900 drop-shadow-[0_1px_1px_rgba(255,255,255,0.6)]'
                          : 'text-stone-900'
                      }`}
                    >
                      {(isWhitePiece ? HOLLOW : SOLID)[p.type]}
                    </span>
                  )}
                </div>
              )}

              {/* Chess.com-style Move Classification Badge on Destination Square */}
              {hasBadge && (
                <span
                  title={`${badge.label} (${badge.icon})`}
                  style={{ backgroundColor: badge.color }}
                  className="pointer-events-none absolute -right-0.5 -top-0.5 z-10 flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[10px] font-black text-white shadow-md ring-2 ring-black/40 sm:right-0.5 sm:top-0.5 sm:h-5.5 sm:min-w-5.5 sm:text-[11px]"
                >
                  {badge.icon}
                </span>
              )}
            </div>
          )
        })}
      </div>

      {/* Validated Stockfish Coaching Arrows Overlay (Only shown on human turn after completed analysis) */}
      {arrows && arrows.length > 0 && (
        <svg
          viewBox="0 0 800 800"
          className="pointer-events-none absolute inset-0 z-[5] h-full w-full"
          aria-label="Coaching recommendation arrows"
        >
          {arrows.map((a, idx) => {
            const p1 = squareCenter(a.from, flipped)
            const p2 = squareCenter(a.to, flipped)
            if (!p1 || !p2 || (p1.x === p2.x && p1.y === p2.y)) return null
            const dx = p2.x - p1.x
            const dy = p2.y - p1.y
            const len = Math.hypot(dx, dy)
            if (len < 10) return null
            const ux = dx / len
            const uy = dy / len
            const startX = p1.x + ux * 16
            const startY = p1.y + uy * 16
            const tipX = p2.x - ux * 8
            const tipY = p2.y - uy * 8
            const lineEndX = p2.x - ux * 38
            const lineEndY = p2.y - uy * 38
            const perpX = -uy
            const perpY = ux
            const wing1X = lineEndX + perpX * 24
            const wing1Y = lineEndY + perpY * 24
            const wing2X = lineEndX - perpX * 24
            const wing2Y = lineEndY - perpY * 24

            return (
              <g key={`${a.from}-${a.to}-${idx}`} opacity={a.opacity ?? 0.86}>
                <line
                  x1={startX}
                  y1={startY}
                  x2={lineEndX}
                  y2={lineEndY}
                  stroke={a.color}
                  strokeWidth={idx === 0 ? 19 : 14}
                  strokeLinecap="round"
                  strokeDasharray={a.dashed ? '20 14' : undefined}
                />
                <polygon
                  points={`${tipX},${tipY} ${wing1X},${wing1Y} ${wing2X},${wing2Y}`}
                  fill={a.color}
                />
                {a.label && (
                  <g>
                    <circle
                      cx={startX + ux * 20}
                      cy={startY + uy * 20}
                      r="16"
                      fill="#1e1c1a"
                      stroke={a.color}
                      strokeWidth="3"
                    />
                    <text
                      x={startX + ux * 20}
                      y={startY + uy * 20 + 5}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="14"
                      fontWeight="bold"
                    >
                      {a.label}
                    </text>
                  </g>
                )}
              </g>
            )
          })}
        </svg>
      )}

      {/* Variation Replay Banner */}
      {replayOverlay && (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 bg-[#1e1c1a]/92 px-3 py-1.5 text-center text-xs font-semibold text-[#81b64c] backdrop-blur-xs">
          {replayOverlay}
        </div>
      )}

      {/* Chess.com-style Pawn Promotion Picker Overlay */}
      {promo && (
        <div
          role="dialog"
          aria-label="Choose promotion piece"
          className="absolute inset-0 z-20 flex items-center justify-center bg-black/70 backdrop-blur-[2px]"
          onClick={() => setPromo(null)}
        >
          <div
            className="flex flex-col items-center gap-3 rounded-xl border border-[#3c3a36] bg-[#262522] p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <span className="text-xs font-bold uppercase tracking-wider text-stone-300">
              Promote Pawn To
            </span>
            <div className="flex gap-2.5">
              {(['q', 'n', 'r', 'b'] as PieceSymbol[]).map((k) => (
                <button
                  key={k}
                  type="button"
                  aria-label={`Promote to ${k}`}
                  onClick={() => {
                    onMove(promo.from, promo.to, k)
                    setPromo(null)
                  }}
                  className="flex h-16 w-16 items-center justify-center rounded-lg border border-[#3c3a36] bg-[#302e2b] p-2 transition hover:scale-105 hover:border-[#81b64c] hover:bg-[#3a3733]"
                >
                  <StauntonPieceSvg type={k} color={turn} />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
