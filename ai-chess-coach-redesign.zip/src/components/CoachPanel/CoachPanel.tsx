import { useEffect, useState } from 'react'
import { Volume2, VolumeX, Play, Square, Sparkles, Sliders } from 'lucide-react'
import Avatar from './Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { CLASS_META, type MoveClass } from '@/lib/evaluation/classify'
import { bandFor, eloTierFor } from '@/lib/stockfish/elo'
import {
  speak,
  subscribeSpeechState,
  type SpeechDiagnosticState,
} from '@/lib/voice/speak'
import { COACH_VOICE_PROFILES, VOICE_PROVIDERS } from '@/lib/voice/voiceConfig'
import type {
  CoachId,
  StructuredCoachResponse,
  VoiceProviderId,
} from '@/types'

export interface Reaction {
  text: string
  cls: MoveClass
  cpLoss: number
  san: string
  bestSan?: string
}

export interface ChatMsg {
  from: 'you' | 'coach'
  text: string
}

const QUICK_QUESTIONS = [
  'Why is this move a mistake?',
  'What would a grandmaster play here?',
  'Why is my king unsafe?',
  'How do I win this endgame?',
  'What happens if I sacrifice this piece?',
  'Explain this position in simpler terms.',
]

const VOICE_TEST_SAMPLES: Array<{
  label: string
  cls: MoveClass
  getText: (coachId: CoachId) => string
}> = [
  {
    label: '!! Brilliant Sacrifice',
    cls: 'brilliant',
    getText: (c) =>
      c === 'flash'
        ? 'BOOM!! Bxh7+ is a brilliant sacrifice! After Kxh7, Ng5+ and Qh5 creates an unstoppable mating net (+M4)!'
        : c === 'gambit'
          ? 'Standing ovation! Nd5!! sacrifices a full knight in the Sicilian Najdorf, ripping open the e-file after exd5 and Rfe1+!'
          : 'Remarkable. Rxd5!! is a clinical exchange sacrifice (+2.4) that paralyzes the opponent’s queenside structure.',
  },
  {
    label: '?? Blunder Alert',
    cls: 'blunder',
    getText: (c) =>
      c === 'flash'
        ? 'No, no, no! Qxf7?? walks straight into Rf8 and your queen is trapped! O-O was required to get your king safe (−340 cp).'
        : c === 'gambit'
          ? 'Gasp! Dramatic plot twist — playing h6?? allows Bxf7+ followed by Ne6, losing the queen! Nf6 was the only way out.'
          : 'That, I am afraid, is a serious error (−280 cp). Playing Ke2?? walks into a pin; Rfe1 was necessary to hold the balance.',
  },
  {
    label: '★ Tactical / Endgame Plan',
    cls: 'best',
    getText: (c) =>
      c === 'flash'
        ? 'Yes! Nxf6+ followed by Qxd4 wins a clean pawn with tempo and keeps the initiative!'
        : c === 'gambit'
          ? 'Chef’s kiss! After O-O-O and f4, we launch a classic fianchetto kingside storm with +1.6 evaluation!'
          : 'Precisely. Rd7 activates the rook on the seventh rank, preparing Ke3 and a passed pawn squeeze in the endgame.',
  },
]

interface Props {
  coachId: CoachId
  elos: Record<CoachId, number>
  onCoach: (id: CoachId) => void
  onElo: (id: CoachId, elo: number) => void
  reaction: Reaction | null
  structured: StructuredCoachResponse | null
  coachLoading?: boolean
  voiceOn: boolean
  onVoice: (on: boolean) => void
  speed: number
  onSpeed: (n: number) => void
  voiceVolume?: number
  onVoiceVolume?: (v: number) => void
  voiceProvider?: VoiceProviderId
  onVoiceProvider?: (p: VoiceProviderId) => void
  onPreview: (id: CoachId) => void
  onReplay: () => void
  onStop: () => void
  chat: ChatMsg[]
  onAsk: (q: string) => void
}

export default function CoachPanel(p: Props) {
  const [q, setQ] = useState('')
  const [showBreakdown, setShowBreakdown] = useState(true)
  const [showVoiceStudio, setShowVoiceStudio] = useState(false)
  const [showCoachesList, setShowCoachesList] = useState(false)
  const [speechDiag, setSpeechDiag] = useState<SpeechDiagnosticState | null>(
    null
  )

  useEffect(() => {
    return subscribeSpeechState(setSpeechDiag)
  }, [])

  const coach = COACHES.find((c) => c.id === p.coachId)!
  const voiceProfile = COACH_VOICE_PROFILES[p.coachId]
  const r = p.reaction
  const currentElo = p.elos[p.coachId]
  const eloTier = eloTierFor(currentElo)

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const t = q.trim()
    if (t) {
      p.onAsk(t)
      setQ('')
    }
  }

  return (
    <section className="space-y-3">
      {/* Main Active Coach & Analysis Card */}
      <div className="rounded-lg border border-[#3a3834] bg-[#262522] p-3.5 shadow-lg">
        {/* Coach Header */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Avatar id={coach.id} accent={coach.accent} size={46} />
              {speechDiag?.isSpeaking && speechDiag.coachId === coach.id && (
                <span
                  title="Speaking"
                  className="absolute -bottom-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#81b64c] text-[#1c1b19] shadow"
                >
                  <Volume2 className="h-2.5 w-2.5 animate-pulse" />
                </span>
              )}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base font-bold leading-tight text-stone-100">
                  {coach.name}
                </h2>
                <span className="rounded border border-[#81b64c]/45 bg-[#81b64c]/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#a3d160]">
                  {eloTier} • {currentElo} Elo
                </span>
              </div>
              <p className="text-xs text-stone-400">{coach.style}</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {p.coachLoading && (
              <span className="flex items-center gap-1.5 rounded-full border border-[#81b64c]/40 bg-[#1e1d1b] px-2.5 py-1 text-[11px] text-[#a3d160]">
                <span className="h-2 w-2 animate-ping rounded-full bg-[#81b64c]" />
                Analysing…
              </span>
            )}
            <button
              type="button"
              onClick={() => setShowCoachesList(!showCoachesList)}
              className="rounded border border-[#3a3834] bg-[#1e1d1b] px-2.5 py-1 text-xs font-medium text-stone-200 transition hover:border-[#81b64c] hover:text-white"
            >
              {showCoachesList ? 'Hide Coaches ▲' : 'Switch Coach / Elo ▼'}
            </button>
          </div>
        </div>

        {/* Collapsible Coach & Elo Switcher Drawer */}
        {showCoachesList && (
          <div className="mt-3 space-y-2.5 rounded-lg border border-[#3a3834] bg-[#1c1b19] p-3">
            <div className="grid gap-2.5">
              {COACHES.map((c) => {
                const sel = c.id === p.coachId
                const vp = COACH_VOICE_PROFILES[c.id]
                return (
                  <div
                    key={c.id}
                    className={`rounded-lg border p-3 transition ${
                      sel
                        ? 'border-[#81b64c] bg-[#262522] shadow-md'
                        : 'border-[#33312d] bg-[#21201d] hover:border-[#46433e]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <Avatar id={c.id} accent={c.accent} size={38} />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h3 className="text-sm font-bold text-stone-100">
                              {c.name}
                            </h3>
                            <span className="rounded bg-[#33312d] px-1.5 py-0.5 text-[10px] text-stone-300">
                              {vp.label}
                            </span>
                          </div>
                          <p className="text-[11px] text-stone-400">
                            {c.inspiredBy}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => p.onPreview(c.id)}
                          className="rounded border border-[#3a3834] bg-[#1c1b19] px-2 py-1 text-[11px] text-stone-300 hover:bg-[#302e2b]"
                        >
                          🔊 Sample
                        </button>
                        <button
                          type="button"
                          onClick={() => p.onCoach(c.id)}
                          className={`rounded px-2.5 py-1 text-xs font-bold transition ${
                            sel
                              ? 'bg-[#81b64c] text-[#1c1b19]'
                              : 'border border-[#81b64c]/60 text-[#a3d160] hover:bg-[#81b64c]/15'
                          }`}
                        >
                          {sel ? 'Active' : 'Select'}
                        </button>
                      </div>
                    </div>

                    <div className="mt-2.5 flex items-center gap-3 text-xs">
                      <label
                        htmlFor={`elo-${c.id}`}
                        className="shrink-0 text-stone-400"
                      >
                        Strength:{' '}
                        <b className="font-mono text-stone-100">
                          {p.elos[c.id]}
                        </b>{' '}
                        <span className="text-[11px] text-stone-400">
                          ({bandFor(p.elos[c.id])})
                        </span>
                      </label>
                      <input
                        id={`elo-${c.id}`}
                        type="range"
                        min={300}
                        max={3200}
                        step={50}
                        value={p.elos[c.id]}
                        onChange={(e) => p.onElo(c.id, Number(e.target.value))}
                        className="w-full accent-[#81b64c]"
                      />
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Chess.com-style Move Classification Pill + Coach Dialogue Bubble */}
        <div className="mt-3 rounded-lg border border-[#363430] bg-[#1c1b19] p-3">
          {r && (
            <div
              className="mb-2 flex flex-wrap items-center gap-2 text-xs"
              title={CLASS_META[r.cls].note}
            >
              <span
                className="inline-flex items-center gap-1 rounded px-2 py-0.5 font-extrabold text-white shadow-xs"
                style={{ background: CLASS_META[r.cls].color }}
              >
                <span>{CLASS_META[r.cls].icon}</span>
                <span>{CLASS_META[r.cls].label}</span>
              </span>
              <span className="font-mono text-sm font-bold text-white">
                {r.san}
              </span>
              {r.cpLoss > 0 && (
                <span className="text-xs text-stone-400">
                  (−{r.cpLoss} cp
                  {r.bestSan && r.bestSan !== r.san
                    ? ` • Best: ${r.bestSan}`
                    : ''}
                  )
                </span>
              )}
            </div>
          )}
          <p
            className="text-sm leading-relaxed text-stone-200"
            aria-live="polite"
          >
            “{r ? r.text : coach.greeting}”
          </p>
        </div>

        {/* Modular Voice Controls & Emotion Status Bar */}
        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-md border border-[#34322e] bg-[#1e1d1b] px-2.5 py-1.5 text-xs">
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => p.onVoice(!p.voiceOn)}
              aria-pressed={p.voiceOn}
              className={`inline-flex items-center gap-1 rounded px-2 py-0.5 font-semibold transition ${
                p.voiceOn
                  ? 'bg-[#81b64c]/20 text-[#a3d160]'
                  : 'bg-[#2c2a27] text-stone-400'
              }`}
            >
              {p.voiceOn ? (
                <Volume2 className="h-3.5 w-3.5" />
              ) : (
                <VolumeX className="h-3.5 w-3.5" />
              )}
              <span>{p.voiceOn ? 'Voice On' : 'Muted'}</span>
            </button>

            <label className="flex items-center gap-1.5 text-stone-300">
              <span>{p.speed.toFixed(1)}×</span>
              <input
                type="range"
                min={0.7}
                max={1.5}
                step={0.1}
                value={p.speed}
                onChange={(e) => p.onSpeed(Number(e.target.value))}
                className="w-16 accent-[#81b64c]"
                aria-label="Voice speed"
              />
            </label>

            {speechDiag && (
              <span className="hidden items-center gap-1 rounded bg-[#2a2825] px-1.5 py-0.5 text-[10px] text-stone-300 sm:inline-flex">
                <Sparkles className="h-3 w-3 text-[#81b64c]" />
                {speechDiag.emotionLabel}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={p.onReplay}
              title="Replay last spoken coaching line"
              className="inline-flex items-center gap-1 rounded border border-[#3a3834] bg-[#262522] px-2 py-0.5 text-[11px] text-stone-200 hover:bg-[#302e2b]"
            >
              <Play className="h-3 w-3" /> Replay
            </button>
            <button
              type="button"
              onClick={p.onStop}
              title="Stop speaking"
              className="inline-flex items-center gap-1 rounded border border-[#3a3834] bg-[#262522] px-2 py-0.5 text-[11px] text-stone-300 hover:bg-[#302e2b]"
            >
              <Square className="h-3 w-3" /> Stop
            </button>
            <button
              type="button"
              onClick={() => setShowVoiceStudio(!showVoiceStudio)}
              className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 text-[11px] transition ${
                showVoiceStudio
                  ? 'border-[#81b64c] bg-[#81b64c]/18 text-[#a3d160]'
                  : 'border-[#3a3834] bg-[#262522] text-stone-300 hover:bg-[#302e2b]'
              }`}
            >
              <Sliders className="h-3 w-3" /> Voice Studio
            </button>
          </div>
        </div>

        {/* Modular Neural Voice Studio & SSML / Notation Preprocessor Drawer */}
        {showVoiceStudio && (
          <div className="mt-2.5 space-y-2.5 rounded-lg border border-[#3a3834] bg-[#1b1a18] p-3 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#33312d] pb-2">
              <div>
                <h3 className="font-bold text-stone-100">
                  {coach.name} Neural Voice Profile ({voiceProfile.label})
                </h3>
                <p className="text-[11px] text-stone-400">
                  {voiceProfile.inspirationNote}
                </p>
              </div>
              <span className="rounded bg-[#2a2825] px-2 py-0.5 font-mono text-[10px] text-[#a3d160]">
                Pitch {voiceProfile.basePitch}× • Pace {voiceProfile.baseRate}×
              </span>
            </div>

            {p.onVoiceProvider && (
              <div className="grid gap-2 sm:grid-cols-2">
                <label className="flex flex-col gap-1 text-stone-300">
                  <span className="text-[11px] font-semibold">
                    TTS Synthesis Provider
                  </span>
                  <select
                    value={p.voiceProvider ?? 'browser-neural'}
                    onChange={(e) =>
                      p.onVoiceProvider?.(e.target.value as VoiceProviderId)
                    }
                    className="rounded border border-[#3a3834] bg-[#262522] px-2 py-1 text-xs text-stone-100"
                  >
                    {VOICE_PROVIDERS.map((vp) => (
                      <option key={vp.id} value={vp.id}>
                        {vp.name}
                      </option>
                    ))}
                  </select>
                </label>

                {p.onVoiceVolume && (
                  <label className="flex flex-col gap-1 text-stone-300">
                    <span className="text-[11px] font-semibold">
                      Voice Volume:{' '}
                      <b className="text-[#a3d160]">
                        {Math.round((p.voiceVolume ?? 0.85) * 100)}%
                      </b>
                    </span>
                    <input
                      type="range"
                      min={0.1}
                      max={1}
                      step={0.05}
                      value={p.voiceVolume ?? 0.85}
                      onChange={(e) =>
                        p.onVoiceVolume?.(Number(e.target.value))
                      }
                      className="accent-[#81b64c]"
                    />
                  </label>
                )}
              </div>
            )}

            {/* Test Emotional Delivery & Chess Notation Pronunciation */}
            <div>
              <span className="block text-[11px] font-semibold text-stone-300">
                Test Dynamic Emotional Delivery & Notation Pronunciation:
              </span>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {VOICE_TEST_SAMPLES.map((sample) => (
                  <button
                    key={sample.label}
                    type="button"
                    onClick={() =>
                      speak(sample.getText(coach.id), coach.id, {
                        speed: p.speed,
                        volume: p.voiceVolume ?? 0.85,
                        provider: p.voiceProvider,
                        context: { moveClass: sample.cls },
                      })
                    }
                    className="rounded border border-[#3a3834] bg-[#262522] px-2.5 py-1 text-[11px] font-medium text-stone-200 transition hover:border-[#81b64c] hover:text-[#a3d160]"
                  >
                    🔊 {sample.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Live Preprocessed Speech & SSML Inspector */}
            {speechDiag && (
              <div className="space-y-1.5 rounded border border-[#33312d] bg-[#141312] p-2.5 text-[11px]">
                <div className="flex flex-wrap items-center justify-between gap-1">
                  <span className="font-semibold text-[#a3d160]">
                    Natural Speech Pipeline ({speechDiag.emotionLabel})
                  </span>
                  <span className="text-[10px] text-stone-400">
                    {speechDiag.cachedHit ? '⚡ Cached Plan' : 'Synthesized'}
                  </span>
                </div>
                <p className="text-stone-300">
                  <b className="text-stone-400">Spoken Output:</b> “
                  {speechDiag.spokenText}”
                </p>
                <details className="text-[10px] text-stone-400">
                  <summary className="cursor-pointer hover:text-stone-200">
                    View Generated W3C SSML Prosody & Emphasis Tags
                  </summary>
                  <pre className="mt-1 overflow-x-auto whitespace-pre-wrap rounded bg-black/50 p-2 font-mono text-[10px] text-emerald-300">
                    {speechDiag.ssml}
                  </pre>
                </details>
              </div>
            )}
          </div>
        )}

        {/* Structured Grandmaster Position Breakdown */}
        {p.structured && (
          <div className="mt-3 rounded-lg border border-[#363430] bg-[#1e1d1b] p-3 text-xs">
            <div className="flex items-center justify-between gap-2">
              <span className="font-bold text-[#a3d160]">
                ✦ {p.structured.headline}
              </span>
              <button
                type="button"
                onClick={() => setShowBreakdown(!showBreakdown)}
                className="text-[11px] text-stone-400 hover:text-white"
              >
                {showBreakdown ? 'Hide ▲' : 'Details ▼'}
              </button>
            </div>
            {showBreakdown && (
              <dl className="mt-2 space-y-2 border-t border-[#33312d] pt-2 text-stone-300">
                <div>
                  <dt className="font-semibold text-stone-200">
                    Move Assessment:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.moveAssessment}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-amber-300">
                    What Was Overlooked:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.overlooked}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-red-300">
                    Opponent Threat:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.opponentThreat}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-emerald-300">
                    Engine Recommendation:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.engineRecommendation}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-sky-300">
                    Strategic Plan ({coach.name}):
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.strategicPlan}
                  </dd>
                </div>
                <div className="rounded border border-[#81b64c]/30 bg-[#81b64c]/8 p-2">
                  <dt className="font-semibold text-[#a3d160]">
                    Coach Improvement Tip:
                  </dt>
                  <dd className="mt-0.5 text-stone-200">
                    {p.structured.improvementTip}
                  </dd>
                </div>
              </dl>
            )}
          </div>
        )}

        {/* Quick-Ask Position Prompts */}
        <div className="mt-3 border-t border-[#363430] pt-2.5">
          <p className="mb-1.5 text-[11px] font-medium text-stone-400">
            Ask {coach.name} about this position:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_QUESTIONS.map((qq) => (
              <button
                key={qq}
                type="button"
                disabled={p.coachLoading}
                onClick={() => p.onAsk(qq)}
                className="rounded-full border border-[#3a3834] bg-[#1c1b19] px-2.5 py-1 text-[11px] text-stone-300 transition hover:border-[#81b64c] hover:text-[#a3d160] disabled:opacity-40"
              >
                {qq}
              </button>
            ))}
          </div>
        </div>

        {/* Conversation Log */}
        {p.chat.length > 0 && (
          <ul
            className="mt-2.5 max-h-44 space-y-2 overflow-y-auto rounded-lg border border-[#33312d] bg-[#181715] p-2.5 text-xs"
            aria-live="polite"
          >
            {p.chat.slice(-10).map((m, i) => (
              <li
                key={i}
                className={
                  m.from === 'you'
                    ? 'ml-6 rounded-lg bg-[#302e2b] px-2.5 py-1.5 text-right text-stone-200'
                    : 'mr-4 rounded-lg border border-[#3a3834] bg-[#262522] px-2.5 py-1.5 text-stone-100'
                }
              >
                {m.from === 'you' ? (
                  <span>You: {m.text}</span>
                ) : (
                  <span>
                    <b className="text-[#a3d160]">{coach.name}:</b> {m.text}
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}

        {/* Free-form Question Input */}
        <form onSubmit={submit} className="mt-2.5 flex gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Ask about this move, variations, king safety, or endgame plan…"
            aria-label="Ask your coach"
            className="min-w-0 flex-1 rounded-md border border-[#3a3834] bg-[#1c1b19] px-3 py-1.5 text-xs text-stone-100 placeholder:text-stone-500 focus:border-[#81b64c] focus:outline-none"
          />
          <button
            type="submit"
            disabled={p.coachLoading}
            className="rounded-md bg-[#81b64c] px-3.5 py-1.5 text-xs font-bold text-[#1c1b19] transition hover:brightness-110 disabled:opacity-50"
          >
            Ask
          </button>
        </form>
      </div>
    </section>
  )
}
