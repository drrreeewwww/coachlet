# AI Chess Coach — Real Stockfish MultiPV Analysis & Grandmaster-Level Coaching

Play Stockfish at any strength from **300 to 3200 Elo** with live MultiPV engine lines, interactive variation replay on the chessboard, Chess.com-style 8-tier move classifications (`Brilliant !!` to `Blunder ??`), SVG board arrows, and personalised AI coaching from three original fictional coaches (**Vale**, **Flash**, and **Gambit**).

## Quick Start

```bash
npm install                   # Installs dependencies
node scripts/copy-stockfish.mjs # Copies Stockfish WASM worker into public/stockfish/
npm run dev                   # Starts the Next.js development server at http://localhost:3000
```

Run the test suite (verifying 8-tier move classifications, sacrifice detection, Stockfish MultiPV=3 search, `chess.js` variation validation, and structured coaching):

```bash
node --experimental-strip-types scripts/test-classify.mjs
```

## Language Model API Configuration (Optional)

Copy `.env.example` to `.env.local` (or `.env`) and configure one of the supported language model providers:

- **Anthropic Claude**: `ANTHROPIC_API_KEY` (and optional `ANTHROPIC_MODEL`, defaults to `claude-sonnet-4-20250514`)
- **OpenAI**: `OPENAI_API_KEY` (and optional `OPENAI_MODEL`, defaults to `gpt-4o-mini`)
- **Google Gemini**: `GEMINI_API_KEY` (and optional `GEMINI_MODEL`, defaults to `gemini-2.5-flash`)

All API keys are read strictly on the server in `src/app/api/coach/route.ts` and are never exposed to the client. Every LLM response is parsed against the structured coaching schema and validated against `chess.js` and Stockfish's MultiPV lines so no invented or illegal moves can ever be rendered. When no external key is set, `/api/coach` automatically uses the built-in deterministic Engine-Grounded Chess Coach Synthesizer powered by real Stockfish MultiPV data.
