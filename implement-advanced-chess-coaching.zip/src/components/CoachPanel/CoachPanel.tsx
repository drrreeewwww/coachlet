'use client'
import { useState } from 'react'
import Avatar from './Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { CLASS_META, type MoveClass } from '@/lib/evaluation/classify'
import { bandFor, eloTierFor } from '@/lib/stockfish/elo'
import type { CoachId, StructuredCoachResponse } from '@/types'

export interface Reaction {
  text: string
  cls: MoveClass
  cpLoss: number
  san: string
  bestSan?: string
}

export interface ChatMsg {
  from: 'you' | 'coach'
  text: string
}

const QUICK_QUESTIONS = [
  'Why is this move a mistake?',
  'What would a grandmaster play here?',
  'Why is my king unsafe?',
  'How do I win this endgame?',
  'What happens if I sacrifice this piece?',
  'Explain this position in simpler terms.',
]

interface Props {
  coachId: CoachId
  elos: Record<CoachId, number>
  onCoach: (id: CoachId) => void
  onElo: (id: CoachId, elo: number) => void
  reaction: Reaction | null
  structured: StructuredCoachResponse | null
  coachLoading?: boolean
  voiceOn: boolean
  onVoice: (on: boolean) => void
  speed: number
  onSpeed: (n: number) => void
  onPreview: (id: CoachId) => void
  onReplay: () => void
  onStop: () => void
  chat: ChatMsg[]
  onAsk: (q: string) => void
}

export default function CoachPanel(p: Props) {
  const [q, setQ] = useState('')
  const [showBreakdown, setShowBreakdown] = useState(true)
  const coach = COACHES.find((c) => c.id === p.coachId)!
  const r = p.reaction
  const currentElo = p.elos[p.coachId]
  const eloTier = eloTierFor(currentElo)
  const small =
    'rounded-md border border-line px-2.5 py-1 text-xs hover:bg-line transition'

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const t = q.trim()
    if (t) {
      p.onAsk(t)
      setQ('')
    }
  }

  return (
    <section className="space-y-4">
      {/* Main Active Coach & Analysis Card */}
      <div className="rounded-xl border border-line bg-panel p-4 shadow-lg">
        {/* Coach Header */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <Avatar id={coach.id} accent={coach.accent} size={50} />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-lg leading-tight">
                  {coach.name}
                </h2>
                <span className="rounded-full border border-gold/40 bg-gold/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-gold">
                  {eloTier} ({currentElo} Elo)
                </span>
              </div>
              <p className="text-xs text-stone-400">{coach.style}</p>
            </div>
          </div>
          {p.coachLoading && (
            <span className="flex items-center gap-1.5 rounded-full border border-gold/40 bg-ink px-2.5 py-1 text-xs text-gold">
              <span className="h-2 w-2 animate-ping rounded-full bg-gold" />
              Coach analysing…
            </span>
          )}
        </div>

        {/* Chess.com-style Move Classification Pill + Speech Bubble */}
        <div className="mt-3 rounded-lg border border-line bg-ink/80 p-3">
          {r && (
            <div
              className="mb-2 flex flex-wrap items-center gap-2 text-sm"
              title={CLASS_META[r.cls].note}
            >
              <span
                className="inline-flex items-center gap-1 rounded-md px-2.5 py-0.5 font-extrabold text-ink shadow-xs"
                style={{ background: CLASS_META[r.cls].color }}
              >
                <span>{CLASS_META[r.cls].icon}</span>
                <span>{CLASS_META[r.cls].label}</span>
              </span>
              <span className="font-mono font-bold text-white">{r.san}</span>
              {r.cpLoss > 0 && (
                <span className="text-xs text-stone-400">
                  (−{r.cpLoss} cp
                  {r.bestSan && r.bestSan !== r.san
                    ? ` • Best: ${r.bestSan}`
                    : ''}
                  )
                </span>
              )}
            </div>
          )}
          <p className="text-sm italic leading-relaxed text-stone-200" aria-live="polite">
            “{r ? r.text : coach.greeting}”
          </p>
        </div>

        {/* Structured Grandmaster Position Breakdown */}
        {p.structured && (
          <div className="mt-3 rounded-lg border border-line/80 bg-ink/50 p-3 text-xs">
            <div className="flex items-center justify-between gap-2">
              <span className="font-semibold text-gold">
                ✦ {p.structured.headline}
              </span>
              <button
                type="button"
                onClick={() => setShowBreakdown(!showBreakdown)}
                className="text-[11px] text-stone-400 hover:text-white"
              >
                {showBreakdown ? 'Hide details ▲' : 'Show details ▼'}
              </button>
            </div>
            {showBreakdown && (
              <dl className="mt-2.5 space-y-2 border-t border-line/60 pt-2.5 text-stone-300">
                <div>
                  <dt className="font-semibold text-stone-200">
                    Why Strong / Weak:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.moveAssessment}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-amber-300">
                    What Was Overlooked:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.overlooked}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-red-300">
                    Opponent Threat:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.opponentThreat}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-emerald-300">
                    Engine Recommendation:
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.engineRecommendation}
                  </dd>
                </div>
                <div>
                  <dt className="font-semibold text-sky-300">
                    Strategic Plan ({coach.name}):
                  </dt>
                  <dd className="mt-0.5 text-stone-300">
                    {p.structured.strategicPlan}
                  </dd>
                </div>
                <div className="rounded border border-gold/30 bg-gold/5 p-2">
                  <dt className="font-semibold text-gold">
                    Future Game Improvement:
                  </dt>
                  <dd className="mt-0.5 text-stone-200">
                    {p.structured.improvementTip}
                  </dd>
                </div>
              </dl>
            )}
          </div>
        )}

        {/* Voice Controls */}
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-stone-400">
          <label className="flex items-center gap-1.5">
            <input
              type="checkbox"
              checked={p.voiceOn}
              onChange={(e) => p.onVoice(e.target.checked)}
              className="accent-[#d1a64a]"
            />{' '}
            Voice
          </label>
          <label className="flex items-center gap-1.5">
            Speed {p.speed.toFixed(1)}×
            <input
              type="range"
              min={0.6}
              max={1.6}
              step={0.1}
              value={p.speed}
              onChange={(e) => p.onSpeed(Number(e.target.value))}
              className="w-20 accent-[#d1a64a]"
            />
          </label>
          <button type="button" className={small} onClick={p.onReplay}>
            Replay
          </button>
          <button type="button" className={small} onClick={p.onStop}>
            Stop
          </button>
        </div>

        {/* Quick-Ask Position Prompts (Section 7) */}
        <div className="mt-3 border-t border-line pt-3">
          <p className="mb-1.5 text-[11px] font-medium text-stone-400">
            Ask {coach.name} about this position:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {QUICK_QUESTIONS.map((qq) => (
              <button
                key={qq}
                type="button"
                disabled={p.coachLoading}
                onClick={() => p.onAsk(qq)}
                className="rounded-full border border-line bg-ink px-2.5 py-1 text-[11px] text-stone-300 transition hover:border-gold hover:text-gold disabled:opacity-40"
              >
                {qq}
              </button>
            ))}
          </div>
        </div>

        {/* Conversation Log */}
        {p.chat.length > 0 && (
          <ul
            className="mt-3 max-h-52 space-y-2 overflow-y-auto rounded-lg border border-line/60 bg-ink/60 p-2.5 text-xs"
            aria-live="polite"
          >
            {p.chat.slice(-10).map((m, i) => (
              <li
                key={i}
                className={
                  m.from === 'you'
                    ? 'ml-6 rounded-lg bg-line/60 px-2.5 py-1.5 text-right text-stone-200'
                    : 'mr-4 rounded-lg border border-line/70 bg-panel px-2.5 py-1.5 text-stone-100'
                }
              >
                {m.from === 'you' ? (
                  <span>You: {m.text}</span>
                ) : (
                  <span>
                    <b className="text-gold">{coach.name}:</b> {m.text}
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}

        {/* Free-form Question Input */}
        <form onSubmit={submit} className="mt-3 flex gap-2">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Ask about this move, variations, king safety, or endgame plan…"
            aria-label="Ask your coach"
            className="min-w-0 flex-1 rounded-md border border-line bg-ink px-3 py-1.5 text-sm placeholder:text-stone-500"
          />
          <button
            type="submit"
            disabled={p.coachLoading}
            className="rounded-md bg-gold px-3.5 py-1.5 text-sm font-semibold text-ink hover:brightness-110 disabled:opacity-50"
          >
            Ask
          </button>
        </form>
      </div>

      {/* Three Distinct Coach Personalities Selector */}
      <div className="grid gap-3 md:grid-cols-3 lg:grid-cols-1">
        {COACHES.map((c) => {
          const sel = c.id === p.coachId
          return (
            <div
              key={c.id}
              className={`rounded-xl border p-4 transition ${
                sel ? 'border-gold bg-panel shadow-md' : 'border-line bg-panel/40'
              }`}
            >
              <div className="flex items-center gap-3">
                <Avatar id={c.id} accent={c.accent} />
                <div>
                  <h3 className="font-display text-lg leading-tight">
                    {c.name}
                  </h3>
                  <p className="text-xs text-stone-400">{c.style}</p>
                </div>
              </div>
              <p className="mt-2.5 text-xs leading-relaxed text-stone-300">
                {c.philosophy}
              </p>
              <ul className="mt-2 flex flex-wrap gap-1">
                {c.focusAreas.map((s) => (
                  <li
                    key={s}
                    className="rounded-full border border-line bg-ink/50 px-2 py-0.5 text-[11px] text-stone-300"
                  >
                    {s}
                  </li>
                ))}
              </ul>
              <label
                htmlFor={`elo-${c.id}`}
                className="mt-3 block text-xs text-stone-400"
              >
                Strength & Coaching Level:{' '}
                <b className="text-gold">{p.elos[c.id]} Elo</b> (
                {bandFor(p.elos[c.id])})
              </label>
              <input
                id={`elo-${c.id}`}
                type="range"
                min={300}
                max={3200}
                step={50}
                value={p.elos[c.id]}
                onChange={(e) => p.onElo(c.id, Number(e.target.value))}
                className="w-full accent-[#d1a64a]"
              />
              <div className="mt-3 flex gap-2 text-xs">
                <button
                  type="button"
                  className={small}
                  onClick={() => p.onPreview(c.id)}
                >
                  Preview voice
                </button>
                <button
                  type="button"
                  onClick={() => p.onCoach(c.id)}
                  aria-pressed={sel}
                  className={`rounded-md px-3 py-1.5 font-semibold ${
                    sel
                      ? 'bg-gold text-ink'
                      : 'border border-gold text-gold hover:bg-gold/10'
                  }`}
                >
                  {sel ? 'Selected' : 'Select coach'}
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </section>
  )
}
