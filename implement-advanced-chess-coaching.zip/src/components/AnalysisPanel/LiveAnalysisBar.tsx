'use client'
import { useState } from 'react'
import { formatScore, toCp, type Score } from '@/lib/evaluation/classify'
import type { PVLine, PositionTactics } from '@/types'

export interface ActiveVariationReplay {
  lineIndex: number // 0, 1, or 2
  stepIndex: number // 0 .. line.steps.length - 1
}

interface Props {
  score: Score
  bestSan: string
  variations: PVLine[]
  tactics?: PositionTactics | null
  depth: number
  seldepth?: number
  thinking: boolean
  activeReplay: ActiveVariationReplay | null
  onSelectReplay: (replay: ActiveVariationReplay | null) => void
  analysisDepth: number
  analysisTime: number
  multiPv: number
  showArrows: boolean
  onConfigChange: (patch: {
    analysisDepth?: number
    analysisTime?: number
    multiPv?: number
    showArrows?: boolean
  }) => void
  startPly?: number
}

const LINE_LABELS = ['1. Best line', '2. Alternative line', '3. Alternative line']
const LINE_COLORS = ['#26c281', '#5aa9c9', '#d1a64a']

export default function LiveAnalysisBar({
  score,
  bestSan,
  variations,
  tactics,
  depth,
  seldepth,
  thinking,
  activeReplay,
  onSelectReplay,
  analysisDepth,
  analysisTime,
  multiPv,
  showArrows,
  onConfigChange,
}: Props) {
  const [configOpen, setConfigOpen] = useState(false)
  const evalLabel = formatScore(score)
  const cp = toCp(score)

  const activeLine =
    activeReplay !== null ? variations[activeReplay.lineIndex] : null
  const activeStep =
    activeLine && activeReplay !== null
      ? activeLine.steps[activeReplay.stepIndex]
      : null

  return (
    <section
      aria-label="Live Stockfish Engine Analysis"
      className="mt-3 rounded-xl border border-line bg-panel p-3.5 shadow-lg"
    >
      {/* Top Engine Status & Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line pb-2.5">
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Numerical Evaluation Badge */}
          <span
            className={`rounded-md px-2.5 py-1 font-mono text-sm font-extrabold shadow-xs ${
              cp >= 0
                ? 'bg-stone-100 text-stone-900'
                : 'border border-stone-600 bg-stone-900 text-stone-100'
            }`}
            title="White-perspective engine evaluation"
          >
            {evalLabel}
          </span>

          {/* Best Move Recommendation */}
          {bestSan && (
            <span className="flex items-center gap-1.5 rounded-md border border-emerald-500/40 bg-emerald-950/50 px-2.5 py-1 text-xs font-medium text-emerald-200">
              <span className="text-emerald-400">★ Best:</span>
              <b className="font-mono text-sm text-white">{bestSan}</b>
            </span>
          )}

          {/* Engine Thinking & Depth Indicator */}
          <span className="flex items-center gap-1.5 text-xs text-stone-400">
            <span
              className={`inline-block h-2 w-2 rounded-full ${
                thinking
                  ? 'animate-ping bg-gold'
                  : 'bg-emerald-400'
              }`}
            />
            <span>
              {thinking ? 'Calculating…' : 'Stockfish 19 WASM'} •{' '}
              <b className="text-stone-200">
                Depth {depth || analysisDepth}
                {seldepth ? `/${seldepth}` : ''}
              </b>{' '}
              • MultiPV {multiPv}
            </span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onConfigChange({ showArrows: !showArrows })}
            aria-pressed={showArrows}
            className={`rounded-md border px-2.5 py-1 text-xs font-medium transition ${
              showArrows
                ? 'border-gold/70 bg-gold/15 text-gold'
                : 'border-line text-stone-400 hover:bg-line'
            }`}
          >
            {showArrows ? '↗ Arrows On' : '↗ Arrows Off'}
          </button>
          <button
            type="button"
            onClick={() => setConfigOpen(!configOpen)}
            aria-expanded={configOpen}
            className="rounded-md border border-line px-2.5 py-1 text-xs text-stone-300 hover:bg-line"
          >
            ⚙ Engine Settings
          </button>
        </div>
      </div>

      {/* Configurable Depth & Calculation Time Drawer */}
      {configOpen && (
        <div className="mt-2.5 grid gap-3 rounded-lg border border-line bg-ink/80 p-3 text-xs sm:grid-cols-3">
          <label className="flex flex-col gap-1 text-stone-300">
            <span>
              Max Depth: <b className="text-gold">{analysisDepth}</b>
            </span>
            <input
              type="range"
              min={8}
              max={20}
              step={1}
              value={analysisDepth}
              onChange={(e) =>
                onConfigChange({ analysisDepth: Number(e.target.value) })
              }
              className="accent-[#d1a64a]"
            />
          </label>
          <label className="flex flex-col gap-1 text-stone-300">
            <span>
              Calc Time: <b className="text-gold">{analysisTime} ms</b>
            </span>
            <input
              type="range"
              min={200}
              max={2500}
              step={100}
              value={analysisTime}
              onChange={(e) =>
                onConfigChange({ analysisTime: Number(e.target.value) })
              }
              className="accent-[#d1a64a]"
            />
          </label>
          <label className="flex flex-col gap-1 text-stone-300">
            <span>
              Candidate Lines (MultiPV): <b className="text-gold">{multiPv}</b>
            </span>
            <select
              value={multiPv}
              onChange={(e) =>
                onConfigChange({ multiPv: Number(e.target.value) })
              }
              className="rounded border border-line bg-panel px-2 py-1 text-stone-200"
            >
              <option value={1}>1 (Best line only)</option>
              <option value={2}>2 (Top 2 lines)</option>
              <option value={3}>3 (Top 3 lines)</option>
            </select>
          </label>
        </div>
      )}

      {/* Active Variation Replay Controls Banner */}
      {activeLine && activeReplay && (
        <div className="mt-3 rounded-lg border border-emerald-500/60 bg-emerald-950/40 p-3 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="rounded bg-emerald-500 px-2 py-0.5 font-bold text-ink">
                Replaying {LINE_LABELS[activeReplay.lineIndex] ?? `Line #${activeReplay.lineIndex + 1}`}
              </span>
              {activeStep && (
                <span className="text-stone-200">
                  Move {activeReplay.stepIndex + 1}/{activeLine.steps.length}:{' '}
                  <b className="font-mono text-emerald-300">{activeStep.san}</b>{' '}
                  ({activeStep.from} → {activeStep.to}) • Eval after move:{' '}
                  <b className="font-mono text-white">
                    {formatScore(activeStep.score)}
                  </b>
                </span>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                disabled={activeReplay.stepIndex <= 0}
                onClick={() =>
                  onSelectReplay({
                    lineIndex: activeReplay.lineIndex,
                    stepIndex: 0,
                  })
                }
                className="rounded border border-line bg-ink px-2 py-1 text-stone-200 hover:bg-line disabled:opacity-40"
                title="First move of variation"
              >
                ⏮
              </button>
              <button
                type="button"
                disabled={activeReplay.stepIndex <= 0}
                onClick={() =>
                  onSelectReplay({
                    lineIndex: activeReplay.lineIndex,
                    stepIndex: Math.max(0, activeReplay.stepIndex - 1),
                  })
                }
                className="rounded border border-line bg-ink px-2.5 py-1 text-stone-200 hover:bg-line disabled:opacity-40"
              >
                ◀ Prev
              </button>
              <button
                type="button"
                disabled={
                  activeReplay.stepIndex >= activeLine.steps.length - 1
                }
                onClick={() =>
                  onSelectReplay({
                    lineIndex: activeReplay.lineIndex,
                    stepIndex: Math.min(
                      activeLine.steps.length - 1,
                      activeReplay.stepIndex + 1
                    ),
                  })
                }
                className="rounded border border-line bg-ink px-2.5 py-1 text-stone-200 hover:bg-line disabled:opacity-40"
              >
                Next ▶
              </button>
              <button
                type="button"
                onClick={() => onSelectReplay(null)}
                className="rounded-md bg-gold px-3 py-1 font-semibold text-ink hover:brightness-110"
              >
                ↩ Return to Position
              </button>
            </div>
          </div>
          {/* Step-by-step clickable continuation pills with evaluation per move */}
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            {activeLine.steps.map((st, sIdx) => {
              const isCur = sIdx === activeReplay.stepIndex
              return (
                <button
                  key={`${st.uci}-${sIdx}`}
                  type="button"
                  onClick={() =>
                    onSelectReplay({
                      lineIndex: activeReplay.lineIndex,
                      stepIndex: sIdx,
                    })
                  }
                  className={`rounded px-2 py-0.5 font-mono text-xs transition ${
                    isCur
                      ? 'bg-emerald-400 font-bold text-ink shadow-xs'
                      : 'bg-ink/80 text-stone-300 hover:bg-line'
                  }`}
                >
                  {sIdx + 1}. {st.san}{' '}
                  <span className="text-[10px] opacity-75">
                    ({formatScore(st.score)})
                  </span>
                </button>
              )
            })}
          </div>
        </div>
      )}

      {/* Three Principal Variations List */}
      <div className="mt-2.5 space-y-1.5">
        {variations.length > 0 ? (
          variations.slice(0, multiPv).map((v, idx) => {
            const isSelectedLine = activeReplay?.lineIndex === idx
            const lineScore = formatScore(v.score)
            const lineCp = toCp(v.score)
            const label = LINE_LABELS[idx] ?? `${idx + 1}. Alternative line`
            const dotColor = LINE_COLORS[idx] ?? '#8aa4b8'

            return (
              <div
                key={v.multipv}
                className={`flex flex-wrap items-center justify-between gap-2 rounded-lg border px-2.5 py-1.5 text-xs transition ${
                  isSelectedLine
                    ? 'border-emerald-500/70 bg-emerald-950/30'
                    : 'border-line/70 bg-ink/50 hover:border-line'
                }`}
              >
                <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5">
                  <span
                    className="inline-block h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: dotColor }}
                  />
                  <span className="shrink-0 font-semibold text-stone-300">
                    {label}:
                  </span>
                  <span
                    className={`shrink-0 rounded px-1.5 py-0.5 font-mono text-[11px] font-bold ${
                      lineCp >= 0
                        ? 'bg-stone-200 text-stone-900'
                        : 'border border-stone-600 bg-stone-900 text-stone-200'
                    }`}
                  >
                    {lineScore}
                  </span>
                  <div className="flex flex-wrap items-center gap-1 font-mono">
                    {v.steps.map((step, sIdx) => {
                      const isStepActive =
                        isSelectedLine && activeReplay?.stepIndex === sIdx
                      return (
                        <button
                          key={`${step.uci}-${sIdx}`}
                          type="button"
                          onClick={() =>
                            onSelectReplay({ lineIndex: idx, stepIndex: sIdx })
                          }
                          title={`Click to preview ${step.san} on the board (${formatScore(step.score)})`}
                          className={`rounded px-1.5 py-0.5 transition ${
                            isStepActive
                              ? 'bg-emerald-400 font-bold text-ink'
                              : sIdx === 0
                                ? 'font-bold text-gold hover:bg-line'
                                : 'text-stone-300 hover:bg-line hover:text-white'
                          }`}
                        >
                          {step.san}
                        </button>
                      )
                    })}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() =>
                    onSelectReplay(
                      isSelectedLine ? null : { lineIndex: idx, stepIndex: 0 }
                    )
                  }
                  className="shrink-0 rounded border border-line px-2 py-0.5 text-[11px] text-stone-300 hover:border-gold hover:text-gold"
                >
                  {isSelectedLine ? 'Exit replay' : '▶ Replay on board'}
                </button>
              </div>
            )
          })
        ) : (
          <p className="py-1 text-xs text-stone-400">
            {thinking
              ? 'Stockfish is calculating candidate variations…'
              : 'Make a move or load a position to view MultiPV lines.'}
          </p>
        )}
      </div>

      {/* Tactical Threats, Hanging Pieces & Defensive Resources Strip */}
      {tactics &&
        (tactics.opponentThreat ||
          tactics.tacticalMotifs.length > 0 ||
          tactics.defensiveResources.length > 0) && (
          <div className="mt-2.5 flex flex-wrap gap-1.5 border-t border-line/70 pt-2 text-[11px]">
            {tactics.opponentThreat && (
              <span className="rounded-md border border-red-500/40 bg-red-950/40 px-2 py-0.5 text-red-200">
                <b className="text-red-400">Threat:</b>{' '}
                {tactics.opponentThreat.description}
              </span>
            )}
            {tactics.defensiveResources.map((d, i) => (
              <span
                key={i}
                className="rounded-md border border-sky-500/40 bg-sky-950/40 px-2 py-0.5 text-sky-200"
              >
                <b className="text-sky-400">Defence:</b> {d}
              </span>
            ))}
            {tactics.tacticalMotifs.slice(0, 2).map((m, i) => (
              <span
                key={i}
                className="rounded-md border border-amber-500/40 bg-amber-950/30 px-2 py-0.5 text-amber-200"
              >
                ⚡ {m}
              </span>
            ))}
          </div>
        )}
    </section>
  )
}
