'use client'
import { Chess, type Square } from 'chess.js'
import { useMemo, useState } from 'react'
import { DEFAULTS, THEMES, type Settings } from '@/lib/settings'
import type { BoardArrow, MoveBadgeOverlay } from '@/types'

const FILES = 'abcdefgh'
const SOLID: Record<string, string> = {
  p: '♟',
  n: '♞',
  b: '♝',
  r: '♜',
  q: '♛',
  k: '♚',
}
const HOLLOW: Record<string, string> = {
  p: '♙',
  n: '♘',
  b: '♗',
  r: '♖',
  q: '♕',
  k: '♔',
}
const nameAt = (i: number) => (FILES[i % 8] + (8 - Math.floor(i / 8))) as Square

function squareCenter(sq: string, flipped: boolean): { x: number; y: number } | null {
  if (!sq || sq.length < 2) return null
  const f = FILES.indexOf(sq[0])
  const r = 8 - Number(sq[1])
  if (f < 0 || f > 7 || r < 0 || r > 7 || Number.isNaN(r)) return null
  const col = flipped ? 7 - f : f
  const row = flipped ? 7 - r : r
  return { x: col * 100 + 50, y: row * 100 + 50 }
}

interface Props {
  fen: string
  flipped: boolean
  lastMove: { from: string; to: string } | null
  disabled: boolean
  marks?: string[]
  highlightSquares?: string[]
  arrows?: BoardArrow[]
  badge?: MoveBadgeOverlay | null
  replayOverlay?: string | null
  look?: Partial<Pick<Settings, 'theme' | 'pieces' | 'coords'>>
  onMove: (from: string, to: string, promotion?: string) => void
}

export default function Chessboard({
  fen,
  flipped,
  lastMove,
  disabled,
  marks,
  highlightSquares,
  arrows,
  badge,
  replayOverlay,
  look,
  onMove,
}: Props) {
  const [sel, setSel] = useState<Square | null>(null)
  const [promo, setPromo] = useState<{ from: Square; to: Square } | null>(null)
  const { theme, pieces, coords } = {
    theme: DEFAULTS.theme,
    pieces: DEFAULTS.pieces,
    coords: DEFAULTS.coords,
    ...look,
  }
  const T = THEMES[theme] ?? THEMES.green
  const chess = useMemo(() => {
    try {
      return new Chess(fen)
    } catch {
      return new Chess()
    }
  }, [fen])
  const board = chess.board().flat()
  const targets = useMemo(
    () =>
      new Set(
        sel ? chess.moves({ square: sel, verbose: true }).map((m) => m.to) : []
      ),
    [sel, chess]
  )
  const checked = chess.inCheck()
    ? board.find((p) => p && p.type === 'k' && p.color === chess.turn())?.square
    : undefined

  const go = (from: Square, to: Square) => {
    setSel(null)
    if (
      chess
        .moves({ square: from, verbose: true })
        .some((m) => m.to === to && m.promotion)
    )
      setPromo({ from, to })
    else onMove(from, to)
  }
  const click = (sq: Square) => {
    if (disabled) return
    if (sel && targets.has(sq)) {
      go(sel, sq)
      return
    }
    const p = chess.get(sq)
    setSel(p && p.color === chess.turn() ? sq : null)
  }

  return (
    <div className="relative grid w-full max-w-[640px] grid-cols-8 overflow-hidden rounded-md border border-line shadow-2xl select-none">
      {Array.from({ length: 64 }, (_, d) => {
        const i = flipped ? 63 - d : d
        const sq = nameAt(i),
          p = board[i]
        const dark = ((i % 8) + Math.floor(i / 8)) % 2 === 1,
          label = dark ? T.light : T.dark
        const canDrag = !disabled && !!p && p.color === chess.turn()
        const white = p?.color === 'w'
        const isHighlightedDest = highlightSquares?.includes(sq)
        const hasBadge = badge && badge.square === sq

        return (
          <div
            key={sq}
            onClick={() => click(sq)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={() => {
              if (sel && targets.has(sq)) go(sel, sq)
              else setSel(null)
            }}
            style={{ background: dark ? T.dark : T.light }}
            className="relative flex aspect-square items-center justify-center"
          >
            {lastMove && (sq === lastMove.from || sq === lastMove.to) && (
              <span className="absolute inset-0 bg-yellow-300/45" />
            )}
            {isHighlightedDest && (
              <span className="absolute inset-0 bg-emerald-400/40 ring-3 ring-inset ring-emerald-300/90" />
            )}
            {marks?.includes(sq) && (
              <span className="absolute inset-0 ring-4 ring-inset ring-red-600/80" />
            )}
            {sq === sel && <span className="absolute inset-0 bg-sky-400/50" />}
            {sq === checked && (
              <span className="absolute inset-0 bg-[radial-gradient(circle,rgba(220,38,38,.9),transparent_70%)]" />
            )}
            {coords && d % 8 === 0 && (
              <span
                className="pointer-events-none absolute left-0.5 top-0 text-[10px] font-semibold leading-tight"
                style={{ color: label }}
              >
                {8 - Math.floor(i / 8)}
              </span>
            )}
            {coords && d >= 56 && (
              <span
                className="pointer-events-none absolute bottom-0 right-0.5 text-[10px] font-semibold leading-tight"
                style={{ color: label }}
              >
                {FILES[i % 8]}
              </span>
            )}
            {targets.has(sq) &&
              (p ? (
                <span className="pointer-events-none absolute inset-1 rounded-full border-4 border-black/30" />
              ) : (
                <span className="pointer-events-none absolute h-1/4 w-1/4 rounded-full bg-black/30" />
              ))}
            {p && (
              <span
                draggable={canDrag}
                onDragStart={() => canDrag && setSel(sq)}
                className={`relative z-[1] select-none leading-none ${canDrag ? 'cursor-grab' : ''}`}
              >
                {pieces === 'letters' ? (
                  <span
                    className={`grid h-[min(9vw,3.2rem)] w-[min(9vw,3.2rem)] place-items-center rounded-full border-2 text-[length:min(5vw,1.7rem)] font-bold ${
                      white
                        ? 'border-stone-800 bg-stone-50 text-stone-900'
                        : 'border-stone-200 bg-stone-900 text-stone-50'
                    }`}
                  >
                    {p.type === 'p' ? 'P' : p.type.toUpperCase()}
                  </span>
                ) : (
                  <span
                    className={`text-[length:min(8vw,3.6rem)] ${
                      pieces === 'outline'
                        ? 'text-stone-900'
                        : white
                          ? 'text-white [text-shadow:0_0_2px_#000,0_1px_2px_#000]'
                          : 'text-stone-900 [text-shadow:0_0_1px_rgba(255,255,255,0.35)]'
                    }`}
                  >
                    {(pieces === 'outline' && white ? HOLLOW : SOLID)[p.type]}
                  </span>
                )}
              </span>
            )}
            {/* Chess.com-style Move Classification Badge on the destination square */}
            {hasBadge && (
              <span
                title={`${badge.label} (${badge.icon})`}
                style={{ backgroundColor: badge.color }}
                className="pointer-events-none absolute right-0.5 top-0.5 z-10 flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[10px] font-extrabold text-ink shadow-md ring-1 ring-black/40"
              >
                {badge.icon}
              </span>
            )}
          </div>
        )
      })}

      {/* SVG Board Arrows Overlay for Best Move, Candidate PVs, Threats, and Variation Replay */}
      {arrows && arrows.length > 0 && (
        <svg
          viewBox="0 0 800 800"
          className="pointer-events-none absolute inset-0 z-[5] h-full w-full"
          aria-label="Analysis arrows"
        >
          {arrows.map((a, idx) => {
            const p1 = squareCenter(a.from, flipped)
            const p2 = squareCenter(a.to, flipped)
            if (!p1 || !p2 || (p1.x === p2.x && p1.y === p2.y)) return null
            const dx = p2.x - p1.x
            const dy = p2.y - p1.y
            const len = Math.hypot(dx, dy)
            if (len < 10) return null
            const ux = dx / len
            const uy = dy / len
            const startX = p1.x + ux * 18
            const startY = p1.y + uy * 18
            const tipX = p2.x - ux * 10
            const tipY = p2.y - uy * 10
            const lineEndX = p2.x - ux * 36
            const lineEndY = p2.y - uy * 36
            const perpX = -uy
            const perpY = ux
            const wing1X = lineEndX + perpX * 22
            const wing1Y = lineEndY + perpY * 22
            const wing2X = lineEndX - perpX * 22
            const wing2Y = lineEndY - perpY * 22

            return (
              <g key={`${a.from}-${a.to}-${idx}`} opacity={a.opacity ?? 0.85}>
                <line
                  x1={startX}
                  y1={startY}
                  x2={lineEndX}
                  y2={lineEndY}
                  stroke={a.color}
                  strokeWidth={idx === 0 ? 18 : 13}
                  strokeLinecap="round"
                  strokeDasharray={a.dashed ? '20 14' : undefined}
                />
                <polygon
                  points={`${tipX},${tipY} ${wing1X},${wing1Y} ${wing2X},${wing2Y}`}
                  fill={a.color}
                />
                {a.label && (
                  <g>
                    <circle
                      cx={startX + ux * 20}
                      cy={startY + uy * 20}
                      r="16"
                      fill="#13201b"
                      stroke={a.color}
                      strokeWidth="3"
                    />
                    <text
                      x={startX + ux * 20}
                      y={startY + uy * 20 + 5}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="15"
                      fontWeight="bold"
                    >
                      {a.label}
                    </text>
                  </g>
                )}
              </g>
            )
          })}
        </svg>
      )}

      {/* Banner when viewing a variation replay on the board */}
      {replayOverlay && (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 bg-emerald-950/90 px-3 py-1.5 text-center text-xs font-semibold text-emerald-200 backdrop-blur-xs">
          {replayOverlay}
        </div>
      )}

      {promo && (
        <div
          className="absolute inset-0 z-20 grid place-items-center bg-black/60"
          role="dialog"
          aria-label="Choose promotion piece"
        >
          <div className="flex gap-2 rounded-lg bg-panel p-3">
            {(['q', 'r', 'b', 'n'] as const).map((p) => (
              <button
                key={p}
                aria-label={`Promote to ${p}`}
                onClick={() => {
                  onMove(promo.from, promo.to, p)
                  setPromo(null)
                }}
                className="rounded p-1 text-5xl text-white hover:bg-line"
              >
                {SOLID[p]}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
