import { toCp, winPct, formatScore, type Score } from '@/lib/evaluation/classify'

export default function EvalBar({
  score,
  flipped,
  thinking,
}: {
  score: Score
  flipped: boolean
  thinking?: boolean
}) {
  const white = winPct(toCp(score))
  const label = formatScore(score)
  const whiteEnd = flipped ? 'top-1.5' : 'bottom-1.5'
  const blackEnd = flipped ? 'bottom-1.5' : 'top-1.5'

  return (
    <div
      role="img"
      aria-label={`Evaluation ${label}`}
      className="relative w-8 shrink-0 self-stretch overflow-hidden rounded-md border border-line bg-stone-900 shadow-inner"
    >
      <div
        className={`absolute inset-x-0 ${flipped ? 'top-0' : 'bottom-0'} bg-stone-100 transition-[height] duration-500 ease-out`}
        style={{ height: `${white}%` }}
      />
      {/* Midpoint equilibrium tick */}
      <div className="pointer-events-none absolute inset-x-0 top-1/2 h-[1.5px] -translate-y-1/2 bg-gold/60" />
      {thinking && (
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-1 animate-pulse bg-gold"
          title="Engine calculating…"
        />
      )}
      <span
        className={`absolute inset-x-0 text-center text-[10px] font-bold tracking-tight ${
          white >= 50
            ? `${whiteEnd} text-stone-900`
            : `${blackEnd} text-stone-100`
        }`}
      >
        {label}
      </span>
    </div>
  )
}
