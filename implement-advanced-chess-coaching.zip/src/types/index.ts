import type { MoveClass, Score } from '@/lib/evaluation/classify'

export type CoachId = 'vale' | 'flash' | 'gambit'
export type EloTier = 'beginner' | 'intermediate' | 'advanced'

export interface Coach {
  id: CoachId
  name: string
  title: string
  style: string
  tagline: string
  accent: string
  greeting: string
  philosophy: string
  focusAreas: string[]
  strengths: string[]
  preview: string
}

export interface PVStep {
  ply: number
  uci: string
  san: string
  from: string
  to: string
  promotion?: string
  fenAfter: string
  score: Score // White-POV evaluation after this move
  turn: 'w' | 'b' // Mover of this step
}

export interface PVLine {
  multipv: number // 1 = Best line, 2 = Second-best line, 3 = Third-best line
  score: Score // White-POV evaluation
  depth: number
  seldepth: number
  uciMoves: string[] // Validated UCI moves
  sanMoves: string[] // Validated SAN moves
  steps: PVStep[] // Validated move-by-move continuation with FEN & eval per move
  firstMove: {
    uci: string
    san: string
    from: string
    to: string
    promotion?: string
  }
}

export interface PositionTactics {
  inCheck: boolean
  isCheckmate: boolean
  isDraw: boolean
  materialBalance: number // White minus Black in pawn units (e.g. +1, -3)
  phase: 'opening' | 'middlegame' | 'endgame'
  tacticalMotifs: string[] // Real detected motifs (e.g. "Fork threat", "Pin", "Discovered check", "Mate sequence", "Capture")
  hangingPieces: string[] // Undefended/attacked pieces on the board
  defensiveResources: string[] // Validated SAN moves that defend against threats
  opponentThreat: {
    uci: string
    san: string
    from: string
    to: string
    description: string
    pvSan: string[]
    score: Score
  } | null
}

export interface BoardArrow {
  from: string
  to: string
  color: string
  label?: string
  dashed?: boolean
  opacity?: number
}

export interface MoveBadgeOverlay {
  square: string
  cls: MoveClass
  icon: string
  color: string
  label: string
}

export interface StructuredCoachResponse {
  headline: string
  moveAssessment: string
  overlooked: string
  opponentThreat: string
  engineRecommendation: string
  strategicPlan: string
  improvementTip: string
  referencedMoves: string[]
  source: 'llm' | 'engine-grounded'
  coachId: CoachId
  eloTier: EloTier
}
