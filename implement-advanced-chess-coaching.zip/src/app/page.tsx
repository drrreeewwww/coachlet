import Link from 'next/link'
import Avatar from '@/components/CoachPanel/Avatar'
import { COACHES } from '@/lib/coaching/coaches'
import { CLASS_META, type MoveClass } from '@/lib/evaluation/classify'

export default function Home() {
  return (
    <main className="mx-auto max-w-6xl px-4 py-14">
      <div className="max-w-3xl">
        <span className="inline-block rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-gold">
          Stockfish 19 WASM MultiPV • Real AI Chess Coaching
        </span>
        <h1 className="mt-4 font-display text-5xl leading-tight sm:text-6xl">
          Play chess with a grandmaster-level coach in your corner.
        </h1>
        <p className="mt-5 max-w-2xl text-lg text-stone-300">
          Face Stockfish at any strength from 300 to 3200 Elo with live MultiPV
          engine variations, interactive board variation replay, 8-tier move
          classifications, and personalised AI coaching grounded in real engine
          analysis.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link
            href="/game"
            className="inline-block rounded-lg bg-gold px-6 py-3 font-semibold text-ink shadow-md hover:brightness-110"
          >
            Start playing &amp; analysing
          </Link>
          <Link
            href="/review"
            className="inline-block rounded-lg border border-line bg-panel px-5 py-3 font-medium text-stone-200 hover:border-gold hover:text-gold"
          >
            Game Review
          </Link>
        </div>
      </div>

      {/* 8-Tier Move Classification Strip */}
      <div className="mt-10 flex flex-wrap items-center gap-2">
        {(Object.keys(CLASS_META) as MoveClass[]).map((k) => (
          <span
            key={k}
            className="inline-flex items-center gap-1.5 rounded-full border border-line bg-panel px-3 py-1 text-xs"
            title={CLASS_META[k].note}
          >
            <span
              className="inline-flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[10px] font-extrabold text-ink"
              style={{ backgroundColor: CLASS_META[k].color }}
            >
              {CLASS_META[k].icon}
            </span>
            <span className="font-medium text-stone-200">
              {CLASS_META[k].label}
            </span>
          </span>
        ))}
      </div>

      {/* Three Distinct Coach Personalities */}
      <div className="mt-12 grid gap-4 sm:grid-cols-3">
        {COACHES.map((c) => (
          <div
            key={c.id}
            className="flex flex-col justify-between rounded-xl border border-line bg-panel p-5 shadow-md"
          >
            <div>
              <Avatar id={c.id} accent={c.accent} size={56} />
              <h2 className="mt-3 font-display text-xl">{c.name}</h2>
              <p className="text-xs font-medium text-gold">{c.title}</p>
              <p className="mt-1 text-sm text-stone-300">{c.style}</p>
              <p className="mt-2 text-sm text-stone-400">{c.philosophy}</p>
              <ul className="mt-3 flex flex-wrap gap-1.5">
                {c.focusAreas.map((f) => (
                  <li
                    key={f}
                    className="rounded-full border border-line bg-ink/60 px-2.5 py-0.5 text-xs text-stone-300"
                  >
                    {f}
                  </li>
                ))}
              </ul>
            </div>
            <Link
              href="/game"
              className="mt-5 inline-block rounded-md border border-gold/60 px-3 py-1.5 text-center text-xs font-semibold text-gold hover:bg-gold hover:text-ink"
            >
              Train with {c.name} →
            </Link>
          </div>
        ))}
      </div>

      <p className="mt-8 max-w-2xl text-xs text-stone-500">
        The coaches are original fictional characters and do not represent any
        real grandmaster endorsing or operating this product. Every move,
        principal variation, and evaluation is calculated by Stockfish WASM and
        validated with chess.js.
      </p>
    </main>
  )
}
