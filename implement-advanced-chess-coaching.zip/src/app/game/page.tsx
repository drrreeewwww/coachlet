'use client'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import { Chess, type Move as ChessMove } from 'chess.js'
import Chessboard from '@/components/Chessboard/Chessboard'
import CoachPanel, {
  type ChatMsg,
  type Reaction,
} from '@/components/CoachPanel/CoachPanel'
import EvalBar from '@/components/EvalBar/EvalBar'
import LiveAnalysisBar, {
  type ActiveVariationReplay,
} from '@/components/AnalysisPanel/LiveAnalysisBar'
import { answer } from '@/lib/coaching/chat'
import { COACHES } from '@/lib/coaching/coaches'
import { tipFor, weaknesses } from '@/lib/coaching/profile'
import { reactionFor } from '@/lib/coaching/reactions'
import { buildEngineGroundedCoaching } from '@/lib/coaching/structured'
import {
  CLASS_META,
  classify,
  toCp,
  type Score,
} from '@/lib/evaluation/classify'
import { hintFor } from '@/lib/hints/hints'
import { saveGame, type MoveRecord } from '@/lib/review/record'
import {
  Engine,
  detectSacrifice,
  uciToMoveObj,
  type Analysis,
} from '@/lib/stockfish/engine'
import { strengthFor } from '@/lib/stockfish/elo'
import { playSound } from '@/lib/sound/sounds'
import { useSettings } from '@/lib/useSettings'
import { speak, stopSpeaking } from '@/lib/voice/speak'
import type {
  BoardArrow,
  CoachId,
  MoveBadgeOverlay,
  StructuredCoachResponse,
} from '@/types'

type Last = { from: string; to: string }
const START = new Chess().fen()

const PRESET_POSITIONS = [
  {
    label: 'Opera Game Sacrifice (Brilliant / Mate)',
    fen: '4kb1r/p2n1ppp/4q3/4p1B1/4P3/1Q6/PPP2PPP/2KR4 w k - 1 16',
  },
  {
    label: 'Tactical Middlegame (Italian Attack)',
    fen: 'r1bqk2r/pppp1ppp/2n2n2/2b1p3/2B1P3/2NP1N2/PPP2PPP/R1BQK2R w KQkq - 1 6',
  },
  {
    label: 'Rook & Pawn Endgame Squeeze',
    fen: '8/5pk1/r5pp/P7/3R4/5PP1/5K1P/8 w - - 1 40',
  },
  {
    label: 'Forced Checkmate in 2',
    fen: 'r1bqkb1r/pppp1ppp/2n2n2/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4',
  },
]

const sanOf = (fen: string, u: string) => {
  if (!u) return ''
  try {
    return new Chess(fen).move(uciToMoveObj(u)).san
  } catch {
    return u
  }
}

const lastOf = (r: MoveRecord[]): Last | null =>
  r.length ? uciToMoveObj(r[r.length - 1].uci) : null

function buildMoveRecord(
  m: ChessMove,
  prev: Analysis,
  afterScore: Score
): MoveRecord {
  const uci = m.from + m.to + (m.promotion ?? '')
  const playedBest = uci === prev.best
  const isSac = detectSacrifice(m.before, uci, prev.pv)
  const secondBestBefore = prev.secondBestScore
    ? toCp(prev.secondBestScore)
    : undefined
  const c = classify(toCp(prev.score), toCp(afterScore), m.color, playedBest, {
    secondBestBefore,
    isSacrifice: isSac,
    mateBefore: prev.score.mate,
    mateAfter: afterScore.mate,
  })
  return {
    color: m.color,
    san: m.san,
    uci,
    fenBefore: m.before,
    fenAfter: m.after,
    before: toCp(prev.score),
    after: toCp(afterScore),
    scoreBefore: prev.score,
    scoreAfter: afterScore,
    cls: c.cls,
    cpLoss: c.cpLoss,
    winLoss: c.winLoss,
    best: prev.best,
    bestSan: prev.bestSan || sanOf(m.before, prev.best),
    secondBestSan: prev.secondBestSan,
    thirdBestSan: prev.thirdBestSan,
    pv: prev.pv,
    variations: prev.variations,
  }
}

export default function GamePage() {
  const game = useRef(new Chess())
  const engine = useRef<Engine | null>(null)
  const cache = useRef(new Map<string, Analysis>())
  const recs = useRef<MoveRecord[]>([])
  const n = useRef(0)
  const coachAbort = useRef<AbortController | null>(null)

  const [fen, setFen] = useState(START)
  const [last, setLast] = useState<Last | null>(null)
  const [coachId, setCoachId] = useState<CoachId>('vale')
  const [elos, setElos] = useState<Record<CoachId, number>>({
    vale: 1200,
    flash: 1600,
    gambit: 800,
  })
  const [flipped, setFlipped] = useState(false)
  const [thinking, setThinking] = useState(false)
  const [engineAnalysing, setEngineAnalysing] = useState(false)
  const [coachLoading, setCoachLoading] = useState(false)
  const [resigned, setResigned] = useState(false)
  const [error, setError] = useState('')
  const [score, setScore] = useState<Score>({ cp: 30 })
  const [currentAnalysis, setCurrentAnalysis] = useState<Analysis | null>(null)
  const [liveDepth, setLiveDepth] = useState(14)
  const [liveSeldepth, setLiveSeldepth] = useState(18)
  const [activeReplay, setActiveReplay] =
    useState<ActiveVariationReplay | null>(null)
  const [reaction, setReaction] = useState<Reaction | null>(null)
  const [structuredCoach, setStructuredCoach] =
    useState<StructuredCoachResponse | null>(null)

  const [st, setSt] = useSettings()
  const {
    voice: voiceOn,
    training,
    threshold: th,
    speed,
    analysisDepth,
    analysisTime,
    multiPv,
    showArrows,
  } = st
  const setVoiceOn = (v: boolean) => setSt({ voice: v })
  const setTraining = (v: boolean) => setSt({ training: v })
  const setTh = (v: number) => setSt({ threshold: v })
  const setSpeed = (v: number) => setSt({ speed: v })

  const [imp, setImp] = useState('')
  const [hint, setHint] = useState(0)
  const [note, setNote] = useState('')
  const [marks, setMarks] = useState<string[]>([])
  const [chat, setChat] = useState<ChatMsg[]>([])
  const spoken = useRef('')

  const say = useCallback(
    (t: string) => {
      spoken.current = t
      if (voiceOn) speak(t, coachId, speed)
    },
    [voiceOn, coachId, speed]
  )

  const analysePosition = useCallback(
    async (
      targetFen: string,
      streamToUi = false
    ): Promise<Analysis> => {
      const cacheKey = `${targetFen}|d${analysisDepth}|t${analysisTime}|p${multiPv}`
      const hit = cache.current.get(cacheKey)
      if (hit) {
        if (streamToUi) {
          setCurrentAnalysis(hit)
          setScore(hit.score)
          setLiveDepth(hit.depth)
          setLiveSeldepth(hit.seldepth)
        }
        return hit
      }
      if (!engine.current) throw new Error('Engine not initialized')
      if (streamToUi) setEngineAnalysing(true)
      try {
        const res = await engine.current.analyse(targetFen, {
          movetime: analysisTime,
          depth: analysisDepth,
          multiPv,
          onProgress: streamToUi
            ? (partial) => {
                setCurrentAnalysis(partial)
                setScore(partial.score)
                setLiveDepth(partial.depth)
                setLiveSeldepth(partial.seldepth)
              }
            : undefined,
        })
        cache.current.set(cacheKey, res)
        if (streamToUi) {
          setCurrentAnalysis(res)
          setScore(res.score)
          setLiveDepth(res.depth)
          setLiveSeldepth(res.seldepth)
        }
        return res
      } finally {
        if (streamToUi) setEngineAnalysing(false)
      }
    },
    [analysisDepth, analysisTime, multiPv]
  )

  /** Requests structured AI coaching from `/api/coach` with automatic cancellation of stale requests. */
  const requestStructuredCoaching = useCallback(
    async (
      posAnalysis: Analysis,
      lastPlayerRec: MoveRecord | null,
      activeCoachId: CoachId,
      activeElo: number
    ) => {
      coachAbort.current?.abort()
      const ctrl = new AbortController()
      coachAbort.current = ctrl

      const payload = {
        fen: posAnalysis.fen,
        moveHistory: game.current.history(),
        lastMove: lastPlayerRec
          ? {
              san: lastPlayerRec.san,
              uci: lastPlayerRec.uci,
              cls: lastPlayerRec.cls,
              cpLoss: lastPlayerRec.cpLoss,
              winLoss: lastPlayerRec.winLoss,
              beforeCp: lastPlayerRec.before,
              afterCp: lastPlayerRec.after,
              bestSan: lastPlayerRec.bestSan,
              fenBefore: lastPlayerRec.fenBefore,
            }
          : null,
        evaluation: posAnalysis.score,
        bestMoveSan: posAnalysis.bestSan,
        variations: posAnalysis.variations,
        tactics: posAnalysis.tactics,
        elo: activeElo,
        coachId: activeCoachId,
        recurringWeaknesses: weaknesses(recs.current),
      }

      // Set immediate engine-grounded structured coaching so the UI responds with zero lag
      const immediate = buildEngineGroundedCoaching(payload)
      setStructuredCoach(immediate)
      if (lastPlayerRec) {
        lastPlayerRec.coachExplanation = immediate
      }

      setCoachLoading(true)
      try {
        const r = await fetch('/api/coach', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(payload),
          signal: ctrl.signal,
        })
        if (r.ok) {
          const data = await r.json()
          if (data.structured) {
            setStructuredCoach(data.structured)
            if (lastPlayerRec) {
              lastPlayerRec.coachExplanation = data.structured
            }
          }
        }
      } catch {
        /* keep immediate engine-grounded structured explanation */
      } finally {
        if (!ctrl.signal.aborted) setCoachLoading(false)
      }
    },
    []
  )

  // Initialize Stockfish Web Worker on mount
  useEffect(() => {
    let e: Engine | null = null
    try {
      e = new Engine()
      engine.current = e
    } catch {
      setError('Stockfish could not start in this browser.')
    }
    if (e) {
      setEngineAnalysing(true)
      e.analyse(START, { movetime: 500, depth: 12, multiPv: 3 })
        .then((a) => {
          cache.current.set(`${START}|d14|t600|p3`, a)
          setCurrentAnalysis(a)
          setScore(a.score)
          setLiveDepth(a.depth)
          setLiveSeldepth(a.seldepth)
          setStructuredCoach(
            buildEngineGroundedCoaching({
              fen: START,
              moveHistory: [],
              evaluation: a.score,
              bestMoveSan: a.bestSan,
              variations: a.variations,
              tactics: a.tactics,
              elo: 1200,
              coachId: 'vale',
            })
          )
        })
        .catch(() => undefined)
        .finally(() => setEngineAnalysing(false))
    }
    return () => {
      coachAbort.current?.abort()
      e?.destroy()
      stopSpeaking()
    }
  }, [])

  // Re-run analysis if the user adjusts depth, calculation time, or MultiPV count in the live settings bar
  useEffect(() => {
    if (!engine.current || thinking) return
    analysePosition(game.current.fen(), true).catch(() => undefined)
  }, [analysisDepth, analysisTime, multiPv, analysePosition, thinking])

  const play = (from: string, to: string, promotion = 'q') => {
    try {
      const m = game.current.move({ from, to, promotion })
      setFen(game.current.fen())
      setLast(m)
      setActiveReplay(null)
      const gg = game.current
      playSound(
        gg.isGameOver()
          ? 'end'
          : m.san.includes('+')
            ? 'check'
            : m.captured
              ? 'capture'
              : 'move',
        st.sound ? st.volume : 0
      )
      return m
    } catch {
      return null
    }
  }

  const persist = (result?: string) => {
    const g = game.current
    saveGame({
      coach: coachId,
      elo: elos[coachId],
      moves: recs.current,
      result:
        result ??
        (g.isCheckmate()
          ? g.turn() === 'w'
            ? '0-1'
            : '1-0'
          : g.isGameOver()
            ? '1/2-1/2'
            : '*'),
    })
  }

  const reset = () => {
    setHint(0)
    setNote('')
    setMarks([])
    setActiveReplay(null)
  }

  const engineReply = async (g: Chess, eng: Engine): Promise<Analysis> => {
    const mv = uciToMoveObj(
      await eng.bestMove(g.fen(), strengthFor(elos[coachId]))
    )
    const r = play(mv.from, mv.to, mv.promotion)
    if (r) {
      const prevA = await analysePosition(r.before, false)
      const afterA = await analysePosition(g.fen(), true)
      recs.current.push(buildMoveRecord(r, prevA, afterA.score))
      return afterA
    }
    return analysePosition(g.fen(), true)
  }

  const onMove = async (from: string, to: string, promotion?: string) => {
    const g = game.current,
      eng = engine.current
    if (!eng) return
    const m = play(from, to, promotion)
    if (!m) return
    reset()
    setThinking(true)
    try {
      const prev = await analysePosition(m.before, false)
      const afterPlayerAnalysis = await analysePosition(g.fen(), true)
      const rec = buildMoveRecord(m, prev, afterPlayerAnalysis.score)
      const bad = rec.cls === 'mistake' || rec.cls === 'blunder'
      const text =
        reactionFor(coachId, rec.cls, n.current++, rec.bestSan) +
        (bad ? ' ' + tipFor(coachId, elos[coachId]) : '')

      if (st.reactions || bad) {
        setReaction({
          text,
          cls: rec.cls,
          cpLoss: rec.cpLoss,
          san: m.san,
          bestSan: rec.bestSan,
        })
        say(text)
      }

      // Training mode: take back a major blunder and let the player retry
      if (training && rec.winLoss >= th) {
        g.undo()
        setFen(g.fen())
        setLast(lastOf(recs.current))
        setScore(prev.score)
        setCurrentAnalysis(prev)
        setMarks([m.from, m.to])
        setNote('Blunder taken back. Try a different move, or ask for a hint.')
        return
      }

      recs.current.push(rec)
      if (bad) {
        const w = weaknesses(recs.current)
        if (w.phase || w.piece) {
          setNote(
            `Pattern noticed: ${
              w.phase
                ? `${w.phase[1]} mistakes in the ${w.phase[0]}`
                : `${w.piece![1]} costly ${w.piece![0]} moves`
            }.`
          )
        }
      }

      let finalPositionAnalysis = afterPlayerAnalysis
      if (!g.isGameOver()) {
        finalPositionAnalysis = await engineReply(g, eng)
      }

      // Trigger structured AI coach explanation for the new position & player's last move
      void requestStructuredCoaching(
        finalPositionAnalysis,
        rec,
        coachId,
        elos[coachId]
      )
    } catch {
      setError('The engine stopped responding. Start a new game.')
    } finally {
      persist()
      setThinking(false)
    }
  }

  const onHint = async () => {
    const g = game.current,
      lvl = Math.min(4, hint + 1) as 1 | 2 | 3 | 4
    try {
      const a = await analysePosition(g.fen(), true),
        h = hintFor(g.fen(), a.best, a.score, lvl)
      setHint(lvl)
      setNote(`Hint ${lvl} of 4: ${h.text}`)
      setMarks(h.marks)
      say(h.text)
    } catch {
      setNote('No hint available right now.')
    }
  }

  const undo = () => {
    const g = game.current
    for (let i = g.history().length % 2 === 0 ? 2 : 1; i > 0; i--) {
      g.undo()
      recs.current.pop()
    }
    setFen(g.fen())
    setLast(lastOf(recs.current))
    setReaction(null)
    reset()
    persist()
    analysePosition(g.fen(), true).catch(() => undefined)
  }

  const newGame = () => {
    game.current = new Chess()
    recs.current = []
    setFen(START)
    setLast(null)
    setResigned(false)
    setError('')
    setReaction(null)
    setChat([])
    spoken.current = ''
    reset()
    stopSpeaking()
    analysePosition(START, true)
      .then((a) => requestStructuredCoaching(a, null, coachId, elos[coachId]))
      .catch(() => undefined)
  }

  const loadFenOrPgn = (rawInput: string) => {
    const t = rawInput.trim(),
      eng = engine.current
    if (!t || thinking || !eng) return
    const c = new Chess()
    try {
      if (/^[rnbqkpRNBQKP1-8]+\/.*\s[wb]\s/.test(t)) c.load(t)
      else c.loadPgn(t)
    } catch {
      setNote('That is not a valid FEN or PGN.')
      return
    }
    game.current = c
    recs.current = []
    setFen(c.fen())
    setLast(null)
    setResigned(false)
    setError('')
    setReaction(null)
    setChat([])
    reset()
    setImp('')
    setNote(
      c.isGameOver()
        ? 'Loaded. This position is already finished.'
        : `Loaded position. ${c.turn() === 'w' ? 'White to move.' : 'Black moves first.'}`
    )
    if (c.turn() === 'b' && !c.isGameOver()) {
      setThinking(true)
      engineReply(c, eng)
        .then((a) => requestStructuredCoaching(a, null, coachId, elos[coachId]))
        .catch(() =>
          setError('The engine stopped responding. Start a new game.')
        )
        .finally(() => {
          persist()
          setThinking(false)
        })
    } else {
      analysePosition(c.fen(), true)
        .then((a) => requestStructuredCoaching(a, null, coachId, elos[coachId]))
        .catch(() => undefined)
    }
  }

  const ask = async (q: string) => {
    setChat((c) => [...c, { from: 'you', text: q }])
    let a: Analysis | null = currentAnalysis
    try {
      if (engine.current && (!a || a.fen !== game.current.fen())) {
        a = await analysePosition(game.current.fen(), true)
      }
    } catch {
      /* answer with current data */
    }
    const mine = recs.current.filter((m) => m.color === 'w')
    const lastRec = mine[mine.length - 1] ?? null
    const ctx = {
      coach: coachId,
      elo: elos[coachId],
      fen: game.current.fen(),
      bestSan: a?.bestSan || (a ? sanOf(game.current.fen(), a.best) : undefined),
      score: a?.score ?? score,
      variations: a?.variations,
      tactics: a?.tactics,
      recs: recs.current,
      over: game.current.isGameOver(),
    }

    let reply = ''
    setCoachLoading(true)
    try {
      const payload = {
        fen: game.current.fen(),
        moveHistory: game.current.history(),
        lastMove: lastRec
          ? {
              san: lastRec.san,
              uci: lastRec.uci,
              cls: lastRec.cls,
              cpLoss: lastRec.cpLoss,
              winLoss: lastRec.winLoss,
              beforeCp: lastRec.before,
              afterCp: lastRec.after,
              bestSan: lastRec.bestSan,
              fenBefore: lastRec.fenBefore,
            }
          : null,
        evaluation: ctx.score,
        bestMoveSan: ctx.bestSan ?? '',
        variations: a?.variations ?? [],
        tactics: a?.tactics ?? null,
        elo: elos[coachId],
        coachId,
        recurringWeaknesses: weaknesses(recs.current),
        question: q,
      }
      const r = await fetch('/api/coach', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (r.ok) {
        const data = await r.json()
        reply = (data.text as string) ?? ''
        if (data.structured) setStructuredCoach(data.structured)
      }
    } catch {
      /* fall back below */
    } finally {
      setCoachLoading(false)
    }
    if (!reply) reply = answer(q, ctx)
    setChat((c) => [...c, { from: 'coach', text: reply }])
    say(reply)
  }

  const copy = (text: string, label: string) =>
    navigator.clipboard?.writeText(text).then(
      () => setNote(`${label} copied.`),
      () => setNote('Copying is blocked in this browser.')
    )

  // Compute displayed board FEN, arrows, highlighted squares, and move classification badge
  const variations = useMemo(
    () => currentAnalysis?.variations ?? [],
    [currentAnalysis]
  )
  const activeStep = useMemo(() => {
    if (!activeReplay) return null
    return variations[activeReplay.lineIndex]?.steps[activeReplay.stepIndex] ?? null
  }, [activeReplay, variations])

  const displayedFen = activeStep ? activeStep.fenAfter : fen
  const displayedScore = activeStep ? activeStep.score : score
  const displayedLastMove = activeStep
    ? { from: activeStep.from, to: activeStep.to }
    : last

  const boardArrows = useMemo<BoardArrow[]>(() => {
    if (!showArrows) return []
    if (activeReplay && activeStep) {
      const line = variations[activeReplay.lineIndex]
      const nextStep = line?.steps[activeReplay.stepIndex + 1]
      const arr: BoardArrow[] = [
        {
          from: activeStep.from,
          to: activeStep.to,
          color: '#26c281',
          label: `${activeReplay.stepIndex + 1}`,
          opacity: 0.9,
        },
      ]
      if (nextStep) {
        arr.push({
          from: nextStep.from,
          to: nextStep.to,
          color: '#5aa9c9',
          dashed: true,
          opacity: 0.65,
        })
      }
      return arr
    }

    const colors = ['#26c281', '#5aa9c9', '#d1a64a']
    return variations.slice(0, multiPv).map((v, idx) => ({
      from: v.firstMove.from,
      to: v.firstMove.to,
      color: colors[idx] ?? '#8aa4b8',
      label: `#${idx + 1}`,
      opacity: idx === 0 ? 0.88 : idx === 1 ? 0.65 : 0.5,
    }))
  }, [showArrows, activeReplay, activeStep, variations, multiPv])

  const highlightSquares = useMemo<string[]>(() => {
    if (activeStep) return [activeStep.to]
    if (showArrows && variations[0]) return [variations[0].firstMove.to]
    return []
  }, [activeStep, showArrows, variations])

  const lastPlayerMoveBadge = useMemo<MoveBadgeOverlay | null>(() => {
    if (activeStep) return null
    const all = recs.current
    if (!all.length) return null
    // Show the player's latest move classification badge on its destination square
    const latestPlayer = [...all].reverse().find((m) => m.color === 'w')
    if (!latestPlayer) return null
    const meta = CLASS_META[latestPlayer.cls]
    return {
      square: latestPlayer.uci.slice(2, 4),
      cls: latestPlayer.cls,
      icon: meta.icon,
      color: meta.color,
      label: meta.label,
    }
  }, [activeStep, fen]) // eslint-disable-line react-hooks/exhaustive-deps

  const g = game.current
  const coach = COACHES.find((c) => c.id === coachId)!
  const over = resigned || g.isGameOver()
  const myTurn =
    g.turn() === 'w' && !over && !thinking && activeReplay === null
  const status = activeReplay
    ? `Replaying Engine Variation #${activeReplay.lineIndex + 1} (Move ${activeReplay.stepIndex + 1})`
    : resigned
      ? 'You resigned.'
      : g.isCheckmate()
        ? `Checkmate. ${g.turn() === 'w' ? 'Black' : 'White'} wins.`
        : g.isDraw()
          ? 'Draw.'
          : thinking
            ? `${coach.name} is thinking…`
            : g.inCheck()
              ? 'Check! Your move.'
              : 'Your move.'

  const hist = g.history()
  const rows = Array.from(
    { length: Math.ceil(hist.length / 2) },
    (_, i) => `${i + 1}. ${hist[2 * i]} ${hist[2 * i + 1] ?? ''}`
  )
  const btn =
    'rounded-md border border-line px-3 py-1.5 hover:bg-panel disabled:opacity-40 transition'

  return (
    <main className="mx-auto grid max-w-6xl gap-6 p-4 lg:grid-cols-[minmax(0,680px)_1fr]">
      <div>
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <p className="font-display text-xl" role="status">
            {error || status}
          </p>
          {activeReplay && (
            <button
              type="button"
              onClick={() => setActiveReplay(null)}
              className="rounded-md bg-gold px-3 py-1 text-xs font-semibold text-ink shadow-xs hover:brightness-110"
            >
              ↩ Return to Live Board
            </button>
          )}
        </div>

        <div className="flex gap-2">
          {st.evalBar && (
            <EvalBar
              score={displayedScore}
              flipped={flipped}
              thinking={thinking || engineAnalysing}
            />
          )}
          <Chessboard
            fen={displayedFen}
            flipped={flipped}
            lastMove={displayedLastMove}
            marks={marks}
            highlightSquares={highlightSquares}
            arrows={boardArrows}
            badge={lastPlayerMoveBadge}
            replayOverlay={
              activeStep && activeReplay
                ? `Variation #${activeReplay.lineIndex + 1} Preview • Move ${activeReplay.stepIndex + 1}: ${activeStep.san} (${activeStep.from}→${activeStep.to})`
                : null
            }
            look={st}
            disabled={!myTurn}
            onMove={onMove}
          />
        </div>

        {/* Live Stockfish MultiPV Analysis & Variation Explorer */}
        <LiveAnalysisBar
          score={displayedScore}
          bestSan={currentAnalysis?.bestSan ?? ''}
          variations={variations}
          tactics={currentAnalysis?.tactics}
          depth={liveDepth}
          seldepth={liveSeldepth}
          thinking={thinking || engineAnalysing}
          activeReplay={activeReplay}
          onSelectReplay={setActiveReplay}
          analysisDepth={analysisDepth}
          analysisTime={analysisTime}
          multiPv={multiPv}
          showArrows={showArrows}
          onConfigChange={(patch) => setSt(patch)}
        />

        {/* Game Action Buttons */}
        <div className="mt-3 flex flex-wrap gap-2 text-sm">
          <button onClick={newGame} disabled={thinking} className={btn}>
            New game
          </button>
          {st.hints && (
            <button onClick={onHint} disabled={!myTurn} className={btn}>
              Hint{hint ? ` (${hint}/4)` : ''}
            </button>
          )}
          {training && (
            <button
              onClick={undo}
              disabled={thinking || !hist.length}
              className={btn}
            >
              Undo
            </button>
          )}
          <button onClick={() => setFlipped(!flipped)} className={btn}>
            Flip board
          </button>
          <button
            onClick={() => {
              setResigned(true)
              persist('0-1')
            }}
            disabled={thinking || over}
            className={btn}
          >
            Resign
          </button>
          <button onClick={() => copy(g.pgn(), 'PGN')} className={btn}>
            Copy PGN
          </button>
          <button onClick={() => copy(g.fen(), 'FEN')} className={btn}>
            Copy FEN
          </button>
          {recs.current.length > 0 && (
            <Link href="/review" className={`${btn} border-gold text-gold`}>
              Review game
            </Link>
          )}
        </div>

        {note && (
          <p
            className="mt-3 rounded-md border border-gold/60 bg-panel p-3 text-sm"
            aria-live="polite"
          >
            {note}
          </p>
        )}

        <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-stone-300">
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={training}
              onChange={(e) => setTraining(e.target.checked)}
              className="accent-[#d1a64a]"
            />{' '}
            Training mode
          </label>
          {training && (
            <label className="flex items-center gap-2">
              Take back moves that lose {th}% or more
              <input
                type="range"
                min={10}
                max={40}
                value={th}
                onChange={(e) => setTh(Number(e.target.value))}
                className="accent-[#d1a64a]"
              />
            </label>
          )}
        </div>

        {/* Import PGN/FEN or Load Tactical/Endgame Test Positions */}
        <details className="mt-3 rounded-md border border-line bg-panel p-3 text-sm">
          <summary className="cursor-pointer font-medium text-stone-300">
            Import PGN / FEN or Load Famous Test Positions
          </summary>
          <div className="mt-2.5 flex flex-wrap gap-1.5">
            {PRESET_POSITIONS.map((pos) => (
              <button
                key={pos.label}
                type="button"
                disabled={thinking}
                onClick={() => loadFenOrPgn(pos.fen)}
                className="rounded border border-line bg-ink px-2.5 py-1 text-xs text-stone-300 hover:border-gold hover:text-gold"
              >
                ♟ {pos.label}
              </button>
            ))}
          </div>
          <textarea
            value={imp}
            onChange={(e) => setImp(e.target.value)}
            rows={3}
            aria-label="PGN or FEN"
            placeholder="Paste a PGN or a FEN position"
            className="mt-2 w-full rounded-md border border-line bg-ink p-2 text-xs"
          />
          <button
            onClick={() => loadFenOrPgn(imp)}
            disabled={thinking || !imp.trim()}
            className={`${btn} mt-2`}
          >
            Load
          </button>
        </details>

        {/* Move History List */}
        <ol className="mt-4 flex flex-wrap gap-x-4 gap-y-1 rounded-md border border-line bg-panel p-3 text-sm text-stone-300">
          {rows.length ? (
            rows.map((r, i) => <li key={i}>{r}</li>)
          ) : (
            <li className="text-stone-500">Moves will appear here.</li>
          )}
        </ol>
      </div>

      <CoachPanel
        coachId={coachId}
        elos={elos}
        onCoach={(id) => {
          stopSpeaking()
          setCoachId(id)
          if (currentAnalysis) {
            const mine = recs.current.filter((m) => m.color === 'w')
            void requestStructuredCoaching(
              currentAnalysis,
              mine[mine.length - 1] ?? null,
              id,
              elos[id]
            )
          }
        }}
        onElo={(id, e) => {
          const next = { ...elos, [id]: e }
          setElos(next)
          if (id === coachId && currentAnalysis) {
            const mine = recs.current.filter((m) => m.color === 'w')
            void requestStructuredCoaching(
              currentAnalysis,
              mine[mine.length - 1] ?? null,
              id,
              e
            )
          }
        }}
        reaction={reaction}
        structured={structuredCoach}
        coachLoading={coachLoading}
        voiceOn={voiceOn}
        onVoice={(on) => {
          setVoiceOn(on)
          if (!on) stopSpeaking()
        }}
        speed={speed}
        onSpeed={setSpeed}
        onPreview={(id) =>
          speak(COACHES.find((c) => c.id === id)!.preview, id, speed)
        }
        onReplay={() =>
          spoken.current && speak(spoken.current, coachId, speed)
        }
        onStop={stopSpeaking}
        chat={chat}
        onAsk={ask}
      />
    </main>
  )
}
