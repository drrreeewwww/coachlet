import './globals.css'
import Link from 'next/link'
import { Fraunces, DM_Sans } from 'next/font/google'

const display = Fraunces({ subsets: ['latin'], variable: '--font-display' })
const sans = DM_Sans({ subsets: ['latin'], variable: '--font-sans' })

export const metadata = {
  title: 'AI Chess Coach — Real Stockfish MultiPV Analysis & Grandmaster Coaching',
  description:
    'Play Stockfish at any strength from 300 to 3200 Elo with live MultiPV engine lines, 8-tier move classifications, and AI coaching.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${display.variable} ${sans.variable}`}>
      <body className="min-h-screen bg-ink font-sans text-stone-100">
        <header className="border-b border-line">
          <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <Link href="/" className="font-display text-xl text-gold">
              ♞ AI Chess Coach
            </Link>
            <div className="flex items-center gap-4">
              <Link
                href="/settings"
                className="text-sm text-stone-300 hover:text-white"
              >
                Settings
              </Link>
              <Link
                href="/review"
                className="text-sm text-stone-300 hover:text-white"
              >
                Review
              </Link>
              <Link
                href="/game"
                className="rounded-md bg-gold px-3 py-1.5 text-sm font-semibold text-ink hover:brightness-110"
              >
                Play
              </Link>
            </div>
          </nav>
        </header>
        {children}
      </body>
    </html>
  )
}
