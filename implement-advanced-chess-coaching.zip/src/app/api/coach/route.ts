import { NextResponse } from 'next/server'
import { COACHES } from '@/lib/coaching/coaches'
import {
  answerPositionQuestion,
  buildEngineGroundedCoaching,
  collectAllowedSanMoves,
  validateStructuredCoachResponse,
  type CoachRequestPayload,
} from '@/lib/coaching/structured'
import { eloTierFor } from '@/lib/stockfish/elo'
import { formatScore } from '@/lib/evaluation/classify'
import type { StructuredCoachResponse } from '@/types'

// Server-side LRU cache to avoid redundant LLM calls on identical position/question queries
const CACHE = new Map<
  string,
  { text: string; structured: StructuredCoachResponse; ts: number }
>()
const MAX_CACHE = 150

function cacheGet(key: string) {
  const hit = CACHE.get(key)
  if (!hit) return null
  if (Date.now() - hit.ts > 10 * 60 * 1000) {
    CACHE.delete(key)
    return null
  }
  return hit
}

function cacheSet(
  key: string,
  val: { text: string; structured: StructuredCoachResponse }
) {
  if (CACHE.size >= MAX_CACHE) {
    const oldest = CACHE.keys().next().value
    if (oldest) CACHE.delete(oldest)
  }
  CACHE.set(key, { ...val, ts: Date.now() })
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => null)
  if (!body || typeof body !== 'object') {
    return NextResponse.json({ error: 'bad_request' }, { status: 400 })
  }

  const coach = COACHES.find((c) => c.id === body.coachId) ?? COACHES[0]
  const elo = Number(body.elo) || 1200
  const eloTier = eloTierFor(elo)
  const question = String(body.question ?? '').trim().slice(0, 400)
  const fen =
    typeof body.fen === 'string' && body.fen.trim()
      ? body.fen.trim()
      : 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'

  const payload: CoachRequestPayload = {
    fen,
    moveHistory: Array.isArray(body.moveHistory)
      ? body.moveHistory.slice(-60).map(String)
      : [],
    lastMove: body.lastMove ?? null,
    evaluation: body.evaluation ?? { cp: 0 },
    bestMoveSan: String(body.bestMoveSan ?? ''),
    variations: Array.isArray(body.variations) ? body.variations.slice(0, 3) : [],
    tactics: body.tactics ?? null,
    elo,
    coachId: coach.id,
    recurringWeaknesses: body.recurringWeaknesses ?? null,
    question: question || undefined,
  }

  const cacheKey = JSON.stringify({
    fen: payload.fen,
    coach: coach.id,
    tier: eloTier,
    last: payload.lastMove?.uci ?? '',
    q: question.toLowerCase(),
  })

  const cached = cacheGet(cacheKey)
  if (cached) {
    return NextResponse.json(cached)
  }

  // Always compute the validated engine-grounded structured coaching baseline first
  const grounded = buildEngineGroundedCoaching(payload)
  const qaResult = question
    ? answerPositionQuestion(question, payload, grounded)
    : {
        text: `${grounded.moveAssessment} ${grounded.overlooked} ${grounded.engineRecommendation}`,
        structured: grounded,
      }

  const anthropicKey = process.env.ANTHROPIC_API_KEY
  const openaiKey = process.env.OPENAI_API_KEY
  const geminiKey = process.env.GEMINI_API_KEY

  // If no external LLM API key is configured, return the validated engine-grounded structured coaching
  if (!anthropicKey && !openaiKey && !geminiKey) {
    cacheSet(cacheKey, qaResult)
    return NextResponse.json(qaResult)
  }

  const allowedMoves = [...collectAllowedSanMoves(payload)].slice(0, 80)

  const systemPrompt = [
    `You are ${coach.name}, an original fictional grandmaster-level chess coach (${coach.title}; style: ${coach.style}).`,
    `Philosophy: ${coach.philosophy}`,
    `Focus areas: ${coach.focusAreas.join(', ')}.`,
    `Do NOT claim to be a real grandmaster. Stay in character as ${coach.name}.`,
    `Player rating: ${elo} Elo (${eloTier.toUpperCase()} tier).`,
    eloTier === 'beginner'
      ? 'Personalisation: Explain concepts in clear, simple language without dense jargon.'
      : eloTier === 'intermediate'
        ? 'Personalisation: Focus on tactical motifs, concrete plans, positional ideas, and why mistakes happen.'
        : 'Personalisation: Discuss deeper MultiPV variations, strategic imbalances, prophylaxis, calculation, and centipawn/mate evaluations.',
    `CRITICAL RULE: You MUST ONLY reference moves that come from Stockfish's analysis or legal moves in the position: [${allowedMoves.join(', ')}].`,
    `NEVER invent chess moves, variations, or evaluations. Never claim a move is engine-approved unless it is in the Stockfish MultiPV lines provided.`,
    `Respond ONLY with a valid JSON object matching this exact schema:`,
    `{`,
    `  "headline": "Short punchy summary in your voice",`,
    `  "moveAssessment": "Why the played move is strong or weak, citing evaluation change",`,
    `  "overlooked": "What the player overlooked or found",`,
    `  "opponentThreat": "What the opponent is threatening in the current position",`,
    `  "engineRecommendation": "Why Stockfish recommends the best move and how it compares to alternative MultiPV lines",`,
    `  "strategicPlan": "The strategic plan behind the position in your coaching style",`,
    `  "improvementTip": "How to improve similar decisions in future games (use recurring mistake patterns if present)",`,
    `  "referencedMoves": ["Array of SAN moves mentioned"],`,
    `  "directAnswer": "Direct conversational answer to the player's question (2-4 sentences)"`,
    `}`,
  ].join('\n')

  const userFacts = {
    currentFen: payload.fen,
    moveHistorySan: payload.moveHistory,
    playerLastMove: payload.lastMove,
    stockfishEvaluationWhitePOV: formatScore(payload.evaluation),
    rawEvaluation: payload.evaluation,
    bestEngineMoveSan: payload.bestMoveSan,
    multiPvVariations: payload.variations.map((v) => ({
      rank: v.multipv,
      firstMoveSan: v.firstMove.san,
      evaluationWhitePOV: formatScore(v.score),
      depth: v.depth,
      continuationSan: v.sanMoves,
    })),
    tacticalFacts: payload.tactics,
    recurringMistakesInGame: payload.recurringWeaknesses,
    playerQuestion: question || 'Explain the current position and last move.',
  }

  try {
    let rawJsonText = ''

    if (anthropicKey) {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': anthropicKey,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-20250514',
          max_tokens: 700,
          system: systemPrompt,
          messages: [
            {
              role: 'user',
              content: `Trusted Stockfish & Board Facts:\n${JSON.stringify(userFacts)}`,
            },
          ],
        }),
      })
      if (r.ok) {
        const data = await r.json()
        rawJsonText = (data.content ?? [])
          .map((b: { type: string; text?: string }) =>
            b.type === 'text' ? b.text : ''
          )
          .join('')
          .trim()
      }
    } else if (openaiKey) {
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          authorization: `Bearer ${openaiKey}`,
        },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
          response_format: { type: 'json_object' },
          max_tokens: 700,
          messages: [
            { role: 'system', content: systemPrompt },
            {
              role: 'user',
              content: `Trusted Stockfish & Board Facts:\n${JSON.stringify(userFacts)}`,
            },
          ],
        }),
      })
      if (r.ok) {
        const data = await r.json()
        rawJsonText = data.choices?.[0]?.message?.content?.trim() ?? ''
      }
    } else if (geminiKey) {
      const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash'
      const r = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`,
        {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: systemPrompt }] },
            generationConfig: { responseMimeType: 'application/json' },
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    text: `Trusted Stockfish & Board Facts:\n${JSON.stringify(userFacts)}`,
                  },
                ],
              },
            ],
          }),
        }
      )
      if (r.ok) {
        const data = await r.json()
        rawJsonText =
          data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ?? ''
      }
    }

    if (rawJsonText) {
      const cleaned = rawJsonText
        .replace(/^```json\s*/i, '')
        .replace(/```\s*$/i, '')
        .trim()
      const parsed = JSON.parse(cleaned)
      const structured = validateStructuredCoachResponse(
        parsed,
        payload,
        grounded
      )
      const directAnswer =
        typeof parsed.directAnswer === 'string' && parsed.directAnswer.trim()
          ? parsed.directAnswer.trim()
          : `${structured.moveAssessment} ${structured.engineRecommendation}`
      const out = { text: directAnswer, structured }
      cacheSet(cacheKey, out)
      return NextResponse.json(out)
    }
  } catch {
    /* Fall back gracefully to validated engine-grounded coaching */
  }

  cacheSet(cacheKey, qaResult)
  return NextResponse.json(qaResult)
}
