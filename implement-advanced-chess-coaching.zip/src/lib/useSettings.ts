import { useCallback, useEffect, useState } from 'react'
import { DEFAULTS, type Settings } from './settings'

const KEY = 'chess-coach:settings'

/** Settings persisted in this browser. Starts from defaults so server and client render the same first paint. */
export function useSettings(): [
  Settings,
  (patch: Partial<Settings>) => void,
  () => void,
] {
  const [s, setS] = useState<Settings>(DEFAULTS)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY)
      if (raw) setS({ ...DEFAULTS, ...JSON.parse(raw) })
    } catch {
      /* use defaults */
    }
  }, [])
  const save = (n: Settings) => {
    try {
      localStorage.setItem(KEY, JSON.stringify(n))
    } catch {
      /* storage unavailable */
    }
  }
  const update = useCallback((p: Partial<Settings>) => {
    setS((prev) => {
      const n = { ...prev, ...p }
      save(n)
      return n
    })
  }, [])
  const reset = useCallback(() => {
    setS(DEFAULTS)
    save(DEFAULTS)
  }, [])
  return [s, update, reset]
}
