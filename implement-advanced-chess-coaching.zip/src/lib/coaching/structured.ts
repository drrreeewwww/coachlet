import { Chess } from 'chess.js'
import {
  CLASS_META,
  formatScore,
  toCp,
  type MoveClass,
  type Score,
} from '@/lib/evaluation/classify'
import { eloTierFor } from '@/lib/stockfish/elo'
import { tipFor } from './profile'
import type {
  CoachId,
  EloTier,
  PVLine,
  PositionTactics,
  StructuredCoachResponse,
} from '@/types'

export interface CoachRequestPayload {
  fen: string
  moveHistory: string[]
  lastMove?: {
    san: string
    uci: string
    cls: MoveClass
    cpLoss: number
    winLoss: number
    beforeCp: number
    afterCp: number
    bestSan: string
    fenBefore: string
  } | null
  evaluation: Score
  bestMoveSan: string
  variations: PVLine[]
  tactics?: PositionTactics | null
  elo: number
  coachId: CoachId
  recurringWeaknesses?: {
    mistakes: number
    totalSlips?: number
    missedTactics?: number
    phase?: [string, number]
    piece?: [string, number]
  } | null
  question?: string
}

/** Inspects a FEN with chess.js to extract concrete positional facts (king safety, centre, development, structure). */
export function inspectBoardFacts(fen: string) {
  const c = new Chess(fen)
  const board = c.board()
  let whiteCastledOrSafe = false
  let blackCastledOrSafe = false
  let whiteKingSq = 'e1'
  let blackKingSq = 'e8'
  let whiteMinorDeveloped = 0
  let blackMinorDeveloped = 0
  let whiteCenterPawns = 0
  let blackCenterPawns = 0
  const whitePawnFiles: number[] = []
  const blackPawnFiles: number[] = []

  for (let r = 0; r < 8; r++) {
    for (let f = 0; f < 8; f++) {
      const p = board[r][f]
      if (!p) continue
      if (p.type === 'k') {
        if (p.color === 'w') {
          whiteKingSq = p.square
          if (['g1', 'c1', 'b1', 'h1'].includes(p.square)) whiteCastledOrSafe = true
        } else {
          blackKingSq = p.square
          if (['g8', 'c8', 'b8', 'h8'].includes(p.square)) blackCastledOrSafe = true
        }
      }
      if ((p.type === 'n' || p.type === 'b') && p.color === 'w' && r < 7) {
        whiteMinorDeveloped++
      }
      if ((p.type === 'n' || p.type === 'b') && p.color === 'b' && r > 0) {
        blackMinorDeveloped++
      }
      if (p.type === 'p') {
        if (p.color === 'w') whitePawnFiles.push(f)
        else blackPawnFiles.push(f)
        if ((r === 3 || r === 4) && (f === 3 || f === 4)) {
          if (p.color === 'w') whiteCenterPawns++
          else blackCenterPawns++
        }
      }
    }
  }

  const countDoubled = (files: number[]) => {
    const counts = new Map<number, number>()
    files.forEach((f) => counts.set(f, (counts.get(f) ?? 0) + 1))
    return [...counts.values()].filter((v) => v >= 2).length
  }

  return {
    turn: c.turn(),
    inCheck: c.inCheck(),
    isCheckmate: c.isCheckmate(),
    isDraw: c.isDraw(),
    whiteKingSq,
    blackKingSq,
    whiteCastledOrSafe,
    blackCastledOrSafe,
    whiteMinorDeveloped,
    blackMinorDeveloped,
    whiteCenterPawns,
    blackCenterPawns,
    whiteDoubledPawns: countDoubled(whitePawnFiles),
    blackDoubledPawns: countDoubled(blackPawnFiles),
  }
}

/** Collects all valid SAN moves allowed to be referenced in this coaching context. */
export function collectAllowedSanMoves(payload: CoachRequestPayload): Set<string> {
  const allowed = new Set<string>()
  try {
    const c = new Chess(payload.fen)
    for (const m of c.moves()) allowed.add(m.replace(/[+#!?]+$/g, ''))
    for (const m of c.moves()) allowed.add(m)
  } catch {
    /* ignore */
  }
  if (payload.lastMove?.fenBefore) {
    try {
      const prev = new Chess(payload.lastMove.fenBefore)
      for (const m of prev.moves()) allowed.add(m.replace(/[+#!?]+$/g, ''))
      for (const m of prev.moves()) allowed.add(m)
    } catch {
      /* ignore */
    }
  }
  for (const h of payload.moveHistory ?? []) {
    allowed.add(h)
    allowed.add(h.replace(/[+#!?]+$/g, ''))
  }
  if (payload.bestMoveSan) {
    allowed.add(payload.bestMoveSan)
    allowed.add(payload.bestMoveSan.replace(/[+#!?]+$/g, ''))
  }
  if (payload.lastMove?.san) {
    allowed.add(payload.lastMove.san)
    allowed.add(payload.lastMove.bestSan)
  }
  for (const v of payload.variations ?? []) {
    for (const s of v.sanMoves) {
      allowed.add(s)
      allowed.add(s.replace(/[+#!?]+$/g, ''))
    }
  }
  if (payload.tactics?.opponentThreat) {
    for (const s of payload.tactics.opponentThreat.pvSan) {
      allowed.add(s)
      allowed.add(s.replace(/[+#!?]+$/g, ''))
    }
  }
  return allowed
}

/**
 * Builds a complete, engine-grounded, grandmaster-level StructuredCoachResponse
 * from real Stockfish MultiPV lines, chess.js board facts, coach personality, and player Elo.
 */
export function buildEngineGroundedCoaching(
  payload: CoachRequestPayload
): StructuredCoachResponse {
  const tier: EloTier = eloTierFor(payload.elo)
  const board = inspectBoardFacts(payload.fen)
  const v1 = payload.variations?.[0]
  const v2 = payload.variations?.[1]
  const v3 = payload.variations?.[2]
  const evalStr = formatScore(payload.evaluation)
  const cp = toCp(payload.evaluation)
  const last = payload.lastMove
  const tactics = payload.tactics
  const phase = tactics?.phase ?? (payload.moveHistory.length < 18 ? 'opening' : 'middlegame')

  // 1. Headline & Move Assessment
  let headline = ''
  let moveAssessment = ''
  let overlooked = ''

  if (last) {
    const meta = CLASS_META[last.cls]
    const beforeStr = formatScore({ cp: last.beforeCp })
    const afterStr = formatScore({ cp: last.afterCp })
    const playedEngineBest =
      last.san === last.bestSan || last.cls === 'best' || last.cls === 'brilliant' || last.cls === 'great'

    if (payload.coachId === 'vale') {
      headline = `${meta.label} (${last.san}) — Evaluation ${beforeStr} → ${afterStr}`
      moveAssessment = playedEngineBest
        ? `${last.san} is ${meta.label.toLowerCase()}. It maintains optimal piece harmony and keeps the evaluation at ${afterStr}.`
        : `${last.san} is rated as ${meta.label.toLowerCase()} (−${last.cpLoss} cp, shifting the evaluation from ${beforeStr} to ${afterStr}). Stockfish preferred ${last.bestSan} to preserve positional control.`
    } else if (payload.coachId === 'flash') {
      headline = `${meta.icon} ${meta.label}: ${last.san} (${beforeStr} → ${afterStr})`
      moveAssessment = playedEngineBest
        ? `Spot on! ${last.san} is ${meta.label.toLowerCase()} and keeps maximal tactical pressure (${afterStr}).`
        : `${last.san} is a ${meta.label.toLowerCase()} that drops ${last.cpLoss} centipawns (${beforeStr} → ${afterStr}). The sharpest continuation was ${last.bestSan}!`
    } else {
      headline = `${meta.label} Move: ${last.san} (${afterStr})`
      moveAssessment = playedEngineBest
        ? `Beautifully played! ${last.san} (${meta.label}) fits the spirit of the position and holds ${afterStr}.`
        : `${last.san} was an ${meta.label.toLowerCase()} (losing ${last.cpLoss} cp from ${beforeStr} to ${afterStr}). The dynamic resource here was ${last.bestSan}.`
    }

    // Overlooked
    if (playedEngineBest) {
      if (last.cls === 'brilliant') {
        overlooked = `You spotted a genuine material sacrifice with ${last.san} where the dynamic compensation outweighs the material invested.`
      } else if (last.cls === 'great') {
        overlooked = `You found the critical move ${last.san} in a razor-sharp position where alternative moves lost significant win probability.`
      } else {
        overlooked = `Nothing overlooked — you matched Stockfish’s primary recommendation (${last.bestSan}).`
      }
    } else {
      const bestLinePreview = v1 ? v1.sanMoves.slice(0, 4).join(' ') : last.bestSan
      if (tier === 'beginner') {
        overlooked = `Instead of ${last.san}, the engine wanted ${last.bestSan}, which keeps your pieces safer and more active.`
      } else if (tier === 'intermediate') {
        overlooked = `You missed ${last.bestSan}, which fights for the initiative and avoids the ${last.cpLoss} cp drop (${bestLinePreview}).`
      } else {
        overlooked = `Playing ${last.san} conceded ${last.cpLoss} cp (${last.winLoss.toFixed(1)}% win probability). Stockfish’s principal line ${last.bestSan} kept tighter control over key squares.`
      }
    }
  } else {
    headline = `Position Evaluation: ${evalStr} (${phase})`
    moveAssessment =
      Math.abs(cp) < 40
        ? `The position is dynamically balanced (${evalStr}). Both sides have playable chances.`
        : cp > 0
          ? `White holds an advantage of ${evalStr} with superior piece activity.`
          : `Black holds the edge at ${evalStr}, putting pressure on White’s position.`
    overlooked = `No move has been played yet in this turn — examine the top 3 Stockfish candidate variations below.`
  }

  // 2. Opponent Threat
  let opponentThreat = ''
  if (board.inCheck) {
    opponentThreat = `Your king on ${board.turn === 'w' ? board.whiteKingSq : board.blackKingSq} is currently in check! You must get out of check immediately (best: ${v1?.firstMove.san ?? payload.bestMoveSan}).`
  } else if (tactics?.opponentThreat) {
    const ot = tactics.opponentThreat
    opponentThreat = `${ot.description}. Expected continuation: ${ot.pvSan.join(' ')}.`
    if (tactics.hangingPieces.length > 0) {
      opponentThreat += ` Watch out for loose pieces: ${tactics.hangingPieces.join(', ')}.`
    }
  } else if (tactics?.hangingPieces?.length) {
    opponentThreat = `Attention: ${tactics.hangingPieces.join(', ')} is currently attacked and undefended.`
  } else {
    opponentThreat = `No immediate forced tactical threat, but the opponent wants to improve their piece coordination and contest the central squares.`
  }

  // 3. Engine Recommendation (comparing PV #1, #2, #3)
  let engineRecommendation = ''
  if (v1) {
    const line1 = v1.sanMoves.slice(0, tier === 'beginner' ? 3 : 5).join(' ')
    const score1 = formatScore(v1.score)
    engineRecommendation = `Stockfish recommends ${v1.firstMove.san} (${score1}), continuing: ${line1}.`
    if (v2) {
      const line2 = v2.sanMoves.slice(0, 4).join(' ')
      engineRecommendation += ` The second-best candidate is ${v2.firstMove.san} (${formatScore(v2.score)}: ${line2})`
      if (v3) {
        engineRecommendation += `, and the third option is ${v3.firstMove.san} (${formatScore(v3.score)}).`
      } else {
        engineRecommendation += '.'
      }
    }
  } else if (payload.bestMoveSan) {
    engineRecommendation = `Stockfish recommends ${payload.bestMoveSan} (${evalStr}).`
  } else {
    engineRecommendation = `The game has reached a terminal state (${evalStr}).`
  }

  // 4. Strategic Plan tailored to Coach Personality & Elo Tier
  let strategicPlan = ''
  if (payload.coachId === 'vale') {
    if (tier === 'beginner') {
      strategicPlan =
        phase === 'opening'
          ? `Positional Plan: Bring your knights and bishops toward the centre, castle your king to safety${!board.whiteCastledOrSafe ? ' (your king is still on ' + board.whiteKingSq + ')' : ''}, and connect your rooks.`
          : phase === 'endgame'
            ? `Endgame Plan: Bring your king toward the centre to help your pawns advance, and keep your rooks active.`
            : `Positional Plan: Find your least active piece and move it to a better square while keeping your pawns protected.`
    } else if (tier === 'intermediate') {
      strategicPlan =
        phase === 'endgame'
          ? `Endgame Technique: Activate the king immediately, place rooks behind passed pawns, and target any isolated or doubled pawns (${board.blackDoubledPawns ? 'Black has doubled pawns to target' : 'maintain structural integrity'}).`
          : `Positional Plan: Consolidate control over the central squares with ${v1?.firstMove.san ?? 'active piece play'}, restrict the opponent’s minor pieces, and prepare a favourable transition if ahead.`
    } else {
      strategicPlan = `Grandmaster Positional Plan: Play ${v1?.firstMove.san ?? 'accurately'} to maximise piece efficiency and prophylaxis. ${cp > 80 ? 'Nurse the +0.8+ structural edge by trading off the opponent’s most active defender.' : 'Maintain tension in the structure and exploit minor square weaknesses in the endgame.'}`
    }
  } else if (payload.coachId === 'flash') {
    if (tier === 'beginner') {
      strategicPlan = `Attacking Plan: Look for safe checks and captures first! ${v1?.firstMove.san ? `Playing ${v1.firstMove.san} puts immediate pressure on your opponent.` : 'Keep your pieces aimed at the enemy king.'}`
    } else if (tier === 'intermediate') {
      strategicPlan = `Tactical Plan: Seize the initiative with ${v1?.firstMove.san ?? 'forcing play'}. Look for forks, pins, and discovered attacks, especially before the opponent can consolidate${!board.blackCastledOrSafe ? ' with their king still on ' + board.blackKingSq : ''}.`
    } else {
      strategicPlan = `Concrete Calculation Plan: Drive the forcing variation ${v1 ? v1.sanMoves.slice(0, 5).join(' ') : ''}. Calculate all forcing replies (checks, captures, intermediate moves) before committing to quiet prophylaxis.`
    }
  } else {
    // Gambit
    if (tier === 'beginner') {
      strategicPlan = `Creative Plan: Fight for the middle of the board and give your bishops and knights open lines! ${v1?.firstMove.san ? `${v1.firstMove.san} sets up an active, fun position.` : ''}`
    } else if (tier === 'intermediate') {
      strategicPlan = `Dynamic Strategy: Embrace the imbalances in this ${phase}! ${v1?.firstMove.san ? `Use ${v1.firstMove.san} to create active piece play and ask difficult questions of the opponent’s setup.` : 'Look for active counterplay across the board.'}`
    } else {
      strategicPlan = `Strategic Imbalance Plan: Leverage the dynamic tension via ${v1 ? v1.sanMoves.slice(0, 4).join(' ') : 'active play'}. Weigh long-term structural concessions against immediate initiative and open files.`
    }
  }

  // 5. Improvement Tip (incorporating recurring mistakes from the game)
  let improvementTip = tipFor(payload.coachId, payload.elo)
  const rw = payload.recurringWeaknesses
  if (rw && rw.mistakes >= 2) {
    const extra: string[] = []
    if (rw.phase) {
      extra.push(`you have made ${rw.phase[1]} errors in the ${rw.phase[0]} this game`)
    }
    if (rw.piece) {
      extra.push(`watch your ${rw.piece[0]} moves (${rw.piece[1]} costly slips)`)
    }
    if (rw.missedTactics) {
      extra.push(`remember to check forcing captures/checks (${rw.missedTactics} missed)`)
    }
    if (extra.length > 0) {
      improvementTip = `Personalised Game Note (${extra.join('; ')}): ${improvementTip}`
    }
  }

  const referencedMoves: string[] = []
  if (v1?.firstMove.san) referencedMoves.push(v1.firstMove.san)
  if (v2?.firstMove.san) referencedMoves.push(v2.firstMove.san)
  if (v3?.firstMove.san) referencedMoves.push(v3.firstMove.san)
  if (last?.san && !referencedMoves.includes(last.san)) referencedMoves.push(last.san)

  return {
    headline,
    moveAssessment,
    overlooked,
    opponentThreat,
    engineRecommendation,
    strategicPlan,
    improvementTip,
    referencedMoves,
    source: 'engine-grounded',
    coachId: payload.coachId,
    eloTier: tier,
  }
}

/**
 * Answers any natural-language player question about the current board position using
 * the real Stockfish MultiPV lines, chess.js board state, Elo tier, and Coach persona.
 */
export function answerPositionQuestion(
  question: string,
  payload: CoachRequestPayload,
  base: StructuredCoachResponse
): { text: string; structured: StructuredCoachResponse } {
  const q = question.toLowerCase().trim()
  const v1 = payload.variations?.[0]
  const v2 = payload.variations?.[1]
  const v3 = payload.variations?.[2]
  const board = inspectBoardFacts(payload.fen)
  const evalStr = formatScore(payload.evaluation)

  // Question 1: Why is this move a mistake / blunder / inaccuracy?
  if (/why.*(mistake|blunder|inaccuracy|bad|wrong|weak)|last move/.test(q)) {
    if (!payload.lastMove) {
      const text = `We haven’t recorded a player move yet. In the current position (${evalStr}), Stockfish’s top choice is ${v1?.firstMove.san ?? 'developing pieces'}.`
      return { text, structured: { ...base, headline: text } }
    }
    const text = `${base.moveAssessment} ${base.overlooked} ${base.engineRecommendation}`
    return { text, structured: base }
  }

  // Question 2: What would a grandmaster play here / best move / suggest?
  if (/grandmaster|gm|best|what (should|would|do) i play|recommend|suggest|candidate/.test(q)) {
    if (!v1) {
      const text = `The game is already over (${evalStr}), so there are no legal moves left to play.`
      return { text, structured: base }
    }
    const alts = [
      v2 ? `2nd line ${v2.firstMove.san} (${formatScore(v2.score)}: ${v2.sanMoves.slice(0, 4).join(' ')})` : '',
      v3 ? `3rd line ${v3.firstMove.san} (${formatScore(v3.score)}: ${v3.sanMoves.slice(0, 4).join(' ')})` : '',
    ]
      .filter(Boolean)
      .join('; ')
    const text = `In this position (${evalStr}), Stockfish’s #1 grandmaster choice is ${v1.firstMove.san}, leading to ${v1.sanMoves.slice(0, 5).join(' ')}.${alts ? ` Alternative candidates: ${alts}.` : ''} ${base.strategicPlan}`
    return { text, structured: { ...base, headline: `Top Engine Choice: ${v1.firstMove.san} (${formatScore(v1.score)})` } }
  }

  // Question 3: Why is my king unsafe / king safety / threat?
  if (/king|unsafe|safe|check|danger|threat|attacking me/.test(q)) {
    const kingStatus = board.inCheck
      ? `Your king on ${board.whiteKingSq} is in check right now!`
      : board.whiteCastledOrSafe
        ? `Your king is tucked on ${board.whiteKingSq}, which is relatively sheltered.`
        : `Your king is still on ${board.whiteKingSq} in the centre, making it vulnerable to open files and checks.`
    const text = `${kingStatus} ${base.opponentThreat} To keep the position under control, Stockfish recommends ${v1 ? `${v1.firstMove.san} (${v1.sanMoves.slice(0, 4).join(' ')})` : 'consolidating your defenders'}.`
    return { text, structured: { ...base, headline: `King Safety & Threat Assessment (${evalStr})` } }
  }

  // Question 4: How do I win this endgame / endgame plan?
  if (/endgame|convert|win this|pawn/.test(q)) {
    const mat = payload.tactics?.materialBalance ?? 0
    const matNote =
      mat > 0
        ? `You are ahead by +${mat} material points.`
        : mat < 0
          ? `You are down ${Math.abs(mat)} material points, so seek active counterplay or blockade.`
          : `Material is equal, so piece activity and king centralisation decide everything.`
    const text = `${matNote} The engine evaluation is ${evalStr}. Best continuation: ${v1 ? v1.sanMoves.slice(0, 5).join(' ') : 'activate your king'}. Centralise your king, push passed pawns with rook support, and avoid unnecessary pawn weaknesses.`
    return { text, structured: { ...base, headline: `Endgame & Conversion Plan (${evalStr})` } }
  }

  // Question 5: What happens if I sacrifice / tactical check?
  if (/sacrific|what happens if|tactic|calculat|combination/.test(q)) {
    const sacCandidates = (payload.variations ?? []).filter((v) =>
      v.firstMove.san.includes('x') || v.firstMove.san.includes('+')
    )
    if (sacCandidates.length > 0) {
      const topForcing = sacCandidates[0]
      const text = `Looking at forcing/tactical tries: Stockfish evaluates ${topForcing.firstMove.san} at ${formatScore(topForcing.score)} with the continuation ${topForcing.sanMoves.slice(0, 5).join(' ')}. Compare that with the #1 line ${v1?.firstMove.san ?? ''} (${formatScore(v1?.score ?? payload.evaluation)}) — only sacrifice when the engine confirms concrete follow-up!`
      return { text, structured: base }
    }
    const text = `Stockfish does not see a sound piece sacrifice in the top 3 lines right now (top choice is ${v1?.firstMove.san ?? 'quiet improvement'} at ${evalStr}, followed by ${v2?.firstMove.san ?? 'solid development'}). Sacrificing without sufficient forcing follow-up would hand over material.`
    return { text, structured: base }
  }

  // Question 6: Explain this position in simpler terms
  if (/simpler|simple|beginner|easy|plain|explain this position/.test(q)) {
    const whoAhead =
      Math.abs(toCp(payload.evaluation)) < 40
        ? 'The game is about equal'
        : toCp(payload.evaluation) > 0
          ? `White is doing better (${evalStr})`
          : `Black is doing better (${evalStr})`
    const text = `In simple terms: ${whoAhead}. ${board.inCheck ? 'Your king is in check, so you must save it first!' : `Your best move is ${v1?.firstMove.san ?? 'to develop your pieces'} because it keeps your pieces active and safe.`} Watch out for your opponent’s idea (${payload.tactics?.opponentThreat?.san ?? 'activating their pieces'}), and focus on keeping every piece protected.`
    return { text, structured: { ...base, headline: `Simple Breakdown: ${whoAhead}` } }
  }

  // Question 7: Training / recurring mistakes
  if (/train|practi|improv|weak|mistake pattern/.test(q)) {
    const text = `${base.improvementTip} In the current position (${evalStr}), focus on ${v1 ? `${v1.firstMove.san} (${v1.sanMoves.slice(0, 4).join(' ')})` : 'piece coordination'}.`
    return { text, structured: base }
  }

  // General position question fallback — always grounded in current FEN + Stockfish MultiPV
  const text = `${base.moveAssessment} ${base.opponentThreat} ${base.engineRecommendation} ${base.strategicPlan}`
  return { text, structured: base }
}

/**
 * Validates an external LLM JSON response against the schema and allowed moves.
 * Guarantees no missing fields and strips/replaces any hallucinated move claims.
 */
export function validateStructuredCoachResponse(
  raw: unknown,
  payload: CoachRequestPayload,
  fallback: StructuredCoachResponse
): StructuredCoachResponse {
  if (!raw || typeof raw !== 'object') return fallback
  const r = raw as Record<string, unknown>
  const str = (v: unknown, def: string) =>
    typeof v === 'string' && v.trim().length > 0 ? v.trim().slice(0, 600) : def

  const allowed = collectAllowedSanMoves(payload)
  const rawRefs = Array.isArray(r.referencedMoves)
    ? r.referencedMoves
        .filter((m): m is string => typeof m === 'string')
        .filter((m) => allowed.has(m) || allowed.has(m.replace(/[+#!?]+$/g, '')))
    : fallback.referencedMoves

  return {
    headline: str(r.headline, fallback.headline),
    moveAssessment: str(r.moveAssessment, fallback.moveAssessment),
    overlooked: str(r.overlooked, fallback.overlooked),
    opponentThreat: str(r.opponentThreat, fallback.opponentThreat),
    engineRecommendation: str(
      r.engineRecommendation,
      fallback.engineRecommendation
    ),
    strategicPlan: str(r.strategicPlan, fallback.strategicPlan),
    improvementTip: str(r.improvementTip, fallback.improvementTip),
    referencedMoves: rawRefs.length > 0 ? rawRefs : fallback.referencedMoves,
    source: 'llm',
    coachId: payload.coachId,
    eloTier: fallback.eloTier,
  }
}
