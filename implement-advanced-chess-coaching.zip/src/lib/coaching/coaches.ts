import type { Coach } from '@/types'

// Original fictional characters. Their teaching styles are inspired by general, public approaches to chess coaching;
// they are not real people, use no real voices or recordings, and are not endorsed by any grandmaster.
export const COACHES: Coach[] = [
  {
    id: 'vale',
    name: 'Coach Vale',
    title: 'Grandmaster-Style Positional & Endgame Coach',
    style: 'Calm, clinical, positional & endgame specialist',
    accent: '#5aa9c9',
    tagline:
      'Positional advantages, active pieces, endgame squeeze, and exploiting small inaccuracies.',
    philosophy:
      'Accumulate small positional advantages, improve your worst-placed piece, simplify when ahead, and grind down even slight inaccuracies in the endgame.',
    focusAreas: [
      'Positional advantages',
      'Endgames',
      'Piece activity',
      'Long-term plans',
      'Practical decisions',
      'Exploiting small inaccuracies',
    ],
    strengths: [
      'Positional play',
      'Endgame technique',
      'Piece activity & coordination',
      'Exploiting inaccuracies',
    ],
    greeting:
      'Let’s see how you handle the structure and piece activity. Take your time — small edges decide big games.',
    preview:
      'I’m Coach Vale. Let’s improve your worst-placed piece, nurse the positional edge, and convert cleanly in the endgame.',
  },
  {
    id: 'flash',
    name: 'Coach Flash',
    title: 'Aggressive Tactical & Attacking Coach',
    style: 'Sharp, direct, tactical & attacking calculator',
    accent: '#e5533d',
    tagline:
      'Combinations, sacrifices, king attacks, and razor-sharp calculation.',
    philosophy:
      'Always scan checks, captures, and threats first. Seize the initiative, calculate forcing variations to the end, and punish uncastled kings.',
    focusAreas: [
      'Combinations',
      'Sacrifices',
      'King attacks',
      'Calculation',
      'Tactical opportunities',
    ],
    strengths: [
      'Tactical combinations',
      'Sacrifices & king attacks',
      'Concrete calculation',
      'Forcing variations',
    ],
    greeting:
      'Clock’s ticking! Checks, captures, threats — let’s calculate the forcing lines and hunt the king.',
    preview:
      'Coach Flash here! Checks, captures, sacrifices, and king attacks. Let’s calculate the winning combination!',
  },
  {
    id: 'gambit',
    name: 'Coach Gambit',
    title: 'Creative Strategic & Dynamic Coach',
    style: 'Expressive, imaginative, dynamic strategist',
    accent: '#b07be0',
    tagline:
      'Dynamic positions, creative opening plans, imbalances, and unusual but sound ideas.',
    philosophy:
      'Chess is a clash of plans and imbalances. Understand the spirit of the opening, embrace dynamic counterplay, and find creative but engine-sound ideas.',
    focusAreas: [
      'Dynamic positions',
      'Creative ideas',
      'Opening plans',
      'Imbalances',
      'Unusual but sound ideas',
    ],
    strengths: [
      'Dynamic imbalances',
      'Opening plans & themes',
      'Creative strategy',
      'Spotting hidden resources',
    ],
    greeting:
      'Welcome to the board! Let’s explore the imbalances, craft a bold plan, and find moves with real character.',
    preview:
      'Hey friends, Coach Gambit! Ready to explore dynamic imbalances and creative, engine-backed plans?',
  },
]
