import type { CoachId } from '@/types'
// Each coach gets its own pitch, pace and (when the browser offers several) its own English voice.
// These are the browser’s built-in synthetic voices: no real person’s voice is cloned or reused.
const VOICE: Record<CoachId, { pitch: number; rate: number; pick: number }> = {
  vale: { pitch: 0.8, rate: 0.92, pick: 0 },
  flash: { pitch: 1.1, rate: 1.2, pick: 1 },
  gambit: { pitch: 1, rate: 1, pick: 2 },
}
const ok = () => typeof window !== 'undefined' && 'speechSynthesis' in window
export const stopSpeaking = () => {
  if (ok()) window.speechSynthesis.cancel()
}
/** Always cancels what is playing first, so two lines can never overlap. `speed` multiplies the coach’s own pace. */
export function speak(text: string, coach: CoachId, speed = 1) {
  if (!ok()) return
  const s = window.speechSynthesis,
    v = VOICE[coach],
    u = new SpeechSynthesisUtterance(text)
  s.cancel()
  const en = s.getVoices().filter((x) => x.lang.startsWith('en'))
  if (en.length) u.voice = en[v.pick % en.length]
  u.pitch = v.pitch
  u.rate = v.rate * speed
  s.speak(u)
}
