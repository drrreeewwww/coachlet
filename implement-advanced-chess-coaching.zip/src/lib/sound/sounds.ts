export type Sfx = 'move' | 'capture' | 'check' | 'end'
// Tiny synthesised sounds (frequency Hz, start s, duration s): no audio files to load or license.
const TONES: Record<Sfx, [number, number, number][]> = {
  move: [[380, 0, 0.06]],
  capture: [
    [220, 0, 0.09],
    [160, 0.04, 0.08],
  ],
  check: [
    [620, 0, 0.1],
    [780, 0.1, 0.12],
  ],
  end: [
    [392, 0, 0.2],
    [494, 0.15, 0.2],
    [587, 0.3, 0.35],
  ],
}
let ctx: AudioContext | null = null
export function playSound(kind: Sfx, volume: number) {
  if (typeof window === 'undefined' || volume <= 0) return
  try {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext
    const c = (ctx ??= new Ctor())
    if (c.state === 'suspended') void c.resume()
    for (const [f, t0, d] of TONES[kind]) {
      const o = c.createOscillator(),
        g = c.createGain(),
        t = c.currentTime + t0
      o.type = kind === 'move' ? 'triangle' : 'sine'
      o.frequency.value = f
      g.gain.setValueAtTime(volume * 0.3, t)
      g.gain.exponentialRampToValueAtTime(0.0001, t + d)
      o.connect(g)
      g.connect(c.destination)
      o.start(t)
      o.stop(t + d + 0.02)
    }
  } catch {
    /* audio unavailable */
  }
}
