export type ThemeId = 'walnut' | 'green' | 'ice' | 'rose'
export type PieceStyle = 'classic' | 'outline' | 'letters'

export const THEMES: Record<
  ThemeId,
  { label: string; light: string; dark: string }
> = {
  walnut: { label: 'Walnut', light: '#e8d8b9', dark: '#8a6a4a' },
  green: { label: 'Tournament green', light: '#eeeed2', dark: '#769656' },
  ice: { label: 'Ice blue', light: '#e6eef5', dark: '#6d8fae' },
  rose: { label: 'Rosewood', light: '#f3e3e3', dark: '#b5727c' },
}

export const PIECE_STYLES: Record<PieceStyle, string> = {
  classic: 'Classic solid',
  outline: 'Outline',
  letters: 'Letter discs',
}

export interface Settings {
  voice: boolean
  speed: number
  reactions: boolean
  hints: boolean
  training: boolean
  threshold: number
  evalBar: boolean
  theme: ThemeId
  pieces: PieceStyle
  coords: boolean
  sound: boolean
  volume: number
  analysisDepth: number
  analysisTime: number
  multiPv: number
  showArrows: boolean
}

export const DEFAULTS: Settings = {
  voice: true,
  speed: 1,
  reactions: true,
  hints: true,
  training: false,
  threshold: 20,
  evalBar: true,
  theme: 'green',
  pieces: 'classic',
  coords: true,
  sound: true,
  volume: 0.6,
  analysisDepth: 14,
  analysisTime: 600,
  multiPv: 3,
  showArrows: true,
}
