import { Chess, type PieceSymbol, type Square } from 'chess.js'
import type { Strength } from './elo'
import { toCp, type Score } from '@/lib/evaluation/classify'
import type { PVLine, PVStep, PositionTactics } from '@/types'

export interface AnalysisOptions {
  movetime?: number
  depth?: number
  multiPv?: number
  onProgress?: (partial: Analysis) => void
}

export interface Analysis {
  fen: string
  score: Score
  best: string
  bestSan: string
  secondBest?: string
  secondBestSan?: string
  secondBestScore?: Score
  thirdBest?: string
  thirdBestSan?: string
  thirdBestScore?: Score
  pv: string[]
   pvSan: string[]
  variations: PVLine[]
  depth: number
  seldepth: number
  tactics: PositionTactics
}

const PIECE_VALUES: Record<PieceSymbol, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
  k: 0,
}

const PIECE_NAMES: Record<PieceSymbol, string> = {
  p: 'pawn',
  n: 'knight',
  b: 'bishop',
  r: 'rook',
  q: 'queen',
  k: 'king',
}

export function uciToMoveObj(uci: string): {
  from: Square
  to: Square
  promotion?: PieceSymbol
} {
  return {
    from: uci.slice(0, 2) as Square,
    to: uci.slice(2, 4) as Square,
    promotion: (uci[4] as PieceSymbol | undefined) || undefined,
  }
}

/**
 * Validates a sequence of UCI moves from `startFen` using chess.js.
 * Stops at the first invalid move so an illegal variation is NEVER displayed.
 */
export function validatePvLine(
  startFen: string,
  multipv: number,
  score: Score,
  depth: number,
  seldepth: number,
  rawUciMoves: string[]
): PVLine | null {
  let chess: Chess
  try {
    chess = new Chess(startFen)
  } catch {
    return null
  }

  const uciMoves: string[] = []
  const sanMoves: string[] = []
  const steps: PVStep[] = []
  const baseCp = toCp(score)

  for (let i = 0; i < rawUciMoves.length && i < 12; i++) {
    const uci = rawUciMoves[i]?.trim()
    if (!uci || uci.length < 4) break
    try {
      const turn = chess.turn()
      const m = chess.move(uciToMoveObj(uci))
      if (!m) break
      const cleanUci = m.from + m.to + (m.promotion ?? '')
      uciMoves.push(cleanUci)
      sanMoves.push(m.san)

      // Compute step evaluation along the principal variation:
      // In a minimax principal variation, optimal play maintains the root score,
      // while mate distance counts down by 1 full move every 2 plies.
      let stepScore: Score = { ...score }
      if (score.mate !== undefined) {
        const sign = score.mate > 0 ? 1 : -1
        const pliesLeft = Math.max(0, Math.abs(score.mate) * 2 - (i + 1))
        const movesLeft = Math.ceil(pliesLeft / 2)
        stepScore = movesLeft === 0 ? { cp: sign * 10000 } : { mate: sign * movesLeft }
      } else {
        stepScore = { cp: baseCp }
      }

      steps.push({
        ply: i + 1,
        uci: cleanUci,
        san: m.san,
        from: m.from,
        to: m.to,
        promotion: m.promotion,
        fenAfter: chess.fen(),
        score: stepScore,
        turn,
      })
    } catch {
      break
    }
  }

  if (steps.length === 0) return null

  return {
    multipv,
    score,
    depth,
    seldepth,
    uciMoves,
    sanMoves,
    steps,
    firstMove: {
      uci: steps[0].uci,
      san: steps[0].san,
      from: steps[0].from,
      to: steps[0].to,
      promotion: steps[0].promotion,
    },
  }
}

/**
 * Detects whether a move in `fenBefore` is a material sacrifice (used for Brilliant !! classification).
 * Checks if the mover captures a lesser piece with a more valuable piece that can be recaptured,
 * or moves a piece (N/B/R/Q) to a square attacked by a lower-value enemy piece, or leaves material en prise
 * along the principal variation.
 */
export function detectSacrifice(
  fenBefore: string,
  uciMove: string,
  pvUci: string[] = []
): boolean {
  try {
    const c = new Chess(fenBefore)
    const mover = c.turn()
    const enemy = mover === 'w' ? 'b' : 'w'

    const matOf = (ch: Chess, col: 'w' | 'b') => {
      let sum = 0
      for (const row of ch.board()) {
        for (const p of row) {
          if (p && p.color === col) sum += PIECE_VALUES[p.type]
        }
      }
      return sum
    }

    const myMatBefore = matOf(c, mover)
    const enemyMatBefore = matOf(c, enemy)
    const netBefore = myMatBefore - enemyMatBefore

    const mv = c.move(uciToMoveObj(uciMove))
    if (!mv) return false

    const movedValue = PIECE_VALUES[mv.piece]
    const capturedValue = mv.captured ? PIECE_VALUES[mv.captured] : 0

    // Case 1: The destination square is attacked by the opponent and the piece moved is worth >= 3 (N/B/R/Q)
    // and worth strictly more than what it captured
    if (movedValue >= 3 && movedValue > capturedValue && c.isAttacked(mv.to as Square, enemy)) {
      // Check if an opponent reply captures it and wins material
      const replies = c.moves({ verbose: true }).filter((r) => r.to === mv.to)
      if (replies.some((r) => PIECE_VALUES[r.piece] < movedValue || capturedValue === 0)) {
        return true
      }
    }

    // Case 2: Following 2 plies of PV, the mover is down net material by at least 2 pawn units
    if (pvUci.length >= 2) {
      const sim = new Chess(fenBefore)
      let ok = true
      for (let i = 0; i < Math.min(3, pvUci.length); i++) {
        try {
          if (!sim.move(uciToMoveObj(pvUci[i]))) {
            ok = false
            break
          }
        } catch {
          ok = false
          break
        }
      }
      if (ok) {
        const netAfter = matOf(sim, mover) - matOf(sim, enemy)
        if (netBefore - netAfter >= 2) return true
      }
    }

    return false
  } catch {
    return false
  }
}

/**
 * Inspects a position using chess.js and validated MultiPV lines to extract:
 * - Material balance & game phase
 * - Tactical motifs (mate threats, checks, captures, hanging pieces, forks/pins)
 * - Strong defensive resources (when under threat or in check)
 * - Opponent's primary threat (using opponent's turn or PV reply)
 */
export function analysePositionTactics(
  fen: string,
  variations: PVLine[],
  opponentThreatLine?: PVLine | null
): PositionTactics {
  const c = new Chess(fen)
  const turn = c.turn()
  const enemy = turn === 'w' ? 'b' : 'w'
  const board = c.board()

  let whiteMat = 0
  let blackMat = 0
  let nonPawnPieces = 0
  const hangingPieces: string[] = []

  for (const row of board) {
    for (const cell of row) {
      if (!cell) continue
      const val = PIECE_VALUES[cell.type]
      if (cell.color === 'w') whiteMat += val
      else blackMat += val
      if (cell.type !== 'p' && cell.type !== 'k') nonPawnPieces++

      // Check if piece is attacked by enemy and undefended by friendly pieces
      if (cell.type !== 'k' && val >= 3) {
        const isAttacked = c.isAttacked(cell.square, cell.color === 'w' ? 'b' : 'w')
        const isDefended = c.isAttacked(cell.square, cell.color)
        if (isAttacked && !isDefended) {
          hangingPieces.push(
            `${cell.color === 'w' ? 'White' : 'Black'} ${PIECE_NAMES[cell.type]} on ${cell.square}`
          )
        }
      }
    }
  }

  const moveNum = Number(fen.split(' ')[5] ?? 1)
  const phase: 'opening' | 'middlegame' | 'endgame' =
    nonPawnPieces <= 6 ? 'endgame' : moveNum <= 10 ? 'opening' : 'middlegame'

  const tacticalMotifs: string[] = []
  const defensiveResources: string[] = []

  const top = variations[0]
  if (c.inCheck()) {
    tacticalMotifs.push('King in check — forced evasion')
  }
  if (top) {
    if (top.score.mate !== undefined) {
      const m = top.score.mate
      if ((turn === 'w' && m > 0) || (turn === 'b' && m < 0)) {
        tacticalMotifs.push(`Forced checkmate in ${Math.abs(m)} (${top.firstMove.san})`)
      } else {
        tacticalMotifs.push(`Defending against mate threat in ${Math.abs(m)}`)
      }
    }
    const firstSan = top.firstMove.san
    if (firstSan.includes('+')) {
      tacticalMotifs.push(`Forcing check with ${firstSan}`)
    }
    if (firstSan.includes('x')) {
      tacticalMotifs.push(`Tactical capture ${firstSan}`)
    }
    if ( firstSan.includes('=') ) {
      tacticalMotifs.push(`Pawn promotion resource ${firstSan}`)
    }
    if (detectSacrifice(fen, top.firstMove.uci, top.uciMoves)) {
      tacticalMotifs.push(`Tactical sacrifice idea ${firstSan}`)
    }
  }
  if (hangingPieces.length > 0) {
    tacticalMotifs.push(`Loose piece alert: ${hangingPieces.slice(0, 2).join(', ')}`)
  }

  // Determine strong defensive moves when under pressure or when alternatives lose heavily
  const moverEval = top ? (turn === 'w' ? toCp(top.score) : -toCp(top.score)) : 0
  if (top && (c.inCheck() || moverEval < 0 || variations.length >= 2)) {
    const secondEval = variations[1]
      ? turn === 'w'
        ? toCp(variations[1].score)
        : -toCp(variations[1].score)
      : moverEval
    if (c.inCheck() || moverEval - secondEval >= 90) {
      defensiveResources.push(
        `${top.firstMove.san} is the key defensive resource (${ variations[1] ? `alternatives like ${variations[1].firstMove.san} drop significant ground` : 'only move' })`
      )
    } else if (moverEval < -50) {
      defensiveResources.push(
        `${top.firstMove.san} offers the most stubborn resistance`
      )
    }
  }

  // Determine opponent's threat
  let opponentThreat: PositionTactics['opponentThreat'] = null
  if (opponentThreatLine && opponentThreatLine.steps.length > 0) {
    const st = opponentThreatLine.steps[0]
    opponentThreat = {
      uci: st.uci,
      san: st.san,
      from: st.from,
      to: st.to,
      description: st.san.includes('#')
        ? `Threatens checkmate with ${st.san}`
        : st.san.includes('+')
          ? `Threatens check ${st.san}`
          : st.san.includes('x')
            ? `Threatens to capture on ${st.to} with ${st.san}`
            : `Plans active continuation ${st.san}`,
      pvSan: opponentThreatLine.sanMoves.slice(0, 4),
      score: opponentThreatLine.score,
    }
  } else if (top && top.steps.length >= 2) {
    // Opponent's best reply in the principal variation
    const reply = top.steps[1]
    opponentThreat = {
      uci: reply.uci,
      san: reply.san,
      from: reply.from,
      to: reply.to,
      description: reply.san.includes('+')
        ? `Counter-check with ${reply.san}`
        : reply.san.includes('x')
          ? `Captures on ${reply.to} (${reply.san})`
          : `Responds with ${reply.san}`,
      pvSan: top.sanMoves.slice(1, 5),
      score: reply.score,
    }
  }

  // If still no opponent threat and not in check, inspect opponent's most dangerous capture/check if they were to move
  if (!opponentThreat && !c.inCheck()) {
    try {
      const parts = fen.split(' ')
      parts[1] = enemy
      parts[3] = '-' // clear en-passant to ensure valid FEN
      const enemyChess = new Chess(parts.join(' '))
      const enemyMoves = enemyChess.moves({ verbose: true })
      const forcing = enemyMoves.find((m) => m.san.includes('#')) ??
        enemyMoves.find((m) => m.captured && PIECE_VALUES[m.captured] >= 3) ??
        enemyMoves.find((m) => m.san.includes('+')) ??
        enemyMoves.find((m) => m.captured)
      if (forcing) {
        opponentThreat = {
          uci: forcing.from + forcing.to + (forcing.promotion ?? ''),
          san: forcing.san,
          from: forcing.from,
          to: forcing.to,
          description: forcing.san.includes('#')
            ? `Threatens immediate mate with ${forcing.san}`
            : forcing.captured
              ? `Threatens to capture ${PIECE_NAMES[forcing.captured]} on ${forcing.to} (${forcing.san})`
              : `Threatens check ${forcing.san}`,
          pvSan: [forcing.san],
          score: top?.score ?? { cp: 0 },
        }
      }
    } catch {
      /* ignore invalid flipped FEN when opponent king is in check */
    }
  }

  return {
    inCheck: c.inCheck(),
    isCheckmate: c.isCheckmate(),
    isDraw: c.isDraw(),
    materialBalance: whiteMat - blackMat,
    phase,
    tacticalMotifs,
    hangingPieces,
    defensiveResources,
    opponentThreat,
  }
}

/**
 * Parses a single UCI `info` line from Stockfish into structured MultiPV metadata.
 */
export function parseUciInfoLine(
  line: string,
  sideMultiplier: 1 | -1
): {
  depth: number
  seldepth: number
  multipv: number
  score: Score
  pv: string[]
} | null {
  if (!line.startsWith('info') || !line.includes(' pv ') || !line.includes(' score ')) {
    return null
  }
  const scoreMatch = /score (cp|mate) (-?\d+)/.exec(line)
  if (!scoreMatch) return null

  const depth = Number(/\bdepth (\d+)/.exec(line)?.[1] ?? 1)
  const seldepth = Number(/\bseldepth (\d+)/.exec(line)?.[1] ?? depth)
  const multipv = Number(/\bmultipv (\d+)/.exec(line)?.[1] ?? 1)
  const val = sideMultiplier * Number(scoreMatch[2])
  const score: Score = scoreMatch[1] === 'cp' ? { cp: val } : { mate: val }
  const pvRaw = line.split(' pv ')[1]?.trim() ?? ''
  const pv = pvRaw ? pvRaw.split(/\s+/).filter(Boolean) : []
  if (pv.length === 0) return null

  return { depth, seldepth, multipv, score, pv }
}

const DEFAULT_ANALYSIS: Strength = {
  limit: false,
  uciElo: 3190,
  skill: 20,
  movetime: 600,
  blunder: 0,
  multiPv: 3,
}

// UCI wrapper around Stockfish in a Web Worker. Calls are queued so searches never overlap,
// with support for MultiPV=3, configurable depth/movetime, live progress streaming, and cancellation.
export class Engine {
  private w: Worker
  private listeners = new Set<(line: string) => void>()
  private ready: Promise<void>
  private chain: Promise<unknown> = Promise.resolve()
  private searching = false

  constructor() {
    this.w = new Worker('/stockfish/stockfish.js#/stockfish/stockfish.wasm')
    this.w.onmessage = (e) => this.listeners.forEach((f) => f(String(e.data)))
    this.ready = this.until('uciok', () => this.send('uci')).then(() =>
      this.until('readyok', () => this.send('isready'))
    )
  }

  private send(cmd: string) {
    this.w.postMessage(cmd)
  }

  private enqueue<T>(fn: () => Promise<T>): Promise<T> {
    const p = this.chain.then(fn)
    this.chain = p.catch(() => undefined)
    return p
  }

  private until(
    token: string,
    start: () => void,
    collect?: (line: string) => void
  ) {
    return new Promise<void>((resolve) => {
      const f = (line: string) => {
        collect?.(line)
        if (line.startsWith(token)) {
          this.listeners.delete(f)
          resolve()
        }
      }
      this.listeners.add(f)
      start()
    })
  }

  /** Stops any currently running search immediately so a newer search can proceed. */
  stop() {
    if (this.searching) {
      this.send('stop')
    }
  }

  private async search(
    fen: string,
    s: Strength & { depth?: number },
    onInfo: (line: string) => void
  ): Promise<string> {
    await this.ready
    this.send(`setoption name UCI_LimitStrength value ${s.limit}`)
    this.send(`setoption name UCI_Elo value ${s.uciElo}`)
    this.send(`setoption name Skill Level value ${s.skill}`)
    this.send(`setoption name MultiPV value ${s.multiPv}`)
    this.send(`position fen ${fen}`)
    let best = ''
    this.searching = true
    const goCmd = s.depth
      ? `go depth ${s.depth} movetime ${s.movetime}`
      : `go movetime ${s.movetime}`
    try {
      await this.until(
        'bestmove',
        () => this.send(goCmd),
        (l) => {
          if (l.startsWith('bestmove')) best = l.split(' ')[1] ?? ''
          else onInfo(l)
        }
      )
    } finally {
      this.searching = false
    }
    return best
  }

  /** The opponent's move in UCI form (e.g. "e7e5"), weakened according to `s`. */
  bestMove(fen: string, s: Strength): Promise<string> {
    return this.enqueue(async () => {
      const candidates = new Map<number, string>()
      const best = await this.search(fen, s, (l) => {
        if (l.startsWith('info') && l.includes(' pv ')) {
          candidates.set(
            Number(/multipv (\d+)/.exec(l)?.[1] ?? 1),
            l.split(' pv ')[1].split(' ')[0]
          )
        }
      })
      if (s.multiPv > 1 && candidates.size > 1 && Math.random() < s.blunder) {
        const others = [...candidates].filter(([k]) => k > 1).map(([, m]) => m)
        return others[Math.floor(Math.random() * others.length)]
      }
      return best
    })
  }

  /**
   * Full-strength MultiPV evaluation of a position, scored from White's point of view.
   * Returns top 3 legal, chess.js-validated Principal Variations, best/2nd/3rd moves,
   * mate/cp scores, depth, and tactical threat analysis.
   */
  analyse(
    fen: string,
    optsOrMovetime: number | AnalysisOptions = 600
  ): Promise<Analysis> {
    const opts: AnalysisOptions =
      typeof optsOrMovetime === 'number'
        ? { movetime: optsOrMovetime }
        : optsOrMovetime
    const movetime = opts.movetime ?? DEFAULT_ANALYSIS.movetime
    const depthLimit = opts.depth ?? 14
    const multiPv = opts.multiPv ?? 3

    return this.enqueue(async () => {
      // Handle terminal positions cleanly
      const rootChess = new Chess(fen)
      if (rootChess.isGameOver()) {
        const terminalScore: Score = rootChess.isCheckmate()
          ? { cp: rootChess.turn() === 'w' ? -10000 : 10000 }
          : { cp: 0 }
        return {
          fen,
          score: terminalScore,
          best: '',
          bestSan: '',
          pv: [],
          pvSan: [],
          variations: [],
          depth: 0,
          seldepth: 0,
          tactics: analysePositionTactics(fen, []),
        }
      }

      const side: 1 | -1 = fen.split(' ')[1] === 'w' ? 1 : -1
      const rawLines = new Map<
        number,
        { depth: number; seldepth: number; score: Score; pv: string[] }
      >()
      let maxDepth = 0
      let maxSeldepth = 0

      const buildSnapshot = (fallbackBestUci = ''): Analysis => {
        const sortedEntries = [...rawLines.entries()].sort((a, b) => a[0] - b[0])
        const variations: PVLine[] = []
        const seenFirstMoves = new Set<string>()

        for (const [, item] of sortedEntries) {
          const validated = validatePvLine(
            fen,
            variations.length + 1,
            item.score,
            item.depth,
            item.seldepth,
            item.pv
          )
          if (validated && !seenFirstMoves.has(validated.firstMove.uci)) {
            seenFirstMoves.add(validated.firstMove.uci)
            variations.push(validated)
          }
        }

        // Fallback if bestmove wasn't captured in info lines
        if (variations.length === 0 && fallbackBestUci) {
          const single = validatePvLine(fen, 1, { cp: 0 }, 1, 1, [fallbackBestUci])
          if (single) variations.push(single)
        }

        const v1 = variations[0]
        const v2 = variations[1]
        const v3 = variations[2]

        return {
          fen,
          score: v1?.score ?? { cp: 0 },
          best: v1?.firstMove.uci ?? fallbackBestUci,
          bestSan: v1?.firstMove.san ?? '',
          secondBest: v2?.firstMove.uci,
          secondBestSan: v2?.firstMove.san,
          secondBestScore: v2?.score,
          thirdBest: v3?.firstMove.uci,
          thirdBestSan: v3?.firstMove.san,
          thirdBestScore: v3?.score,
          pv: v1?.uciMoves ?? [],
          pvSan: v1?.sanMoves ?? [],
          variations,
          depth: maxDepth || (v1?.depth ?? 1),
          seldepth: maxSeldepth || (v1?.seldepth ?? 1),
          tactics: analysePositionTactics(fen, variations),
        }
      }

      const bestUci = await this.search(
        fen,
        { ...DEFAULT_ANALYSIS, movetime, multiPv, depth: depthLimit },
        (line) => {
          const parsed = parseUciInfoLine(line, side)
          if (parsed) {
            rawLines.set(parsed.multipv, {
              depth: parsed.depth,
              seldepth: parsed.seldepth,
              score: parsed.score,
              pv: parsed.pv,
            })
            if (parsed.depth > maxDepth) {
              maxDepth = parsed.depth
              maxSeldepth = Math.max(maxSeldepth, parsed.seldepth)
              if (opts.onProgress && parsed.multipv === 1 && parsed.depth >= 4) {
                opts.onProgress(buildSnapshot())
              }
            }
          }
        }
      )

      return buildSnapshot(bestUci)
    })
  }

  destroy() {
    this.w.terminate()
  }
}
