// Copies the single-threaded Stockfish WASM build into /public/stockfish so the browser can load it as a Web Worker.
import fs from 'node:fs'
import path from 'node:path'

const dirs = ['node_modules/stockfish/bin', 'node_modules/stockfish/src']
const out = 'public/stockfish'

try {
  const src = dirs.find((d) => fs.existsSync(d))
  if (!src) throw new Error('No stockfish build directory found in node_modules/stockfish')
  const files = fs
    .readdirSync(src)
    .filter((f) => f.includes('single'))
    .sort((a, b) => +b.includes('lite') - +a.includes('lite'))
  const js = files.find((f) => f.endsWith('.js'))
  const wasm = files.find((f) => f.endsWith('.wasm'))
  if (!js || !wasm) throw new Error('Could not find single-threaded stockfish .js/.wasm files')
  fs.mkdirSync(out, { recursive: true })
  fs.copyFileSync(path.join(src, js), path.join(out, 'stockfish.js'))
  fs.copyFileSync(path.join(src, wasm), path.join(out, 'stockfish.wasm'))
  console.log('Stockfish copied:', js, wasm)
} catch (e) {
  console.warn('Stockfish copy skipped:', e instanceof Error ? e.message : String(e))
}
