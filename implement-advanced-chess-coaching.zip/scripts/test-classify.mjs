import assert from 'node:assert/strict'
import { createRequire, registerHooks } from 'node:module'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier.startsWith('@/')) {
      const target = path.resolve('src', specifier.slice(2)) + '.ts'
      return nextResolve(pathToFileURL(target).href, context)
    }
    if (
      (specifier.startsWith('./') || specifier.startsWith('../')) &&
      !path.extname(specifier)
    ) {
      const base = context.parentURL
        ? path.dirname(new URL(context.parentURL).pathname)
        : process.cwd()
      const target = path.resolve(base, specifier) + '.ts'
      return nextResolve(pathToFileURL(target).href, context)
    }
    return nextResolve(specifier, context)
  },
})

const require = createRequire(import.meta.url)

const { accuracyOf, classify, winPct, toCp, formatScore, CLASS_META } =
  await import('../src/lib/evaluation/classify.ts')
const {
  validatePvLine,
  detectSacrifice,
  analysePositionTactics,
  parseUciInfoLine,
} = await import('../src/lib/stockfish/engine.ts')
const {
  buildEngineGroundedCoaching,
  answerPositionQuestion,
  validateStructuredCoachResponse,
} = await import('../src/lib/coaching/structured.ts')

// 1. Original unit tests (100% preserved)
assert.equal(Math.round(winPct(0)), 50)
assert.ok(winPct(300) > 70 && winPct(-300) < 30)
assert.equal(classify(50, 50, 'w', true).cls, 'best')
assert.equal(classify(50, 45, 'w', false).cls, 'best') // ~5cp loss is noise, treated as best
assert.equal(classify(50, 20, 'w', false).cls, 'good') // 30cp loss
assert.equal(classify(50, -250, 'w', false).cls, 'blunder') // White drops 3 pawns
assert.equal(classify(-50, 250, 'b', false).cls, 'blunder') // same from Black's side
assert.equal(classify(100, 100, 'b', false).cls, 'best') // Black’s eval unchanged
assert.equal(classify(0, -150, 'w', false).cls, 'mistake')
assert.equal(classify(0, -60, 'w', false).cls, 'inaccuracy')
assert.equal(classify(0, 200, 'w', false).cls, 'best')
assert.equal(classify(0, 200, 'w', false).cpLoss, 0)
assert.equal(toCp({ mate: 3 }), 9970)
assert.equal(toCp({ mate: -3 }), -9970)
assert.equal(formatScore({ cp: 40 }), '+0.4')
assert.equal(formatScore({ mate: -2 }), '-M2')
assert.ok(accuracyOf(0) > 99 && accuracyOf(30) < 30)

// 2. Extended 8-tier move classification tests (Brilliant, Great, Excellent, Forced Mates)
assert.equal(Object.keys(CLASS_META).length, 8)
assert.equal(
  classify(120, 120, 'w', true, { isSacrifice: true }).cls,
  'brilliant'
)
assert.equal(
  classify(150, 150, 'w', true, { secondBestBefore: -80 }).cls,
  'great'
)
assert.equal(classify(50, 35, 'w', false).cls, 'excellent')
assert.equal(
  classify(40, -9980, 'w', false, { mateAfter: -2 }).cls,
  'blunder'
)
assert.equal(
  classify(9970, 0, 'w', false, { mateBefore: 3 }).cls,
  'blunder'
)

// 3. Sacrifice detection on Morphy's Opera Game (16.Qb8+!! Nxb8 17.Rd8#)
const operaFen = '4kb1r/p2n1ppp/4q3/4p1B1/4P3/1Q6/PPP2PPP/2KR4 w k - 1 16'
assert.equal(detectSacrifice(operaFen, 'b3b8', ['b3b8', 'd7b8', 'd1d8']), true)

// 4. Test real Stockfish WASM MultiPV=3 search and chess.js PV validation
const startItalian =
  'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R b KQkq - 3 3'
const multiPvLines = await new Promise((resolve, reject) => {
  const raw = new Map()
  const sf = require('stockfish')('lite-single', (line) => {
    const parsed = parseUciInfoLine(String(line), -1)
    if (parsed) {
      raw.set(parsed.multipv, parsed)
    }
    if (String(line).startsWith('bestmove')) {
      sf.terminate()
      resolve([...raw.values()])
    }
  })
  setTimeout(() => {
    sf.terminate()
    reject(new Error('Stockfish timed out'))
  }, 10000)
  sf.processCommand('uci')
  sf.processCommand('setoption name MultiPV value 3')
  sf.processCommand('isready')
  sf.processCommand(`position fen ${startItalian}`)
  sf.processCommand('go depth 8')
})

assert.equal(multiPvLines.length, 3, 'MultiPV=3 must return 3 distinct lines')
const validatedVariations = multiPvLines
  .map((item, idx) =>
    validatePvLine(
      startItalian,
      idx + 1,
      item.score,
      item.depth,
      item.seldepth,
      item.pv
    )
  )
  .filter(Boolean)

assert.equal(validatedVariations.length, 3)
assert.notEqual(
  validatedVariations[0].firstMove.uci,
  validatedVariations[1].firstMove.uci
)
assert.ok(validatedVariations[0].sanMoves.length >= 1)
assert.ok(validatedVariations[0].steps[0].fenAfter.includes(' w '))

// 5. Test tactical analysis and structured coaching across Vale, Flash, and Gambit
const tactics = analysePositionTactics(startItalian, validatedVariations)
assert.equal(tactics.phase, 'opening')

const valeCoaching = buildEngineGroundedCoaching({
  fen: startItalian,
  moveHistory: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'],
  evaluation: validatedVariations[0].score,
  bestMoveSan: validatedVariations[0].firstMove.san,
  variations: validatedVariations,
  tactics,
  elo: 1200,
  coachId: 'vale',
})
const flashCoaching = buildEngineGroundedCoaching({
  fen: startItalian,
  moveHistory: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'],
  evaluation: validatedVariations[0].score,
  bestMoveSan: validatedVariations[0].firstMove.san,
  variations: validatedVariations,
  tactics,
  elo: 1800,
  coachId: 'flash',
})
const gambitCoaching = buildEngineGroundedCoaching({
  fen: startItalian,
  moveHistory: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'],
  evaluation: validatedVariations[0].score,
  bestMoveSan: validatedVariations[0].firstMove.san,
  variations: validatedVariations,
  tactics,
  elo: 900,
  coachId: 'gambit',
})

assert.ok(
  valeCoaching.engineRecommendation.includes(
    validatedVariations[0].firstMove.san
  )
)
assert.notEqual(valeCoaching.strategicPlan, flashCoaching.strategicPlan)
assert.notEqual(flashCoaching.strategicPlan, gambitCoaching.strategicPlan)

const qa = answerPositionQuestion(
  'What would a grandmaster play here?',
  {
    fen: startItalian,
    moveHistory: ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4'],
    evaluation: validatedVariations[0].score,
    bestMoveSan: validatedVariations[0].firstMove.san,
    variations: validatedVariations,
    tactics,
    elo: 1500,
    coachId: 'vale',
  },
  valeCoaching
)
assert.ok(qa.text.includes(validatedVariations[0].firstMove.san))

// Verify move validation strips illegal/invented moves from LLM output
const sanitized = validateStructuredCoachResponse(
  {
    headline: 'Custom LLM Headline',
    referencedMoves: [' Qxe9# ', validatedVariations[0].firstMove.san],
  },
  {
    fen: startItalian,
    moveHistory: [],
    evaluation: validatedVariations[0].score,
    bestMoveSan: validatedVariations[0].firstMove.san,
    variations: validatedVariations,
    elo: 1200,
    coachId: 'vale',
  },
  valeCoaching
)
assert.ok(!sanitized.referencedMoves.includes(' Qxe9# '))
assert.ok(
  sanitized.referencedMoves.includes(validatedVariations[0].firstMove.san)
)

console.log('classify + MultiPV Stockfish + coaching: all tests passed')
