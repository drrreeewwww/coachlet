import { expect, test, type Page } from '@playwright/test'

const cursorText = async (page: Page) => (await page.locator('[aria-current="step"]').first().textContent().catch(() => null)) ?? ''
const plyCount = async (page: Page) => page.locator('ol button').count()

test('Play: click-to-move gets a real Stockfish reply and no page errors', async ({ page }) => {
  const errors: string[] = []
  page.on('pageerror', (e) => errors.push(e.message))
  await page.goto('/play')
  await page.locator('[data-square="e2"]').click()
  await page.locator('[data-square="e4"]').click()
  await expect(page.getByText(/MOVE HISTORY \(2 PLIES\)/i)).toBeVisible({ timeout: 60_000 })
  expect(errors).toEqual([])
})

test('Opening Explorer: select, step, flip, branch, and all three playback modes', async ({ page }) => {
  const errors: string[] = []
  page.on('pageerror', (e) => errors.push(e.message))
  await page.setViewportSize({ width: 1440, height: 900 })
  await page.goto('/openings')
  await page.getByLabel(/Search openings/).fill('Italian Game: Giuoco Piano')
  await page.locator('section[aria-label="Opening library"] ul button').first().click()
  const n = await plyCount(page)
  expect(n).toBeGreaterThan(3)
  await expect(page.getByRole('heading', { name: /Giuoco Piano/ }).first()).toBeVisible()

  // Prev / Next / Restart
  await page.getByLabel('Previous move').click()
  expect(await cursorText(page)).toContain(String(Math.floor((n - 2) / 2) + 1))
  await page.getByLabel('Next move').click()
  await page.getByLabel('Restart from the first move').click()
  expect(await page.locator('[aria-current="step"]').count()).toBe(0)
  await page.getByLabel('Flip board').click()
  await page.getByLabel('Flip board').click()

  // Selected variation: one ply per 1.5 s, starting immediately
  await page.getByRole('radio', { name: 'Selected variation' }).click()
  await page.getByLabel('Play line').click()
  await page.waitForTimeout(200)
  expect(await plyIndex(page)).toBe(1)
  await page.waitForTimeout(1500)
  expect(await plyIndex(page)).toBe(2)
  await page.waitForTimeout(1500)
  expect(await plyIndex(page)).toBe(3)
  await page.getByLabel('Pause playback').click()
  const paused = await plyIndex(page)
  await page.waitForTimeout(2200)
  expect(await plyIndex(page)).toBe(paused) // pause really pauses
  await page.getByLabel('Play line').click() // resume
  await page.waitForTimeout(300)
  expect(await plyIndex(page)).toBe(paused + 1)
  await page.getByLabel('Pause playback').click()

  // Manual branch: play a different move from the board while stepped back
  await page.getByLabel('Restart from the first move').click()
  await page.locator('[data-square="d2"]').click()
  await page.locator('[data-square="d4"]').click()
  expect(await plyCount(page)).toBe(1) // old future replaced by the new branch

  // Engine mode: real Stockfish plays both sides
  await page.getByRole('radio', { name: 'Engine best line' }).click()
  await page.getByLabel('Speed').or(page.getByLabel(/Playback speed/)).selectOption('1000')
  await page.getByLabel('Play line').click()
  await expect.poll(() => plyCount(page), { timeout: 30_000 }).toBeGreaterThanOrEqual(4)
  await page.getByLabel('Pause playback').click()

  // Most-played: works offline from Coachlet's own database, no token needed
  await page.getByLabel('Restart from the first move').click()
  await page.getByRole('radio', { name: 'Most-played line' }).click()
  await expect(page.getByText(/named lines? reach this position/)).toBeVisible({ timeout: 15_000 })
  await page.getByLabel('Play line').click()
  await expect.poll(() => plyCount(page), { timeout: 15_000 }).toBeGreaterThanOrEqual(2)
  await page.getByLabel('Pause playback').click()
  // The database panel lists real continuations with share bars, and no token UI remains
  await expect(page.locator('section[aria-label="Opening database statistics"] table')).toBeVisible()
  await expect(page.getByText(/API token/i)).toHaveCount(0)
  expect(errors).toEqual([])
})

async function plyIndex(page: Page): Promise<number> {
  return page.evaluate(() => {
    const items = [...document.querySelectorAll('ol button')]
    const i = items.findIndex((b) => b.getAttribute('aria-current') === 'step')
    return i + 1
  })
}

test('Settings: voice download can be cancelled and leaves nothing cached', async ({ page }) => {
  await page.goto('/settings')
  await page.getByRole('button', { name: /Download voice/ }).click()
  await expect(page.getByText(/Downloading… \d+ \/ \d+ MB/)).toBeVisible({ timeout: 30_000 })
  await page.waitForTimeout(1500)
  await page.getByRole('button', { name: /Cancel download/ }).click()
  await expect(page.getByText(/Not downloaded\./)).toBeVisible()
  const cached = await page.evaluate(async () => (await (await caches.open('transformers-cache')).keys()).length)
  expect(cached).toBe(0)
  await expect(page.getByRole('button', { name: /Download voice/ })).toBeVisible() // recoverable
})

test('Kokoro: full download, cache, real synthesis and playback lifecycle', async ({ page }) => {
  test.setTimeout(420_000)
  const errors: string[] = []
  page.on('pageerror', (e) => errors.push(e.message))
  await page.goto('/settings')
  await page.getByRole('button', { name: /Download voice/ }).click()
  await expect(page.getByText(/Loaded and ready|Downloaded and cached|Loading the model/)).toBeVisible({ timeout: 300_000 })
  const cached = await page.evaluate(async () => (await (await caches.open('transformers-cache')).keys()).length)
  expect(cached).toBe(4)
  await expect(page.getByText(/Loaded and ready/)).toBeVisible({ timeout: 120_000 })
  const t0 = Date.now()
  await page.getByRole('button', { name: 'Preview Heart' }).click()
  const stop = page.getByRole('button', { name: /Stop/ }).first()
  await expect(stop).toBeEnabled({ timeout: 5_000 })
  // playback finishes by itself (state follows real audio end)
  await expect(stop).toBeDisabled({ timeout: 120_000 })
  console.log('kokoro preview total ms', Date.now() - t0)
  expect(errors).toEqual([])
})
