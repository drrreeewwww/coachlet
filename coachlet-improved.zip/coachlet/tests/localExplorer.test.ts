// Coachlet's own opening database: index building, position statistics, honest shares.
import { describe, expect, it } from 'vitest'
import { Chess } from 'chess.js'
import { buildCatalogue, epdOf, type Catalogue } from '@/lib/openings/catalogue'
import {
  buildLocalIndex,
  formatCount,
  moveShare,
  statsForPosition,
  type LocalExplorerIndex,
} from '@/lib/openings/localExplorer'
import rows from '@/lib/openings/data/openings.json'

const cat: Catalogue = buildCatalogue(rows as unknown as Array<[string, string, string, string]>)
const index: LocalExplorerIndex = buildLocalIndex(cat)

const startFen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'
const afterE4 = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1' // chess.js drops the phantom e3 ep square
const epd = (fen: string) => fen.split(' ').slice(0, 4).join(' ')

describe('local explorer index', () => {
  it('counts lines through the start position = number of catalogue entries', () => {
    expect(statsForPosition(index, startFen).total).toBe(cat.entries.length)
  })

  it('1. e4 is the most common first move, ahead of 1. d4, with real line counts', () => {
    const s = statsForPosition(index, startFen)
    expect(s.moves[0].san).toBe('e4')
    const e4 = s.moves.find((m) => m.san === 'e4')!
    const d4 = s.moves.find((m) => m.san === 'd4')!
    expect(e4.lines).toBeGreaterThan(d4.lines)
    expect(s.moves.every((m) => m.lines >= 1)).toBe(true)
    // All shares are computed from real counts and every move's share sums to <= 100.
    const totalShare = s.moves.reduce((sum, m) => sum + moveShare(m, s), 0)
    expect(totalShare).toBeGreaterThan(90)
    expect(totalShare).toBeLessThanOrEqual(100.0001)
  })

  it('continuation counts follow the actual catalogue lines', () => {
    // After 1. e4, the number of lines through that position must equal the number of
    // catalogue entries whose first move is e4 — verified independently.
    const e4Lines = cat.entries.filter((e) => e.sans[0] === 'e4').length
    const s = statsForPosition(index, afterE4)
    expect(s.total).toBe(e4Lines)
    // Every line through 1. e4 got there by playing e4 from the start.
    const e4Stat = statsForPosition(index, startFen).moves.find((m) => m.san === 'e4')!
    expect(e4Stat.lines).toBe(e4Lines)
  })

  it('UCI strings match the SAN moves (spot check with chess.js)', () => {
    const s = statsForPosition(index, startFen)
    for (const m of s.moves.slice(0, 10)) {
      const board = new Chess()
      const mv = board.move(m.san)
      expect(m.uci).toBe(`${mv.from}${mv.to}${mv.promotion ?? ''}`)
    }
  })

  it('stats carry no names — the view supplies the opening label', () => {
    const s = statsForPosition(index, startFen)
    expect('opening' in s).toBe(false)
    expect(s.moves.length).toBeGreaterThan(0)
  })

  it('handles positions outside the book with empty, honest results', () => {
    const board = new Chess('rnbq1bnr/ppppkppp/8/4p3/4P3/8/PPPPKPPP/RNBQ1BNR w - - 2 3')
    const s = statsForPosition(index, board.fen())
    expect(s.total).toBe(0)
    expect(s.moves).toEqual([])
  })

  it('skips an illegal catalogue line instead of throwing (defensive)', () => {
    const tiny: Catalogue = buildCatalogue([['A00', 'Broken Line', 'Ke4 e5', epd(new Chess().fen())]])
    expect(() => buildLocalIndex(tiny)).not.toThrow()
    const idx = buildLocalIndex(tiny)
    expect(statsForPosition(idx, startFen).moves).toEqual([])
  })
})

describe('formatCount', () => {
  it('formats like the old explorer counts', () => {
    expect(formatCount(3865)).toBe('3.9k')
    expect(formatCount(999)).toBe('999')
    expect(formatCount(12_345)).toBe('12k')
    expect(formatCount(2_500_000)).toBe('2.5M')
  })
})
