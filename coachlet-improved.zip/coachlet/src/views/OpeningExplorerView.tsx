'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Chess } from 'chess.js'
import Chessboard from '@/components/Chessboard/Chessboard'
import OpeningLibrary from '@/components/Openings/OpeningLibrary'
import PlaybackBar, { type PlayMode } from '@/components/Openings/PlaybackBar'
import { DatabasePanel, EnginePanel, type EngineView } from '@/components/Openings/DatabasePanels'
import LearnPanel from '@/components/Openings/LearnPanel'
import { Autoplay, type StepResult } from '@/lib/openings/autoplay'
import { categoriesOf, epdOf, loadCatalogue, nameForLine, type Catalogue, type OpeningEntry } from '@/lib/openings/catalogue'
import { loadLocalIndex, statsForPosition, type LocalExplorerIndex } from '@/lib/openings/localExplorer'
import { infoFor } from '@/lib/openings/familyInfo'
import { positionInsights } from '@/lib/openings/insights'
import { START_FEN, emptyLine, fenAt, goTo, lastMoveAt, lineFromSans, moveLabel, tryPlay, type LineState, type MoveInput } from '@/lib/openings/lineState'
import { useExplorerPrefs } from '@/lib/openings/prefs'
import { Engine, type Analysis } from '@/lib/stockfish/engine'
import { useSettings } from '@/lib/useSettings'

type Tab = 'library' | 'moves' | 'learn'

export default function OpeningExplorerView() {
  const [st] = useSettings()
  const [prefs, setPrefs] = useExplorerPrefs()
  const [cat, setCat] = useState<Catalogue | null>(null)
  const [line, setLine] = useState<LineState>(emptyLine())
  const [selected, setSelected] = useState<OpeningEntry | null>(null)
  const [mode, setMode] = useState<PlayMode>('most-played')
  const [running, setRunning] = useState(false)
  const [message, setMessage] = useState<string | null>(null)
  const [tab, setTab] = useState<Tab>('library')
  const [index, setIndex] = useState<LocalExplorerIndex | null>(null)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [engineStatus, setEngineStatus] = useState<'starting' | 'ready' | 'fallback'>('starting')
  const [analysis, setAnalysis] = useState<Analysis | null>(null)
  const [engineBusy, setEngineBusy] = useState(false)

  // Latest values for the autoplay step (no stale closures).
  const lineRef = useRef(line)
  const modeRef = useRef(mode)
  const prefsRef = useRef(prefs)
  const indexRef = useRef(index)
  const engineRef = useRef<Engine | null>(null)
  const engineDrives = useRef(false)
  useEffect(() => { modeRef.current = mode }, [mode])
  useEffect(() => { prefsRef.current = prefs }, [prefs])
  useEffect(() => { indexRef.current = index }, [index])

  const commit = useCallback((l: LineState) => {
    lineRef.current = l
    setLine(l)
  }, [])

  // ---- Local opening database (catalogue + continuation index). No network, no tokens.
  useEffect(() => {
    let alive = true
    loadLocalIndex()
      .then((idx) => {
        if (!alive) return
        setIndex(idx)
        return loadCatalogue().then((c) => alive && setCat(c))
      })
      .catch((e: Error) => alive && setLoadError(`Could not load the opening database: ${e.message}`))
    return () => { alive = false }
  }, [])

  // ---- Own Stockfish worker (never shared with Play); destroyed on unmount.
  useEffect(() => {
    let off: (() => void) | null = null
    let e: Engine | null = null
    try {
      e = new Engine()
      engineRef.current = e
      off = e.onStatus(setEngineStatus)
    } catch {
      setEngineStatus('fallback')
    }
    return () => {
      off?.()
      e?.destroy()
      engineRef.current = null
    }
  }, [])

  // ---- Autoplay controller (single instance; epoch-guarded)
  const autoplay = useRef<Autoplay | null>(null)
  if (!autoplay.current) {
    autoplay.current = new Autoplay({
      getIntervalMs: () => prefsRef.current.speedMs,
      onRunning: setRunning,
      step: async (isActive): Promise<StepResult> => {
        const stop = (msg: string): StepResult => { if (isActive()) setMessage(msg); return 'stop' }
        const l = lineRef.current
        const mdl = modeRef.current
        const fen = fenAt(l)
        const apply = (input: MoveInput | null): StepResult => {
          if (!isActive()) return 'stop'
          const n = input ? tryPlay(lineRef.current, input) : null
          if (!n) return stop('The suggested move was not legal, so playback stopped.')
          commit(n)
          return 'continue'
        }
        if (mdl === 'selected') {
          if (l.cursor >= l.plies.length) return stop('Reached the end of the selected variation.')
          commit(goTo(l, l.cursor + 1))
          return 'continue'
        }
        if (new Chess(fen).isGameOver()) return stop('The game is over in this line.')
        if (mdl === 'most-played') {
          const idx = indexRef.current
          if (!idx) return stop('The opening database is still loading — try again in a moment.')
          const s = statsForPosition(idx, fen)
          const top = s.moves[0]
          if (!top) return stop('No named continuation in the database for this position — end of the most-played line.')
          return apply({ san: top.san })
        }
        // engine mode
        const e = engineRef.current
        if (!e || e.getStatus() === 'fallback') return stop('Stockfish analysis is unavailable, so the engine line cannot be played.')
        e.cancelPendingAnalysis() // stop any panel analysis; stale results are guarded by isActive()
        let a: Analysis
        try {
          a = await e.analyse(fen, { movetime: 600, multiPv: 1, depth: 14 })
        } catch {
          return stop('Engine analysis was interrupted.')
        }
        if (!isActive()) return 'stop'
        if (e.getStatus() === 'fallback') return stop('Stockfish stopped responding, so playback stopped.')
        if (!a.best) return stop('The engine returned no move.')
        return apply({ uci: a.best })
      },
    })
  }
  useEffect(() => {
    const ap = autoplay.current
    return () => ap?.stop()
  }, [])

  const stopAuto = useCallback(() => autoplay.current?.stop(), [])

  const fen = fenAt(line)
  const last = lastMoveAt(line)
  const atStart = line.cursor === 0
  const atEnd = line.cursor >= line.plies.length

  // ---- Local database statistics for the current position (pure lookups once the index is built)
  const stats = useMemo(() => (index ? statsForPosition(index, fen) : null), [index, fen])

  engineDrives.current = running && mode === 'engine'

  // ---- Engine analysis for the panel (paused while the engine drives autoplay)
  useEffect(() => {
    const e = engineRef.current
    if (!e || engineStatus === 'fallback' || (running && mode === 'engine')) return
    let cancelled = false
    setAnalysis(null)
    const t = setTimeout(async () => {
      const epoch = e.cancelPendingAnalysis()
      setEngineBusy(true)
      try {
        const a = await e.analyse(fen, { movetime: 700, multiPv: 3, depth: 14, epoch })
        if (!cancelled) setAnalysis(a)
      } catch {
        /* superseded */
      } finally {
        if (!cancelled) setEngineBusy(false)
      }
    }, 400)
    return () => { cancelled = true; clearTimeout(t); if (!engineDrives.current) e.cancelPendingAnalysis() }
  }, [fen, engineStatus, running, mode])

  // ---- Naming / explanations
  const epds = useMemo(() => [epdOf(START_FEN), ...line.plies.map((p) => epdOf(p.fen))], [line.plies])
  const named = useMemo(() => (cat ? nameForLine(cat, epds, line.cursor) : null), [cat, epds, line.cursor])
  const entry = named?.entry ?? null
  const { info, curated } = useMemo(() => (entry ? infoFor(entry.family, categoriesOf(entry)[0]) : { info: null, curated: false }), [entry])
  const lastSan = line.cursor > 0 ? line.plies[line.cursor - 1].san : null
  const insights = useMemo(() => positionInsights(fen, lastSan), [fen, lastSan])

  // ---- Actions (any manual action cancels autoplay first)
  const selectOpening = useCallback((e: OpeningEntry) => {
    stopAuto()
    const l = lineFromSans(e.sans)
    if (!l) { setMessage(`Could not load ${e.name}: its move list is not legal.`); return }
    setSelected(e)
    setMessage(null)
    commit(l)
    setTab('moves')
  }, [commit, stopAuto])

  const play = useCallback((input: MoveInput) => {
    stopAuto()
    const n = tryPlay(lineRef.current, input)
    if (!n) { setMessage('That move is not legal in this position.'); return }
    setMessage(null)
    commit(n)
  }, [commit, stopAuto])

  const onBoardMove = (from: string, to: string, promotion?: string) => play({ from, to, promotion })
  const prev = useCallback(() => { stopAuto(); commit(goTo(lineRef.current, lineRef.current.cursor - 1)); setMessage(null) }, [commit, stopAuto])
  const next = useCallback(() => { stopAuto(); commit(goTo(lineRef.current, lineRef.current.cursor + 1)); setMessage(null) }, [commit, stopAuto])
  const restart = useCallback(() => { stopAuto(); commit(goTo(lineRef.current, 0)); setMessage(null) }, [commit, stopAuto])
  const flip = useCallback(() => setPrefs({ flipped: !prefsRef.current.flipped }), [setPrefs])

  const onPlayPress = () => {
    setMessage(null)
    // From the end of a selected-variation replay, start over.
    if (modeRef.current === 'selected' && lineRef.current.cursor >= lineRef.current.plies.length && lineRef.current.plies.length > 0) {
      commit(goTo(lineRef.current, 0))
    }
    autoplay.current?.start()
  }

  const changeMode = (m: PlayMode) => { stopAuto(); setMode(m); setMessage(null) }

  // Keyboard shortcuts (ignored while typing)
  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      const t = ev.target as HTMLElement | null
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return
      if (ev.key === 'ArrowLeft') { ev.preventDefault(); prev() }
      else if (ev.key === 'ArrowRight') { ev.preventDefault(); next() }
      else if (ev.key.toLowerCase() === 'f' && !ev.metaKey && !ev.ctrlKey) flip()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [prev, next, flip])

  const selectedSan = atEnd ? null : line.plies[line.cursor]?.san ?? null
  const engineView: EngineView = { status: engineStatus, busy: engineBusy, analysis: analysis && analysis.fen === fen ? analysis : null, paused: running && mode === 'engine' }
  const title = entry ? `${entry.eco} · ${entry.name}` : line.cursor === 0 ? 'Starting position' : 'Position outside the catalogue'
  const turnLabel = new Chess(fen).turn() === 'w' ? 'White to move' : 'Black to move'

  const tabBtn = (t: Tab, label: string) => (
    <button key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`min-h-11 flex-1 rounded-md px-2 text-xs font-bold ${tab === t ? 'bg-[#81b64c] text-[#1c1b19]' : 'bg-[#262522] text-stone-300'}`}>{label}</button>
  )

  return (
    <div className="mx-auto w-full max-w-[1700px] p-3 sm:p-4">
      <h1 className="mb-2 text-lg font-extrabold text-white short:hidden">Opening Explorer</h1>
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[290px_minmax(0,1fr)_380px] short:grid-cols-[calc(100dvh-24px)_minmax(0,1fr)] short:items-start">
        {/* Board column */}
        <div className="order-first min-w-0 xl:order-2 short:row-span-3">
          <div className="mx-auto w-full max-w-[var(--board-max)] [--board-max:max(260px,calc(100dvh-300px-env(safe-area-inset-bottom)))] md:[--board-max:max(260px,calc(100dvh-250px))] short:max-w-none short:[--board-max:100%] xl:sticky xl:top-3 short:sticky short:top-3">
            <div className="mb-2 flex items-baseline justify-between gap-2 text-xs short:hidden">
              <b className="min-w-0 truncate text-sm text-white" title={title}>{title}</b>
              <span className="shrink-0 text-stone-400">{turnLabel}</span>
            </div>
            <Chessboard fen={fen} flipped={prefs.flipped} lastMove={last} disabled={false} look={st} onMove={onBoardMove} />
            <PlaybackBar
              running={running} atStart={atStart} atEnd={atEnd} mode={mode} onMode={changeMode}
              speedMs={prefs.speedMs} onSpeed={(n) => setPrefs({ speedMs: n })}
              onPlay={onPlayPress} onPause={stopAuto} onPrev={prev} onNext={next} onRestart={restart} onFlip={flip}
              message={message}
            />
          </div>

          {/* Move history (synchronised with the board; later plies are the replayable rest of the line) */}
          <div className="mx-auto mt-3 w-full max-w-[var(--board-max)] [--board-max:max(260px,calc(100dvh-300px))] md:[--board-max:max(260px,calc(100dvh-250px))] short:max-w-none">
            <div className="rounded-lg border border-[#3a3834] bg-[#262522] p-2" aria-label="Move history" role="group">
              {line.plies.length === 0 ? (
                <p className="p-1 text-xs text-stone-400">Pick an opening, or make a move on the board to start exploring.</p>
              ) : (
                <ol className="flex flex-wrap gap-1 text-xs">
                  {line.plies.map((p, i) => (
                    <li key={`${i}-${p.uci}`}>
                      <button type="button" onClick={() => { stopAuto(); commit(goTo(lineRef.current, i + 1)) }} aria-current={i + 1 === line.cursor ? 'step' : undefined}
                        className={`min-h-9 rounded px-2 font-mono font-semibold ${i + 1 === line.cursor ? 'bg-[#81b64c] text-[#1c1b19]' : i + 1 > line.cursor ? 'text-stone-500 hover:bg-[#33312d]' : 'text-stone-100 hover:bg-[#33312d]'}`}>
                        {moveLabel(i, p.san)}
                      </button>
                    </li>
                  ))}
                </ol>
              )}
            </div>
            <div className="mt-3 flex gap-1 xl:hidden short:hidden" role="tablist" aria-label="Explorer panels">
              {tabBtn('library', 'Library')}
              {tabBtn('moves', 'Moves & engine')}
              {tabBtn('learn', 'Learn')}
            </div>
          </div>
        </div>

        {/* Library */}
        <div className={`${tab === 'library' ? 'block' : 'hidden'} min-w-0 xl:order-1 xl:block short:block`}>
          <OpeningLibrary cat={cat} loadError={loadError} activeName={selected?.name ?? entry?.name ?? null} onSelect={selectOpening} />
        </div>

        {/* Right: database, engine, learn */}
        <div className="min-w-0 space-y-3 xl:order-3">
          <div className={`${tab === 'moves' ? 'block' : 'hidden'} space-y-3 xl:block short:block`}>
            <DatabasePanel
              state={{ loading: !index && !loadError, error: loadError }} stats={stats} opening={entry ? { eco: entry.eco, name: entry.name } : null}
              onPlay={(san: string) => play({ san })} selectedSan={selectedSan}
            />
            <EnginePanel e={engineView} onPlay={(uci) => play({ uci })} />
          </div>
          <div className={`${tab === 'learn' ? 'block' : 'hidden'} xl:block short:block`}>
            <LearnPanel entry={entry} plyOfEntry={named?.ply ?? 0} cursor={line.cursor} info={info} curated={curated} insights={insights}
              lineLabel={entry ? `ply ${named?.ply ?? 0}` : ''} />
          </div>
        </div>
      </div>
    </div>
  )
}
