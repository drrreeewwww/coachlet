import { useCallback, useEffect, useState } from 'react'

const KEY = 'coachlet:explorer:v1'
export interface ExplorerPrefs {
  flipped: boolean
  speedMs: 1000 | 1500 | 2000
}
const DEFAULT: ExplorerPrefs = { flipped: false, speedMs: 1500 }

function read(): ExplorerPrefs {
  if (typeof window === 'undefined') return DEFAULT
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) {
      // Older versions stored Lichess token/source here; only the keys below are used.
      const old = JSON.parse(raw) as Partial<ExplorerPrefs>
      return {
        flipped: typeof old.flipped === 'boolean' ? old.flipped : DEFAULT.flipped,
        speedMs: old.speedMs === 1000 || old.speedMs === 2000 ? old.speedMs : DEFAULT.speedMs,
      }
    }
  } catch {
    /* defaults */
  }
  return DEFAULT
}

export function useExplorerPrefs(): [ExplorerPrefs, (p: Partial<ExplorerPrefs>) => void] {
  const [p, setP] = useState<ExplorerPrefs>(DEFAULT)
  useEffect(() => setP(read()), [])
  const update = useCallback((patch: Partial<ExplorerPrefs>) => {
    setP((prev) => {
      const n = { ...prev, ...patch }
      try {
        localStorage.setItem(KEY, JSON.stringify(n))
      } catch {
        /* storage unavailable */
      }
      return n
    })
  }, [])
  return [p, update]
}
