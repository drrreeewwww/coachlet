/**
 * Coachlet's own opening database — the "Most played" statistics source.
 *
 * Source of truth: the local catalogue (lichess-org/chess-openings, CC0; 3,865 named
 * openings with ECO codes, names and SAN lines). No network calls, no tokens, nothing
 * invented: every count here is the number of real catalogue lines that reach a position
 * or continue with a move, computed once by replaying the whole catalogue with chess.js.
 */
import { Chess, type Move } from 'chess.js'
import { epdOf, loadCatalogue, type Catalogue } from './catalogue'
import { START_FEN } from './lineState'

export interface LocalMoveStat {
  san: string
  uci: string
  /** How many catalogue lines play this move from the position. */
  lines: number
}

export interface LocalPositionStats {
  epd: string
  /** Catalogue lines that reach this position. */
  total: number
  /** Continuations found in the catalogue, most common first. */
  moves: LocalMoveStat[]
}

export interface LocalExplorerIndex {
  /** Catalogue lines reaching each position (position-identity = first 4 FEN fields). */
  linesByEpd: Map<string, number>
  /** Continuations from each position, keyed by SAN. */
  movesByEpd: Map<string, Map<string, LocalMoveStat>>
}

const startEpd = epdOf(START_FEN)

/** Replays every catalogue line and counts, for each position, each continuation move. */
export function buildLocalIndex(cat: Catalogue): LocalExplorerIndex {
  const linesByEpd = new Map<string, number>()
  const movesByEpd = new Map<string, Map<string, LocalMoveStat>>()
  const bump = (epd: string) => linesByEpd.set(epd, (linesByEpd.get(epd) ?? 0) + 1)

  for (const entry of cat.entries) {
    const board = new Chess()
    bump(startEpd)
    for (let i = 0; i < entry.sans.length; i++) {
      const fromEpd = epdOf(board.fen())
      const mv = tryMove(board, entry.sans[i])
      if (!mv) break // defensive: the catalogue is generated and legal, but never trust input blindly
      const toEpd = epdOf(board.fen())
      bump(toEpd)
      let moves = movesByEpd.get(fromEpd)
      if (!moves) movesByEpd.set(fromEpd, (moves = new Map()))
      const stat = moves.get(mv.san)
      if (stat) stat.lines += 1
      else moves.set(mv.san, { san: mv.san, uci: `${mv.from}${mv.to}${mv.promotion ?? ''}`, lines: 1 })
    }
  }
  return { linesByEpd, movesByEpd }
}

/** chess.js throws on illegal SAN; the index builder just skips such a line. */
function tryMove(board: Chess, san: string): Move | null {
  try {
    return board.move(san)
  } catch {
    return null
  }
}

/** Statistics for one position from the built index. Cheap: pure map lookups. */
export function statsForPosition(index: LocalExplorerIndex, fen: string): LocalPositionStats {
  const epd = epdOf(fen)
  const moves = [...(index.movesByEpd.get(epd)?.values() ?? [])].sort(
    (a, b) => b.lines - a.lines || a.san.localeCompare(b.san),
  )
  const total = index.linesByEpd.get(epd) ?? 0
  return { epd, total, moves }
}

/** Share of the position's catalogue lines in which this move was chosen (0..100). */
export function moveShare(m: LocalMoveStat, pos: Pick<LocalPositionStats, 'total'>): number {
  return pos.total > 0 ? (m.lines / pos.total) * 100 : 0
}

let memo: Promise<LocalExplorerIndex> | null = null
/** Builds (once) and caches the local index. The UI shows a loading state meanwhile. */
export function loadLocalIndex(): Promise<LocalExplorerIndex> {
  if (!memo) memo = loadCatalogue().then(buildLocalIndex)
  return memo
}

export function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M`
  if (n >= 10_000) return `${Math.round(n / 1000)}k`
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`
  return String(n)
}
