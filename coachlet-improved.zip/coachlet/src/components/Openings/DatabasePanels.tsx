'use client'

import { Loader2 } from 'lucide-react'
import type { Analysis } from '@/lib/stockfish/engine'
import { formatScore } from '@/lib/evaluation/classify'
import { formatCount, moveShare, type LocalMoveStat, type LocalPositionStats } from '@/lib/openings/localExplorer'

export interface DbState {
  /** True while the catalogue/index is being built. */
  loading: boolean
  /** Catalogue load failure — shown instead of any statistics. */
  error: string | null
}

interface DbProps {
  state: DbState
  /** Statistics for the current board position (null while loading). */
  stats: LocalPositionStats | null
  /** The named opening for the current position, from the catalogue (null at start / off-book). */
  opening?: { eco: string; name: string } | null
  onPlay: (san: string) => void
  /** SAN of the move about to be played from the current position (highlights the row). */
  selectedSan: string | null
}

const pct = (n: number) => (n >= 10 ? n.toFixed(0) : n.toFixed(1))

export function DatabasePanel(p: DbProps) {
  const ranked = p.stats?.moves ?? []

  return (
    <section className="rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg" aria-label="Opening database statistics">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-sm font-extrabold text-white">
          Most played <span className="font-normal text-stone-400">· Coachlet database</span>
        </h2>
      </div>

      <div className="mt-2 min-h-[3rem]" aria-live="polite">
        {p.state.loading && (
          <p className="flex items-center gap-2 text-xs text-stone-400">
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Loading the opening database…
          </p>
        )}
        {p.state.error && <p className="text-xs text-red-300">{p.state.error}</p>}
        {!p.state.loading && !p.state.error && p.stats && (
          <p className="text-[11px] text-stone-400">
            {p.stats.total > 0
              ? `${formatCount(p.stats.total)} named line${p.stats.total === 1 ? '' : 's'} reach this position`
              : 'No named opening lines reach this position'}
            {p.opening ? ` · book: ${p.opening.eco} ${p.opening.name}` : ''}
          </p>
        )}
      </div>

      {!p.state.loading && !p.state.error && p.stats && ranked.length > 0 && (
        <div className="mt-1 overflow-x-auto">
          <table className="w-full min-w-[300px] text-xs">
            <caption className="sr-only">Moves played in this position, most common in the database first</caption>
            <thead>
              <tr className="text-left text-[10px] uppercase tracking-wide text-stone-500">
                <th className="py-1 pr-2 font-semibold">#</th>
                <th className="py-1 pr-2 font-semibold">Move</th>
                <th className="py-1 font-semibold">Share of database lines</th>
              </tr>
            </thead>
            <tbody>
              {ranked.map((m, i) => (
                <MoveRow key={m.uci} m={m} i={i} stats={p.stats!} onPlay={p.onPlay} selected={p.selectedSan === m.san} />
              ))}
            </tbody>
          </table>
          <p className="mt-1 text-[10px] text-stone-500">
            Counts are named opening lines in Coachlet&apos;s database (lichess-org/chess-openings, CC0) — not game counts, and nothing is
            invented. Popularity ≠ strength: compare with the engine below.
          </p>
        </div>
      )}
      {!p.state.loading && !p.state.error && p.stats && ranked.length === 0 && (
        <p className="mt-1 text-xs text-stone-300">
          The database has no continuations for this position. You have left the known book; the board and engine still work.
        </p>
      )}
    </section>
  )
}

function MoveRow({
  m,
  i,
  stats,
  onPlay,
  selected,
}: {
  m: LocalMoveStat
  i: number
  stats: LocalPositionStats
  onPlay: (san: string) => void
  selected: boolean
}) {
  const share = moveShare(m, stats)
  return (
    <tr className={`border-t border-[#33312d] ${selected ? 'bg-[#81b64c]/10' : ''}`}>
      <td className="py-1 pr-2 text-stone-500">{i + 1}</td>
      <td className="py-0.5 pr-2">
        <button
          type="button"
          onClick={() => onPlay(m.san)}
          className="min-h-10 rounded px-2 font-mono text-sm font-bold text-white hover:bg-[#33312d]"
          aria-label={`Play ${m.san}, played in ${pct(share)} percent of database lines`}
        >
          {m.san}
        </button>
      </td>
      <td className="py-1 pr-2">
        <div className="font-semibold text-stone-100">{pct(share)}%</div>
        <div className="text-[10px] text-stone-500">{formatCount(m.lines)} {m.lines === 1 ? 'line' : 'lines'}</div>
        <div className="mt-0.5 h-1 w-full overflow-hidden rounded bg-[#33312d]">
          <div className="h-full bg-[#81b64c]" style={{ width: `${Math.max(2, share)}%` }} />
        </div>
      </td>
    </tr>
  )
}

export interface EngineView {
  status: 'starting' | 'ready' | 'fallback'
  busy: boolean
  analysis: Analysis | null
  paused: boolean
}

export function EnginePanel({ e, onPlay }: { e: EngineView; onPlay: (uci: string) => void }) {
  return (
    <section className="rounded-lg border border-[#3a3834] bg-[#262522] p-3 shadow-lg" aria-label="Engine analysis">
      <div className="flex items-center justify-between gap-2">
        <h2 className="text-sm font-extrabold text-white">
          Best by engine <span className="font-normal text-stone-400">· Stockfish 19</span>
        </h2>
        {e.busy && <Loader2 className="h-4 w-4 animate-spin text-[#81b64c]" aria-label="Analysing" />}
      </div>
      <div aria-live="polite" className="mt-1.5">
        {e.status === 'fallback' && (
          <p className="text-xs text-red-300">
            Stockfish could not start in this browser, so no engine analysis is available. The database and board still work.
          </p>
        )}
        {e.status === 'starting' && <p className="text-xs text-stone-400">Starting Stockfish…</p>}
        {e.status === 'ready' && e.paused && !e.analysis && <p className="text-xs text-stone-400">Analysis resumes when playback stops.</p>}
        {e.status === 'ready' && !e.analysis && !e.paused && <p className="text-xs text-stone-400">Analysing…</p>}
        {e.analysis && e.analysis.variations.length === 0 && <p className="text-xs text-stone-400">No legal moves in this position.</p>}
        {e.analysis && e.analysis.variations.length > 0 && (
          <ul className="space-y-1">
            {e.analysis.variations.map((v, i) => (
              <li key={v.firstMove.uci}>
                <button
                  type="button"
                  onClick={() => onPlay(v.firstMove.uci)}
                  className="flex min-h-11 w-full items-center gap-2 rounded-md px-2 py-1 text-left hover:bg-[#302e2b]"
                  aria-label={`Play engine move ${v.firstMove.san}, evaluation ${formatScore(v.score)}`}
                >
                  <span
                    className={`w-14 shrink-0 rounded px-1.5 py-0.5 text-center font-mono text-[11px] font-bold ${
                      i === 0 ? 'bg-[#81b64c] text-[#1c1b19]' : 'bg-[#33312d] text-stone-200'
                    }`}
                  >
                    {formatScore(v.score)}
                  </span>
                  <span className="font-mono text-sm font-bold text-white">{v.firstMove.san}</span>
                  <span className="min-w-0 flex-1 truncate font-mono text-[11px] text-stone-500">{v.sanMoves.slice(1, 6).join(' ')}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
        {e.analysis && e.analysis.depth > 0 && (
          <p className="mt-1 text-[10px] text-stone-500">
            Depth {e.analysis.depth}, evaluation from White&apos;s point of view. Engine output, not database statistics.
          </p>
        )}
      </div>
    </section>
  )
}
