'use client'

import { useId } from 'react'
import { CLASS_META, type MoveClass } from '@/lib/evaluation/classify'

/**
 * Chess.com-style circular move-classification badge.
 *
 * A solid disc in the classification's colour with the classification glyph knocked out
 * in the app's dark ink, plus a subtle top gloss — instantly recognisable at 12-20 px.
 * Brilliant gets its sparkle rays; Great gets the lone blue "!"; Blunder the red "??".
 * The classification logic itself is untouched — this is presentation only.
 */
export default function ClassBadge({
  cls,
  size = 16,
  title,
  className = '',
}: {
  cls: MoveClass
  /** Rendered width/height in px. */
  size?: number
  /** Override the default tooltip/aria text (defaults to the classification label). */
  title?: string
  className?: string
}) {
  const meta = CLASS_META[cls]
  const gradId = useId().replace(/[:]/g, '')
  const glyph = meta.icon
  // Wider glyphs need a smaller font size to stay inside the disc.
  const fontSize = glyph.length >= 2 ? 11 : glyph === '★' ? 12 : 13
  const label = title ?? `${meta.label} move`
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      role="img"
      aria-label={label}
      className={`inline-block shrink-0 align-[-0.15em] ${className}`}
    >
      <title>{label}</title>
      <defs>
        <linearGradient id={`gloss-${gradId}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.35" />
          <stop offset="0.5" stopColor="#fff" stopOpacity="0.06" />
          <stop offset="1" stopColor="#000" stopOpacity="0.14" />
        </linearGradient>
      </defs>
      {cls === 'brilliant' && (
        <g fill={meta.color}>
          {/* Sparkle rays, like a small burst around the disc */}
          <circle cx="3.4" cy="4.6" r="1.7" />
          <circle cx="20.6" cy="4.6" r="1.7" />
          <circle cx="2.2" cy="19" r="1.2" />
          <circle cx="21.8" cy="19" r="1.2" />
        </g>
      )}
      <circle cx="12" cy="12" r={cls === 'brilliant' ? 8.6 : 10.4} fill={meta.color} />
      <circle cx="12" cy="12" r={cls === 'brilliant' ? 8.6 : 10.4} fill={`url(#gloss-${gradId})`} />
      <text
        x="12"
        y={cls === 'brilliant' ? 12.4 : 12.8}
        textAnchor="middle"
        dominantBaseline="central"
        fontSize={cls === 'brilliant' ? fontSize + 1 : fontSize}
        fontWeight={900}
        fill="#1c1b19"
        style={{ fontFamily: "'Segoe UI', system-ui, sans-serif", letterSpacing: '-0.5px' }}
      >
        {glyph}
      </text>
    </svg>
  )
}
